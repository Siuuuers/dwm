extends "res://addons/gut/test.gd"
## Connected Text Pause -> selected schema-5 Load. No fake positive native,
## restore, route, suspension, Profile or Run acknowledgement is supplied.
const FIXTURE := preload("res://tests/support/ScenePauseLoadFixture.gd")
var fixture: RefCounted
var fixture_ready := false
var prior_root := ""
var sequence := 0

func before_each() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	prior_root = OS.get_environment("DWM_TEST_ROOT")
	sequence += 1
	if prior_root.is_empty():
		assert_false(prior_root.is_empty(), "cloud wrapper must isolate test storage")
		return
	OS.set_environment("DWM_TEST_ROOT", prior_root.path_join("scene_pause_%d" % sequence))
	fixture = FIXTURE.new()
	var checked: Dictionary = await fixture.setup_pause(get_tree())
	fixture_ready = checked.get("ok", false)
	assert_true(fixture_ready, str(checked))

func after_each() -> void:
	if fixture != null: await fixture.close_restart()
	fixture = null
	fixture_ready = false
	OS.set_environment("DWM_TEST_ROOT", prior_root)

func _ok(result: Dictionary) -> bool:
	assert_true(result.get("ok", false), str(result))
	return result.get("ok", false)

func test_real_text_pause_load_finishes_async_activation_once_and_releases_custody() -> void:
	await _happy_load(false)

func test_real_text_quick_load_retains_pending_identity_and_rejects_old_pause_completion() -> void:
	await _happy_load(true)

func _happy_load(quick: bool) -> void:
	if not fixture_ready or not _ok(await fixture.start_text()): return
	if quick and not _ok(fixture.manager.quick_save_latest()): return
	var source: Dictionary = fixture.game.capture_run_snapshot_input().duplicate(true)
	var profile_before: Dictionary = fixture.profile_bytes()
	var selected: Dictionary = fixture.manager.get_latest_stable_checkpoint()
	if not _ok(selected): return
	var checkpoint: Dictionary = selected.value.bundle.snapshot.narrative_checkpoint.duplicate(true)
	assert_eq(checkpoint.reading_session.schema_version, 5)
	assert_eq(checkpoint.reading_session.boundary, "line")
	if not _ok(await fixture.pause.request_pause()): return
	assert_true(get_tree().paused)
	assert_eq(fixture.pause.coordinator.get_state().value.state, &"Suspended")
	assert_eq(fixture.input_owner.get_state().value.state, &"Suspended")
	assert_eq(fixture.audio_owner.get_state().value.state, &"Suspended")
	var old_handle: Dictionary = fixture.pause._handle.duplicate(true)
	var prepared: Dictionary = fixture.pause._backup_port.prepare_quick_action("load") if quick \
		else fixture.pause._backup_port.prepare_action("load", "slot:1")
	if not _ok(prepared): return
	var token: String = prepared.value.token
	fixture.ready_count = 0
	var routes: int = fixture.route_confirmations.size()
	var narratives: int = fixture.narrative_confirmations.size()
	fixture.call_deferred("observe_pending_load")
	var committed: Dictionary = await fixture.pause._backup_port.commit_action(token)
	if not _ok(committed): return
	if not _ok(await fixture.settle_load()): return
	assert_eq(fixture.ready_count, 1, "one real destination readiness publication")
	assert_eq(fixture.route_confirmations.size(), routes + 1)
	assert_eq(fixture.narrative_confirmations.size(), narratives + 1)
	assert_eq(fixture.pause_closed_count, 1)
	assert_false(fixture.pending_observation.is_empty(), "real asynchronous activation retains operation identity")
	if not fixture.pending_observation.is_empty():
		assert_true(fixture.pending_observation.tree_paused)
		assert_eq(fixture.pending_observation.input_state, &"Suspended")
		assert_eq(fixture.pending_observation.ready_count, 0)
		assert_eq(fixture.pending_observation.closed_count, 0)
		assert_false(fixture.pending_observation.foreign_retry.get("ok", false))
	assert_false(get_tree().paused)
	assert_eq(fixture.pause.coordinator.get_state().value.state, &"Active")
	assert_eq(fixture.input_owner.get_state().value.state, &"Active")
	assert_eq(fixture.audio_owner.get_state().value.state, &"Active")
	assert_eq(fixture.bridge.get_state().value.state, &"Active")
	assert_false(fixture.router.is_restore_publication_held())
	assert_false(fixture.pause._loading)
	assert_false(fixture.pause.surface.visible)
	var destination: Dictionary = fixture.game.capture_run_snapshot_input()
	assert_ne(destination.lifecycle.branch_id, source.lifecycle.branch_id)
	assert_eq(fixture.bridge._reading_session.boundary, "line")
	var restored_checkpoint: Dictionary = fixture.bridge.capture_reading_checkpoint(false)
	if not _ok(restored_checkpoint): return
	assert_eq(restored_checkpoint.value.reading_session.entry_id, checkpoint.reading_session.entry_id)
	assert_eq(restored_checkpoint.value.reading_session.program_index, checkpoint.reading_session.program_index)
	assert_eq(fixture.profile_bytes(), profile_before, "Load and publication never repeat Profile consequences")
	assert_eq(fixture.native_markers, [], "no source challenge marker is replayed")
	assert_eq(fixture.challenge_record(), {})
	assert_eq(destination.command_receipts, source.command_receipts, "selected Load does not replay scene effects")
	var after: Dictionary = destination.duplicate(true)
	var duplicate: Dictionary = await fixture.pause._backup_port.commit_action(token)
	assert_false(duplicate.get("ok", false), "consumed consent cannot Load twice")
	for frame: int in 8: await get_tree().process_frame
	assert_eq(fixture.ready_count, 1)
	assert_eq(fixture.pause_closed_count, 1)
	assert_eq(fixture.game.capture_run_snapshot_input(), after)
	assert_eq(fixture.profile_bytes(), profile_before)
	if not quick: return
	# A completed old handle must never retire a newly suspended real native source,
	# including when the caller legitimately owns a later restore lease.
	if not _ok(await fixture.pause.request_pause()): return
	var newer_handle: Dictionary = fixture.pause._handle.duplicate(true)
	assert_ne(newer_handle, old_handle)
	var frontier: Dictionary = fixture.bridge.capture_pause_frontier()
	if not _ok(frontier): return
	var lease: Dictionary = fixture.gate.acquire(&"restore")
	if not _ok(lease): return
	var stale: Dictionary = await fixture.bridge.complete_pause_restore(old_handle)
	fixture.gate.release(&"restore", lease.value.token)
	assert_false(stale.get("ok", false), "old completion cannot consume a new native pause")
	assert_eq(fixture.pause._handle, newer_handle)
	assert_eq(fixture.bridge.capture_pause_frontier(), frontier)
	assert_eq(fixture.pause.coordinator.get_state().value.state, &"Suspended")
	assert_true(get_tree().paused)
	if not _ok(await fixture.pause.request_continue()): return
	assert_false(get_tree().paused)
	assert_eq(fixture.game.capture_run_snapshot_input(), after)
	assert_eq(fixture.profile_bytes(), profile_before)

func test_real_precommit_write_refusal_preserves_paused_text_and_continue() -> void:
	if not fixture_ready or not _ok(await fixture.start_text()): return
	if not _ok(await fixture.pause.request_pause()): return
	var source: Dictionary = fixture.game.capture_run_snapshot_input().duplicate(true)
	var session: Dictionary = fixture.game.capture_live_session().value.duplicate(true)
	var profile_before: Dictionary = fixture.profile_bytes()
	var frontier: Dictionary = fixture.bridge.capture_pause_frontier()
	if not _ok(frontier): return
	var handle: Dictionary = fixture.pause._handle.duplicate(true)
	var prepared: Dictionary = fixture.pause._backup_port.prepare_action("load", "slot:1")
	if not _ok(prepared): return
	fixture.ready_count = 0
	fixture.write_fault.armed = true
	var refused: Dictionary = await fixture.pause._backup_port.commit_action(prepared.value.token)
	assert_false(refused.get("ok", false), str(refused))
	assert_eq(fixture.write_fault.refusal_count, 1, fixture.write_fault.refused_path)
	assert_false(refused.get("committed", false), "failure precedes destination ownership")
	assert_true(get_tree().paused)
	assert_eq(fixture.pause.coordinator.get_state().value.state, &"Suspended")
	assert_eq(fixture.pause._handle, handle)
	assert_false(fixture.pause._loading)
	assert_eq(fixture.ready_count, 0)
	assert_eq(fixture.pause_closed_count, 0)
	assert_eq(fixture.game.capture_live_session().value, session)
	assert_eq(fixture.game.capture_run_snapshot_input(), source)
	assert_eq(fixture.profile_bytes(), profile_before)
	assert_eq(fixture.bridge.capture_pause_frontier(), frontier)
	assert_eq(fixture.input_owner.get_state().value.state, &"Suspended")
	assert_eq(fixture.audio_owner.get_state().value.state, &"Suspended")
	assert_false(fixture.router.is_restore_publication_held())
	if not _ok(await fixture.pause.request_continue()): return
	assert_false(get_tree().paused)
	assert_eq(fixture.pause_closed_count, 1)
	assert_eq(fixture.input_owner.get_state().value.state, &"Active")
	assert_eq(fixture.audio_owner.get_state().value.state, &"Active")
	assert_eq(fixture.bridge.get_state().value.state, &"Active")
	assert_eq(fixture.game.capture_run_snapshot_input(), source)
	assert_eq(fixture.profile_bytes(), profile_before)
	assert_eq(fixture.native_markers, [])

extends "res://tests/integration/test_scene_clock_layout.gd"
## Narrow reproducer: no Save/Pause between direct Day7 and final Accept.

func _trace_ending(label: String) -> void:
	var layer: Node = _caption()
	var runtime: Node = bridge._runtime_adapter._dialogic
	var inputs: Node = runtime.get_subsystem("Inputs")
	var state := {"label": label, "route": get_tree().current_scene.scene_file_path,
		"input_blocked": inputs.is_input_blocked(), "input_block_left": inputs.input_block_timer.time_left,
		"paused": runtime.paused, "lifecycle": game._run_lifecycle.to_dict(),
		"ending_binding": bridge._ending_reading, "active_entry": bridge._active_entry}
	if is_instance_valid(layer):
		state["layer"] = {"session": layer._ending_caption_session, "handoff": layer._ending_caption_handoff,
			"waiting_text": layer._line_waiting_for_text, "admitted": layer.accept_input.is_source_admitted(),
			"neutral_wait": layer.accept_input._await_initial_neutral, "contacts": layer.accept_input._contacts,
			"accepted_frame": layer.accept_input._accepted_frame, "presented": layer._presented_line}
	if get_tree().current_scene is EndingScene:
		state["failure"] = get_tree().current_scene._last_playback_failure
	print("DIRECT_ENDING_TRACE ", JSON.stringify(state))

func test_direct_ending_accept_returns_without_save() -> void:
	await test_clock_and_upper_transport_on_title_ordinary_and_ending()
	if not get_tree().current_scene is EndingScene: return
	_trace_ending("before_accept")
	await _accept()
	_trace_ending("after_accept")
	if not await _wait_route(MENU):
		_trace_ending("route_timeout")
		return
	assert_eq(game._run_lifecycle.to_dict().state, "COMPLETED")
	assert_false(FileAccess.file_exists("user://saves/slot_2.json"), "Save is not a prerequisite")

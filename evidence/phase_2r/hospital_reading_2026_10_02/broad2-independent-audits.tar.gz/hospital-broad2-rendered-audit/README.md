# Broad2 rendered-evidence audit

## Verdict

**PASS with zero failures** for the bounded rendered scope. Evidence is bound to successful run `37048318182`, source `a24f71766a624b57601814dda487b53c66518c39`, and checkout `c9c013397f2e309b48fc1548490b401e54938c6c`.

The rendered journeys, desktop/dialogue, and Hospital reading jobs completed successfully with all required evidence steps. Hospital image semantics remain outside this report; that job is used here only for its speech capability receipt.

| Evidence set | Expected and actual PNGs | Result |
|---|---:|---|
| Desktop scaling | 38 | `ok=true`, no failures, X11 |
| Delivery/dialogue | 25 | `ok=true`, no failures, X11 |
| Angela overlay | 10 | `ok=true`, no failures, X11 |
| Japanese/Korean UI | 30 | `ok=true`, no failures, X11 |
| Font choices | 30 | `ok=true`, no failures, X11 |
| Startup/Logout | 4 exact names | all PASS markers and terminal receipt |
| Five cloud journeys | 27 | exact case/process/marker/hash/dimension binding |

All **164** PNGs were structurally parsed with positive dimensions. Primary marker JSON equals each retained report. Import, render, journey, user-dir, stdout, and stderr evidence is strict-clean. The five journey cases have distinct, strictly contained profiles; zero-exit/non-timeout receipts; exact marker and fixture scopes; and per-image byte/hash/dimension agreement.

Both UI literal reports contain records and no failures. The source9 catalogue validator reproduces the Japanese and Korean 303-message receipts. All three rendered jobs retain the expected speech modules, null sink, empty enumeration stderr, successful `espeak-ng` startup, 13,151 parsed language-bearing voice rows, and matching console receipts.

## Representative visual review

Fourteen representative frames span every render family and all five journeys.

- **11 changed Broad2 images were opened fresh at original detail**, including Japanese large/contrast launcher and Settings, both Angela states, pixel/readable Japanese boards, Logout and Dating consent, Gallery, condition-ending board, and legacy Practice.
- **3 images exactly match previously reviewed Broad1 bytes**: Korean 150% challenge rules, Traditional Chinese older dialogue, and the empty-Practice picker. Both hashes are recorded in `audit.json`.

No obvious tofu, clipping, unintended overlap, missing control, or unreachable inspected scroll endpoint was visible. Expected wrapping and disabled-control styling were present.

## Limits

- Manual inspection is representative, not exhaustive acceptance of all 164 PNGs.
- Software-display evidence does not prove native accessibility, hardware/OS rendering, or Windows behavior.
- Speech receipts establish service/module startup and enumeration, not audible playback or native assistive-technology integration.
- Synthetic fixture records/boards/dialogue do not establish full gameplay acceptance.
- Hospital PNG semantics and original reading/selector evidence are separate audits.

Machine-readable detail: `audit.json`.

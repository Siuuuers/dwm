# Broad2 normalization evidence audit

## Verdict

**PASS with zero failures** for the outgoing- and lazy-normalization components of successful run `37048318182`. Evidence is bound to source `a24f71766a624b57601814dda487b53c66518c39` and checkout `c9c013397f2e309b48fc1548490b401e54938c6c`.

Both exact jobs completed successfully. Checkout output, steps, source9 blobs, transferred manifests and actual payloads, raw receipts, unique contained roots, strict logs, engine markers, samples, medians, pair deltas, summaries, and structured console receipts agree.

## Payload provenance

- Fresh Broad2 Day7: 1,910,332 bytes, SHA-256 `0ac0f5afcaaafe72fa1dd70211ee1ee93d9c230c9a80d08b57154f7f16f34c8a`, 66 bundles, producer attempt 1.
- Its producer report binds seven days, 98 synthetic checkpoints, final 32 line + 32 manual-save + 2 semantic records, and cold-read retention 66.
- Both localized schema-7 inputs are same-run/head baseline-producer payloads with two bundles and exact manifest/file hashes.

No Broad1 payload hash is treated as Broad2 evidence: the Day7 identity is derived from and checked against the fresh Broad2 manifest and bytes.

## Outgoing normalization

Exactly six isolated probes—baseline/candidate × zh-CN/zh-HK/Day7—exit zero with one matching engine marker each. Input/output bytes are unchanged, schema versions are 7, bundle validation is 2/2 or 66/66, and each five-sample median recomputes exactly after two warmups.

| Payload | Baseline median µs | Candidate median µs | Candidate − baseline µs |
|---|---:|---:|---:|
| zh-CN | 20,767 | 15,836 | −4,931 |
| zh-HK | 16,283 | 12,143 | −4,140 |
| Day7 | 168,493 | 88,165 | −80,328 |

Both variants use the current port and strict schema; only complete-document versus proven-journal normalization differs. No threshold is asserted.

## Lazy normalization

Eight alternating pairs produce sixteen fresh isolated probes. Odd pairs run baseline→candidate and even pairs candidate→baseline. Every process preserves the exact fresh Day7 hash/length, 66 bundles, schema 7, identity/source invariants, and reference provenance. All metrics have two warmups, five nonnegative samples, and exact recomputed medians.

| Mode | Metric | Baseline median µs | Candidate median µs | Median paired delta µs |
|---|---|---:|---:|---:|
| full | schema helper | 82,161.0 | 73,185.5 | −9,352.0 |
| full | port helper | 83,246.0 | 73,165.5 | −10,080.5 |
| full | port seam | 164,221.0 | 152,782.0 | −11,694.5 |
| splice | schema helper | 2,243.5 | 1,950.0 | −308.5 |
| splice | port helper | 1,912.0 | 1,714.0 | −198.0 |
| splice | port seam | 82,802.0 | 81,193.0 | −1,609.0 |

One splice `port_seam` pair has a positive candidate delta of `+2,052 µs`; the valid claim is the paired evidence and aggregate median, not that every candidate observation is faster.

## Limits

- Timings are observational on one shared Windows runner; OS caches were not flushed and no threshold applies.
- Direct helper and seam timers are inclusive and must not be summed.
- Outgoing evidence is a strict-validation seam, not gameplay proof-cache completeness.
- Lazy evidence is not a matched schema-build, full checkpoint, physical save, gameplay, real-disk, or input-to-paint comparison.

Machine-readable detail: `audit.json`.

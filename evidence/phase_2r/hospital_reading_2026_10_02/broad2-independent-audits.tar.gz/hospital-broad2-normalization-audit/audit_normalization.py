#!/usr/bin/env python3
"""Offline source-bound audit of the two successful normalization jobs."""
from __future__ import annotations
import hashlib, json, pathlib, re, statistics, subprocess, sys

BASE = pathlib.Path(__file__).resolve().parent.parent
ART = BASE / "hospital-broad2" / "artifacts"
LOGS = BASE / "hospital-broad2" / "logs"
SRC = BASE / "dwm"
OUT = pathlib.Path(__file__).resolve().parent
RUN = 37048318182
RUN_S = str(RUN)
HEAD = "c9c013397f2e309b48fc1548490b401e54938c6c"
SOURCE_COMMIT = "a24f71766a624b57601814dda487b53c66518c39"
STRICT = re.compile(r"SCRIPT ERROR:|(?:^|\s)ERROR:|Unicode parsing error|Unexpected NUL character|Parse Error:|\b(?:OUTGOING|LAZY)_NORMALIZATION_FAIL:", re.M)
LIFETIME = ("Resource still in use", "Leaked instance", "Orphan StringName")
failures=[]

def check(v,msg):
    if not v: failures.append(msg)
def hook(pairs):
    d={}
    for k,v in pairs:
        if k in d: raise ValueError("duplicate key "+k)
        d[k]=v
    return d
def load(p):
    try: return json.loads(p.read_text(encoding="utf-8-sig"), object_pairs_hook=hook)
    except Exception as e: failures.append(f"strict JSON parse failed {p.relative_to(BASE)}: {e}"); return {}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def clean(p):
    t=p.read_text(encoding="utf-8",errors="replace")
    check(not STRICT.search(t),f"strict diagnostic in {p.relative_to(BASE)}")
    for x in LIFETIME: check(x not in t,f"lifetime diagnostic {x!r} in {p.relative_to(BASE)}")
def output_count(text,exact):
    return len(re.findall(r"(?m)^\d{4}-\d\d-\d\dT[^ ]+Z "+re.escape(exact)+r"\r?$",text))
def console_json(text,prefix):
    rows=[]
    pattern=re.compile(r"(?m)^\d{4}-\d\d-\d\dT[^ ]+Z "+re.escape(prefix)+r"([^\r\n]+)\r?$")
    for m in pattern.finditer(text): rows.append(json.loads(m.group(1),object_pairs_hook=hook))
    return rows
def marker_json(path,prefix):
    rows=[]
    for line in path.read_text(encoding="utf-8",errors="replace").splitlines():
        if line.startswith(prefix): rows.append(json.loads(line[len(prefix):],object_pairs_hook=hook))
    return rows

run=load(BASE/"hospital-broad2/run.json")
subprocess.check_call(["git","-C",str(SRC),"cat-file","-e",SOURCE_COMMIT+"^{commit}"],stdout=subprocess.DEVNULL)
check(run.get("id")==RUN and run.get("head_sha")==HEAD and run.get("run_attempt")==1,"run identity mismatch")
check(run.get("status")=="completed" and run.get("conclusion") in ("success","failure"),"whole-run status is not terminal")
jobs_doc=load(BASE/"hospital-broad2/jobs.json")
jobs=jobs_doc.get("jobs",[])
job_specs={
 "Windows / outgoing-normalization comparison":True,
 "Windows / lazy-normalization comparison":False,
}
job_out={}
job_ids={}
for name,requires_localized in job_specs.items():
    matches=[job for job in jobs if job.get("name")==name]
    check(len(matches)==1,f"expected one job named {name}, found {len(matches)}")
    j=matches[0] if matches else {}
    jid=j.get("id"); job_ids[name]=jid
    check(j.get("name")==name and j.get("run_id")==RUN and j.get("head_sha")==HEAD,f"job identity mismatch {jid}")
    check((j.get("status"),j.get("conclusion"))==("completed","success"),f"job not successful {jid}")
    steps={s["name"]:s for s in j.get("steps",[])}
    for step in ["Run actions/checkout@v7","Download exact Day7 producer inputs","Verify Day7 checkout, run, attempt, hashes and recovered identity","Run isolated retained-history comparison","Upload comparison raw evidence and input provenance"]:
        s=steps.get(step,{})
        check((s.get("status"),s.get("conclusion"))==("completed","success"),f"job {jid} step unsuccessful: {step}")
    if requires_localized:
        s=steps.get("Download current localized payloads for outgoing comparison",{})
        check((s.get("status"),s.get("conclusion"))==("completed","success"),"outgoing localized payload download step unsuccessful")
    log=(LOGS/f"{jid}.log").read_text(encoding="utf-8",errors="replace")
    check(output_count(log,HEAD)>=1,f"job {jid} missing exact checkout output")
    job_out[str(jid)]={"name":name,"status":"completed/success","head":HEAD}

# Producer payload provenance, including actual transferred bytes.
day_dir=ART/f"seven-day-inputs-{RUN}"
day_manifest=load(day_dir/"consumer-input-manifest.json")
day_results=load(day_dir/"results.json")
day_file=day_dir/"day7-autosave.json"
day7_hash=day_manifest.get("files",{}).get("day7-autosave.json","")
check(day_manifest.get("schema_version")==1 and day_manifest.get("checkout_ref")==HEAD and day_manifest.get("producer_run_id")==RUN_S,"Day7 manifest identity mismatch")
check(1 <= day_manifest.get("producer_run_attempt",0) <= run.get("run_attempt",0),"Day7 producer attempt invalid")
check(set(day_manifest.get("files",{}))=={"results.json","day7-autosave.json"},"Day7 manifest file set mismatch")
check(day_manifest.get("files",{}).get("results.json")==sha(day_dir/"results.json"),"Day7 results hash mismatch")
check(re.fullmatch(r"[0-9a-f]{64}",day7_hash) is not None and sha(day_file)==day7_hash,"Day7 autosave hash mismatch")
check(day_results.get("checkout_ref")==HEAD and day_results.get("payload_sha256")==day7_hash,"Day7 results checkout/payload mismatch")
check(day_results.get("write",{}).get("retained")=={"line":32,"manual_save":32,"semantic":2},"Day7 producer retention mismatch")
check(day_results.get("write",{}).get("synthetic_checkpoints")==98,"Day7 synthetic checkpoint count mismatch")
check(day_results.get("cold_read",{}).get("retained_checkpoint_count")==66,"Day7 cold-read retention mismatch")

loc_dir=ART/f"checkpoint-payloads-{RUN}"
loc_manifest=load(loc_dir/"payload-manifest.json")
check(loc_manifest.get("checkout_ref")==HEAD and loc_manifest.get("producer_run_id")==RUN_S,"localized manifest identity mismatch")
check(1 <= loc_manifest.get("producer_run_attempt",0) <= run.get("run_attempt",0),"localized producer attempt invalid")
loc={x.get("locale"):x for x in loc_manifest.get("payloads",[])}
check(set(loc)=={"zh-CN","zh-HK"},"localized manifest locale set mismatch")
for locale,ending in (("zh-CN","win"),("zh-HK","loss")):
    x=loc.get(locale,{})
    p=loc_dir/f"fixed-{locale}-autosave.json"
    check(x.get("file")==p.name and x.get("sha256")==sha(p),f"localized {locale} actual hash mismatch")
    check(x.get("journal_bundles")==2 and x.get("schema_version")==7 and x.get("snapshot_schema_version")==7,f"localized {locale} schema/bundle mismatch")
    check(x.get("producer_variant")=="baseline" and x.get("dating_ending")==ending,f"localized {locale} producer/ending mismatch")

source_hashes={
 "scripts/application/run/SaveManagerCheckpointPort.gd":"ab8824ecb5617b48c5feb581133e4286facae70d42714add825fbea88e60272f",
 "scripts/infrastructure/save/SaveDocumentSchema.gd":"c7a18cea7a87699a1e69cef4ec2fc61f4ace858c9b45df5a6db622830e5e0540",
 "scripts/domain/run/RunSnapshotSchema.gd":"88c329ce56350c8cd09124222cc69ae2f0335731f6519d655c8c8a14beff9158",
 "tests/support/EagerNormalizationReference.gd":"f1bb63f480e09b72abeaa486047e7c2ac0a5d63b0396874ddb55d9bbf1b44cf8",
 "tests/manual/benchmark_lazy_normalization.gd":"44f7b26800252ca8af28c52b3f1b76e132c15ca4239a869faa514c5714d59a78",
 "tests/manual/benchmark_outgoing_normalization.gd":"5ba4bdd823335e872a84c93c5f71bfc0a716ef5c4cc32f24a1d1f50c2657128d",
 "tools/testing/Invoke-LazyNormalizationPerformance.ps1":"e733717d5347295abb8e8020d037aee1a3012fe8756ebd377fc379dae0753531",
 "tools/testing/Invoke-OutgoingNormalizationPerformance.ps1":"47f7b7cbb557161a1385930e9f9ac2b43a6da42051ca4dbb8988d86412535e38",
}
for rel,h in source_hashes.items():
    committed=subprocess.check_output(["git","-C",str(SRC),"show",SOURCE_COMMIT+":"+rel])
    check(hashlib.sha256(committed).hexdigest()==h,f"source committed hash mismatch {rel}")

def audit_receipt(ci_dir,log_dir,name,variant,mode=None):
    stem=f"{mode}-{name}" if mode else f"{variant}-{name}"
    receipt_path=ci_dir/(stem+".jsonl")
    rows=[json.loads(x,object_pairs_hook=hook) for x in receipt_path.read_text().splitlines() if x.strip()]
    check(len(rows)==1,f"{stem} receipt count mismatch")
    r=rows[0] if rows else {}
    suite=f"cloud-{'lazy' if mode else 'outgoing'}-normalization-{stem}"
    expected_log=suite+".log"
    check(r.get("suite_id")==suite and r.get("exit_code")==0,f"{stem} suite/exit mismatch")
    check(pathlib.PureWindowsPath(r.get("log_path","")).name==expected_log,f"{stem} log path mismatch")
    root=r.get("test_root","").rstrip("\\").lower(); user=r.get("user_dir","").lower()
    check(bool(root) and user.startswith(root+"\\"),f"{stem} user dir not contained")
    args=r.get("argv",[])
    check(f"--variant={variant}" in args and (not mode or f"--mode={mode}" in args),f"{stem} argv mismatch")
    log=log_dir/expected_log
    clean(log)
    prefix="LAZY_NORMALIZATION_BENCHMARK: " if mode else "OUTGOING_NORMALIZATION_BENCHMARK: "
    markers=marker_json(log,prefix)
    check(len(markers)==1,f"{stem} benchmark marker count mismatch")
    return r,(markers[0] if markers else {})

# Outgoing normalization: six exact payload probes.
out_root=ART/f"outgoing-normalization-{RUN}-1"
out_ci=out_root/"ci/outgoing-normalization"; out_logs=out_root/"phase2r_logs"
out_report=load(out_ci/"results.json")
check(out_report.get("checkout_ref")==HEAD,"outgoing report checkout mismatch")
check(out_report.get("localized_payload_manifest")==loc_manifest,"outgoing embedded localized manifest mismatch")
check((out_root/"ci/performance/payload-manifest.json").read_bytes()==(loc_dir/"payload-manifest.json").read_bytes(),"outgoing localized manifest copy differs")
check((out_root/"ci/seven-day-history/consumer-input-manifest.json").read_bytes()==(day_dir/"consumer-input-manifest.json").read_bytes(),"outgoing Day7 manifest copy differs")
expected_source={"checkpoint_port":source_hashes["scripts/application/run/SaveManagerCheckpointPort.gd"],"document_schema":source_hashes["scripts/infrastructure/save/SaveDocumentSchema.gd"],"run_schema":source_hashes["scripts/domain/run/RunSnapshotSchema.gd"]}
check(out_report.get("source_sha256")==expected_source,"outgoing source hashes mismatch")
measure={(x.get("variant"),x.get("label")):x.get("measurement") for x in out_report.get("measurements",[])}
check(len(out_report.get("measurements",[]))==6 and len(measure)==6,"outgoing measurement cardinality mismatch")
out_roots=set(); outgoing_summary={}
for variant in ("baseline","candidate"):
 for label in ("zh-CN","zh-HK","day7"):
    receipt,marker=audit_receipt(out_ci,out_logs,label,variant)
    out_roots.add(receipt.get("test_root"))
    m=measure.get((variant,label),{})
    check(marker==m,f"outgoing {variant}/{label} marker/report mismatch")
    expected_hash=day7_hash if label=="day7" else loc[label]["sha256"]
    expected_bytes=day_file.stat().st_size if label=="day7" else (loc_dir/f"fixed-{label}-autosave.json").stat().st_size
    bundles=66 if label=="day7" else 2
    samples=m.get("samples_us",[])
    check(m.get("variant")==variant and m.get("input_sha256")==m.get("output_sha256")==expected_hash,f"outgoing {variant}/{label} identity/hash mismatch")
    check(m.get("bytes")==expected_bytes and m.get("journal_bundles")==m.get("validated_journal_bundles")==bundles,f"outgoing {variant}/{label} bytes/bundles mismatch")
    check(m.get("schema_version")==7 and m.get("snapshot_schema_version")==7,f"outgoing {variant}/{label} schema mismatch")
    check(len(samples)==5 and all(isinstance(v,int) and v>=0 for v in samples) and statistics.median(samples)==m.get("median_us"),f"outgoing {variant}/{label} samples/median mismatch")
    outgoing_summary[f"{variant}/{label}"]={"median_us":m.get("median_us"),"samples_us":samples,"bytes":m.get("bytes"),"bundles":bundles}
check(len(out_roots)==6,"outgoing roots not unique")
clean(out_root/"ci/import.log")
out_console=(LOGS/f"{job_ids['Windows / outgoing-normalization comparison']}.log").read_text(encoding="utf-8",errors="replace")
check(output_count(out_console,"OUTGOING_NORMALIZATION_PERFORMANCE_VERIFIED: six exact-payload probes with unchanged validation and retention.")==1,"outgoing terminal receipt mismatch")
check(output_count(out_console,"DAY7_CONSUMER_INPUTS_VERIFIED: "+json.dumps(day_manifest,separators=(",",":")))==1,"outgoing Day7 receipt mismatch")
out_proofs=console_json(out_console,"OUTGOING_NORMALIZATION_PROOF: ")
expected_out_proof={"checkout_ref":out_report.get("checkout_ref"),"source_sha256":out_report.get("source_sha256"),"localized_payload_manifest":loc_manifest,"ablation":out_report.get("ablation")}
check(len(out_proofs)==1 and out_proofs[0]==expected_out_proof,"outgoing structured console proof/report mismatch")

# Lazy normalization: 8 alternating pairs / 16 isolated probes and six summaries.
lazy_root=ART/f"lazy-normalization-{RUN}-1"; lazy_ci=lazy_root/"ci/lazy-normalization"; lazy_logs=lazy_root/"phase2r_logs"
lazy=load(lazy_ci/"results.json")
check(lazy.get("checkout_ref")==HEAD and lazy.get("run_id")==RUN_S and lazy.get("input_sha256")==day7_hash,"lazy identity mismatch")
check(lazy.get("retained_checkpoint_count")==66,"lazy retained count mismatch")
check((lazy_root/"ci/seven-day-history/consumer-input-manifest.json").read_bytes()==(day_dir/"consumer-input-manifest.json").read_bytes(),"lazy Day7 manifest copy differs")
expected_lazy_source={"schema":source_hashes["scripts/infrastructure/save/SaveDocumentSchema.gd"],"port":source_hashes["scripts/application/run/SaveManagerCheckpointPort.gd"],"reference":source_hashes["tests/support/EagerNormalizationReference.gd"],"harness":source_hashes["tests/manual/benchmark_lazy_normalization.gd"]}
check(lazy.get("source_sha256")==expected_lazy_source,"lazy source hashes mismatch")
pairs=lazy.get("pairs",[]); check(len(pairs)==8,"lazy pair count mismatch")
metrics=("schema_helper","port_helper","port_seam")
lazy_roots=set(); pair_summary=[]
for mode in ("full","splice"):
 selected=[p for p in pairs if p.get("mode")==mode]
 check([p.get("pair") for p in selected]==[1,2,3,4],f"lazy {mode} pair numbers mismatch")
 for p in selected:
    n=p["pair"]; order=["baseline","candidate"] if n%2 else ["candidate","baseline"]
    check(p.get("order")==order,f"lazy {mode}/{n} order mismatch")
    for variant in order:
        receipt,marker=audit_receipt(lazy_ci,lazy_logs,str(n)+"-"+variant,variant,mode)
        lazy_roots.add(receipt.get("test_root")); m=p.get(variant,{})
        check(marker==m,f"lazy {mode}/{n}/{variant} marker/report mismatch")
        check(m.get("variant")==variant and m.get("mode")==mode,f"lazy {mode}/{n}/{variant} identity mismatch")
        check(m.get("input_sha256")==m.get("output_sha256")==day7_hash and m.get("bytes")==day_file.stat().st_size,f"lazy {mode}/{n}/{variant} payload mismatch")
        check(m.get("journal_bundles")==m.get("validated_journal_bundles")==66 and m.get("schema_version")==m.get("snapshot_schema_version")==7,f"lazy {mode}/{n}/{variant} bundle/schema mismatch")
        check(m.get("warmup_count")==2 and m.get("sample_count")==5,f"lazy {mode}/{n}/{variant} warmup/sample count mismatch")
        check(m.get("identity_preserved_unchanged") is True and m.get("identity_replaced_changed") is True and m.get("source_unchanged") is True,f"lazy {mode}/{n}/{variant} identity/source invariant mismatch")
        check(m.get("reference_commit")=="dae70bf9aa05b6b3debb60f95738e5ffc4e97548",f"lazy {mode}/{n}/{variant} reference commit mismatch")
        check(m.get("candidate_schema_source_sha256")==expected_lazy_source["schema"] and m.get("candidate_port_source_sha256")==expected_lazy_source["port"],f"lazy {mode}/{n}/{variant} candidate source mismatch")
        for metric in metrics:
            samples=m.get(metric+"_samples_us",[])
            check(len(samples)==5 and all(isinstance(v,int) and v>=0 for v in samples) and statistics.median(samples)==m.get(metric+"_median_us"),f"lazy {mode}/{n}/{variant}/{metric} samples/median mismatch")
    invariant_fields=("helper_input_sha256","helper_input_bytes","reference_commit","reference_schema_source_sha256","reference_port_source_sha256","reference_schema_helper_sha256","reference_port_helper_sha256")
    for f in invariant_fields: check(p["baseline"].get(f)==p["candidate"].get(f),f"lazy {mode}/{n} paired invariant differs: {f}")
    recomputed={m:p["candidate"][m+"_median_us"]-p["baseline"][m+"_median_us"] for m in metrics}
    check(p.get("candidate_minus_baseline_us")==recomputed,f"lazy {mode}/{n} delta mismatch")
    pair_summary.append({"mode":mode,"pair":n,"order":order,"candidate_minus_baseline_us":recomputed})
check(len(lazy_roots)==16,"lazy roots not unique")
expected_summaries=[]
for mode in ("full","splice"):
 selected=[p for p in pairs if p.get("mode")==mode]
 for metric in metrics:
    expected_summaries.append({"mode":mode,"metric":metric,"pairs":4,"baseline_median_us":statistics.median([p["baseline"][metric+"_median_us"] for p in selected]),"candidate_median_us":statistics.median([p["candidate"][metric+"_median_us"] for p in selected]),"median_paired_candidate_minus_baseline_us":statistics.median([p["candidate_minus_baseline_us"][metric] for p in selected])})
check(lazy.get("summaries")==expected_summaries,"lazy six summaries do not recompute")
clean(lazy_root/"ci/import.log")
lazy_console=(LOGS/f"{job_ids['Windows / lazy-normalization comparison']}.log").read_text(encoding="utf-8",errors="replace")
check(output_count(lazy_console,"LAZY_NORMALIZATION_VERIFIED: sixteen matched processes preserved strict bytes, identity and 66 retained checkpoints.")==1,"lazy terminal receipt mismatch")
check(output_count(lazy_console,"DAY7_CONSUMER_INPUTS_VERIFIED: "+json.dumps(day_manifest,separators=(",",":")))==1,"lazy Day7 receipt mismatch")
lazy_comparisons=console_json(lazy_console,"LAZY_NORMALIZATION_COMPARISON: ")
expected_lazy_comparison={"checkout_ref":HEAD,"source_sha256":expected_lazy_source,"input_sha256":day7_hash,"sampling":lazy.get("sampling"),"scope":lazy.get("scope"),"summaries":expected_summaries}
check(len(lazy_comparisons)==1 and lazy_comparisons[0]==expected_lazy_comparison,"lazy structured console comparison/report mismatch")

result={
 "schema":1,"audit":"hospital-broad2-normalization-audit","status":"pass" if not failures else "fail","failures":failures,
 "identity":{"run_id":RUN,"run_attempt":1,"workflow_head":HEAD,"runtime_source":SOURCE_COMMIT,"whole_run_conclusion":run.get("conclusion")},
 "bounded_jobs":job_out,"source_file_sha256":source_hashes,
 "payloads":{"day7":{"sha256":day7_hash,"bytes":day_file.stat().st_size,"bundles":66,"producer_attempt":day_manifest.get("producer_run_attempt")},"localized":{k:{"sha256":v["sha256"],"bytes":(loc_dir/v["file"]).stat().st_size,"bundles":2,"ending":v["dating_ending"]} for k,v in loc.items()}},
 "outgoing_normalization":{"probes":6,"unique_isolated_roots":len(out_roots),"measurements":outgoing_summary,"ablation":out_report.get("ablation")},
 "lazy_normalization":{"pairs":8,"probes":16,"unique_isolated_roots":len(lazy_roots),"pair_deltas":pair_summary,"summaries":expected_summaries,"sampling":lazy.get("sampling"),"scope":lazy.get("scope")},
 "limits":["This audit accepts only the two named normalization jobs; whole-run status is recorded but cannot substitute for their raw evidence.","No fixed speed threshold is asserted; medians are observational on one shared Windows runner and OS caches were not flushed.","Nested/direct helper and seam timings are inclusive and must not be summed.","Outgoing comparison is a normalization/strict-validation seam, not gameplay proof-cache evidence.","Lazy comparison is not matched schema-build, full checkpoint, physical-save, gameplay, or input-to-paint evidence."],
}
(OUT/"audit.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({"status":result["status"],"failures":len(failures),"outgoing_probes":6,"lazy_probes":16},sort_keys=True))
sys.exit(0 if not failures else 1)

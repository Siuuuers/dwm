#!/usr/bin/env python3
"""Independent, offline, source-bound audit of broad-run original reading controls."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import shutil
import struct
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "dwm"
ARTIFACT_TOP = ROOT / "hospital-broad2/artifacts/reading-rail-37048318182-1"
OUT = Path(__file__).resolve().parent
EXPECTED_SOURCE = "a24f71766a624b57601814dda487b53c66518c39"
EXPECTED_HEAD = "c9c013397f2e309b48fc1548490b401e54938c6c"
EXPECTED_RUN = "37048318182"
EXPECTED_VALIDATOR = {"bytes": 69867, "sha256": "df0e318b8f01e7a66c576f93b0841b964379e4747e8ca94f54aa8cc423884c6b"}
ORIGINAL_MODES = ("write", "read", "repeat", "variant", "witness-read", "next-unseen", "next", "next-read")
SETTINGS_MODES = ("settings-write", "settings-read")


def strict_json(path: Path) -> dict:
    def pairs(items):
        value = {}
        for key, item in items:
            if key in value:
                raise AssertionError(f"duplicate JSON key {key}: {path}")
            value[key] = item
        return value
    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(AssertionError(f"nonfinite JSON {value}: {path}")))


def identity(path: Path) -> dict:
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def load_validator():
    sys.path.insert(0, str(SOURCE / "tools/testing"))
    source = SOURCE / "tools/testing/run_reading_rail_journey.py"
    spec = importlib.util.spec_from_file_location("bound_reading_validator", source)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def discover_raw() -> Path:
    candidates = [path for path in ARTIFACT_TOP.iterdir()
                  if path.is_dir() and (path / "result.json").is_file()]
    require(len(candidates) == 1, f"expected one raw UUID directory, found {len(candidates)}")
    return candidates[0]


def check_process(folder: Path, mode: str, expected_marker: str, expected_user_dir: str | None = None) -> dict:
    receipt_path = folder / f"{mode}.process.json"
    receipt = strict_json(receipt_path)
    require(receipt["exit_code"] == 0 and receipt["timed_out"] is False, f"bad process outcome: {mode}")
    require(receipt["timeout_seconds"] == 600, f"unexpected watchdog: {mode}")
    expected_script = ("res://tools/evidence/print_user_dir.gd" if mode == "user-dir-proof"
                       else "res://tests/integration/verify_reading_rail_journey.gd")
    require(receipt["argv"].count(expected_script) == 1, f"wrong process script: {mode}")
    if mode != "user-dir-proof":
        require(f"--reading-rail-mode={mode}" in receipt["argv"], f"wrong argv mode: {mode}")
    paths = (folder / f"{mode}.stdout.txt", folder / f"{mode}.stderr.txt", folder / f"{mode}.log")
    for path in paths:
        require(path.is_file(), f"missing log: {path}")
    stdout, stderr, engine = (path.read_text(encoding="utf-8", errors="replace") for path in paths)
    error_pattern = re.compile(r"SCRIPT ERROR:|(?:^|\s)ERROR:|Unicode parsing error|Unexpected NUL character|Parse Error:|\bPLAYABLE_[A-Z0-9_]*_FAIL:", re.MULTILINE)
    lifetime_pattern = re.compile(r"Resource still in use:|Leaked instance:|Orphan StringName:")
    for label, text in zip(("stdout", "stderr", "engine"), (stdout, stderr, engine)):
        require(not error_pattern.search(text), f"strict diagnostic in {mode}/{label}")
        require(not lifetime_pattern.search(text), f"lifetime diagnostic in {mode}/{label}")
    if expected_marker:
        count = len(re.findall(r"^" + re.escape(expected_marker) + r":", stdout, re.MULTILINE))
        require(count == 1, f"marker count {mode}/{expected_marker}: {count}")
    if expected_user_dir is not None:
        markers = re.findall(r"^PHASE2R_USER_DIR=(.+)$", stdout, re.MULTILINE)
        require(len(markers) == 1 and markers[0].rstrip("/") == expected_user_dir.rstrip("/"),
                f"user-dir proof mismatch: {mode}")
    return receipt


def check_png(path: Path, expected: dict) -> dict:
    raw = path.read_bytes()
    require(raw[:8] == b"\x89PNG\r\n\x1a\n" and raw[12:16] == b"IHDR", f"invalid PNG: {path.name}")
    width, height = struct.unpack(">II", raw[16:24])
    actual = {"width": width, "height": height, **identity(path)}
    require(actual == {key: expected[key] for key in ("width", "height", "bytes", "sha256")},
            f"PNG identity mismatch: {path.name}")
    require(width > 0 and height > 0, f"empty PNG: {path.name}")
    return actual


def check_seal(root: Path, manifest_name: str, sealed_dir: str, current_capture_dir: Path | None = None) -> dict:
    manifest = strict_json(root / manifest_name)
    sealed_root = root / sealed_dir
    for name, expected in manifest["files"].items():
        sealed = sealed_root / name
        require(identity(sealed) == expected, f"sealed identity mismatch: {name}")
        if name == "transactions.jsonl":
            require((root / name).read_bytes().startswith(sealed.read_bytes()), "transaction seal is not a prefix")
        elif current_capture_dir is not None and name.endswith(".png"):
            require(identity(current_capture_dir / name) == expected, f"capture differs from seal: {name}")
        else:
            require(identity(root / name) == expected, f"current file differs from seal: {name}")
    return {"files": len(manifest["files"]), "manifest": identity(root / manifest_name)}


def check_minimums(path: Path, mode: str) -> dict:
    document = strict_json(path)
    require(document["kind"] == "explicit_minimum_query_after_stop", f"wrong minimum observation: {mode}")
    controls = document["controls"]
    require("ChallengeTitle" in controls, f"title absent from minimum observation: {mode}")
    for control_name, control in controls.items():
        for stage in ("before", "after"):
            view = control[stage]
            for field in ("rect", "clip"):
                box = view[field]
                require(len(box) == 4 and all(type(value) in (int, float) and math.isfinite(value) for value in box)
                        and box[2] > 0 and box[3] > 0, f"bad {field}: {mode}/{control_name}/{stage}")
        for field in ("minimum", "combined_minimum"):
            size = control[field]
            require(len(size) == 2 and all(type(value) in (int, float) and math.isfinite(value) and value >= 0 for value in size),
                    f"bad {field}: {mode}/{control_name}")
    title = controls["ChallengeTitle"]
    require(title["before"]["fully_inside_clip"] is True and title["after"]["fully_inside_clip"] is True,
            f"challenge title clipped in minimum observation: {mode}")
    return {"file": identity(path), "controls": len(controls), "title_inside_clip": True}


def main() -> int:
    raw = discover_raw()
    validator = load_validator()
    declared = strict_json(ARTIFACT_TOP / "result.json")
    raw_result = strict_json(raw / "result.json")
    require((ARTIFACT_TOP / "result.json").read_bytes() == (raw / "result.json").read_bytes(), "top/raw result mismatch")
    require(declared == raw_result and declared["ok"] is True and declared["failures"] == [], "declared result not clean")
    require(declared["checkout_sha"] == EXPECTED_HEAD, "checkout mismatch")
    require(declared["workflow"] == {"GITHUB_RUN_ID": EXPECTED_RUN, "GITHUB_RUN_ATTEMPT": "1", "GITHUB_JOB": "rendered-journeys", "GITHUB_SHA": EXPECTED_HEAD},
            "workflow identity mismatch")
    source_validator_identity = identity(SOURCE / "tools/testing/run_reading_rail_journey.py")
    require(source_validator_identity == EXPECTED_VALIDATOR,
            "source validator identity mismatch")
    committed_validator = subprocess.check_output([
        "git", "-C", str(SOURCE), "show",
        EXPECTED_SOURCE + ":tools/testing/run_reading_rail_journey.py",
    ])
    require({"bytes": len(committed_validator), "sha256": hashlib.sha256(committed_validator).hexdigest()} == EXPECTED_VALIDATOR,
            "expected source commit validator identity mismatch")

    reports = {mode: strict_json(raw / f"{mode}.json") for mode in ORIGINAL_MODES}
    require(set(declared["reports"]) == set(ORIGINAL_MODES), "original report set mismatch")
    require(set(declared["processes"]) == set(ORIGINAL_MODES) | {"user-dir-proof"}, "original process set mismatch")
    pids = [reports[mode]["process_id"] for mode in ORIGINAL_MODES]
    require(all(type(pid) is int and pid > 0 for pid in pids) and len(set(pids)) == len(pids), "original PIDs not positive/distinct")
    user_dir = declared["user_dir"]
    for mode in ORIGINAL_MODES:
        require(reports[mode]["mode"] == mode and reports[mode]["user_dir"].rstrip("/") == user_dir.rstrip("/"),
                f"report identity mismatch: {mode}")
        marker = "READING_RAIL_" + mode.upper().replace("-", "_") + "_PASS"
        receipt = check_process(raw, mode, marker)
        require(receipt == declared["processes"][mode], f"embedded process receipt mismatch: {mode}")
    proof_receipt = check_process(raw, "user-dir-proof", "", user_dir)
    require(proof_receipt == declared["processes"]["user-dir-proof"], "embedded user-dir receipt mismatch")

    audit = {
        "schema_version": 1,
        "scope": "original Solo reading controls plus nested F5 and F9 only",
        "status": "fail",
        "run_id": int(EXPECTED_RUN),
        "run_attempt": 1,
        "source_commit": EXPECTED_SOURCE,
        "workflow_head_checkout": EXPECTED_HEAD,
        "source_validator": source_validator_identity,
        "raw_artifact": {"directory": raw.name, "file_count": sum(1 for path in raw.rglob("*") if path.is_file()), "result": identity(raw / "result.json")},
        "verified_claims": {},
        "failures": [],
        "limits": [
            "This audit covers only original Solo, F5, and F9; other broad-run jobs are outside its scope.",
            "Geometry and PNG structure/identity are checked, but visual-quality inspection is handled separately.",
            "Process identity is the positive distinct Godot process_id emitted in each retained report; OS PID is not present in process receipts.",
        ],
    }

    with tempfile.TemporaryDirectory(prefix="reading-audit-") as temp_name:
        copied = Path(temp_name) / "raw"
        shutil.copytree(raw, copied)
        recomputed = Path(temp_name) / "recomputed"
        recomputed.mkdir()
        copied_reports = {mode: strict_json(copied / f"{mode}.json") for mode in ORIGINAL_MODES}

        writer, reader = copied_reports["write"], copied_reports["read"]
        for field in ("canonical_transcript", "current_line_id", "physical_record", "quick_sha256", "quick_bytes"):
            require(writer[field] == reader[field], f"writer/reader mismatch: {field}")
        require(writer["speech_admissions"] > 0 and reader["speech_admissions"] == 0,
                "live/restored speech control mismatch")
        require(writer["history_observations"] >= 2 and reader["history_observations"] >= 1,
                "history observation control mismatch")
        pause = validator.validate_pause_save(writer, copied, recomputed)
        validator.validate_trace(copied_reports, copied, ORIGINAL_MODES)
        quick_id = identity(copied / "saved-quick.json")
        require(quick_id == {"bytes": writer["quick_bytes"], "sha256": writer["quick_sha256"]}, "retained Quick mismatch")
        witness = validator.validate_witnesses(copied_reports, copied, recomputed)
        next_result = validator.validate_next(copied_reports, copied, recomputed)
        layout = validator.validate_challenge_layout(copied_reports, copied, recomputed)

        original_seal = check_seal(copied, "write-read-seal.json", "sealed-write-read", copied / "captures")
        require(original_seal["files"] == 14, "original seal must contain five data files and nine captures")

        next_capture_names = ("01-next-unseen.png", "02-next-board.png", "03-next-restored-board.png")
        expected_captures = {Path(item["file"]).name: item for item in declared["next_captures"]}
        require(set(expected_captures) == set(next_capture_names), "Next capture set mismatch")
        next_captures = {name: check_png(copied / "next/captures" / name, expected_captures[name]) for name in next_capture_names}
        minimums = {
            "next": check_minimums(copied / "layout-next-minimums.json", "next"),
            "next-read": check_minimums(copied / "layout-next-read-minimums.json", "next-read"),
        }

        f5_root = copied / "settings-quick"
        f5_declared = strict_json(f5_root / "result.json")
        require(f5_declared == declared["settings_quick_save"] and f5_declared["ok"] is True and f5_declared["failures"] == [],
                "F5 nested result mismatch")
        require(set(f5_declared["reports"]) == set(SETTINGS_MODES), "F5 report set mismatch")
        require(set(f5_declared["processes"]) == set(SETTINGS_MODES) | {"user-dir-proof"}, "F5 process set mismatch")
        f5_reports = {mode: strict_json(f5_root / f"{mode}.json") for mode in SETTINGS_MODES}
        f5_pids = [report["process_id"] for report in f5_reports.values()]
        require(all(type(pid) is int and pid > 0 for pid in f5_pids) and len(set(f5_pids)) == 2 and not set(f5_pids) & set(pids),
                "F5 processes not fresh")
        require(f5_declared["user_dir"].rstrip("/") != user_dir.rstrip("/") and f5_declared["isolation_root"] != declared["isolation_root"],
                "F5 isolation not independent")
        for mode in SETTINGS_MODES:
            receipt = check_process(f5_root, mode, "READING_RAIL_" + mode.upper().replace("-", "_") + "_PASS")
            require(receipt == f5_declared["processes"][mode], f"F5 receipt mismatch: {mode}")
        f5_proof = check_process(f5_root, "user-dir-proof", "", f5_declared["user_dir"])
        require(f5_proof == f5_declared["processes"]["user-dir-proof"], "F5 proof receipt mismatch")
        f5_validation = validator.validate_settings_quick(f5_reports, f5_root, recomputed)
        f5_seal = check_seal(f5_root, "settings-write-seal.json", "sealed-settings-write")
        require(f5_seal["files"] == 3, "F5 writer seal cardinality mismatch")

        f9_root = copied / "settings-load"
        f9_declared = strict_json(f9_root / "result.json")
        require(f9_declared == f5_declared["settings_load"] and f9_declared["ok"] is True and f9_declared["failures"] == [],
                "F9 nested result mismatch")
        require(set(f9_declared["reports"]) == {"settings-load"} and set(f9_declared["processes"]) == {"settings-load"},
                "F9 report/process set mismatch")
        f9_report = strict_json(f9_root / "settings-load.json")
        require(type(f9_report["process_id"]) is int and f9_report["process_id"] > 0
                and f9_report["process_id"] not in set(pids + f5_pids), "F9 process not fresh")
        f9_receipt = check_process(f9_root, "settings-load", "READING_RAIL_SETTINGS_LOAD_PASS")
        require(f9_receipt == f9_declared["processes"]["settings-load"], "F9 process receipt mismatch")
        f9_validation = validator.validate_settings_load(
            f9_report,
            f5_reports["settings-write"],
            f9_root,
            f9_root,
            f9_declared["input_files"],
            {key: identity(f9_root / f"final-{key}.json") for key in validator.SETTINGS_DISK_PATHS},
        )
        recovery = f9_validation["recovery_bookkeeping"]
        require(recovery["operation_count"] == 224 and recovery["atomic_commits"] == 16
                and len(recovery["completed_participants"]) == 9
                and recovery["primary_file_operation_attempts"] == 0,
                "F9 recovery summary mismatch")

        input_ids = f9_validation["raw_input"]
        baseline_ids = f9_validation["raw_paused_source"]
        final_ids = f9_validation["raw_final"]
        require(input_ids["quick"] == baseline_ids["quick"] == final_ids["quick"], "F9 Quick boundary mismatch")
        require(input_ids["autosave"] == baseline_ids["autosave"] == final_ids["autosave"], "F9 Autosave boundary mismatch")
        require(input_ids["profile"] != baseline_ids["profile"] and baseline_ids["profile"] == final_ids["profile"],
                "F9 Profile boundary mismatch")

        audit["verified_claims"] = {
            "identity_and_processes": {
                "top_raw_result_equal": True,
                "checkout_and_workflow_bound": True,
                "original_reports": list(ORIGINAL_MODES),
                "original_process_ids": dict(zip(ORIGINAL_MODES, pids)),
                "all_mode_logs_strict_clean": True,
                "all_mode_markers_exactly_one": True,
                "separate_f5_profile": True,
                "fresh_f5_process_ids": dict(zip(SETTINGS_MODES, f5_pids)),
                "fresh_f9_process_id": f9_report["process_id"],
            },
            "original_solo": {
                "writer_reader_exact_fields": ["canonical_transcript", "current_line_id", "physical_record", "quick_sha256", "quick_bytes"],
                "live_speech_positive_and_restore_silent": True,
                "pause_slot3": pause,
                "retained_quick": quick_id,
                "seal": original_seal,
                "trace_rows": sum(len(validator.TRACE_KINDS[mode]) for mode in ORIGINAL_MODES),
                "witnesses": witness,
                "next": next_result,
                "challenge_layout": layout,
                "minimum_observations": minimums,
                "next_captures": next_captures,
            },
            "f5_settings_quick": {
                "validation": f5_validation,
                "seal": f5_seal,
                "trace_rows": sum(len(validator.TRACE_KINDS[mode]) for mode in SETTINGS_MODES),
            },
            "f9_settings_load": {
                "validation": f9_validation,
                "primary_boundaries": {
                    "quick_input_baseline_final_equal": True,
                    "autosave_input_baseline_final_equal": True,
                    "profile_input_differs_after_live_advance": True,
                    "profile_paused_baseline_final_equal": True,
                },
            },
        }

    manifest_rows = []
    for path in sorted(path for path in raw.rglob("*") if path.is_file()):
        manifest_rows.append({"path": path.relative_to(raw).as_posix(), **identity(path)})
    manifest_domain = json.dumps(manifest_rows, sort_keys=True, separators=(",", ":")).encode()
    audit["raw_artifact"]["manifest_sha256"] = hashlib.sha256(manifest_domain).hexdigest()
    audit["status"] = "pass"
    (OUT / "audit.json").write_text(json.dumps(audit, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    f9 = audit["verified_claims"]["f9_settings_load"]["validation"]
    md = f"""# Original reading-controls audit — run {EXPECTED_RUN}

## Verdict

**PASS for the bounded original Solo/F5/F9 scope.** The retained evidence is source-bound to runtime `{EXPECTED_SOURCE}` and workflow checkout `{EXPECTED_HEAD}`. No failure was found in the original reading controls.

This is not a full broad-run acceptance: all other jobs are outside this audit, and visual-quality review is separate.

## Independently verified

- Top-level and raw `result.json` are byte-identical, successful, failure-free, and bound to run {EXPECTED_RUN}, attempt 1, `rendered-journeys`, and the expected checkout.
- The source validator bytes match the checklist identity `{source_validator_identity['sha256']}`. All semantic validators were rerun offline against a copied artifact tree; raw evidence was not modified.
- The eight original modes have distinct positive process IDs `{pids}`. Their eight mode processes plus `user-dir-proof` are the exact process set. Every process exited zero without timeout; each PASS marker occurs exactly once; stdout, stderr, and engine logs contain no source-defined error, Unicode/NUL, parse, failure-marker, or lifetime diagnostic.
- Writer/reader canonical transcript, current line, physical record, retained Quick bytes and hash agree. Live speech is positive; fresh restore speech is zero. Pause/slot3, sealed write/read files, exact trace order/process binding, witness repeat/variant durability, and Next semantics all pass source validation.
- Both Next layout streams contain 120 process and 120 post-draw visible samples, zero dropped events, distinct frames, finite positive title geometry, and an unclipped ChallengeTitle. Both explicit minimum snapshots retain valid finite geometry. All three 1280×720 Next PNGs match recorded bytes and hashes.
- F5 uses a separate isolated profile and fresh process IDs `{f5_pids}`. Its 7 trace rows bind exactly; partial A persists through Settings, F5 completes only A, host/focus/suspension are preserved, exactly one Quick candidate is written, and Autosave/Profile remain unchanged. Fresh F5 restore is silent. The three-file writer seal remains intact.
- F9 runs in fresh process `{f9_report['process_id']}`. Its 7 raw stages and all exact all-true check sets bind to the trace. Released Enter then Escape packets are ordered on increasing frames. Prepare/Cancel preserve partial B, scene, focus, scroll, suspension, and primary files; reprepare uses a distinct token. Confirm restores saved A/history/physical/app, closes Settings/Pause, and adds no restored speech.
- F9 recovery contains exactly `{f9['recovery_bookkeeping']['operation_count']}` ordered FileOps = `{f9['recovery_bookkeeping']['atomic_commits']}` atomic commits × 14 operations, one completed restore, all nine participants, one exact retained-Quick-bound allocation, contiguous appended issuer receipts, preserved prior records, and zero primary-file operation attempts.

## Primary-file boundary nuance

Quick and Autosave are byte-identical across F9 input, paused baseline, and final. Profile input differs from the paused baseline because the live advance to partial B legitimately updates Profile before the F9 interaction; the paused baseline and final Profile are byte-identical. Recovery issuer/journal files are expected to change and were validated as recovery bookkeeping, not claimed unchanged.

## Limits

- Scope is only original Solo, F5, and F9. Other broad-run jobs are outside this audit.
- PNG structure, dimensions, hashes, and source-defined geometry were verified; visual-quality review is handled separately.
- Retained process receipts do not expose OS PIDs. Freshness is proven by the positive, distinct Godot `process_id` values emitted by the reports and bound into traces.

Machine-readable detail: `audit.json`.
"""
    (OUT / "audit.md").write_text(md, encoding="utf-8")
    print(json.dumps({"status": audit["status"], "json": str(OUT / "audit.json"), "markdown": str(OUT / "audit.md")}, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        failure = {"schema_version": 1, "status": "fail", "failures": [f"{type(error).__name__}: {error}"]}
        OUT.mkdir(parents=True, exist_ok=True)
        (OUT / "audit.json").write_text(json.dumps(failure, indent=2) + "\n", encoding="utf-8")
        raise

# Broad2 original reading audit

**PASS with zero failures** for original Solo, nested F5, and nested F9 evidence.

Expected identity:

- run `37048318182`, attempt 1
- source `a24f71766a624b57601814dda487b53c66518c39`
- workflow checkout `c9c013397f2e309b48fc1548490b401e54938c6c`
- artifact `hospital-broad2/artifacts/reading-rail-37048318182-1`

The raw UUID directory was discovered only because exactly one nested directory contains `result.json`. The validator is independently bound to the unchanged source9 Git blob. Semantic validators were rerun offline against a temporary copy of the fresh Broad2 artifact; original evidence was not modified.

The audit verifies fresh process identities and strict logs; writer/reader transcript, line, physical record and Quick equality; live/restored speech controls; Pause/slot3, original seals/traces, witness and Next semantics; 120+120 layout streams and three Next PNG identities; isolated F5 state/seal/restore; and F9’s seven stages, primary boundaries, 224 FileOps, 16 atomic commits, nine participants, one completed restore, and zero primary-file operation attempts.

No Broad1 seal, report, or payload is read or treated as Broad2 evidence. See `audit.md` for the bounded findings and `audit.json` for machine-readable detail.

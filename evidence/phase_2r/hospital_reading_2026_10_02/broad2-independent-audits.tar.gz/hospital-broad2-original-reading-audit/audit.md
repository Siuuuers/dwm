# Original reading-controls audit — run 37048318182

## Verdict

**PASS for the bounded original Solo/F5/F9 scope.** The retained evidence is source-bound to runtime `a24f71766a624b57601814dda487b53c66518c39` and workflow checkout `c9c013397f2e309b48fc1548490b401e54938c6c`. No failure was found in the original reading controls.

This is not a full broad-run acceptance: all other jobs are outside this audit, and visual-quality review is separate.

## Independently verified

- Top-level and raw `result.json` are byte-identical, successful, failure-free, and bound to run 37048318182, attempt 1, `rendered-journeys`, and the expected checkout.
- The source validator bytes match the checklist identity `df0e318b8f01e7a66c576f93b0841b964379e4747e8ca94f54aa8cc423884c6b`. All semantic validators were rerun offline against a copied artifact tree; raw evidence was not modified.
- The eight original modes have distinct positive process IDs `[4512, 4591, 4657, 4750, 4821, 4885, 4953, 5019]`. Their eight mode processes plus `user-dir-proof` are the exact process set. Every process exited zero without timeout; each PASS marker occurs exactly once; stdout, stderr, and engine logs contain no source-defined error, Unicode/NUL, parse, failure-marker, or lifetime diagnostic.
- Writer/reader canonical transcript, current line, physical record, retained Quick bytes and hash agree. Live speech is positive; fresh restore speech is zero. Pause/slot3, sealed write/read files, exact trace order/process binding, witness repeat/variant durability, and Next semantics all pass source validation.
- Both Next layout streams contain 120 process and 120 post-draw visible samples, zero dropped events, distinct frames, finite positive title geometry, and an unclipped ChallengeTitle. Both explicit minimum snapshots retain valid finite geometry. All three 1280×720 Next PNGs match recorded bytes and hashes.
- F5 uses a separate isolated profile and fresh process IDs `[5094, 5166]`. Its 7 trace rows bind exactly; partial A persists through Settings, F5 completes only A, host/focus/suspension are preserved, exactly one Quick candidate is written, and Autosave/Profile remain unchanged. Fresh F5 restore is silent. The three-file writer seal remains intact.
- F9 runs in fresh process `5231`. Its 7 raw stages and all exact all-true check sets bind to the trace. Released Enter then Escape packets are ordered on increasing frames. Prepare/Cancel preserve partial B, scene, focus, scroll, suspension, and primary files; reprepare uses a distinct token. Confirm restores saved A/history/physical/app, closes Settings/Pause, and adds no restored speech.
- F9 recovery contains exactly `224` ordered FileOps = `16` atomic commits × 14 operations, one completed restore, all nine participants, one exact retained-Quick-bound allocation, contiguous appended issuer receipts, preserved prior records, and zero primary-file operation attempts.

## Primary-file boundary nuance

Quick and Autosave are byte-identical across F9 input, paused baseline, and final. Profile input differs from the paused baseline because the live advance to partial B legitimately updates Profile before the F9 interaction; the paused baseline and final Profile are byte-identical. Recovery issuer/journal files are expected to change and were validated as recovery bookkeeping, not claimed unchanged.

## Limits

- Scope is only original Solo, F5, and F9. Other broad-run jobs are outside this audit.
- PNG structure, dimensions, hashes, and source-defined geometry were verified; visual-quality review is handled separately.
- Retained process receipts do not expose OS PIDs. Freshness is proven by the positive, distinct Godot `process_id` values emitted by the reports and bound into traces.

Machine-readable detail: `audit.json`.

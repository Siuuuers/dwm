# Paired checkpoint performance audit

Bounded contract checks passed for run 37048318182, checkout c9c013397f2e309b48fc1548490b401e54938c6c, source a24f71766a624b57601814dda487b53c66518c39. This is not full-gate acceptance.

- Original artifact 11245219099: 158,077 bytes, SHA256 `4a98cb2752982a0771cada65f110442c3336a4fb3b9da7053d8acc9ef52f3f84`. CRC and every one of 22 extracted members verified.
- Exact current-source baseline ablation and both schema hashes verified. Four localized fresh journeys and four fixed-payload probes have eight unique isolated roots, sequential intervals and exit 0 receipts.
- Raw journey summaries/settlements/profiles match reports; 1,160 raw clicks independently reconstruct 46 summary groups and their source-defined upper-middle medians. CN exercises Dating win; HK exercises Dating loss; each journey exercises App win and loss.
- Both retained localized payloads match manifest and all fixed input/output hashes; schema 7 and two journal bundles preserved. All 100 timing samples and 20 medians recomputed.
- All eight measured engine logs and the import log have zero script/error/Unicode/resource-lifetime matches. Broad1 import diagnostics are not carried forward.

Job 110976704748 succeeded; actual checkout, payload-manifest marker and CHECKPOINT_PERFORMANCE_VERIFIED terminal receipt match. Retained-history comparisons and all other gate components remain outside this audit.

| Locale | Variant | Parse median μs | Schema median μs | Outgoing validation median μs |
|---|---|---:|---:|---:|
| zh-CN | baseline | 103219 | 23508 | 18998 |
| zh-HK | baseline | 76765 | 18745 | 15925 |
| zh-CN | candidate | 103536 | 23488 | 15102 |
| zh-HK | candidate | 76536 | 18415 | 11978 |

Timing observations have no fixed speed threshold; fresh journey boards can differ and profiling adds overhead.

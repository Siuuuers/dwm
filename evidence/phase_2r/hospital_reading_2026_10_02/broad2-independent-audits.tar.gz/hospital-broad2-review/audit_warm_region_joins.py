#!/usr/bin/env python3
"""Join completed bounded audits to captured Actions API metadata and raw checkout/upload logs."""
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path('/workspace/scratch/e58f796fe7a3')
CAPTURE = ROOT / 'hospital-broad2'
OUT = Path(__file__).resolve().parent
RUN = 37048318182
HEAD = 'c9c013397f2e309b48fc1548490b401e54938c6c'
SOURCE = 'a24f71766a624b57601814dda487b53c66518c39'


def require(value, label):
    if not value:
        raise ValueError(label)


def identity(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def clean(line):
    return re.sub(r'^\d{4}-\d\d-\d\dT\S+\s+', '', re.sub(r'\x1b\[[0-9;]*m', '', line))


run = load(CAPTURE/'run.json')
require((run['id'], run['head_sha'], run['run_attempt'], run['status'], run['conclusion']) ==
        (RUN, HEAD, 1, 'completed', 'success'), 'run identity/conclusion')
jobs = {job['name']: job for job in load(CAPTURE/'jobs.json')['jobs']}
artifacts = {artifact['name']: artifact for artifact in load(CAPTURE/'artifacts-api.json')['artifacts']}
downloads = {artifact['id']: artifact for artifact in load(CAPTURE/'artifact-manifest.json')}


def join(job_name, artifact_names):
    job = jobs[job_name]
    require((job['run_id'], job['head_sha'], job['status'], job['conclusion']) ==
            (RUN, HEAD, 'completed', 'success'), 'job identity/conclusion: '+job_name)
    log_path = CAPTURE/'logs'/f"{job['id']}.log"
    raw_lines = log_path.read_text().splitlines()
    lines = [clean(line) for line in raw_lines]
    checkout_rows = [index for index, line in enumerate(lines) if '[command]' in line and ' log -1 --format=%H' in line]
    require(len(checkout_rows) == 1 and lines[checkout_rows[0]+1] == HEAD, 'actual checkout command/result: '+job_name)
    joined = []
    for name in artifact_names:
        artifact = artifacts[name]
        downloaded = downloads[artifact['id']]
        for key in ('id', 'name', 'digest', 'size_in_bytes', 'workflow_run'):
            require(downloaded[key] == artifact[key], 'captured API/download metadata: '+key)
        require(artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == HEAD,
                'artifact API workflow identity: '+name)
        zip_path = Path(downloaded['local_zip'])
        info = identity(zip_path)
        require(info['bytes'] == artifact['size_in_bytes'] and 'sha256:'+info['sha256'] == artifact['digest'],
                'original ZIP digest/size: '+name)
        matching = [line for line in lines if line == f"Artifact {name} has been successfully uploaded! Final size is {info['bytes']} bytes. Artifact ID is {artifact['id']}"]
        require(len(matching) == 1, 'raw upload artifact id/size/name: '+name)
        joined.append({'artifact_id': artifact['id'], 'name': name, 'zip': info, 'upload_log_receipt': matching[0]})
    return {'job_id': job['id'], 'job_name': job_name, 'run_id': RUN, 'head_sha': HEAD,
            'conclusion': 'success', 'log': identity(log_path), 'checkout_command_line': checkout_rows[0]+1,
            'checkout_result_line': checkout_rows[0]+2, 'artifacts': joined}


producer = join('Windows / seven-day retained history producer',
                [f'seven-day-inputs-{RUN}', f'seven-day-history-{RUN}-1'])
transfer = downloads[artifacts[f'seven-day-inputs-{RUN}']['id']]
full = downloads[artifacts[f'seven-day-history-{RUN}-1']['id']]
lineage = {}
with zipfile.ZipFile(transfer['local_zip']) as transferred, zipfile.ZipFile(full['local_zip']) as original:
    for name in ('results.json', 'day7-autosave.json', 'consumer-input-manifest.json'):
        raw = transferred.read(name)
        matches = [member for member in original.namelist() if member.endswith('/seven-day-history/'+name)]
        require(len(matches) == 1 and raw == original.read(matches[0]), 'exact producer to transfer member: '+name)
        lineage[name] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
                         'producer_member': matches[0], 'transfer_member': name}

comparisons = {}
for kind in ('warm-outgoing-proof', 'history-region-search'):
    audit_path = OUT/(kind+'-audit-initial.json')
    audit = load(audit_path)
    require(audit['status'] == 'BOUNDED_ARTIFACT_PASS' and audit['runtime_evidence_audited'] is True
            and not audit['broad_acceptance'] and audit['pending'] == [], 'completed bounded artifact audit: '+kind)
    require((audit['source'], audit['checkout'], audit['run_id']) == (SOURCE, HEAD, str(RUN)), 'bounded audit identity')
    joined = join('Windows / '+kind+' comparison', [kind+f'-{RUN}-1'])
    require(audit['receipts']['job_log']['sha256'] == joined['log']['sha256'], 'audited job log join')
    require(audit['receipts']['original_zips']['comparison']['sha256'] == joined['artifacts'][0]['zip']['sha256'], 'audited original ZIP join')
    require(audit['receipts']['original_zips']['producer_inputs']['sha256'] == producer['artifacts'][0]['zip']['sha256'], 'audited transferred ZIP join')
    comparisons[kind] = {'audit': identity(audit_path), 'job_artifact_join': joined,
                         'processes': audit['receipts']['processes'], 'pairs': audit['receipts']['pairs'],
                         'retained_metric_samples': audit['receipts']['samples'], 'summaries': audit['receipts']['summaries']}

report = {'status':'BOUNDED_WARM_REGION_AUDIT_PASS', 'runtime_evidence_audited':True, 'broad_acceptance':False,
          'source':SOURCE, 'checkout':HEAD, 'run_id':RUN, 'run_attempt':1,
          'producer_job_artifacts':producer, 'producer_transfer_exact_bytes':lineage,
          'comparisons':comparisons, 'metadata':{name:identity(CAPTURE/name) for name in
                                               ('run.json','jobs.json','artifacts-api.json','artifact-manifest.json')},
          'helper_unchanged_since_static_review':True,
          'helper_sha256':identity(OUT/'audit_warm_region.py')['sha256'],
          'join_helper':identity(Path(__file__)),
          'limits':['The parent audit owns full-workflow acceptance and the complete producer performance contracts.',
                    'Godot Variant hashes are source-bound cloud assertions cross-checked for invariance, not Python var_to_bytes recomputations.',
                    'Local historical226/5c ports are reconstructed from pinned sources; actual historical blobs/schema/journal guards ran in cloud.',
                    'FakeFileOps timings on shared Windows runners have no performance threshold and no disk/gameplay/input-to-paint claim.']}
require(report['helper_sha256'] == '0e4015df59186927e440a5bb539194fd08ad49460cfc122876cc50692cc9a7e4', 'helper changed after pre-artifact static review')
(OUT/'warm-region-combined-audit.json').write_text(json.dumps(report,indent=2)+'\n')
rows = []
for kind, comparison in comparisons.items():
    for summary in comparison['summaries']:
        rows.append('| '+kind+' | '+summary['mode']+' | '+summary['metric']+' | '+str(summary['baseline_median_us'])+' | '+str(summary['candidate_median_us'])+' | '+str(summary['median_paired_candidate_minus_baseline_us'])+' |')
markdown = '''Both bounded raw-artifact audits pass for source9 `{source}`, checkout `{head}`, run `{run}` attempt 1. **This does not accept the complete broad gate.**

- Warm proof: 24 isolated processes, 12 alternating pairs, 240 retained metric samples, 6 summaries.
- Region search: 16 isolated processes, 8 alternating pairs, 160 retained metric samples, 4 summaries.
- All 51 warm and 35 region ZIP members match original archives; the 3 transferred Day7 members also match the producer archive byte for byte.
- API run/job/artifact identities, original ZIP digest/size, raw checkout command/results, and upload artifact IDs join exactly. Both comparison jobs and the producer completed successfully.
- Exact source guards, shared cold-Autosave evolution receipts, 66 retained bundles, canonical proof/journal hashes, raw benchmark markers, isolated roots/process order, physical traces, invariant signatures, medians/deltas/summaries all pass. The pre-artifact helper was unchanged; no checker predicate was narrowed after inspecting evidence.

Observed medians are microseconds; candidate-minus-baseline uses the median of paired differences. These FakeFileOps observations have no fixed performance threshold.

| Comparison | Mode | Metric | Baseline median | Candidate median | Median paired difference |
|---|---|---|---:|---:|---:|
{rows}

The mixed warm-proof commit observation is +15,331 microseconds; this is retained as observed, with no universal speedup claim. Godot Variant hashes remain source-bound cloud assertions, checked for exact invariance here. The parent audit owns full workflow and producer-performance acceptance.
'''.format(source=SOURCE,head=HEAD,run=RUN,rows='\n'.join(rows))
(OUT/'warm-region-combined-audit.md').write_text(markdown)
print(json.dumps({'status':report['status'],'broad_acceptance':False,'processes':40,'metric_samples':400,
                  'report':str(OUT/'warm-region-combined-audit.json')}))

#!/usr/bin/env python3
"""Source9-bound raw warm/region artifact audit. Python only; no engine/PS/network.

The comparison artifact does not upload the actual Day7 inputs. Supply the separately
downloaded seven-day-inputs/producer artifact via --input-root and --input-zip, or
put both extractions below --artifact-root. Missing ZIPs yield INCOMPLETE, never PASS.
This is a bounded benchmark evidence audit, never a broad-workflow acceptance gate.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
from pathlib import Path, PurePosixPath, PureWindowsPath
import re
import statistics
import subprocess
import sys
import tempfile
import zipfile

SOURCE = "a24f71766a624b57601814dda487b53c66518c39"
CHECKOUT = "c9c013397f2e309b48fc1548490b401e54938c6c"
RUN = "37048318182"
PORT = "scripts/application/run/SaveManagerCheckpointPort.gd"
GUARD = "tools/testing/Assert-WarmOutgoingProofBaseline.ps1"
KINDS = ("warm-outgoing-proof", "history-region-search")
RETAINED = {"line": 32, "manual_save": 32, "semantic": 2}
SHARED = {
    "reviewed_commit": "dca8b35b40e4ba9d80f204c77064357d16f07319",
    "source_path": PORT,
    "reviewed_port_sha256": "ab8824ecb5617b48c5feb581133e4286facae70d42714add825fbea88e60272f",
    "method": "_capture_storage_backup",
    "current_method_sha256": "803bbae0ca2bfc1b8944ddca1952d8743b10ea579b92946dcf5cf438e0d16e7b",
    "historical_method_sha256": "8a5c4fce433ef77722d0bab6fa503aec51a1c70257d129a8a714aeca9de006a2",
    "reversal_is_provenance_text_only": True,
    "warm_control_inherits_current_method": True,
}
WARM_REFS = {
    "reference_commit": "226d3da868784baacc6fc33f58823f95b5815a51",
    "reference_port_source_sha256": "bac00cb4df7573a6c670bbab1593e77f6ca8d0dd31b3cd7dade6d50616fd04bc",
    "reference_schema_source_sha256": "1676d41225675acf4e3c154c60e38c2bd831417047266d5a9f00e4466bd448b2",
    "reference_journal_commit": "226d3da868784baacc6fc33f58823f95b5815a51",
    "reference_journal_source_sha256": "617aa35fe71b426c8c0b643b9fdda2e65322f5e37e652fb98bf7f78f64e7c344",
    "reference_commit_method_sha256": "c8a1d78923cee29d2af4b6520e34d3d131d83ead92b170e8f907f8454132ed58",
    "reference_splice_method_sha256": "2d35e02daecdb6fc77cb7058132a76b7301825115f6db29750e3de81145b6d9c",
    "reference_validate_method_sha256": "f5836a5a142eab40679a4b4f76dbff9bd2dc0c1ee92dc18874db350c6526ef61",
    "reference_remember_method_sha256": "70a0dcfb3e8668366339d986a2b96949a0b6a36b31fad67957f33a3698c994d4",
}
REGION_REFS = {
    "reference_commit": "5c3368dbba14475a3749bd71df971bfed353699f",
    "reference_port_source_sha256": "72d400998c3bc6d9a3b4a7645bfd24a749e34a78eaa140ba73d1b23d6fc20310",
    "reference_method_sha256": "470919ccd5ff929337c6a0c00185e9082772c97de7f5ce72a3b9e0209dff4617",
}


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(value):
    return hashlib.sha256(value.encode("utf-8") if isinstance(value, str) else value).hexdigest()


def equal(actual, expected, label):
    require(type(actual) is type(expected) or (type(actual) in (int, float) and type(expected) in (int, float)),
            label + ": JSON type mismatch")
    if isinstance(expected, dict):
        require(actual.keys() == expected.keys(), label + ": key mismatch")
        for key in expected:
            equal(actual[key], expected[key], label + "." + str(key))
    elif isinstance(expected, list):
        require(len(actual) == len(expected), label + ": length mismatch")
        for index, value in enumerate(expected):
            equal(actual[index], value, label + "[" + str(index) + "]")
    else:
        require(actual == expected, label + ": value mismatch")


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "duplicate JSON key: " + key)
        result[key] = value
    return result


def parse(text, **kwargs):
    return json.loads(text, object_pairs_hook=unique_object,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError("nonfinite JSON: " + value)), **kwargs)


class RawNumber(str):
    """Preserve canonical source numeric lexemes instead of reformatting floats."""


def canonical(value):
    if isinstance(value, RawNumber):
        return str(value)
    if isinstance(value, dict):
        return "{" + ",".join(canonical(k) + ":" + canonical(value[k]) for k in sorted(value, key=lambda k: k.encode())) + "}"
    if isinstance(value, list):
        return "[" + ",".join(map(canonical, value)) + "]"
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def signature(value):
    return sha(canonical(value))


def method(text, name):
    values = re.findall(r"(?ms)^(?:static )?func " + re.escape(name) + r"\(.*?(?=^(?:func |static func |## )|\Z)", text)
    require(len(values) == 1, "unique GDScript method: " + name)
    return values[0].rstrip("\r\n") + "\n"


def markers(text, name, structured=True):
    found = []
    for line in text.splitlines():
        line = re.sub(r"\x1b\[[0-9;]*m", "", line)
        line = re.sub(r"^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?Z\s+", "", line)
        if line.startswith(name + ": "):
            value = line[len(name) + 2:]
            found.append(parse(value) if structured else value)
    return found


def one_marker(text, name, structured=True):
    result = markers(text, name, structured)
    require(len(result) == 1, "expected exactly one " + name)
    return result[0]


def median(values):
    require(isinstance(values, list) and values, "nonempty numeric sample array")
    require(all(type(x) in (int, float) and math.isfinite(x) and x >= 0 for x in values), "finite nonnegative samples")
    return statistics.median(values)


def is_hash(value):
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None


class Auditor:
    def __init__(self, args):
        self.args = args
        self.repo = Path(args.repo).resolve()
        self.root = Path(args.artifact_root).resolve()
        self.input_root = Path(args.input_root).resolve() if args.input_root else self.root
        self.used = {}
        self.verified_zip_paths = set()
        self.pending = []
        self.receipts = {}

    def git(self, commit, path):
        return subprocess.check_output(["git", "-C", str(self.repo), "show", commit + ":" + path], stderr=subprocess.PIPE)

    def source(self, path):
        raw = self.git(self.args.source, path)
        equal((self.repo / path).read_bytes(), raw, "working source " + path)
        # The actual workflow head is an auxiliary merge with the same source files.
        equal(self.git(self.args.checkout, path), raw, "checkout source " + path)
        self.receipts.setdefault("source_files", {})[path] = {"sha256": sha(raw), "bytes": len(raw)}
        return raw.decode("utf-8")

    def locate(self, root, suffix):
        normalized = suffix.replace("\\", "/").strip("/")
        paths = [p for p in root.rglob(Path(normalized).name) if p.is_file()
                 and (p.relative_to(root).as_posix() == normalized or p.relative_to(root).as_posix().endswith("/" + normalized))]
        require(len(paths) == 1, "expected one artifact member " + normalized + "; found " + str(len(paths)))
        return paths[0]

    def read(self, path, as_json=False):
        raw = path.read_bytes()
        self.used[str(path.resolve())] = {"bytes": len(raw), "sha256": sha(raw)}
        text = raw.decode("utf-8-sig")
        return parse(text) if as_json else text

    def zip_audit(self, root, filename, label):
        if not filename:
            self.pending.append(label + " original ZIP byte audit not supplied")
            return
        path = Path(filename).resolve()
        with zipfile.ZipFile(path) as archive:
            require(archive.testzip() is None, label + " ZIP CRC failure")
            names = archive.namelist()
            require(len(names) == len(set(names)), label + " ZIP duplicate names")
            count = 0
            for info in archive.infolist():
                name = info.filename
                require(not name.startswith("/") and ".." not in PurePosixPath(name).parts and "\\" not in name,
                        label + " unsafe ZIP member")
                require((info.external_attr >> 16) & 0o170000 != 0o120000, label + " ZIP symlink member")
                if info.is_dir():
                    continue
                extracted = self.locate(root, name)
                equal(extracted.read_bytes(), archive.read(info), label + " ZIP bytes " + name)
                self.verified_zip_paths.add(str(extracted.resolve()))
                count += 1
        self.receipts.setdefault("original_zips", {})[label] = {"path": str(path), "sha256": sha(path.read_bytes()), "members": count}

    def bind_source(self):
        equal(self.args.source, SOURCE, "reviewed source9")
        equal(self.args.checkout, CHECKOUT, "reviewed broad2 checkout")
        equal(str(self.args.run_id), RUN, "reviewed broad2 run")
        require(self.args.run_attempt >= 1, "positive consumer run attempt")
        script_name = "WarmOutgoingProof" if self.kind == KINDS[0] else "HistoryRegionSearch"
        self.driver = self.source("tools/testing/Invoke-" + script_name + "Performance.ps1")
        self.harness = self.source("tests/manual/benchmark_" + ("warm_outgoing_proofs" if self.kind == KINDS[0] else "history_region_search") + ".gd")
        self.source(GUARD)
        pairs = re.findall(r"^    @\('([^']+)', '([^']+)'\)", self.driver, re.M)
        require(len(pairs) == 10, "exact ten driver source files")
        self.hashes = {key: sha(self.source(path)) for key, path in pairs}
        for extra in ("tools/testing/Invoke-IsolatedGodot.ps1", "scripts/validation/CanonicalJsonWriter.gd", "autoload/SaveManager.gd", ".github/workflows/windows-tests.yml"):
            self.source(extra)
        guard = self.source(GUARD)
        for value in [*SHARED.values(), *WARM_REFS.values()]:
            if isinstance(value, str):
                require(value in guard, "preserved source guard pin " + value)
        port = self.source(PORT)
        equal(sha(port), SHARED["reviewed_port_sha256"], "reviewed whole production port")
        equal(sha(self.git(SHARED["reviewed_commit"], PORT)), SHARED["reviewed_port_sha256"], "immutable shared evolution port")
        capture = method(port, SHARED["method"])
        equal(sha(capture), SHARED["current_method_sha256"], "current shared method")
        old = method(self.git("28dbdd345abfce3915dcefdc514530c40a299f27", PORT).decode(), SHARED["method"])
        equal(sha(old), SHARED["historical_method_sha256"], "historical shared method")
        frozen = self.source("tests/support/WarmOutgoingProofReference.gd")
        region = self.source("tests/support/HistoryRegionSearchReference.gd")
        for reference in (frozen, region):
            require(reference.startswith('extends "res://' + PORT + '"\n'), "control exact shared parent")
            require(not re.search(r"(?m)^[ \t]*(?:static[ \t]+)?func[ \t]+_capture_storage_backup[ \t]*\(", reference), "control may not override shared method")
        bridged = port
        for name, key in (("commit", "reference_commit_method_sha256"), ("_splice_autosave_text", "reference_splice_method_sha256")):
            body = method(frozen, name).replace("proven_journal: Array = [], _proven_documents: Array = []) -> String:", "proven_journal: Array = []) -> String:")
            equal(sha(body), WARM_REFS[key], "frozen " + name)
            bridged = bridged.replace(method(port, name), body)
        comment = "## `proven_documents` collects the normalized document proofs under those same ids/text lifetimes;\n## an empty entry preserves the raw-proof fallback. Neither output is trusted on a failed splice.\n"
        require(bridged.count(comment) == 1, "reviewed comment boundary")
        bridged = bridged.replace(comment, "").replace(capture, old)
        equal(sha(bridged), WARM_REFS["reference_port_source_sha256"], "reconstructed accepted226 port")
        region_method = method(region, "_remember_written_history")
        equal(sha(region_method), REGION_REFS["reference_method_sha256"], "frozen region method")
        equal(sha(bridged.replace(method(port, "_remember_written_history"), region_method)), REGION_REFS["reference_port_source_sha256"], "reconstructed original region port")
        # Full guard execution and actual historical blob reads are separately evidenced by
        # the source-bound cloud receipt; this local check is explicitly reconstruction.
        self.receipts["static_provenance"] = {"shared_current_method_exact": True, "controls_inherit_current_method": True,
            "reconstructed_accepted226_port_sha256": sha(bridged), "historical_blob_validation": "Source-bound cloud guard; local original226/5c trees unavailable"}

    def lineage(self, job):
        manifest_path = self.locate(self.root, "seven-day-history/consumer-input-manifest.json")
        manifest = self.read(manifest_path, True)
        equal(set(manifest), {"schema_version", "checkout_ref", "producer_run_id", "producer_run_attempt", "files"}, "input manifest keys")
        equal(manifest["schema_version"], 1, "input schema")
        equal(manifest["checkout_ref"], self.args.checkout, "input checkout")
        equal(manifest["producer_run_id"], str(self.args.run_id), "input run")
        require(type(manifest["producer_run_attempt"]) is int and 1 <= manifest["producer_run_attempt"] <= self.args.run_attempt, "admitted producer attempt")
        equal(set(manifest["files"]), {"results.json", "day7-autosave.json"}, "exact two producer files")
        equal(one_marker(job, "DAY7_CONSUMER_INPUTS_VERIFIED"), manifest, "consumer job receipt")
        # Shared producer artifacts may be flat (seven-day-inputs) or preserve ci paths.
        candidates = [p for p in self.input_root.rglob("day7-autosave.json") if p.is_file()]
        require(len(candidates) == 1, "actual Day7 payload required exactly once; supply --input-root")
        payload_path = candidates[0]
        history_path = payload_path.parent / "results.json"
        producer_manifest_path = payload_path.parent / "consumer-input-manifest.json"
        equal(self.read(producer_manifest_path, True), manifest, "producer/consumer input manifest")
        raw = payload_path.read_bytes()
        payload_text = self.read(payload_path)
        history = self.read(history_path, True)
        for name, path in (("results.json", history_path), ("day7-autosave.json", payload_path)):
            equal(sha(path.read_bytes()), manifest["files"][name], "actual input bytes " + name)
        payload_hash = sha(raw)
        equal(history["checkout_ref"], self.args.checkout, "producer checkout")
        if "run_id" in history:
            equal(history["run_id"], str(self.args.run_id), "producer run")
        for field in (history["payload_sha256"], history["write"]["autosave_sha256"], history["cold_read"]["autosave_sha256"]):
            equal(field, payload_hash, "producer/cold payload hash")
        equal(history["cold_read"]["save_manager_sha256"], sha(self.source("autoload/SaveManager.gd")), "cold source")
        equal(history["cold_read"]["day"], 7, "cold Day7")
        equal(history["cold_read"]["retained_checkpoint_count"], 66, "cold retention")
        equal(history["write"]["retained"], RETAINED, "writer retention")
        document = parse(payload_text, parse_int=RawNumber, parse_float=RawNumber)
        equal((canonical(document) + "\n").encode(), raw, "canonical Day7 bytes with preserved numeric lexemes")
        equal(int(document["schema_version"]), 7, "payload schema")
        current = document["current_snapshot"]
        equal(int(current["snapshot"]["schema_version"]), 7, "snapshot schema")
        equal(int(current["snapshot"]["lifecycle"]["day"]), 7, "payload Day7")
        bundles = document["recovery_journal"]
        require(len(bundles) == 66, "actual payload 66 retained bundles")
        retained = {k: 0 for k in RETAINED}
        proof_manifest = []
        for bundle in bundles:
            bucket = bundle["checkpoint_kind"] if bundle["checkpoint_kind"] in ("line", "manual_save") else "semantic"
            retained[bucket] += 1
            text = canonical(bundle)
            proof_manifest.append({"checkpoint_id": bundle["snapshot"]["checkpoint_id"], "text_sha256": sha(text), "bytes": len(text.encode())})
        equal(retained, RETAINED, "actual payload retention")
        require(len({x["checkpoint_id"] for x in proof_manifest}) == 66, "unique actual checkpoint ids")
        final = {"run_id": current["snapshot"]["run_id"], "next_sequence": int(current["snapshot"]["checkpoint_sequence"]) + 1, "current": current, "earlier": bundles}
        prior = copy.deepcopy(final)
        prior["current"] = prior["earlier"].pop()
        prior["next_sequence"] = int(current["snapshot"]["checkpoint_sequence"])
        self.payload = {"sha256": payload_hash, "bytes": len(raw), "manifest": proof_manifest, "final_journal_sha256": signature(final), "prior_journal_sha256": signature(prior)}
        self.receipts["input_lineage"] = {"producer_manifest": manifest, "actual_payload_bytes": len(raw), "actual_payload_sha256": payload_hash, "actual_retention": retained}

    def isolation(self, name, measurement):
        prefix = "cloud-" + self.kind + "-" + name
        log_path = self.locate(self.root, "phase2r_logs/" + prefix + ".log")
        log = self.read(log_path)
        require(re.search(r"^Godot Engine v4\.6\.3\.stable\.official\.", log, re.M), name + " Godot standard4.6.3 header")
        require("mono" not in log.splitlines()[0].lower(), name + " standard engine required")
        require(not re.search(r"SCRIPT ERROR:|(?:^|\n)ERROR:|Unicode parsing error|Unexpected NUL character|_FAIL:|GODOT_CHILD_TIMEOUT|WARNING:.*(?:ObjectDB|leak|resources still)", log), name + " raw log error")
        equal(one_marker(log, self.marker + "_BENCHMARK"), measurement, name + " raw measurement/report equality")
        evidence_path = self.locate(self.root, self.kind + "/" + name + ".jsonl")
        rows = [parse(line) for line in self.read(evidence_path).splitlines() if line.strip()]
        require(len(rows) == 1, name + " one isolation record")
        record = rows[0]
        equal(record["suite_id"], prefix, name + " suite id")
        equal(record["exit_code"], 0, name + " isolated exit")
        equal(PureWindowsPath(record["log_path"]).name, prefix + ".log", name + " isolated log")
        root = PureWindowsPath(record["test_root"])
        user = PureWindowsPath(record["user_dir"])
        require(".." not in root.parts and ".." not in user.parts, name + " canonical isolated paths")
        require(root.is_absolute() and root.parent.name == "phase2r_tests" and root.parent.parent.name == ".godot", name + " contained root")
        require(re.fullmatch(r"[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}", root.name), name + " root GUID")
        require(user.is_relative_to(root) and user != root, name + " contained user dir")
        root_key = str(root).casefold()
        require(root_key not in self.roots, name + " unique fresh root")
        self.roots.add(root_key)
        argv = record["argv"]
        harness = "res://tests/manual/benchmark_" + ("warm_outgoing_proofs" if self.kind == KINDS[0] else "history_region_search") + ".gd"
        require(len(argv) == 11 and argv[:2] == ["--headless", "--path"] and argv[3] == "--log-file" and argv[4] == record["log_path"]
                and argv[5:8] == ["-s", harness, "--"] and argv[8].startswith("--document=")
                and PureWindowsPath(argv[8][11:]).name == "day7-autosave.json"
                and argv[9:] == ["--variant=" + measurement["variant"], "--mode=" + measurement["mode"]], name + " exact isolated argv")
        require(root.is_relative_to(PureWindowsPath(argv[2])) and PureWindowsPath(record["log_path"]).is_relative_to(PureWindowsPath(argv[2])), name + " repository containment")
        from datetime import datetime
        start = datetime.fromisoformat(record["started_at_utc"].replace("Z", "+00:00"))
        end = datetime.fromisoformat(record["ended_at_utc"].replace("Z", "+00:00"))
        require(start.tzinfo is not None and end.tzinfo is not None and start <= end, name + " valid UTC interval")
        if self.last_end is not None:
            require(start >= self.last_end, name + " actual process ordering/no overlap")
        self.last_end = end

    def measurement(self, m, mode, variant, label):
        present = {"cold": 0, "mixed": 51, "warm": 66}[mode]
        expected = {"variant": variant, "mode": mode, "input_sha256": self.payload["sha256"], "output_sha256": self.payload["sha256"],
                    "bytes": self.payload["bytes"], "journal_bundles": 66, "validated_journal_bundles": 66, "retained": RETAINED,
                    "schema_version": 7, "snapshot_schema_version": 7, "warmup_count": 2, "sample_count": 5,
                    "initial_proofs_present": present, "initial_proofs_missing": 66-present, "source_unchanged": True,
                    "exact_proof_strings_and_documents": True, "exact_physical_bytes": True,
                    "proof_seed": self.payload["manifest"][:present], "final_proof_manifest": self.payload["manifest"],
                    "final_journal_sha256": self.payload["final_journal_sha256"], "prior_journal_sha256": self.payload["prior_journal_sha256"],
                    "candidate_port_source_sha256": self.hashes["port"]}
        expected.update(WARM_REFS if self.kind == KINDS[0] else REGION_REFS)
        if self.kind == KINDS[0]:
            expected.update(exact_composed_values_types_and_bytes=True, candidate_schema_source_sha256=self.hashes["schema"],
                            candidate_journal_source_sha256=self.hashes["journal"], journal_reference_source_sha256=self.hashes["journal_reference"])
        expected["proof_seed_sha256"] = signature(expected["proof_seed"])
        expected["final_proof_manifest_sha256"] = signature(expected["final_proof_manifest"])
        for key, value in expected.items():
            equal(m[key], value, label + " " + key)
        for key in ("timing_boundary", "scope", "control_boundary"):
            matches = re.findall(r'"' + key + r'": "([^"\n]*)"', self.harness)
            if matches:
                require(len(matches) == 1, "unique harness description " + key)
                equal(m[key], matches[0], label + " exact harness " + key)
        physical_root = "warm-outgoing-proof-benchmark" if self.kind == KINDS[0] else "history-region-benchmark"
        for metric in self.metrics:
            samples = m[metric + "_samples_us"]
            require(len(samples) == 5, label + " five " + metric + " samples")
            equal(m[metric + "_median_us"], median(samples), label + " recomputed " + metric + " median")
            evidence = m["evidence"][metric]
            equal(evidence["journal_sha256"], self.payload["final_journal_sha256"], label + " exact final journal")
            physical = {physical_root + "/autosave.json": self.payload["sha256"]}
            if metric == "port_commit_fake_io":
                # write_atomic uses keep_backup=true; previous and outgoing bytes are identical.
                physical[physical_root + "/autosave.json.bak"] = self.payload["sha256"]
            equal(evidence["physical_files"], physical, label + " exact physical manifest")
            trace = evidence["operation_trace"]
            require(isinstance(trace, list), label + " ordered operation trace")
            require((len(trace) > 0) == (metric == "port_commit_fake_io"), label + " physical-operation boundary")
            for operation in trace:
                require(set(operation) == {"ordinal", "operation", "path", "destination"} and type(operation["ordinal"]) is int
                        and operation["ordinal"] >= 0 and isinstance(operation["operation"], str), label + " trace record")
            if self.kind == KINDS[0]:
                count = present if metric == "schema_composition" else 66
                equal(evidence["final_proof_count"], count, label + " proof count")
                state = evidence["proof_state"]
                require(len(state) == 66, label + " 66 proof-state rows")
                for index, proof in enumerate(state):
                    equal(proof["checkpoint_id"], self.payload["manifest"][index]["checkpoint_id"], label + " proof id/order")
                    equal(proof["text_sha256"], self.payload["manifest"][index]["text_sha256"] if index < count else sha(""), label + " proof text hash")
                    require(is_hash(proof["document_type_sha256"]), label + " document Variant hash")
                for key in ("journal_type_sha256", "raw_proof_type_sha256"):
                    require(is_hash(evidence[key]), label + " " + key)
                if metric == "schema_composition":
                    require(is_hash(evidence["composed_type_sha256"]), label + " composed Variant hash")
                else:
                    equal(evidence["composed_type_sha256"], "", label + " commit composition hash absent")
        # Full non-timing invariants are compared within each mode, including every source,
        # exact physical operation order, every proof-state/type signature and scope string.
        invariant = {key: value for key, value in m.items() if key not in {"variant", *[x+s for x in self.metrics for s in ("_samples_us", "_median_us")]}}
        if mode in self.invariants:
            equal(invariant, self.invariants[mode], label + " all non-timing mode invariants")
        else:
            self.invariants[mode] = invariant

    def run(self):
        possible = [kind for kind in KINDS if any(p.parent.name == kind for p in self.root.rglob("results.json"))]
        self.kind = self.args.kind or (possible[0] if len(possible) == 1 else None)
        require(self.kind in KINDS, "specify --kind when results directory is ambiguous")
        self.marker = self.kind.upper().replace("-", "_")
        if self.kind == KINDS[0]:
            self.marker = "WARM_OUTGOING_PROOF"
        self.modes = ["cold", "mixed", "warm"] if self.kind == KINDS[0] else ["cold", "mixed"]
        self.metrics = ["schema_composition", "port_commit_fake_io"] if self.kind == KINDS[0] else ["learning_seam", "port_commit_fake_io"]
        self.roots, self.invariants, self.last_end = set(), {}, None
        self.bind_source()
        self.zip_audit(self.root, self.args.zip, "comparison")
        if self.input_root != self.root or self.args.input_zip:
            self.zip_audit(self.input_root, self.args.input_zip, "producer_inputs")
        job = Path(self.args.job_log).read_text(encoding="utf-8-sig")
        self.receipts["job_log"] = {"path": str(Path(self.args.job_log).resolve()), "sha256": sha(Path(self.args.job_log).read_bytes())}
        report = self.read(self.locate(self.root, self.kind + "/results.json"), True)
        equal(report["checkout_ref"], self.args.checkout, "report actual checkout")
        equal(report["run_id"], str(self.args.run_id), "report run")
        equal(report["source_sha256"], self.hashes, "report exact source hashes")
        equal(report["retained_checkpoint_count"], 66, "report retention")
        receipt = dict(SHARED)
        if self.kind == KINDS[1]:
            receipt["region_control_inherits_current_method"] = True
        equal(report["shared_port_evolution"], receipt, "report exact shared evolution")
        equal(one_marker(job, "WARM_PROOF_SHARED_EVOLUTION_VERIFIED"), SHARED, "raw source guard receipt")
        self.lineage(job)
        equal(report["input_sha256"], self.payload["sha256"], "report input")
        for field in ("sampling", "scope"):
            values = re.findall(r"^    " + field + r" = '([^']*)'", self.driver, re.M)
            require(len(values) == 1, "unique driver " + field)
            equal(report[field], values[0], "exact report " + field)
        pairs = report["pairs"]
        require(len(pairs) == len(self.modes)*4, "exact pair count")
        equal(markers(job, self.marker + "_PAIR"), pairs, "raw job pair markers in order")
        for index, pair in enumerate(pairs):
            mode, number = self.modes[index//4], index%4+1
            equal(pair["mode"], mode, "pair mode/order")
            equal(pair["pair"], number, "pair ordinal")
            equal(pair["order"], ["baseline", "candidate"] if number%2 else ["candidate", "baseline"], "alternating process order")
            for variant in pair["order"]:
                name = mode + "-" + str(number) + "-" + variant
                self.measurement(pair[variant], mode, variant, name)
                self.isolation(name, pair[variant])
            equal(pair["candidate_minus_baseline_us"], {metric: pair["candidate"][metric+"_median_us"]-pair["baseline"][metric+"_median_us"] for metric in self.metrics}, "paired deltas")
        summaries = []
        for mode in self.modes:
            selected = [row for row in pairs if row["mode"] == mode]
            for metric in self.metrics:
                summaries.append({"mode": mode, "metric": metric, "pairs": 4,
                    "baseline_median_us": statistics.median(row["baseline"][metric+"_median_us"] for row in selected),
                    "candidate_median_us": statistics.median(row["candidate"][metric+"_median_us"] for row in selected),
                    "median_paired_candidate_minus_baseline_us": statistics.median(row["candidate_minus_baseline_us"][metric] for row in selected)})
        equal(report["summaries"], summaries, "recomputed summaries/order")
        equal(one_marker(job, self.marker + "_COMPARISON"), {key: report[key] for key in ("checkout_ref", "source_sha256", "input_sha256", "shared_port_evolution", "sampling", "scope", "summaries")}, "raw comparison marker")
        verified = re.findall(r"Write-Host '" + self.marker + r"_VERIFIED: ([^']*)'", self.driver)
        require(len(verified) == 1, "unique source terminal receipt")
        equal(one_marker(job, self.marker + "_VERIFIED", False), verified[0], "raw verified receipt")
        expected_logs = {"cloud-"+self.kind+"-"+mode+"-"+str(pair)+"-"+variant+".log" for mode in self.modes for pair in range(1,5) for variant in ("baseline","candidate")}
        equal({p.name for p in self.root.rglob("cloud-"+self.kind+"-*.log")}, expected_logs, "exact raw log census")
        result_dir = self.locate(self.root, self.kind+"/results.json").parent
        equal({p.name for p in result_dir.glob("*.jsonl")}, {name.removeprefix("cloud-"+self.kind+"-").removesuffix(".log")+".jsonl" for name in expected_logs}, "exact isolation census")
        uncovered = sorted(set(self.used) - self.verified_zip_paths)
        if uncovered:
            self.pending.append("Consumed files lack original ZIP byte binding: " + "; ".join(uncovered))
        self.receipts.update(kind=self.kind, processes=len(self.roots), pairs=len(pairs), samples=len(self.roots)*len(self.metrics)*5,
            summaries=summaries, mode_invariant_sha256={key: signature(value) for key,value in self.invariants.items()}, consumed_files=self.used)
        return {"status": "INCOMPLETE" if self.pending else "BOUNDED_ARTIFACT_PASS", "runtime_evidence_audited": True,
            "broad_acceptance": False, "source": self.args.source, "checkout": self.args.checkout, "run_id": str(self.args.run_id),
            "pending": self.pending, "receipts": self.receipts, "limits": [
                "Source9 and broad2 identities are intentionally pinned; review contracts before reusing for another source/run.",
                "Cloud benchmark assertions establish Godot Variant type equivalence; Python verifies their raw hashes and across-process invariance, not var_to_bytes encoding.",
                "Historical original226/5c blob reads are performed by the source-bound cloud guard; local check reconstructs the pinned whole ports.",
                "Actual Actions checkout execution, job/run success, producer performance gates and full workflow census remain the parent audit's responsibility.",
                "This compares FakeFileOps benchmark boundaries; no real-disk, gameplay, input-to-paint or broad acceptance claim."]}


def self_test():
    """Small adversarial parser/primitive checks, never fabricated runtime acceptance."""
    checks = {}
    cases = {"duplicate_json_key": lambda: parse('{"a":1,"a":2}'), "nonfinite_json": lambda: parse('{"a":NaN}'),
             "bool_numeric_sample": lambda: median([True]), "negative_sample": lambda: median([-1]),
             "duplicate_marker": lambda: one_marker('X: {}\nX: {}', "X"),
             "type_confusion": lambda: equal(True, 1, "boolean vs integer"),
             "nested_type_confusion": lambda: equal({"x":[True]}, {"x":[1]}, "nested boolean vs integer"),
             "wrong_pair_delta": lambda: equal({"x":2}, {"x":1}, "delta"),
             "missing_marker": lambda: one_marker("", "X")}
    for name, operation in cases.items():
        try:
            operation()
        except (ValueError, KeyError):
            checks[name] = "rejected"
        else:
            raise ValueError("negative check admitted: " + name)
    value = parse('{"a":1.0,"b":1.5e2,"c":[3,"中文"]}', parse_int=RawNumber, parse_float=RawNumber)
    equal(canonical(value), '{"a":1.0,"b":1.5e2,"c":[3,"中文"]}', "raw number preservation")
    equal(one_marker('2026-10-02T12:34:56.0000000Z X: {"ok":true}', "X"), {"ok":True}, "timestamped raw marker")
    with tempfile.TemporaryDirectory(prefix="warm-region-static-") as temporary:
        base = Path(temporary)
        extracted = base / "extracted"
        extracted.mkdir()
        (extracted / "value.txt").write_bytes(b"original")
        archive = base / "artifact.zip"
        with zipfile.ZipFile(archive, "w") as handle:
            handle.writestr("value.txt", b"original")
        auditor = Auditor(argparse.Namespace(repo=str(base), artifact_root=str(extracted), input_root=None))
        auditor.zip_audit(extracted, str(archive), "synthetic")
        (extracted / "value.txt").write_bytes(b"tampered")
        try:
            auditor.zip_audit(extracted, str(archive), "synthetic")
        except ValueError:
            checks["extracted_member_tamper"] = "rejected"
        else:
            raise ValueError("tampered extracted bytes admitted")
        with zipfile.ZipFile(archive, "w") as handle:
            handle.writestr("../escape.txt", b"unsafe")
        try:
            auditor.zip_audit(extracted, str(archive), "synthetic")
        except ValueError:
            checks["unsafe_zip_member"] = "rejected"
        else:
            raise ValueError("unsafe ZIP member admitted")
    return {"status":"STATIC_SYNTHETIC_CHECKS_ONLY", "runtime_evidence_audited":False, "broad_acceptance":False,
            "negative_checks":checks, "positive_checks":["numeric lexeme preservation", "timestamped exact marker"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("repo", "source", "checkout", "run-id", "artifact-root", "job-log", "output"):
        parser.add_argument("--"+name)
    parser.add_argument("--kind", choices=KINDS)
    parser.add_argument("--zip", help="Original comparison artifact ZIP")
    parser.add_argument("--input-root", help="Separate producer/seven-day-inputs extraction")
    parser.add_argument("--input-zip", help="Original separate producer/input ZIP")
    parser.add_argument("--run-attempt", type=int, default=1)
    parser.add_argument("--self-test", action="store_true", help="Static/synthetic checks only; runtime evidence remains unaudited")
    args = parser.parse_args()
    if not args.self_test:
        for field in ("repo","source","checkout","run_id","artifact_root","job_log","output"):
            if not getattr(args, field):
                parser.error("--"+field.replace("_","-")+" is required for runtime auditing")
    try:
        result = self_test() if args.self_test else Auditor(args).run()
    except (ValueError, KeyError, IndexError, OSError, UnicodeError, OverflowError, subprocess.CalledProcessError, zipfile.BadZipFile, TypeError) as error:
        result = {"status":"FAIL", "runtime_evidence_audited":False, "broad_acceptance":False,
                  "error": str(error), "source":args.source, "checkout":args.checkout, "run_id":args.run_id}
    result["auditor"] = {"path":str(Path(__file__).resolve()), "sha256":sha(Path(__file__).read_bytes())}
    text = json.dumps(result, ensure_ascii=False, indent=2)+"\n"
    if args.output:
        output = Path(args.output)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(text, encoding="utf-8")
    print(text)
    return 1 if result["status"] == "FAIL" else 2 if result["status"] == "INCOMPLETE" else 0


if __name__ == "__main__":
    sys.exit(main())

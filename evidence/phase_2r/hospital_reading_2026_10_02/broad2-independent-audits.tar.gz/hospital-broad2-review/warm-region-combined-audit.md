Both bounded raw-artifact audits pass for source9 `a24f71766a624b57601814dda487b53c66518c39`, checkout `c9c013397f2e309b48fc1548490b401e54938c6c`, run `37048318182` attempt 1. **This does not accept the complete broad gate.**

- Warm proof: 24 isolated processes, 12 alternating pairs, 240 retained metric samples, 6 summaries.
- Region search: 16 isolated processes, 8 alternating pairs, 160 retained metric samples, 4 summaries.
- All 51 warm and 35 region ZIP members match original archives; the 3 transferred Day7 members also match the producer archive byte for byte.
- API run/job/artifact identities, original ZIP digest/size, raw checkout command/results, and upload artifact IDs join exactly. Both comparison jobs and the producer completed successfully.
- Exact source guards, shared cold-Autosave evolution receipts, 66 retained bundles, canonical proof/journal hashes, raw benchmark markers, isolated roots/process order, physical traces, invariant signatures, medians/deltas/summaries all pass. The pre-artifact helper was unchanged; no checker predicate was narrowed after inspecting evidence.

Observed medians are microseconds; candidate-minus-baseline uses the median of paired differences. These FakeFileOps observations have no fixed performance threshold.

| Comparison | Mode | Metric | Baseline median | Candidate median | Median paired difference |
|---|---|---|---:|---:|---:|
| warm-outgoing-proof | cold | schema_composition | 107207.0 | 104531.5 | -2738.0 |
| warm-outgoing-proof | cold | port_commit_fake_io | 1532907.5 | 1499702.5 | -35021.5 |
| warm-outgoing-proof | mixed | schema_composition | 104524.5 | 102286.5 | -2624.5 |
| warm-outgoing-proof | mixed | port_commit_fake_io | 958725.5 | 969287.0 | 15331.0 |
| warm-outgoing-proof | warm | schema_composition | 119438.0 | 49984.0 | -60212.0 |
| warm-outgoing-proof | warm | port_commit_fake_io | 279394.0 | 213091.0 | -61988.0 |
| history-region-search | cold | learning_seam | 865869.5 | 704557.0 | -161312.5 |
| history-region-search | cold | port_commit_fake_io | 1597037.5 | 1438012.0 | -159658.0 |
| history-region-search | mixed | learning_seam | 268801.5 | 202262.0 | -67819.5 |
| history-region-search | mixed | port_commit_fake_io | 993302.0 | 925189.5 | -68305.5 |

The mixed warm-proof commit observation is +15,331 microseconds; this is retained as observed, with no universal speedup claim. Godot Variant hashes remain source-bound cloud assertions, checked for exact invariance here. The parent audit owns full workflow and producer-performance acceptance.

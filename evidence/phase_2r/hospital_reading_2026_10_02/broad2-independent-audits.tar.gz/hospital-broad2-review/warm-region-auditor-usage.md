This helper audits warm-outgoing-proof or history-region-search artifacts for source9 `a24f71766a624b57601814dda487b53c66518c39`, workflow checkout `c9c013397f2e309b48fc1548490b401e54938c6c`, run `37048318182`. It runs Python and Git reads only. Runtime evidence has **not yet been audited**.

```bash
python -B /workspace/scratch/e58f796fe7a3/hospital-broad2-review/audit_warm_region.py \
  --repo /workspace/scratch/e58f796fe7a3/dwm \
  --source a24f71766a624b57601814dda487b53c66518c39 \
  --checkout c9c013397f2e309b48fc1548490b401e54938c6c \
  --run-id 37048318182 --run-attempt 1 \
  --artifact-root /absolute/comparison/extraction \
  --zip /absolute/original-comparison.zip \
  --input-root /absolute/seven-day-inputs/extraction \
  --input-zip /absolute/original-seven-day-inputs.zip \
  --job-log /absolute/comparison-job.log \
  --output /absolute/audit.json
```

Kind is inferred from the `warm-outgoing-proof/results.json` or `history-region-search/results.json` directory; `--kind` resolves ambiguity. The comparison upload contains the consumer manifest, but **does not contain the actual Day7 payload and producer report**. Supply the separately downloaded `seven-day-inputs` or `seven-day-history` artifact. Extraction and ZIP paths can also refer to a common root that contains both artifacts, provided member lookup remains unambiguous.

The helper verifies all original ZIP member bytes/CRCs; consumed-file provenance; source9 and actual-checkout source hashes; historical constants and exact shared evolution; producer checkout/run/attempt and actual input hashes; 66 retained bundles and canonical bundle/journal hashes; all 24 warm or 16 region isolated processes; alternating pair order and actual nonoverlapping timestamps; raw benchmark and job-marker equality; metric boundaries, proof state and per-mode invariant signatures; 5 samples after 2 declared warmups; medians, paired deltas and summaries. Commit evidence retains both `autosave.json` and `autosave.json.bak`; the direct metric retains only `autosave.json`.

Exit codes: `0` means `BOUNDED_ARTIFACT_PASS` for actual inputs, `2` means `INCOMPLETE` (for example, original ZIP binding missing), `1` means `FAIL`. Neither a bounded pass nor a self-test accepts the full broad gate. Missing actual Day7 input bytes fail the audit. The helper deliberately pins source9/broad2; review its contracts before changing those identities.

Run `--self-test --output /absolute/static-checks.json` for parser and ZIP tamper checks. Its status is always `STATIC_SYNTHETIC_CHECKS_ONLY` with `runtime_evidence_audited=false`; no benchmark measurements are fabricated. Static source-binding receipts are recorded separately in `warm-region-source-checks.json`.

Limits: Godot `var_to_bytes` hashes are checked for format and exact cross-process invariance; Python does not reproduce Godot Variant serialization. Historical226/5c whole-port hashes are reconstructed locally from pinned frozen methods and the historical capture method; the source-bound cloud guard performs actual historical Git blob reads and full schema/journal reconstruction. Actual Actions checkout execution, run/job conclusions, the producer's complete performance gate and the full workflow census remain the parent audit's responsibility. These metrics use FakeFileOps and make no physical-disk or gameplay/input-to-paint timing claim.

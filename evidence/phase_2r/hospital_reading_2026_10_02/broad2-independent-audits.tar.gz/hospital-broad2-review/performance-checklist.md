# Performance and Day7 evidence supplement

Source **a24f71766a624b57601814dda487b53c66518c39**, actual checkout **c9c013397f2e309b48fc1548490b401e54938c6c**, run **37048318182**. Static requirements only; no results accepted yet.

| Evidence directory under `.godot/ci/` | Required cardinality and fields |
|---|---|
| `performance/` | `results.json`: four journeys and four fixed-payload measurements, baseline/candidate × zh-CN/win and zh-HK/loss. Exact `schema_sha256.baseline/candidate`. Each journey: one `CLICK_LATENCY_PASS`, localized non-ASCII reply, `CLICK_LATENCY_MODE.mode=fresh-account`, nonempty checkpoint/consequence profiles. Each fixed payload: input/output SHA256 equal, journal and validated bundles=2, five nonnegative samples for `parse_us,schema_us,stringify_us,value_validation_us,outgoing_validation_us`. |
| `seven-day-history/` | `results.json`, `admission-pairs.json`, `manual-prepare-pairs.json`, `day7-autosave.json`, `consumer-input-manifest.json`. Writer days exactly1…7, nonnegative terminal settlement times, 98 synthetic checkpoints, retained32 line/32 manual/2 semantic. Disabled then enabled parse-cache cold controls; eight admission pairs and eight manual-prepare pairs. **35 isolated probes** total. |
| `outgoing-normalization/` | Six `measurements`: baseline/candidate × zh-CN/zh-HK/day7. Exact variant/input/output hashes, five nonnegative samples; journal and validated bundles=2 localized/66 Day7. |
| `lazy-normalization/` | Eight pairs/16 probes, four each full/splice; six summaries. Metrics schema_helper/port_helper/port_seam: two warmups, five nonnegative samples, exact recomputed medians. |
| `history-region-search/` | Eight pairs/16 probes, four each cold/mixed; four summaries. Metrics learning_seam/port_commit_fake_io: two warmups, five nonnegative samples, exact medians. |
| `warm-outgoing-proof/` | Twelve pairs/24 probes, four each cold/mixed/warm; six summaries. Metrics schema_composition/port_commit_fake_io: two warmups, five nonnegative samples, exact medians. |

- Bind every `checkout_ref` to workflow head; every run field to string `37048318182`. Each expected probe must have matching `suite_id,argv,exit_code=0,log_path,test_root,user_dir` in isolation JSONL, unique contained roots and clean logs. Reject timeout/script/load/Unicode/NUL and family FAIL markers.
- Pair order alternates baseline→candidate on odd pairs, candidate→baseline on even pairs. Check all pair numbers and membership; recompute candidate-minus-baseline differences and median summaries. Timing has no fixed speed threshold; nested timers are inclusive and must not be summed.

## Transferred payload provenance

- Day7 `consumer-input-manifest.json`: schema1, exact checkout/run, producer attempt positive and at most consumer run attempt; exactly files `results.json` and `day7-autosave.json`, actual hashes matching manifest. All four comparison logs require `DAY7_CONSUMER_INPUTS_VERIFIED:`.
- Bind `history.payload_sha256`, writer autosave SHA256 and cold-read autosave SHA256 to actual Day7 bytes; cold-read SaveManager hash to actual source; day7 and66 retained. The writer's retention is exactly32 line/32 manual_save/2 semantic.
- Localized manifest: exact checkout/run/admitted producer attempt, two payloads only, zh-CN and zh-HK, exact `fixed-$locale-autosave.json`, actual SHA256, bundle count2. Its producer schema hash must identify the recorded baseline variant.
- The checkout-free aggregate must prove producer and all four comparison jobs succeeded; it cannot stand in for missing producer/consumer artifacts.

## Day7 controls and diagnostics

- `cold_read` is the enabled control. Disabled/enabled restored gameplay, board and recovery-journal SHA256 values must be valid and equal. Every admission sample has day7, exact current variant SaveManager and autosave hashes, cache enabled,66 retained, nonnegative login time and those same restored hashes. All retained source JSON hashes remain unchanged.
- Canonical producer uses **`-ComparePreparation`**. Require `manual_prepare_comparison.metric=prepare_us`, not a manual-write comparison. Each sample: nonnegative prepare/commit time, `write_variant=production`, `timing_mode=legacy-phase-context`, cache enabled,66 retained, exact SaveManager/storage/harness/witness-port source hashes, **one strict validation in both variants**.
- All16 preparation samples preserve `candidate_sha256,source_revision,source_files_sha256,output_files_sha256,prior_journal_sha256,journal_sha256,output_sha256,output_bytes,retained_checkpoint_count,parse_cache_before`.
- Checkpoint profile diagnostics: version2; positive equal successful-autosave prepare/commit counts; all numeric fields listed in source `Assert-CheckpointDiagnostics` present/nonnegative; proof outcomes boolean; splice-dependent journal timing present.

## Normalization and proof ablations

- Lazy/region/warm measurements: exact input=output=Day7 hash and byte length,66 input/output bundles, document/snapshot schema7, warmup2/sample5, source document unchanged.
- Lazy: unchanged identity retained, changed identity replaced. Reference commit `dae70bf9aa05b6b3debb60f95738e5ffc4e97548`; actual candidate port/schema hashes exact; paired helper input bytes/hash and reference source/helper hashes equal.
- Region proof present/missing counts cold0/66, mixed51/15. Warm adds warm66/0. Seed count equals present; final manifest66. Match exact proof documents/strings/physical bytes.
- Region frozen reference commit `5c3368dbba14475a3749bd71df971bfed353699f`, whole-port SHA256 `72d400998c3bc6d9a3b4a7645bfd24a749e34a78eaa140ba73d1b23d6fc20310`, method SHA256 `470919ccd5ff929337c6a0c00185e9082772c97de7f5ce72a3b9e0209dff4617`.
- Warm provenance must satisfy source `Assert-WarmOutgoingProofBaseline.ps1`, accepted commit `226d3da868784baacc6fc33f58823f95b5815a51`, exact historical port/schema/journal and four method hashes. Recompute all current-source hashes.
- Region/warm invariants equal across all eight processes within each mode: seeds/manifests/hashes, journals, complete ordered FileOps traces, file hashes and source provenance. Direct metric physical trace empty; commit trace nonempty; every metric journal hash equals final journal.
- Warm additionally requires exact composed values/types/bytes, composition proof count=initial present, commit proof count66, both proof-state arrays66, and nonempty composed-type hash. Region/warm commit I/O is `FakeFileOps`; do not claim real-disk or input-to-paint speed.

## Required terminal receipts

Require `CHECKPOINT_PERFORMANCE_VERIFIED`, `CHECKPOINT_PHASE_DIAGNOSTICS_VERIFIED`, `SAVE_ADMISSION_COMPARISON`, `MANUAL_SAVE_PREPARE_COMPARISON`, `SEVEN_DAY_HISTORY_PERFORMANCE_VERIFIED`, `OUTGOING_NORMALIZATION_PERFORMANCE_VERIFIED`, `LAZY_NORMALIZATION_VERIFIED`, `HISTORY_REGION_SEARCH_VERIFIED`, and `WARM_OUTGOING_PROOF_VERIFIED` with matching structured reports. Retain result/pair files, all per-probe JSONLs, raw family engine logs, import logs, transferred actual payloads and both producer manifests. Markers alone do not establish the matching/control predicates above.

## Source9 shared evolution

Apply the exact `shared_port_evolution` contract in `checklist-identities.json` to `results.json`, comparison job markers and guard marker. Region adds its verified inheritance flag only after its own guard. Frozen226 port/schema/journal and method hashes, and frozen5c region source/method hashes, must remain unchanged. Require actual measured24 warm and16 region processes; preflight guard success alone is insufficient.

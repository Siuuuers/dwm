#!/usr/bin/env python3
"""Prepare source-bound audit expectations only; never execute tests or poll CI."""
from collections import Counter
from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess
import sys

B = Path('/workspace/scratch/e58f796fe7a3')
OUT = B / 'hospital-broad2-suite-audit'
HEAD = 'c9c013397f2e309b48fc1548490b401e54938c6c'
SOURCE = 'a24f71766a624b57601814dda487b53c66518c39'
OLD_SOURCE = '856520f09440d9b47cc272de3363009924ffedca'
OLD_HEAD = '1bc4f6afd759e969f82b9c2134eb178479c19d13'
RUN = 37048318182
sys.path.insert(0, str(B / 'hospital-tools'))
import build_hospital_broad_workflow as helper


def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def file_identity(path):
    return {'path': str(path), **identity(path.read_bytes())}


def git(*args):
    return subprocess.check_output(['git', *args], cwd=B / 'dwm')


class GitSource:
    def __init__(self, commit):
        self.commit = commit
        self.inventory = {}
        self.cache = {}

    def read(self, path):
        if path not in self.cache:
            self.cache[path] = git('show', self.commit + ':' + path)
        raw = self.cache[path]
        self.inventory[path] = identity(raw)
        return raw


manifest_path = B / 'hospital-broad2.yml.manifest.json'
manifest = json.loads(manifest_path.read_text())
checklist_path = B / 'hospital-broad2-review/checklist-identities.json'
checklist = json.loads(checklist_path.read_text())
assert manifest['source_commit'] == SOURCE
assert checklist['source_commit'] == SOURCE and checklist['run_id'] == RUN
assert checklist['workflow_head_and_expected_checkout'] == HEAD
assert identity(manifest_path.read_bytes()) == checklist['broad_derivation_manifest']
assert identity((B / 'hospital-broad2-review/checklist.md').read_bytes()) == checklist['checklist_documents']['checklist.md']
assert identity((B / 'hospital-tools/build_hospital_broad_workflow.py').read_bytes()) == checklist['helper_identities']['hospital-tools/build_hospital_broad_workflow.py']

head_commit = git('cat-file', '-p', HEAD).decode()
parents = re.findall(r'^parent ([0-9a-f]{40})$', head_commit, re.M)
assert parents == [OLD_HEAD, SOURCE]
assert git('diff', '--name-only', SOURCE, HEAD).decode().splitlines() == ['.github/workflows/hospital-reading-cloud.yml']
assert git('show', HEAD + ':.github/workflows/hospital-reading-cloud.yml') == (B / 'hospital-broad2.yml').read_bytes()
assert git('rev-parse', SOURCE + '^{tree}').decode().strip() == manifest['source_tree']
assert git('diff', '--name-only', OLD_SOURCE, SOURCE).decode().splitlines() == sorted(checklist['changed_powershell_source_identities'])

source = GitSource(HEAD)
census = helper.inherited_suite_census(source, tuple(manifest['canonical_suites']),
                                     tuple(manifest['automatically_discovered_changed_fixtures']))
assert census == manifest['suite_census'], 'Independent recursive census must equal new manifest'
assert len(census['suites']) == 13
assert {key: census[key] for key in ('predicted_case_executions', 'predicted_script_executions',
                                   'predicted_unique_cases', 'predicted_unique_scripts')} == {
    'predicted_case_executions': 2437, 'predicted_script_executions': 204,
    'predicted_unique_cases': 2433, 'predicted_unique_scripts': 203}
assert census['suites']['shop']['static_case_count'] == 144
assert census['suites']['endings']['static_case_count'] == 106
for path, expected in checklist['changed_powershell_source_identities'].items():
    assert identity(source.read(path)) == expected
    assert identity(git('show', SOURCE + ':' + path)) == expected
    assert manifest['source_file_identities'][path] == expected
for path in ('evidence/phase_2r/runtime/game_state_surface.json',
             'evidence/phase_2r/runtime/save_manager_surface.json'):
    assert identity(source.read(path)) == manifest['source_file_identities'][path]
for path, expected in source.inventory.items():
    assert identity(git('show', SOURCE + ':' + path)) == expected

patterns = {
    'legacy_prepared_fixture': r'\bv[1-6]_desktop_prepared\.json\b',
    'historical_day3_seed': r'valid_day3\.json',
    'backup_fixture_helper': r'BackupSnapshotFixture',
    'run_document_version': r'\b(?:schema_version|SCHEMA_VERSION|DOCUMENT_VERSION)\b',
    'empty_contacts_literal': r"\bcontacts\b[\"']?\s*[:=]\s*\{\s*\}",
}
symbols = ['get_affection_tier', 'is_contact_choice_selected', 'get_contact_choices',
           'can_respond_to_invitation', 'can_buy_supportz', 'has_unread_friend_messages',
           'prepare_run_candidate', 'commit_run_candidate', 'get_minesweeper_safety_level',
           'should_warn_minesweeper_before_schedule_done']
paths = git('ls-tree', '-r', '--name-only', HEAD, '--', 'autoload/', 'scripts/', 'tests/',
            'tools/testing/', '.github/workflows/', 'scenes/').decode().splitlines()
paths = sorted(p for p in paths if Path(p).suffix in {'.gd', '.ps1', '.py', '.yml', '.yaml', '.tscn'})
batch = subprocess.check_output(['git', 'cat-file', '--batch'], cwd=B / 'dwm',
                                input=''.join(HEAD + ':' + p + '\n' for p in paths).encode())
offset = 0; blobs = {}
for path in paths:
    end = batch.index(b'\n', offset)
    fields = batch[offset:end].decode().split()
    assert len(fields) == 3 and fields[1] == 'blob'
    size = int(fields[2]); offset = end + 1
    blobs[path] = batch[offset:offset + size]
    offset += size + 1
assert offset == len(batch)
fixture_paths = [p for p in paths if not p.startswith('scenes/') and Path(p).suffix != '.tscn']
compiled = {key: re.compile(value) for key, value in patterns.items()}
records = []
for path in fixture_paths:
    for index, line in enumerate(blobs[path].decode('utf-8-sig').splitlines(), 1):
        families = [key for key, pattern in compiled.items() if pattern.search(line)]
        if families:
            records.append({'path': path, 'line': index, 'families': families, 'text': line})
retire_paths = [p for p in paths if Path(p).suffix in {'.gd', '.tscn'} and p.split('/')[0] in {'autoload', 'scripts', 'scenes', 'tests'}]
retire_pattern = re.compile(r'\b(?:' + '|'.join(re.escape(s) for s in symbols) + r')\b')
retired_hits = []
for path in retire_paths:
    for index, line in enumerate(blobs[path].decode('utf-8-sig').splitlines(), 1):
        if retire_pattern.search(line):
            retired_hits.append({'path': path, 'line': index, 'text': line})
assert not retired_hits
expected_public = {'fixture_scanned_files': len(fixture_paths), 'fixture_matching_lines': len(records),
                   'fixture_family_memberships': dict(Counter(f for row in records for f in row['families'])),
                   'retirement_source_files': len(retire_paths), 'retirement_hits': []}
resolved = {'source_commit': SOURCE, 'actual_checkout': HEAD, 'run_id': RUN,
            'initial_manifest': identity(manifest_path.read_bytes()),
            'source_and_checkout_test_ancestry_bytes_equal': True,
            'helper': identity((B / 'hospital-tools/build_hospital_broad_workflow.py').read_bytes()),
            'suite_census': census, 'source_identities': source.inventory,
            'changed_powershell_source_identities': checklist['changed_powershell_source_identities'],
            'public_fixture_patterns': patterns, 'retired_symbols': symbols,
            'public_source_expected': expected_public}
(OUT / 'resolved-census.json').write_text(json.dumps(resolved, indent=2) + '\n')
ast.parse((OUT / 'audit_suites.py').read_text())
broad1_reports = {
    'hospital-broad1-suite-audit/hospital-broad1-suite-audit.json':
        '279849f690815d485103ff6b4c702a1d3da389f44de34f7da92501352e49207d',
    'hospital-broad1-suite-audit/hospital-broad1-suite-audit.md':
        '570c788508b9f4e6b424381d1392a56a500a754831563b1d87a6db859eb80664'}
for path, expected_sha in broad1_reports.items():
    assert identity((B / path).read_bytes())['sha256'] == expected_sha
preparation = {
    'status': 'prepared_static_only_awaiting_broad2_artifacts', 'run_id': RUN, 'attempt': 1,
    'source': SOURCE, 'checkout': HEAD, 'ordered_checkout_parents': parents,
    'source_to_checkout_only_difference': '.github/workflows/hospital-reading-cloud.yml',
    'no_engine_or_powershell_or_remote_execution': True, 'no_busy_polling': True,
    'broad1_reports_unchanged': True, 'whole_broad_acceptance': False,
    'broad1_report_sha256s_retained': broad1_reports,
    'required_ordinary_xml': 13, 'required_case_executions': 2437,
    'required_script_executions': 204, 'required_unique_named_cases': 2433,
    'required_unique_scripts': 203, 'endings_required_cases': 106,
    'source_identities': source.inventory,
    'changed_powershell_source_identities': checklist['changed_powershell_source_identities'],
    'public_source_expected': expected_public,
    'bound_files': {'manifest': file_identity(manifest_path), 'checklist_identities': file_identity(checklist_path),
                    'resolved_census': file_identity(OUT / 'resolved-census.json'),
                    'audit_script': file_identity(OUT / 'audit_suites.py'),
                    'preparation_script': file_identity(Path(__file__))},
    'run_when_ready': 'python hospital-broad2-suite-audit/audit_suites.py --artifact-root <Broad2 artifacts> --artifact-manifest <Broad2 artifact manifest> --jobs-json <Broad2 jobs snapshot> --logs-dir <Broad2 job logs>',
    'remaining_inputs': ['All 13 Broad2 XMLs and their own engine/import logs and isolated receipts.',
                         'Broad2 original ZIPs/API digest-size manifest and completed job metadata/console logs.',
                         'Broad2 own negative-controls-subaudit.json, independently verified and bound to run/source/attempt.',
                         'No Broad1 component evidence may fill a missing Broad2 input.'],
    'limits': 'Preparation validates static source only. The actual audit must consume new bytes, and component success cannot declare the entire 24-job broad gate accepted.'}
(OUT / 'preparation.json').write_text(json.dumps(preparation, indent=2) + '\n')
print(json.dumps({'preparation': file_identity(OUT / 'preparation.json'),
                  'audit_script': file_identity(OUT / 'audit_suites.py'),
                  'public_source_expected': expected_public}, indent=2))

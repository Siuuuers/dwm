# Broad2 ordinary suite and public evidence audit

**Bounded component evidence passes: all 13 ordinary/public XMLs, 2,437 executions, 204 script executions, 2,433 unique script/test pairs and 203 unique scripts.** Every actual named multiset matches the new source-derived recursive census, with zero failures/errors/skips/disabled. Whole-run acceptance is outside this report.

Run `37048318182`, attempt 1; actual checkout `c9c013397f2e309b48fc1548490b401e54938c6c`; runtime source `a24f71766a624b57601814dda487b53c66518c39`. Each job's observed checkout, exact `CLOUD_GUT_RESULT`, XML, isolated exit-zero receipt and retained import/engine logs agree. Every retained extracted member matches its own original ZIP; digest, size and CRC agree with the run-bound artifact manifest.

| Suite | Executed cases | Script executions |
|---|---:|---:|
| public_surfaces | 11 | 1 |
| minesweeper | 210 | 22 |
| shop | 144 | 8 |
| desktop | 334 | 22 |
| settings | 357 | 31 |
| checkpoint_diagnostics | 22 | 4 |
| new_account | 179 | 15 |
| reading_delivery | 480 | 35 |
| localization | 153 | 18 |
| dating | 167 | 12 |
| persistence | 230 | 22 |
| endings | 106 | 12 |
| audio | 44 | 2 |

The historical lexical count was 2,421 / 2,417 unique cases. The corrected recursive source census includes eight base tests inherited by each of two Shop scene scripts, yielding Shop 144 and the full 2,437 / 2,433. `resolved-census.json` binds the exact source names, lines, ancestry and hashes; this audit also binds all three changed PowerShell files to the new source and actual checkout. Broad1 files remain immutable and supply no Broad2 passing evidence.

Both public inventories reproduce committed bytes without regeneration. The independent exact-checkout scan reproduces every record in the fixture census and console: 963 files, 908 matching lines. Retirement scanning covers 954 files and the ten exact expected symbols, with zero references. Historical fixture/schema mentions are observational; they do not establish production migration or unexercised content acceptance.

`negative-controls-subaudit.json` binds this run's own exact negative controls and standalone receipts. The audit reopens both 83/80/3 Settings negative XMLs and unchanged before/after repository snapshots; these 166 intentional cases are excluded from ordinary totals. The ordinary new-account log admits exactly the one attributed ff diagnostic and no other Unicode/NUL exemption. Standalone manual-witness, capture and latency assertions are excluded from GUT counts. No Broad1 numeric standalone result is copied as evidence.

Source preparation does not execute tests. This report is produced only after all required Broad2 artifact, console and subaudit inputs are available. No engine, PowerShell, connector or remote calls are used. Complete rendered semantics, visual inspection, performance/export evidence and whole-run acceptance remain separate.

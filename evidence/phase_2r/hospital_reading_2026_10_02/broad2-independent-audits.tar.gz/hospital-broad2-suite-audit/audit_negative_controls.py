#!/usr/bin/env python3
"""Read-only Broad2 artifact/source checks; writes only the sibling audit JSON."""
from pathlib import Path
import collections
import datetime as dt
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

BASE = Path('/workspace/scratch/e58f796fe7a3')
CAPTURE = BASE / 'hospital-broad2'
ART = CAPTURE / 'artifacts'
REPO = BASE / 'dwm'
OUT = BASE / 'hospital-broad2-suite-audit'
RUN = 37048318182
HEAD = 'c9c013397f2e309b48fc1548490b401e54938c6c'
SOURCE = 'a24f71766a624b57601814dda487b53c66518c39'
ANSI = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
DIAGNOSTIC = re.compile(r'^(?:SCRIPT ERROR:|ERROR:|Unicode parsing error\b|Unexpected NUL character\b|Parse Error:)|ObjectDB instances leaked|Resources still in use|Orphan StringName', re.I)
FF = 'Unicode parsing error, some characters were replaced with \ufffd (U+FFFD): Invalid UTF-8 leading byte (ff)'
CASE = 'test_prepare_counts_nonempty_unreadable_autosave_but_not_zero_bytes'
CASE_SCRIPT = 'tests/integration/test_prepared_new_run.gd'

def sha(b): return hashlib.sha256(b).hexdigest()
def ident(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': sha(b)}
def readjson(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def lines(p): return [ANSI.sub('', s.rstrip('\r')) for s in p.read_text(encoding='utf-8-sig').split('\n')]
def gitblob(commit, p): return subprocess.check_output(['git', 'show', f'{commit}:{p}'], cwd=REPO)
def winpath(p): return str(p).replace('\\', '/').rstrip('/').casefold()
def under(p, root): return winpath(p).startswith(winpath(root) + '/')
def logcheck(p, allowed=()):
    data = p.read_bytes()
    found = [{'line': n, 'text': s} for n, s in enumerate(lines(p), 1) if DIAGNOSTIC.search(s)]
    assert data and b'\0' not in data, p
    assert all(x['text'] in allowed for x in found), (str(p), found)
    return {**ident(p), 'lf_line_count': len(data.split(b'\n')) - int(data.endswith(b'\n')), 'diagnostic_lines': found, 'raw_nul_count': data.count(b'\0')}
def receipt(p, suite, exit_code, script=None, tail=()):
    rows = [json.loads(s) for s in p.read_text(encoding='utf-8-sig').splitlines() if s.strip()]
    assert len(rows) == 1, p
    row = rows[0]
    assert list(row) == ['suite_id', 'argv', 'exit_code', 'log_path', 'test_root', 'user_dir', 'started_at_utc', 'ended_at_utc']
    assert row['suite_id'] == suite and row['exit_code'] == exit_code
    assert under(row['user_dir'], row['test_root']) and '/.godot/phase2r_tests/' in winpath(row['test_root'])
    argv = row['argv']
    assert argv[:2] == ['--headless', '--path'] and argv[3] == '--log-file'
    assert argv[4] == row['log_path']
    if script: assert argv[5:] == ['-s', 'res://' + script, *tail]
    duration = (dt.datetime.fromisoformat(row['ended_at_utc'].replace('Z', '+00:00')) - dt.datetime.fromisoformat(row['started_at_utc'].replace('Z', '+00:00'))).total_seconds()
    assert duration > 0
    return {**ident(p), 'row_count': 1, 'record': row, 'duration_seconds': duration, 'user_dir_strictly_under_test_root': True}

report = {'schema_version': 1, 'run_id': RUN, 'attempt': 1, 'expected_checkout': HEAD,
          'runtime_source': SOURCE, 'scope': 'Intentional negative controls and standalone receipts only; no ordinary XML census or whole-run acceptance.',
          'status': 'pass_bounded_negative_controls_and_standalone', 'artifact_root': str(ART)}
sources = ['tools/testing/Invoke-StorageRefusalChecks.ps1', 'tools/testing/Invoke-CloudTests.ps1',
           'tests/tooling/Test-InvokeIsolatedGodot.ps1', 'tools/testing/Invoke-IsolatedGodot.ps1',
           CASE_SCRIPT, 'tests/backup_storage/test_manual_witness_revision_storage.gd',
           'tests/save_load_capture/test_capture.gd', 'tests/integration/verify_new_acc_latency.gd',
           'tests/integration/verify_complete_action_recovery.gd',
           'tests/unit/test_minesweeper_shop_purchase_participant.gd', 'tests/unit/test_save_manager_checkpoint_port.gd']
source = {p: gitblob(HEAD, p) for p in sources}
report['source_identity'] = {}
for p, b in source.items():
    assert b == gitblob(SOURCE, p), p
    report['source_identity'][p] = {'commit': HEAD, 'bytes': len(b), 'sha256': sha(b), 'runtime_source_blob_equal': True}
workflow = gitblob(HEAD, '.github/workflows/hospital-reading-cloud.yml')
report['workflow_identity'] = {'commit': HEAD, 'path': '.github/workflows/hospital-reading-cloud.yml', 'bytes': len(workflow), 'sha256': sha(workflow)}

# Bind four relevant original archives and every extracted entry to the manifest.
manifest = readjson(CAPTURE / 'artifact-manifest.json')
names = [f'{s}-{RUN}-1' for s in ['public-surfaces', 'windows-settings', 'windows-new_account', 'windows-persistence']]
archives = []
for name in names:
    candidates = [x for x in manifest if x['name'] == name]
    assert len(candidates) == 1
    entry = candidates[0]
    p = Path(entry['local_zip']); zident = ident(p)
    assert entry['workflow_run']['id'] == RUN and entry['workflow_run']['head_sha'] == HEAD
    assert entry['digest'] == 'sha256:' + zident['sha256'] and entry['size_in_bytes'] == zident['bytes']
    matched = []
    with zipfile.ZipFile(p) as z:
        files = [x for x in z.infolist() if not x.is_dir()]
        assert len({x.filename for x in files}) == len(files)
        for zi in files:
            extracted = ART / name / zi.filename
            assert z.read(zi) == extracted.read_bytes(), extracted
            matched.append({'entry': zi.filename, 'bytes': zi.file_size, 'sha256': ident(extracted)['sha256']})
    actual_files = sorted(x.relative_to(ART / name).as_posix() for x in (ART / name).rglob('*') if x.is_file())
    assert actual_files == sorted(x['entry'] for x in matched)
    archives.append({'artifact_id': entry['id'], 'name': name, 'zip': zident, 'workflow_run': entry['workflow_run'], 'digest_verified': True, 'extracted_entries_exact': matched})
report['capture_binding'] = {'artifact_manifest': ident(CAPTURE / 'artifact-manifest.json'), 'archives': archives}

# Source-bound successful Actions jobs, observed git checkout, exact output lines.
jobnames = {'public': 'Windows / public API surface contracts', 'settings': 'Windows / settings', 'new_account': 'Windows / new_account', 'persistence': 'Windows / persistence'}
jobs = readjson(CAPTURE / 'jobs.json')['jobs']
console = {}; jobreports = {}
for key, name in jobnames.items():
    found = [j for j in jobs if j['name'] == name]
    assert len(found) == 1
    job = found[0]
    assert (job['run_id'], job['run_attempt'], job['head_sha'], job['status'], job['conclusion']) == (RUN, 1, HEAD, 'completed', 'success')
    assert all(s['status'] == 'completed' and s['conclusion'] == 'success' for s in job['steps'])
    p = CAPTURE / 'logs' / f"{job['id']}.log"
    ls = [re.sub(r'^\d{4}-\d\d-\d\dT\S+Z ', '', s) for s in lines(p)]
    commands = [i for i, s in enumerate(ls) if s.startswith('[command]') and s.endswith(' log -1 --format=%H')]
    assert len(commands) == 1 and ls[commands[0] + 1] == HEAD
    rows = [(n, json.loads(s)) for n, s in enumerate(ls, 1) if s.startswith('{"suite_id":')]
    console[key] = {'lines': ls, 'receipts': rows}
    jobreports[key] = {'log': ident(p), 'job': {k: job[k] for k in ['id', 'run_id', 'run_attempt', 'head_sha', 'name', 'status', 'conclusion']},
                       'all_steps_completed_success': True, 'observed_checkout': {'command_line': commands[0] + 1, 'value_line': commands[0] + 2, 'value': HEAD},
                       'exact_markers': {}, 'process_receipt_count_by_suite': dict(collections.Counter(r['suite_id'] for _, r in rows))}
report['actions_console'] = {'jobs_snapshot': ident(CAPTURE / 'jobs.json'), 'jobs': jobreports}
def marker(job, text):
    ns = [i for i, s in enumerate(console[job]['lines'], 1) if s == text]
    assert len(ns) == 1, (job, text, ns)
    jobreports[job]['exact_markers'][text] = ns
    return ns[0]
def console_receipt(job, rec):
    matches = [(n, row) for n, row in console[job]['receipts'] if row['suite_id'] == rec['record']['suite_id']]
    assert len(matches) == 1 and matches[0][1] == rec['record']
    return matches[0][0]

settings = ART / f'windows-settings-{RUN}-1'
negative = settings / 'ci/storage-refusal'
results = readjson(negative / 'results.json')
assert [r['case'] for r in results] == ['empty', 'whitespace']
xmls = sorted(x.relative_to(negative).as_posix() for x in negative.rglob('*.xml'))
assert xmls == ['empty/tests.xml', 'whitespace/tests.xml']
expected_passes = {'test_clear_transient_consequence_checkpoints_does_not_depend_on_storage_readiness', 'test_prepare_consequence_checkpoint_requires_configuration', 'test_prepare_composes_the_autosave_journal_from_the_journals_own_proofs'}
case_sources = ['tests/unit/test_minesweeper_shop_purchase_participant.gd', 'tests/unit/test_save_manager_checkpoint_port.gd']
expected_cases = collections.Counter((p, n) for p in case_sources for n in re.findall(r'^func (test_\w+)\(', source[p].decode(), re.M))
assert len(expected_cases) == 83
refusals = {}
for rr in results:
    c = rr['case']; p = negative / c
    assert (rr['exit_code'], rr['tests'], rr['expected_root_refusals'], rr['storage_free_passes']) == (1, 83, 80, 3)
    xml = ET.parse(p / 'tests.xml').getroot(); cases = xml.findall('.//testcase'); fails = xml.findall('.//failure')
    assert xml.attrib['tests'] == '83' and xml.attrib['failures'] == '80'
    assert len(cases) == 83 and len(fails) == 80 and all('test_root_missing' in ''.join(f.itertext()) for f in fails)
    assert not xml.findall('.//error') and not xml.findall('.//skipped')
    assert collections.Counter((t.get('classname'), t.get('name')) for t in cases) == expected_cases
    passes = [t for t in cases if not list(t)]
    assert {t.get('name') for t in passes} == expected_passes and all(t.get('status') == 'pass' for t in passes)
    assert all(t.get('classname') == case_sources[1] for t in passes)
    assert all(t.get('status') == 'fail' and len(t.findall('failure')) == 1 for t in cases if list(t))
    before = p / 'repository-before.json'; after = p / 'repository-after.json'
    assert before.read_bytes() == after.read_bytes()
    snap = readjson(before)
    for path, b in source.items(): assert snap['file:' + path] == sha(b), path
    assert snap['file:.github/workflows/hospital-reading-cloud.yml'] == sha(workflow)
    proofs = []
    for f in ['user-dir-console.log', 'user-dir.log']:
        proof = logcheck(p / f)
        observed = [s.removeprefix('PHASE2R_USER_DIR=') for s in lines(p / f) if s.startswith('PHASE2R_USER_DIR=')]
        assert len(observed) == 1 and winpath(observed[0]) == winpath(rr['user_dir'])
        assert under(observed[0], f'D:/a/dwm/dwm/.godot/ci/storage-refusal/{c}')
        proof.update(observed_user_dir=observed[0], matches_results=True, strictly_under_case_root=True); proofs.append(proof)
    refusals[c] = {'xml': ident(p / 'tests.xml'), 'tests': len(cases), 'failure_nodes': len(fails), 'failures_containing_test_root_missing': len(fails),
                   'passes': [t.attrib for t in passes], 'errors': 0, 'skips': 0, 'script_case_counts': dict(collections.Counter(t.get('classname') for t in cases)),
                   'exact_named_source_cases': True, 'exit_code': rr['exit_code'], 'repository_before': ident(before), 'repository_after': ident(after),
                   'repository_snapshot_entries': len(snap), 'repository_bytes_equal': True, 'snapshot_source_hashes_verified': [*sources, '.github/workflows/hospital-reading-cloud.yml'],
                   'user_dir_proofs': proofs, 'logs': [logcheck(p / f) for f in ['godot.log', 'console.log']]}
setting_receipt = receipt(settings / 'ci/settings.jsonl', 'cloud-settings', 0)
console_receipt('settings', setting_receipt)
marker('settings', 'STORAGE_REFUSAL_VERIFIED: empty and whitespace roots refused without repository mutations.')
report['storage_refusal'] = {'results': {**ident(negative / 'results.json'), 'records': results}, 'exact_two_negative_xmls': xmls, 'cases': refusals, 'ordinary_settings_receipt': setting_receipt, 'console_marker_verified': True}

new = ART / f'windows-new_account-{RUN}-1'
newlog = new / 'phase2r_logs/cloud-new_account.log'; check = logcheck(newlog, [FF])
assert len(check['diagnostic_lines']) == 1
attributed = []; active_script = ''; active_test = ''
for n, s in enumerate(lines(newlog), 1):
    if re.fullmatch(r'res://tests/.+\.gd', s): active_script = s; active_test = ''
    if s.startswith('* test_'): active_test = s[2:]
    if DIAGNOSTIC.search(s): attributed.append({'line': n, 'script': active_script, 'test': active_test, 'text': s})
assert len(attributed) == 1 and attributed[0]['script'] == 'res://' + CASE_SCRIPT and attributed[0]['test'] == CASE and attributed[0]['text'] == FF
case_xml = [x for x in ET.parse(new / 'ci/new_account.xml').getroot().findall('.//testcase') if x.get('name') == CASE and x.get('classname') == CASE_SCRIPT]
assert len(case_xml) == 1 and case_xml[0].get('status') == 'pass' and not list(case_xml[0])
new_rec = receipt(new / 'ci/new_account.jsonl', 'cloud-new_account', 0)
console_receipt('new_account', new_rec)
marker('new_account', 'CORRUPT_SAVE_DIAGNOSTIC_VERIFIED: expected 0xff fixture diagnostic observed once.')
report['new_account_corrupt_save'] = {'log': check, 'attributed_diagnostics': attributed, 'exactly_one_expected_diagnostic': True, 'xml_case': case_xml[0].attrib,
                                     'xml': ident(new / 'ci/new_account.xml'), 'receipt': new_rec, 'console_marker_verified': True,
                                     'source_fixture_lines': [139, 149], 'source_wrapper_guard_lines': [275, 301]}

public = ART / f'public-surfaces-{RUN}-1'
timeout = receipt(public / 'ci/isolation-timeout.jsonl', 'fixture-timeout', 124)
assert 19 <= timeout['duration_seconds'] <= 50
engine = public / 'phase2r_logs/cloud-isolation-timeout.log'; timeoutlog = public / 'phase2r_logs/cloud-isolation-timeout.log.timeout.log'
assert lines(engine).count('ISOLATION_TIMEOUT_PROBE_STARTED') == 1
assert lines(timeoutlog).count('GODOT_CHILD_TIMEOUT: exceeded 20 seconds.') == 1
assert lines(timeoutlog).count('ISOLATION_TIMEOUT_PROBE_STARTED') == 1
marker('public', 'ISOLATION_HELPER: PASS')
isolation_commands = [i for i, s in enumerate(console['public']['lines'], 1) if s == './tests/tooling/Test-InvokeIsolatedGodot.ps1']
assert len(isolation_commands) == 1
helper = source['tests/tooling/Test-InvokeIsolatedGodot.ps1'].decode()
for token in ['fixture-forbidden-path', 'fixture-log-escape', 'fixture-evidence-stray', 'fixture-evidence-escape', 'fixture-valid', 'fixture-evidence-first', 'fixture-evidence-second', 'ISOLATION_HELPER: PASS']:
    assert token in helper
for statement in ['$forbidden.ExitCode -ne 124', '$escape.ExitCode -ne 124', '$stray.ExitCode -ne 124', '$escaped.ExitCode -ne 124', '$valid.ExitCode -ne 0', '$first.ExitCode -ne 0', '$second.ExitCode -ne 0', '$timeout.ExitCode -ne 124', '$timeoutDuration -lt 19 -or $timeoutDuration -gt 50']:
    assert statement in helper
assert helper.count("Write-Output 'ISOLATION_HELPER: PASS'") == 1
report['public_isolation'] = {'timeout_receipt': timeout, 'engine_log': logcheck(engine), 'timeout_log': logcheck(timeoutlog), 'timeout_bound_verified': True,
                             'source_expected_refusal_exits': {s: 124 for s in ['fixture-forbidden-path', 'fixture-log-escape', 'fixture-evidence-stray', 'fixture-evidence-escape']},
                             'source_expected_successes': ['fixture-valid', 'fixture-evidence-first', 'fixture-evidence-second'],
                             'forbidden_exits_runtime_corroborated': True, 'historical_root_cleanup_corroborated': True, 'helper_pass_marker_verified': True,
                             'corroboration_method': 'Actual-checkout helper assertions plus its exactly one final PASS in the successful public job; timeout independently has one retained JSONL and two nonempty logs. Forbidden child receipts are captured internally by helper and are not separately retained.'}
report['public_isolation']['source_assertion_references'] = {
    'path': 'tests/tooling/Test-InvokeIsolatedGodot.ps1', 'commit': HEAD,
    'forbidden_path_refusal': [51, 54], 'log_escape_refusal': [56, 59],
    'valid_probe_exit_keys_containment_cleanup': [61, 78], 'timeout_exit_receipt_logs_duration_cleanup': [100, 125],
    'closeout_successes_lf_ordered_append': [157, 180], 'missing_parent_refusal_and_noncreation': [186, 193],
    'evidence_escape_refusal': [195, 198], 'residue_cleanup': [199, 210], 'terminal_pass': 213,
    'review_note': 'All guards precede terminal PASS. Refusal assertions check expected exit124, not individual diagnostic strings. Historical mutation comments do not prove a new Broad2 mutation campaign.'}
jobreports['public']['isolation_command_line'] = isolation_commands[0]

standalone = {}
manualrec = receipt(settings / 'ci/manual-witness-revision-storage.jsonl', 'cloud-manual-witness-revision-storage', 0, 'tests/backup_storage/test_manual_witness_revision_storage.gd')
manuallog = settings / 'phase2r_logs/cloud-manual-witness-revision-storage.log'
manual_lines = lines(manuallog)
assert manual_lines.count('MANUAL_WITNESS_REVISION_STORAGE_PASS') == 1
stats = [json.loads(s) for s in manual_lines if s.startswith('{')]
assert len(stats) == 1 and stats[0]['failures'] == []
assert set(stats[0]) == {'assertions', 'distinct_snapshots', 'failures', 'refusal_pairs', 'restart_fault_pairs', 'restart_pairs', 'write_fault_pairs', 'write_pairs'}
assert all(type(v) is int and v > 0 for k, v in stats[0].items() if k != 'failures')
console_receipt('settings', manualrec); marker('settings', 'MANUAL_WITNESS_REVISION_STORAGE_PASS')
assert sum(s == json.dumps(stats[0], separators=(',', ':')) for s in console['settings']['lines']) == 1
standalone['manual_witness_revision_storage'] = {'receipt': manualrec, 'engine_log': logcheck(manuallog), 'marker': 'MANUAL_WITNESS_REVISION_STORAGE_PASS', 'marker_count': 1, 'stats': stats[0], 'console_receipt_matches_jsonl': True, 'console_marker_verified': True, 'console_stats_match_engine': True}

persistence = ART / f'windows-persistence-{RUN}-1'
capturerec = receipt(persistence / 'ci/save-load-capture.jsonl', 'cloud-save-load-capture', 0, 'tests/save_load_capture/test_capture.gd')
capturelog = persistence / 'phase2r_logs/cloud-save-load-capture.log'
capturemarkers = [s for s in lines(capturelog) if re.fullmatch(r'SAVE_LOAD_CAPTURE_PASS [0-9]+ checks; failures=0', s)]
assert len(capturemarkers) == 1
checks = int(capturemarkers[0].split()[1]); assert checks > 0
console_receipt('persistence', capturerec); marker('persistence', capturemarkers[0])
standalone['save_load_capture'] = {'receipt': capturerec, 'engine_log': logcheck(capturelog), 'marker': capturemarkers[0], 'marker_count': 1, 'checks': checks, 'console_receipt_matches_jsonl': True, 'console_marker_verified': True}

latencyrec = receipt(new / 'ci/new-account-latency.jsonl', 'cloud-new-account-latency', 0, 'tests/integration/verify_new_acc_latency.gd', ['--', '--phase2r-bootstrap-mode=final'])
latencylog = new / 'phase2r_logs/cloud-new-account-latency.log'; latencyreport = new / 'ci/new-account-latency.json'
latency = readjson(latencyreport)
assert latency['ok'] is True and len(latency['samples']) == 2 and sorted(s['case'] for s in latency['samples']) == ['fresh', 'replacement']
assert all(type(s['button_to_desktop_us']) is int and s['button_to_desktop_us'] > 0 and type(s['max_frame_gap_us']) is int and s['max_frame_gap_us'] >= 0 for s in latency['samples'])
latencymarkers = [s for s in lines(latencylog) if s.startswith('NEW_ACC_LATENCY_VERIFIED ')]
assert len(latencymarkers) == 1 and json.loads(latencymarkers[0].split(' ', 1)[1]) == latency
console_receipt('new_account', latencyrec); marker('new_account', latencymarkers[0])
standalone['new_account_latency'] = {'receipt': latencyrec, 'engine_log': logcheck(latencylog), 'marker': 'NEW_ACC_LATENCY_VERIFIED', 'marker_count': 1,
                                    'report': {**ident(latencyreport), 'value': latency, 'log_matches_report': True}, 'console_receipt_matches_jsonl': True, 'console_marker_verified': True,
                                    'interpretation': 'Correctness evidence and measurements only; no fixed machine-dependent performance budget is asserted.'}
all_roots = [r['record']['test_root'] for r in [setting_receipt, new_rec, timeout, manualrec, capturerec, latencyrec]]
assert len(all_roots) == len(set(all_roots))
report['standalone'] = standalone
report['isolated_receipt_roots_distinct'] = True
report['pending_console_corroboration'] = []
report['limitations'] = ['No engine or PowerShell execution performed by auditor; no connectors used.',
                         'Artifact copies cannot directly inspect deleted CI paths. Source-bound helper PASS corroborates cleanup and four refusal exits; those child receipts are not separately retained.',
                         'Storage refusal helper deliberately bypasses Invoke-IsolatedGodot; its child exits are retained in results.json rather than per-child JSONL.',
                         'The 166 intentional storage-refusal cases and all standalone assertion counts are excluded from ordinary GUT totals.',
                         'This is a bounded audit and does not declare whole-run acceptance.']
report['reproducible_audit_script'] = ident(Path(__file__))
target = OUT / 'negative-controls-subaudit.json'
target.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps({'status': report['status'], 'output': ident(target), 'storage_refusal': {c: [x['tests'], x['failure_nodes'], len(x['passes'])] for c, x in refusals.items()}, 'manual_witness': stats[0], 'capture_checks': checks, 'latency': latency, 'timeout_seconds': timeout['duration_seconds']}, indent=2))

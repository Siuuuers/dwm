# Day7 retained-history producer audit

**Pass for this bounded producer evidence review:** run `37048318182`, attempt 1, job `110976704737`, checkout `c9c013397f2e309b48fc1548490b401e54938c6c`, runtime source `a24f71766a624b57601814dda487b53c66518c39`. Four comparison consumers and the checkout-free aggregate remain outside this audit.

All **1031 checks** passed. Original ZIP digests/lengths/CRC and every extracted member were rechecked. Producer and transfer copies of `results.json`, `day7-autosave.json`, and the manifest are byte-identical.

- **35 isolated probes:** writer, disabled/enabled cold controls, 16 admission samples, and 16 manual-preparation samples. Unique contained roots, source arguments, execution order, bounded durations, zero exits, and clean import/engine/lifetime logs agree with their JSONL receipts.
- Days **1–7**, **98 synthetic checkpoint records**, and actual retained Autosave counts **32 line / 32 manual / 2 semantic**. Day7 is schema7 with 66 retained records. Its **1,910,332 bytes** hash to `0ac0f5afcaaafe72fa1dd70211ee1ee93d9c230c9a80d08b57154f7f16f34c8a`.
- Raw saved-state reconstruction independently reproduces cold restored gameplay, board, and journal hashes. The enabled/disabled controls and all admission samples restore those exact values. Writer-proof bytes were reconstructed and their hash independently matched.
- Eight alternating admission pairs and eight alternating **prepare_us** pairs reproduce all raw receipts, exact source ablations, profiles, differences, and medians. Each of the 16 preparation samples retains exactly **one strict write validation**, production write variant, all ten invariant values, and identical source/output identity joins.
- All **190 checkpoint**, **349 consequence**, **40 writer save/load**, **35 enabled reader**, and **35 disabled reader** profile rows match raw logs. Version2 diagnostics contain **35 matched successful autosave prepare/commit records**, complete nonnegative source-defined fields, proof Booleans, and the required splice-dependent timing. Every emitted profile aggregate and source-defined trace row was recomputed.

| Observed metric | Baseline median µs | Candidate median µs | Median paired candidate − baseline µs |
|---|---:|---:|---:|
| Cold Login admission | 10,611,740.0 | 9,204,158.5 | -1,411,621.5 |
| Manual preparation | 2,264,593.0 | 2,243,729.5 | -25,937.5 |

These are shared-runner observations, not fixed speed or frame-time guarantees. Timers are inclusive and must not be added. The history fixture is explicitly synthetic; production gameplay, restore, and storage owners are exercised.

The complete writer source directory and every manual Slot output are not exported. Their unchanged/equal hashes are retained cloud observations backed by the inspected source checks; the exported Autosave, reconstructed writer proof, baseline source bytes, and consumer transfer bytes are independently recomputed. No Godot or PowerShell ran locally, and no original evidence changed.

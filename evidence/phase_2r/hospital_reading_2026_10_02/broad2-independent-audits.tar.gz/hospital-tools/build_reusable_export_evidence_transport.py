#!/usr/bin/env python3
"""Build a metadata-bound, checkout-free GitHub artifact transport workflow.

The generated workflow downloads one exact GitHub artifact ZIP with a read-only
workflow token, validates its API identity and every ZIP member CRC, splits the
unchanged bytes into raw parts no larger than 25 MiB, verifies ordered
reassembly, and uploads the raw parts plus a sanitized manifest. This generator
and its self-tests never access the network, run an engine, or edit a repository.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
from pathlib import Path
import re
import tempfile
import zipfile

import yaml


MAX_CHUNK_BYTES = 25 * 1024 * 1024
WORKFLOW_REPOSITORY_PATH = ".github/workflows/export-evidence-transport.yml"
METADATA_KEYS = {
    "repository", "id", "name", "size_in_bytes", "digest", "run_id", "workflow_head"
}


def require(condition: bool, detail: str) -> None:
    if not condition:
        raise ValueError(detail)


def strict_json(raw: str):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, f"DUPLICATE_JSON_KEY: {key}")
            result[key] = value
        return result

    def constant(value):
        raise ValueError(f"NONFINITE_JSON_NUMBER: {value}")

    return json.loads(raw, object_pairs_hook=pairs, parse_constant=constant)


def identity_bytes(raw: bytes) -> dict:
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def identity_file(path: Path) -> dict:
    return {"bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def validate_metadata(value) -> dict:
    require(isinstance(value, dict) and set(value) == METADATA_KEYS,
            "EXACT_METADATA_KEYS_REQUIRED: " + ",".join(sorted(METADATA_KEYS)))
    require(isinstance(value["repository"], str)
            and re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", value["repository"]),
            "EXACT_REPOSITORY_REQUIRED")
    require(type(value["id"]) is int and value["id"] > 0, "POSITIVE_ARTIFACT_ID_REQUIRED")
    require(isinstance(value["name"], str) and 0 < len(value["name"]) <= 256
            and not re.search(r"[\x00-\x1f\x7f]", value["name"]), "SAFE_ARTIFACT_NAME_REQUIRED")
    require(type(value["size_in_bytes"]) is int and value["size_in_bytes"] > 0,
            "POSITIVE_ARTIFACT_SIZE_REQUIRED")
    require(isinstance(value["digest"], str)
            and re.fullmatch(r"sha256:[0-9a-f]{64}", value["digest"]), "EXACT_SHA256_DIGEST_REQUIRED")
    require(type(value["run_id"]) is int and value["run_id"] > 0, "POSITIVE_RUN_ID_REQUIRED")
    require(isinstance(value["workflow_head"], str)
            and re.fullmatch(r"[0-9a-f]{40}", value["workflow_head"]), "EXACT_WORKFLOW_HEAD_REQUIRED")
    return dict(value)


def validate_parent(value: str) -> str:
    require(re.fullmatch(r"[0-9a-f]{40}", value or "") is not None, "EXACT_PARENT_SHA_REQUIRED")
    return value


def validate_branch(value: str) -> str:
    require(isinstance(value, str) and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._/-]{0,199}", value or "") is not None,
            "SAFE_BRANCH_REQUIRED")
    require(not any(token in value for token in ("..", "//", "@{", "\\"))
            and not value.endswith(("/", ".", ".lock"))
            and all(part and not part.startswith(".") for part in value.split("/")), "SAFE_BRANCH_REQUIRED")
    return value


SPLITTER_TEMPLATE = r'''import hashlib
import json
import os
from pathlib import Path
import zipfile


def require(condition, detail):
    if not condition:
        raise ValueError(detail)


def strict_json(text):
    def pairs(values):
        result = {}
        for key, value in values:
            require(key not in result, 'DUPLICATE_JSON_KEY')
            result[key] = value
        return result
    def constant(value):
        raise ValueError('NONFINITE_JSON_NUMBER: ' + value)
    return json.loads(text, object_pairs_hook=pairs, parse_constant=constant)


def sha256(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def verify_split(archive, api_metadata, destination, expected, chunk_bytes, transport):
    require(set(api_metadata) == {'id', 'name', 'size_in_bytes', 'digest', 'expired', 'workflow_run'},
            'EXACT_API_METADATA_KEYS_REQUIRED')
    require(api_metadata.get('id') == expected['id'], 'SOURCE_ARTIFACT_ID_MISMATCH')
    require(api_metadata.get('name') == expected['name'], 'SOURCE_ARTIFACT_NAME_MISMATCH')
    require(api_metadata.get('expired') is False, 'SOURCE_ARTIFACT_EXPIRED')
    require(api_metadata.get('size_in_bytes') == expected['size_in_bytes'], 'SOURCE_API_SIZE_MISMATCH')
    require(api_metadata.get('digest') == expected['digest'], 'SOURCE_API_DIGEST_MISMATCH')
    source_run = api_metadata.get('workflow_run')
    require(isinstance(source_run, dict) and set(source_run) == {'id', 'head_sha'},
            'EXACT_WORKFLOW_RUN_KEYS_REQUIRED')
    require(source_run.get('id') == expected['run_id'], 'SOURCE_RUN_MISMATCH')
    require(source_run.get('head_sha') == expected['workflow_head'], 'SOURCE_WORKFLOW_HEAD_MISMATCH')
    require(transport.get('GITHUB_REPOSITORY') == expected['repository'], 'TRANSPORT_REPOSITORY_MISMATCH')
    require(archive.is_file() and not archive.is_symlink(), 'ORIGINAL_ZIP_REQUIRED')
    require(archive.stat().st_size == expected['size_in_bytes'], 'ORIGINAL_ZIP_SIZE_MISMATCH')
    require(sha256(archive) == expected['digest'][7:], 'ORIGINAL_ZIP_SHA256_MISMATCH')
    require(type(chunk_bytes) is int and 0 < chunk_bytes <= 25 * 1024 * 1024,
            'BOUNDED_CHUNK_SIZE_REQUIRED')
    with zipfile.ZipFile(archive) as opened:
        members = opened.infolist()
        require(bool(members), 'EMPTY_ORIGINAL_ZIP')
        require(opened.testzip() is None, 'ORIGINAL_ZIP_CRC_MISMATCH')
        member_count = len(members)
    # No output directory or chunk exists until metadata, original identity and every member CRC pass.
    require(not destination.exists(), 'REFUSE_EXISTING_TRANSPORT_OUTPUT')
    destination.mkdir(parents=True)
    chunks = []
    with archive.open('rb') as stream:
        offset = 0
        index = 1
        while data := stream.read(chunk_bytes):
            require(len(data) <= chunk_bytes, 'CHUNK_SIZE_LIMIT_EXCEEDED')
            name = f'original.zip.part{index:03d}'
            path = destination / name
            with path.open('xb') as output:
                output.write(data)
            chunks.append({'index': index, 'file': name, 'offset': offset,
                           'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
            offset += len(data)
            index += 1
        require(offset == expected['size_in_bytes'], 'SPLIT_BYTE_COUNT_MISMATCH')
    require(bool(chunks), 'NO_CHUNKS_WRITTEN')
    combined = hashlib.sha256()
    combined_bytes = 0
    for expected_index, chunk in enumerate(chunks, 1):
        require(chunk['index'] == expected_index and chunk['offset'] == combined_bytes,
                'NONCONTIGUOUS_CHUNK_ORDER')
        path = destination / chunk['file']
        require(path.stat().st_size == chunk['bytes'] and chunk['bytes'] <= chunk_bytes
                and sha256(path) == chunk['sha256'], 'WRITTEN_CHUNK_MISMATCH')
        with path.open('rb') as stream:
            while data := stream.read(1024 * 1024):
                combined.update(data)
                combined_bytes += len(data)
    require(combined_bytes == expected['size_in_bytes'] and combined.hexdigest() == expected['digest'][7:],
            'REASSEMBLED_ORIGINAL_IDENTITY_MISMATCH')
    manifest = {
        'schema_version': 2,
        'purpose': 'Exact original GitHub artifact ZIP transport; no engine execution or evidence reinterpretation.',
        'source_artifact': dict(expected),
        'original_zip': {'bytes': expected['size_in_bytes'], 'sha256': expected['digest'][7:],
                         'crc_verified': True, 'member_count': member_count},
        'chunk_size_limit': chunk_bytes,
        'chunk_count': len(chunks),
        'chunks': chunks,
        'ordered_chunk_reassembly_matches_original': True,
        'transport_execution': {key: transport.get(key, '') for key in
                                ('GITHUB_REPOSITORY', 'GITHUB_RUN_ID', 'GITHUB_RUN_ATTEMPT',
                                 'GITHUB_SHA', 'GITHUB_JOB')},
        'reassembly': 'Concatenate raw chunk contents in ascending index, verify each chunk and final original size/SHA256, then verify original ZIP CRC before normal extraction/audit.',
        'limits': ['Transport success is not original workflow or exported-build acceptance.',
                   'Uploaded artifacts are wrappers; reconstruct from their extracted raw part files.'],
    }
    forbidden_keys = {'url', 'archive_download_url', 'token', 'authorization', 'local_path', 'signed_url'}
    def check_sanitized(value):
        if isinstance(value, dict):
            require(not (set(value) & forbidden_keys), 'UNSANITIZED_MANIFEST_KEY')
            for nested in value.values():
                check_sanitized(nested)
        elif isinstance(value, list):
            for nested in value:
                check_sanitized(nested)
    check_sanitized(manifest)
    manifest_path = destination / 'transport-manifest.json'
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    require(strict_json(manifest_path.read_text(encoding='utf-8')) == manifest,
            'MANIFEST_JSON_ROUNDTRIP_MISMATCH')
    return manifest


if __name__ == '__main__':
    expected = EXPECTED_PLACEHOLDER
    root = Path(os.environ['DWM_EXPORT_TRANSPORT_ROOT'])
    api_metadata = strict_json((root / 'source-metadata.json').read_text(encoding='utf-8'))
    transport = {key: os.environ.get(key, '') for key in
                 ('GITHUB_REPOSITORY', 'GITHUB_RUN_ID', 'GITHUB_RUN_ATTEMPT', 'GITHUB_SHA', 'GITHUB_JOB')}
    manifest = verify_split(root / 'original.zip', api_metadata, root / 'parts', expected,
                            CHUNK_PLACEHOLDER, transport)
    require(manifest['chunk_count'] == EXPECTED_PART_COUNT_PLACEHOLDER, 'UNEXPECTED_CHUNK_COUNT')
    print(json.dumps({'original_sha256': manifest['original_zip']['sha256'],
                      'original_bytes': manifest['original_zip']['bytes'],
                      'chunk_count': manifest['chunk_count'], 'crc_verified': True,
                      'reassembly_verified': True}))
'''


def embedded_splitter(expected: dict, chunk_bytes: int) -> str:
    part_count = (expected["size_in_bytes"] + chunk_bytes - 1) // chunk_bytes
    return (SPLITTER_TEMPLATE.replace("EXPECTED_PLACEHOLDER", repr(expected))
            .replace("CHUNK_PLACEHOLDER", str(chunk_bytes))
            .replace("EXPECTED_PART_COUNT_PLACEHOLDER", str(part_count)))


def build_workflow(expected: dict, branch: str, chunk_bytes: int) -> tuple[bytes, str]:
    splitter = embedded_splitter(expected, chunk_bytes)
    repository = expected["repository"]
    artifact_id = expected["id"]
    root_line = 'export DWM_EXPORT_TRANSPORT_ROOT="$RUNNER_TEMP/export-evidence-transport"'
    steps = [
        {
            "name": "Download exact original artifact ZIP with read-only workflow token",
            "env": {"GH_TOKEN": "${{ github.token }}"},
            "run": (
                "set -euo pipefail\n" + root_line + "\n"
                "mkdir -p \"$DWM_EXPORT_TRANSPORT_ROOT\"\n"
                f"gh api repos/{repository}/actions/artifacts/{artifact_id} "
                "--jq '{id,name,size_in_bytes,digest,expired,workflow_run:{id:.workflow_run.id,head_sha:.workflow_run.head_sha}}' "
                "> \"$DWM_EXPORT_TRANSPORT_ROOT/source-metadata.json\"\n"
                f"gh api repos/{repository}/actions/artifacts/{artifact_id}/zip "
                "> \"$DWM_EXPORT_TRANSPORT_ROOT/original.zip\"\n"
            ),
        },
        {
            "name": "Verify source identity and CRC, split raw bytes, and verify reassembly",
            "run": "set -euo pipefail\n" + root_line + "\npython3 - <<'PY'\n" + splitter + "PY\n",
        },
    ]
    part_count = (expected["size_in_bytes"] + chunk_bytes - 1) // chunk_bytes
    for index in range(1, part_count + 1):
        steps.append({
            "name": f"Upload original ZIP raw chunk {index:03d}",
            "uses": "actions/upload-artifact@v4",
            "with": {
                "name": f"export-artifact-{artifact_id}-part{index:03d}-${{{{ github.run_id }}}}-${{{{ github.run_attempt }}}}",
                "path": f"${{{{ runner.temp }}}}/export-evidence-transport/parts/original.zip.part{index:03d}",
                "compression-level": 0,
                "if-no-files-found": "error",
                "retention-days": 7,
            },
        })
    steps.append({
        "name": "Upload sanitized original and chunk identity manifest",
        "uses": "actions/upload-artifact@v4",
        "with": {
            "name": f"export-artifact-{artifact_id}-transport-manifest-${{{{ github.run_id }}}}-${{{{ github.run_attempt }}}}",
            "path": "${{ runner.temp }}/export-evidence-transport/parts/transport-manifest.json",
            "compression-level": 0,
            "if-no-files-found": "error",
            "retention-days": 7,
        },
    })
    workflow = {
        "name": "Exact original export artifact transport",
        "on": {"push": {"branches": [branch]}},
        "permissions": {"contents": "read", "actions": "read"},
        "concurrency": {"group": "export-evidence-transport-${{ github.ref }}", "cancel-in-progress": False},
        "jobs": {
            "transport-original-export": {
                "name": "Transport exact original export evidence",
                "runs-on": "ubuntu-24.04",
                "timeout-minutes": 20,
                "defaults": {"run": {"shell": "bash"}},
                "steps": steps,
            }
        },
    }
    raw = yaml.safe_dump(workflow, sort_keys=False, width=120).encode()
    require(yaml.safe_load(raw) == workflow, "WORKFLOW_YAML_ROUNDTRIP_MISMATCH")
    require("env" not in workflow["jobs"]["transport-original-export"], "JOB_ENV_REFUSED")
    require(not any(step.get("uses", "").startswith("actions/checkout") for step in steps),
            "CHECKOUT_REFUSED")
    require(all(root_line in step["run"] for step in steps if "run" in step),
            "SHELL_RUNNER_TEMP_REQUIRED")
    require(raw.count(b"GH_TOKEN") == 1, "TOKEN_SCOPE_MUST_BE_ONE_STEP")
    require(len([step for step in steps if step.get("uses") == "actions/upload-artifact@v4"])
            == part_count + 1, "UPLOAD_COUNT_MISMATCH")
    ast.parse(splitter)
    return raw, splitter


def self_test(splitter: str) -> dict:
    namespace = {"__name__": "transport_selftest"}
    exec(compile(splitter, "<embedded-splitter>", "exec"), namespace)
    verify_split = namespace["verify_split"]
    with tempfile.TemporaryDirectory(prefix="reusable-export-transport-") as temporary:
        root = Path(temporary)
        archive = root / "synthetic.zip"
        with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_STORED) as output:
            timestamp = (2000, 1, 1, 0, 0, 0)
            output.writestr(zipfile.ZipInfo("raw-data.bin", timestamp), bytes(range(256)) * 40)
            output.writestr(zipfile.ZipInfo("nested/receipt.json", timestamp), '{"ok":true}\n')
        raw = archive.read_bytes()
        expected = {
            "repository": "Siuuuers/dwm",
            "id": 123456,
            "name": "synthetic-export",
            "size_in_bytes": len(raw),
            "digest": "sha256:" + hashlib.sha256(raw).hexdigest(),
            "run_id": 654321,
            "workflow_head": "1" * 40,
        }
        metadata = {
            "id": expected["id"], "name": expected["name"], "expired": False,
            "size_in_bytes": expected["size_in_bytes"], "digest": expected["digest"],
            "workflow_run": {"id": expected["run_id"], "head_sha": expected["workflow_head"]},
        }
        transport = {"GITHUB_REPOSITORY": expected["repository"]}
        manifest = verify_split(archive, metadata, root / "valid-parts", expected, 3072, transport)
        require(all(item["bytes"] <= 3072 for item in manifest["chunks"]), "SYNTHETIC_CHUNK_BOUND_FAILED")
        reconstructed = b"".join((root / "valid-parts" / item["file"]).read_bytes()
                                 for item in manifest["chunks"])
        require(reconstructed == raw and archive.read_bytes() == raw, "SYNTHETIC_REASSEMBLY_FAILED")
        require(strict_json((root / "valid-parts/transport-manifest.json").read_text()) == manifest,
                "SYNTHETIC_MANIFEST_ROUNDTRIP_FAILED")
        refusals = []
        changed_cases = {
            "id": dict(metadata, id=0),
            "name": dict(metadata, name="wrong"),
            "size": dict(metadata, size_in_bytes=1),
            "digest": dict(metadata, digest="sha256:" + "0" * 64),
            "expired": dict(metadata, expired=True),
            "run": dict(metadata, workflow_run={"id": 0, "head_sha": expected["workflow_head"]}),
            "head": dict(metadata, workflow_run={"id": expected["run_id"], "head_sha": "0" * 40}),
        }
        for label, changed in changed_cases.items():
            destination = root / ("reject-" + label)
            try:
                verify_split(archive, changed, destination, expected, 3072, transport)
            except ValueError:
                require(not destination.exists(), "REFUSAL_EMITTED_OUTPUT: " + label)
                refusals.append(label)
            else:
                raise AssertionError("Did not reject " + label)
        try:
            verify_split(archive, metadata, root / "reject-repository", expected, 3072,
                         {"GITHUB_REPOSITORY": "wrong/repository"})
        except ValueError:
            require(not (root / "reject-repository").exists(), "REPOSITORY_REFUSAL_EMITTED_OUTPUT")
            refusals.append("repository")
        else:
            raise AssertionError("Did not reject repository")
        corrupted = root / "corrupted.zip"
        bad = bytearray(raw)
        with zipfile.ZipFile(archive) as opened:
            info = opened.getinfo("raw-data.bin")
            data_offset = info.header_offset + 30 + len(info.filename.encode()) + len(info.extra)
        bad[data_offset] ^= 1
        corrupted.write_bytes(bad)
        bad_expected = dict(expected, size_in_bytes=len(bad),
                            digest="sha256:" + hashlib.sha256(bad).hexdigest())
        bad_metadata = dict(metadata, digest=bad_expected["digest"])
        try:
            verify_split(corrupted, bad_metadata, root / "reject-crc", bad_expected, 3072, transport)
        except (ValueError, zipfile.BadZipFile):
            require(not (root / "reject-crc").exists(), "CRC_REFUSAL_EMITTED_OUTPUT")
            refusals.append("member_crc")
        else:
            raise AssertionError("Did not reject CRC corruption")
        try:
            verify_split(corrupted, metadata, root / "reject-original-sha", expected, 3072, transport)
        except ValueError:
            require(not (root / "reject-original-sha").exists(), "SHA_REFUSAL_EMITTED_OUTPUT")
            refusals.append("downloaded_original_sha256")
        else:
            raise AssertionError("Did not reject changed original bytes")
        try:
            verify_split(archive, metadata, root / "reject-chunk-limit", expected,
                         MAX_CHUNK_BYTES + 1, transport)
        except ValueError:
            require(not (root / "reject-chunk-limit").exists(), "CHUNK_LIMIT_REFUSAL_EMITTED_OUTPUT")
            refusals.append("chunk_size_over_25_mib")
        else:
            raise AssertionError("Did not reject oversized chunks")
        return {
            "passed": True,
            "synthetic_zip": identity_bytes(raw),
            "member_count": 2,
            "chunk_count": manifest["chunk_count"],
            "all_chunks_within_limit": True,
            "ordered_reassembly_byte_identical": True,
            "original_untouched": True,
            "saved_manifest_json_roundtrip": True,
            "manifest_sanitization_checked": True,
            "refusals_before_chunk_creation": refusals,
        }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--metadata", type=Path, required=True,
                        help="Strict JSON with repository,id,name,size_in_bytes,digest,run_id,workflow_head")
    parser.add_argument("--parent", required=True, help="Exact intended publication parent commit")
    parser.add_argument("--branch", required=True, help="Exact push-trigger branch for the generated workflow")
    parser.add_argument("--output", type=Path, required=True, help="New workflow YAML output")
    parser.add_argument("--chunk-bytes", type=int, default=MAX_CHUNK_BYTES,
                        help="Raw part size, positive and no larger than 25 MiB")
    args = parser.parse_args()

    metadata_raw = args.metadata.read_bytes()
    expected = validate_metadata(strict_json(metadata_raw.decode("utf-8-sig")))
    parent = validate_parent(args.parent)
    branch = validate_branch(args.branch)
    require(type(args.chunk_bytes) is int and 0 < args.chunk_bytes <= MAX_CHUNK_BYTES,
            "BOUNDED_CHUNK_SIZE_REQUIRED")
    require(args.output.suffix.lower() in (".yml", ".yaml"), "YAML_OUTPUT_REQUIRED")

    workflow_raw, splitter = build_workflow(expected, branch, args.chunk_bytes)
    tests = self_test(splitter)
    part_count = (expected["size_in_bytes"] + args.chunk_bytes - 1) // args.chunk_bytes
    review = {
        "schema_version": 1,
        "scope": "Reusable metadata-bound workflow generation plus offline static and synthetic checks only.",
        "workflow_repository_path": WORKFLOW_REPOSITORY_PATH,
        "branch": branch,
        "expected_publication_parent": parent,
        "metadata_input": {"path": str(args.metadata.resolve()), **identity_bytes(metadata_raw)},
        "expected_source_artifact": expected,
        "permissions": {"contents": "read", "actions": "read"},
        "checkout_required": False,
        "engine_execution": False,
        "network_access_by_generator": False,
        "repository_or_game_edits": False,
        "github_context_placement": "No job-level runner context; shell steps derive the work path from RUNNER_TEMP. runner.temp appears only in upload step inputs.",
        "original_zip_preserved": True,
        "chunk_bytes": args.chunk_bytes,
        "expected_chunk_count": part_count,
        "upload_count": part_count + 1,
        "upload_compression_level": 0,
        "manifest_sanitized": True,
        "secret_handling": "GH_TOKEN is scoped only to the read-only download step environment; API output is reduced to exact identity fields and no token, URL or local path enters the transport manifest.",
        "workflow": identity_bytes(workflow_raw),
        "embedded_splitter": identity_bytes(splitter.encode()),
        "helper": {"path": str(Path(__file__).resolve()), **identity_file(Path(__file__))},
        "static_and_synthetic_checks": tests,
        "pending": [
            "Review exact metadata, parent, branch and generated bytes before any publication.",
            "Run the generated workflow only with separate authorization.",
            "Capture wrapper artifacts, extract raw parts, verify ordered original identity/CRC, then perform the normal bounded export audit.",
        ],
    }
    review_raw = (json.dumps(review, indent=2, sort_keys=True) + "\n").encode()
    review_path = args.output.with_name(args.output.name + ".static-review.json")
    outputs = ((args.output, workflow_raw), (review_path, review_raw))
    for path, data in outputs:
        if path.exists():
            require(path.read_bytes() == data, "REFUSE_DIFFERING_RETAINED_OUTPUT: " + str(path))
    for path, data in outputs:
        path.parent.mkdir(parents=True, exist_ok=True)
        if not path.exists():
            path.write_bytes(data)
    print(json.dumps({
        "workflow": str(args.output),
        "static_review": str(review_path),
        "workflow_identity": identity_bytes(workflow_raw),
        "helper_identity": review["helper"],
        "expected_chunk_count": part_count,
        "synthetic_checks_passed": True,
    }))


if __name__ == "__main__":
    main()

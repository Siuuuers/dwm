# Broad2 Windows export audit

Status: qualified bounded pass. `windows-export-audit.json` records 73 successful static checks binding the original artifact, cloud source/checkout/job, nested archive, 17 payload files, 111 runtime data files and isolated 240-iteration headless startup. No local engine or executable ran.

The exporter's combined console includes the same ObjectDB instances-leaked-at-exit warning as Broad1. Warning-free, leak-free and exporter-lifetime acceptance are excluded. The cause, object count and owner are not established; combined stdout/stderr file order is not a temporal trace. The separate diagnostic review and Broad1 additive erratum retain this distinction.

`audit_export.strict-initial.py` preserves the initial stricter scratch checker that stopped on the warning. `audit_export.py` enforces the unchanged canonical functional diagnostic patterns and separately requires the exact known warning, the Broad1 byte identity and absence from the other exported runtime logs. It does not change production validation or dismiss the warning as harmless.

The original binary bytes and transport chunks are excluded from repository packaging; exact original and nested identities are retained. Repository records do not promise permanent binary archival after Actions expiry.

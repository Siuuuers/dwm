# Broad2 Hospital semantic audit

**All fifteen independent Hospital check groups passed on Broad2’s own bytes.** This component result does not declare whole broad acceptance.

Run `37048318182`, attempt 1, Hospital job `110976704735`, artifact `11246075745`. Actual checkout `c9c013397f2e309b48fc1548490b401e54938c6c`; runtime source `a24f71766a624b57601814dda487b53c66518c39`. Source9 changes only three PowerShell performance files; all three Hospital runner/helper/verifier identities match both runtime source and actual checkout. The observed Actions checkout agrees.

Original ZIP: 4,646,071 bytes, SHA256 `9380fcd20ddb5f2579dcce44088bc610f07c39941daa03cda330f16c7b326e70`. All 112 entries, 20 writer-sealed files, 42 raw manifest records and the exact 12-row writer prefix in the final 22-row trace are verified.

| Proof | Broad2 observation |
|---|---|
| Fresh processes | Writer 3882, reader 3957, forge 4023; distinct, exit zero, one PASS each, no timeout/script/Unicode/lifetime errors |
| Slot3 | 168,414 bytes; seven identical copies; SHA256 `6b37789ccabff3fca055ed997e300b847ef676304954cc1f4ab2887e731ac07d` |
| Raw saved authority | Real accepted Sylvia Schedule-Done sources reconstruct command, physical token and shared frame; strict Hospital schema3 and exact A/B frontier |
| Partial B | 8 / 202 characters; Pause/Cancel/Continue/History preserve source; Save completes only B |
| Fresh Load | One B start at frame 11; no A, speech, new witness or completion; exact input Profile and History |
| Ordinary completion | Enter press/release frames 52/53; one matching Hospital native end and physical receipt |
| Settlement | Durable Day4, exact completed Hospital receipt, health6 / pressure3, missed Sylvia date, one witness; separately observed live desktop |
| Next Solo | Fresh Day4 Priscilla session; only `fixture.next.solo.pre.a`, no Hospital rows |
| Forgeries | Both exact mutations independently refuse before installation; all four primary states unchanged; Quick absent |

Command SHA256: `506688bcceb0d9b7548519ffc0a017d05ae83df4e8a93c41ecd0dedbc31f9278`. Physical token: `narrative_presentation.e7fd6e929351e8aca210efbc145566110beb7c48e0816b65dbd15b820582a071`.

Settled Autosave: 234,531 bytes, SHA256 `c77b8257c9700bb98f0e805c20a2a45feb2249ea142ee73a01a77946d05c1f76`. It retains `route_id=hospital`, `between_entries` and `unlock_day=pending`; later live observation establishes completed unlock and desktop focus. Do not describe the retained Autosave as already containing the desktop route.

The later other-generation native end belongs to next-Solo teardown. Same-frame callback order reflects nested signals and is not a separate causal dispatch-order proof. Reader Autosave/Profile changes are legitimate progression; whole-primary invariance is asserted during forge only.

Five capture identities and 1280×720 dimensions are verified; the two Hospital History images are byte-identical. Root reviews these originals visually. This audit carries over no earlier-run image acceptance.

No engine, PowerShell, connector, repository edit or raw-evidence mutation occurred. The JSON contains all fifteen groups, actual receipts, source identities, input hashes and the archive census. The fixture remains bounded noncanonical Day3/Sylvia Schedule-Done evidence; production content, other ingresses/conditions, pair/ending continuity, all days and native accessibility remain outside this proof.

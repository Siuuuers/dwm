#!/usr/bin/env python3
"""Independent retained-byte Hospital audit. No engine, runner import, or network."""
from pathlib import Path
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import math
import re
import struct
import subprocess
import zipfile

B = Path('/workspace/scratch/e58f796fe7a3')
OUT = B / 'hospital-broad2-semantic-audit'
CAP = B / 'hospital-broad2'
ART = CAP / 'artifacts/hospital-reading-37048318182-1'
ROOT = next(ART.glob('*/result.json')).parent
RAW = ROOT / 'raw-evidence'
SEALED = ROOT / 'sealed-write'
HEAD = 'c9c013397f2e309b48fc1548490b401e54938c6c'
SOURCE = 'a24f71766a624b57601814dda487b53c66518c39'
RUN = 37048318182
ENTRY = 'hospital.faint.day3'
LINES = ['fixture.hospital.a', 'fixture.hospital.b']
MODES = ['write', 'read', 'forge']
STAGES = {
    'write': ['prior_solo', 'prior_retired', 'hospital_a', 'paused_b', 'pause_cancelled', 'availability',
              'pause_continued', 'hospital-partial-history-entered', 'hospital-partial-history-closed',
              'pause_reentered', 'backup_entered', 'saved'],
    'read': ['loaded', 'hospital-restored-history-entered', 'hospital-restored-history-closed',
             'completion_input', 'settled', 'next_solo', 'next-solo-history-entered', 'next-solo-history-closed'],
    'forge': ['forge-frame', 'forge-caption']}
checks = []


def identity(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def fileid(path):
    return {'path': str(path), **identity(path.read_bytes())}


def pairs(items):
    out = {}
    for key, value in items:
        assert key not in out, ('duplicate JSON key', key)
        out[key] = value
    return out


def forbidden(value):
    raise ValueError('Nonfinite JSON number: ' + value)


def finite(value):
    number = float(value)
    assert math.isfinite(number)
    return number


def parse(text):
    return json.loads(text, object_pairs_hook=pairs, parse_constant=forbidden, parse_float=finite)


def read(path):
    return parse(path.read_text(encoding='utf-8-sig'))


def rows(path):
    return [parse(line) for line in path.read_text().splitlines() if line.strip()]


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()


def check(name, details):
    checks.append({'check': name, 'passed': True, 'details': details})


def git(ref, path):
    return subprocess.check_output(['git', 'show', ref + ':' + path], cwd=B / 'dwm')


def state(stage):
    return {key: stage[key] for key in ['source', 'native']}


def native(native, partial):
    assert native['line_id'] == LINES[1]
    assert type(native['visible_characters']) is int and type(native['total_characters']) is int
    assert native['total_characters'] > 0
    if partial:
        assert native['revealing'] is True and 0 <= native['visible_ratio'] < 1
        assert 0 <= native['visible_characters'] < native['total_characters']
    else:
        assert native['revealing'] is False and native['visible_ratio'] == 1
        assert native['visible_characters'] == -1 or native['visible_characters'] >= native['total_characters']


def input_protocol(value, keys, source_line):
    assert value['packet_type'] == 'InputEventKey' and value['source_line'] == source_line
    assert value['contacts_after'] == {} and len(value['events']) == len(keys) * 2
    frame = -1; generation = -1
    for index, event in enumerate(value['events']):
        down = index % 2 == 0
        assert event['pressed'] is down and event['key'] == keys[index // 2]
        assert type(event['frame']) is int and event['frame'] > frame
        if down:
            assert len(event['contacts']) == 1
            current = next(iter(event['contacts'].values()))
            assert type(current) is int and current > generation
            generation = current
        else:
            assert event['contacts'] == {}
        frame = event['frame']


def history_pair(stages, label, line_ids):
    entered, closed = stages[label + '-entered'], stages[label + '-closed']
    assert state(entered) == state(closed)
    assert [row['line_id'] for row in entered['source']['history']['captions']] == line_ids
    ui, after = entered['ui'], closed['ui']
    assert ui['tree_paused'] and ui['history_open'] and ui['history_focus'] and ui['focus_owner']
    assert ui['bridge_suspension']['ok'] and ui['bridge_suspension']['value']['state'] == 'Suspended' and ui['bridge_pause_handle']
    assert not after['tree_paused'] and not after['history_open'] and after['history_button_focus']
    assert after['bridge_pause_handle'] == {} and after['bridge_suspension']['value']['state'] == 'Active'


before_hashes = {p.relative_to(ART).as_posix(): identity(p.read_bytes()) for p in ART.rglob('*') if p.is_file()}
manifest = read(CAP / 'artifact-manifest.json')
meta, = [x for x in manifest if x['name'] == ART.name]
assert meta['workflow_run']['id'] == RUN and meta['workflow_run']['head_sha'] == HEAD
zip_path = Path(meta['local_zip'])
zip_raw = zip_path.read_bytes()
assert identity(zip_raw) == {'bytes': meta['size_in_bytes'], 'sha256': meta['digest'].split(':')[1]}
archive_entries = []
with zipfile.ZipFile(zip_path) as z:
    assert z.testzip() is None
    for member in z.infolist():
        if member.is_dir():
            continue
        assert not Path(member.filename).is_absolute() and '..' not in Path(member.filename).parts
        local = ART / member.filename
        assert local.is_file() and local.read_bytes() == z.read(member.filename)
        archive_entries.append({'member': member.filename, **identity(local.read_bytes())})
assert len(archive_entries) == len(before_hashes) == 112
check('Original artifact bytes', {'zip': fileid(zip_path), 'api_artifact_id': meta['id'],
                                'matched_archive_file_entries': len(archive_entries), 'zip_crc_ok': True})

result = read(ROOT / 'result.json')
assert result == read(ART / 'result.json')
assert result['checkout_sha'] == HEAD
assert result['workflow'] == {'GITHUB_RUN_ID': str(RUN), 'GITHUB_RUN_ATTEMPT': '1',
                             'GITHUB_JOB': 'rendered-hospital-reading', 'GITHUB_SHA': HEAD}
source_ids = result['source_identity']
assert set(source_ids) == {'tools/testing/run_hospital_reading_journey.py', 'tools/testing/run_cloud_journeys.py',
                           'tests/integration/verify_hospital_reading_journey.gd'}
for path, expected in source_ids.items():
    assert identity(git(HEAD, path)) == identity(git(SOURCE, path)) == expected
    assert identity(git('856520f09440d9b47cc272de3363009924ffedca', path)) == expected
changed = subprocess.check_output(['git', 'diff', '--name-only', '856520f09440d9b47cc272de3363009924ffedca', SOURCE], cwd=B / 'dwm', text=True).splitlines()
assert changed == ['tools/testing/Assert-WarmOutgoingProofBaseline.ps1', 'tools/testing/Invoke-HistoryRegionSearchPerformance.ps1', 'tools/testing/Invoke-WarmOutgoingProofPerformance.ps1']
assert subprocess.check_output(['git', 'diff', '--name-only', SOURCE, HEAD], cwd=B / 'dwm', text=True).splitlines() == ['.github/workflows/hospital-reading-cloud.yml']
jobs_obj = read(CAP / 'jobs.json'); jobs = jobs_obj['jobs'] if isinstance(jobs_obj, dict) else jobs_obj
job, = [j for j in jobs if j['id'] == 110976704735]
assert job['run_id'] == RUN and job['run_attempt'] == 1 and job['head_sha'] == HEAD and job['conclusion'] == 'success'
console_path = CAP / 'logs/110976704735.log'
console = [re.sub(r'^\d{4}-\d\d-\d\dT\S+Z ', '', line.rstrip('\r')) for line in console_path.read_text().split('\n')]
markers = [i for i, line in enumerate(console) if line.startswith('[command]') and line.endswith(' log -1 --format=%H')]
assert len(markers) == 1 and console[markers[0] + 1] == HEAD
check('Source and workflow binding', {'actual_checkout_sha': HEAD, 'runtime_source_sha': SOURCE,
                                     'source_identities': source_ids, 'source9_only_changes': changed,
                                     'source9_changed_identities': {p: identity(git(SOURCE, p)) for p in changed},
                                     'actions_log': fileid(console_path), 'checkout_output_line': markers[0] + 2,
                                     'workflow': result['workflow']})

reports = {mode: read(ROOT / (mode + '.json')) for mode in MODES}
assert result['reports'] == reports
pid = {mode: reports[mode]['process_id'] for mode in MODES}
assert len(set(pid.values())) == 3 and all(type(value) is int and value > 0 for value in pid.values())
user_dir = Path(result['user_dir'])
assert Path(result['isolation_root']) in user_dir.parents
assert set(result['processes']) == {'user-dir-proof', *MODES}
bad = re.compile(r'SCRIPT ERROR:|(?:^|\s)ERROR:|Unicode parsing error|Unexpected NUL character|Parse Error:|Parser Error:|ObjectDB instances leaked|resources still in use|RID allocations? of type|orphan StringName|Unreferenced static string', re.I)
processes = {}
for mode in ['user-dir-proof', *MODES]:
    proc = result['processes'][mode]
    assert proc['exit_code'] == 0 and proc['timed_out'] is False
    assert datetime.fromisoformat(proc['ended_at_utc']) > datetime.fromisoformat(proc['started_at_utc'])
    if (ROOT / (mode + '.process.json')).exists():
        assert read(ROOT / (mode + '.process.json')) == proc
    logs = {}
    notices = []
    for suffix in ['stdout.txt', 'stderr.txt', 'log']:
        path = ROOT / (mode + '.' + suffix)
        raw = path.read_bytes()
        assert b'\0' not in raw
        lines = raw.decode('utf-8-sig').splitlines()
        assert not [line for line in lines if bad.search(line)], (mode, suffix)
        logs[path.name] = identity(raw)
        notices.extend(line for line in lines if 'warning' in line.lower() or 'V-Sync' in line or 'cursor' in line.lower())
    assert (ROOT / (mode + '.stderr.txt')).stat().st_size == 0
    stdout = (ROOT / (mode + '.stdout.txt')).read_text()
    if mode in MODES:
        assert reports[mode]['mode'] == mode and Path(reports[mode]['user_dir']) == user_dir
        m = re.findall(r'^HOSPITAL_READING_PROCESS: (.+)$', stdout, re.M)
        assert len(m) == 1 and parse(m[0]) == result['godot_process_identities'][mode]
        assert parse(m[0])['process_id'] == pid[mode]
        assert len(re.findall('^HOSPITAL_READING_' + mode.upper() + '_PASS:', stdout, re.M)) == 1
        assert '--hospital-reading-mode=' + mode in proc['argv'] and '--headless' not in proc['argv']
    else:
        assert str(user_dir) in stdout
    processes[mode] = {'pid': pid.get(mode), 'receipt': proc, 'logs': logs,
                       'error_and_lifetime_matches': 0, 'environment_notices': sorted(set(notices))}
import_path = ART / 'import.log'
assert not bad.search(import_path.read_text())
check('Fresh processes and strict diagnostics', {'processes': processes, 'import_log': fileid(import_path),
                                                'warning_free_claim': False})

seal = read(ROOT / 'write-seal.json')
assert seal['sealed_after_mode'] == 'write' and seal['before_mode'] == 'read'
assert len(seal['files']) == 20 and seal == result['write_seal']
for name, entry in seal['files'].items():
    assert identity((SEALED / name).read_bytes()) == {key: entry[key] for key in ['bytes', 'sha256']}
    if name == 'transactions.jsonl':
        assert (RAW / name).read_bytes().startswith((SEALED / name).read_bytes())
    else:
        assert (SEALED / name).read_bytes() == (RAW / name).read_bytes()
raw_manifest = read(ROOT / 'raw-evidence-manifest.json')
assert len(raw_manifest) == 42
for name, item in raw_manifest.items():
    assert identity((RAW / name).read_bytes()) == {key: item[key] for key in ['bytes', 'sha256']}
check('Writer seal and raw evidence', {'sealed_files': 20, 'raw_manifest_files': 42,
                                      'seal': fileid(ROOT / 'write-seal.json'), 'raw_manifest': fileid(ROOT / 'raw-evidence-manifest.json'),
                                      'exact_writer_prefix_preserved': True})

trace = rows(RAW / 'transactions.jsonl')
assert [(x['mode'], x['kind']) for x in trace] == [(mode, stage) for mode in MODES for stage in STAGES[mode]]
assert len(rows(SEALED / 'transactions.jsonl')) == 12 and len(trace) == 22
for mode in MODES:
    report = reports[mode]
    assert set(report['stages']) == set(STAGES[mode])
    assert report == read(RAW / (mode + '.json'))
    assert report['catalogues'] == read(RAW / (mode + '-catalogues.json'))
    for sequence, row in enumerate([x for x in trace if x['mode'] == mode], 1):
        assert type(row['sequence']) is int and row['sequence'] == sequence
        assert row['process_id'] == pid[mode] and row['value'] == report['stages'][row['kind']]
        assert row['value'] == read(RAW / (mode + '-' + row['kind'] + '.json'))
check('Standalone stages and chronological trace', {'row_count': 22, 'stage_counts': {k: len(v) for k, v in STAGES.items()},
                                                    'all_stage_values_equal_reports_and_trace': True})

slot_path = RAW / 'saved-hospital-slot.json'
slot_bytes = slot_path.read_bytes()
primary_ids = {}
slot_copies = [slot_path, SEALED / 'saved-hospital-slot.json']
for mode in MODES:
    primary_ids[mode] = {}
    for boundary in ['input', 'output']:
        value = result['primary_files'][mode][boundary]
        path = ROOT / (mode + '-' + boundary + '-primary-files.json')
        if path.exists():
            assert read(path) == value
        assert set(value) == {'slot', 'autosave', 'quick', 'profile'} and not value['quick']['exists']
        primary_ids[mode][boundary] = {}
        for key, record in value.items():
            local = ROOT / (mode + '-' + boundary + '-' + key + '.json')
            if record['exists']:
                assert identity(local.read_bytes()) == {field: record[field] for field in ['bytes', 'sha256']}
                primary_ids[mode][boundary][key] = {'exists': True, **identity(local.read_bytes())}
                if key == 'slot':
                    assert local.read_bytes() == slot_bytes
                    slot_copies.append(local)
            else:
                assert not local.exists()
                primary_ids[mode][boundary][key] = {'exists': False}
assert len(slot_copies) == 7 and all(p.read_bytes() == slot_bytes for p in slot_copies)
assert all(not item['exists'] for item in primary_ids['write']['input'].values())
assert primary_ids['write']['output'] == primary_ids['read']['input']
assert primary_ids['read']['output'] == primary_ids['forge']['input'] == primary_ids['forge']['output']
check('Primary file boundaries', {'saved_slot': identity(slot_bytes), 'byte_identical_slot_copies': len(slot_copies),
                                 'primary_file_identities': primary_ids, 'all_four_unchanged_during_forge': True,
                                 'all_four_unchanged_during_read': False, 'quick_absent_at_all_retained_boundaries': True})

document = read(slot_path)
snapshot = document['current_snapshot']['snapshot']
checkpoint = snapshot['narrative_checkpoint']; reading = checkpoint['reading_session']; ledger = reading['ledger']
assert snapshot['route_id'] == 'hospital' and snapshot['lifecycle']['day'] == 3 and snapshot['lifecycle']['state'] == 'PLAYING'
assert snapshot['lifecycle']['active_condition_hospital_plan'] is None and snapshot['gameplay']['pending_hospital'] is True
assert checkpoint['entry_id'] == ENTRY and checkpoint['stage'] == 'hospital'
assert type(reading['schema_version']) is int and reading['schema_version'] == 3 and reading['family'] == 'hospital' and reading['boundary'] == 'line'
assert set(reading) == {'schema_version', 'family', 'catalogue_fingerprint', 'boundary', 'ledger', 'frontier'}
assert set(ledger) == {'session_token', 'frozen_context', 'entry_contexts', 'captions'}
plan = snapshot['lifecycle']['active_resolution_plan']
request = snapshot['gameplay']['route_context']['hospital_frozen_contexts_v1']['requests'][plan['resolution_id']]
stage, = [x for x in plan['stages'] if x['stage_id'] == 'hospital_if_triggered']
assert stage['state'] == 'active' and plan['source_day'] == 3
assert request['resolution_id'] == plan['resolution_id'] and request['resolution_issuer_receipt'] == plan['resolution_issuer_receipt']
assert request['stage_id'] == stage['transaction_id'] and request['timeline_id'] == 'hospital.faint' and request['route_id'] == 'hospital'
assert request['context']['day'] == 3 and request['context']['kind'] == 'hospital'
presentation = request['context']['presentation']; fields = presentation['fields']
assert fields['entry_id'] == ENTRY and fields['entry_role'] == 'hospital' and fields['day'] == 3
assert fields['qualifying_cause'] == 'schedule_done' and fields['sylvia_eligible'] is True and fields['sylvia_witness_receipt_id'] is None
assert fields['accepted_record_ids'] == fields['unfulfilled_record_ids']
schedule = [x for x in plan['committed_schedule']['entries'] if x['action_kind'] in ['solo', 'group']]
assert schedule and request['context']['source_entry_ids'] == sorted(x['schedule_entry_id'] for x in schedule)
assert fields['accepted_record_ids'] == sorted({x['source_receipt_id'] for x in schedule})
sylvia_sources = []
for entry in schedule:
    receipt = snapshot['contacts']['schedule_source_receipts'][entry['source_receipt_id']]
    assert receipt['day'] == 3 and receipt['action_id'] == entry['action_id'] and receipt['participants'] == entry['participants']
    if receipt['participants'] == ['sylvia']:
        sylvia_sources.append(entry['source_receipt_id'])
assert sylvia_sources and snapshot['contacts']['sylvia_hospital_witness_receipts'] == {}
command_hash = hashlib.sha256(canonical(request)).hexdigest()
completion_id = request['completion_transaction_id']
token = 'narrative_presentation.' + hashlib.sha256(canonical(completion_id + '|' + command_hash)).hexdigest()
command = {**request, 'command_sha256': command_hash, 'physical_token': token}
frame = {'expected_stage': 'hospital', 'playback_id': token + ':hospital', 'role': 'hospital',
         'transaction_id': completion_id + ':hospital', 'presentation': presentation}
assert ledger['session_token'] == completion_id and ledger['frozen_context'] == {'family': 'hospital', 'completion_transaction_id': completion_id, 'entry_id': ENTRY}
assert ledger['entry_contexts'] == {ENTRY: frame} and checkpoint['frozen_context'] == frame and checkpoint['transaction_id'] == frame['transaction_id']
captions = ledger['captions']
assert [x['beat']['line_id'] for x in captions] == LINES and all(x['beat']['owning_entry_id'] == ENTRY for x in captions)
assert len({x['publication_id'] for x in captions}) == 2
assert reading['frontier'] == {'line_id': LINES[1], 'publication_id': captions[1]['publication_id']}
writer, reader, forged = (reports[k] for k in MODES); w = writer['stages']; r = reader['stages']
catalogue = writer['catalogues']['hospital']
assert catalogue['schema_version'] == 1 and catalogue['kind'] == 'hospital_reading_catalogue'
cat_entry, = catalogue['entries']; assert cat_entry['entry_id'] == ENTRY and [x['line_id'] for x in cat_entry['lines']] == LINES
assert reading['catalogue_fingerprint'] == hashlib.sha256(canonical(catalogue)).hexdigest()
for report in reports.values():
    assert report['catalogues']['production_content'] is False and report['fixture']['production_content'] is False
    assert report['fixture'] == writer['fixture'] and report['catalogues']['hospital'] == catalogue
assert writer['fixture']['days'] == {'prior_solo': 1, 'empty_schedule': 2, 'hospital': 3, 'next_solo': 4}
assert writer['fixture']['condition'] == {'health': 0, 'pressure': 10, 'condition_effects_today': ['sequela']}
assert writer['saved_checkpoint'] == checkpoint == w['saved']['source']['checkpoint']
assert writer['hospital_command'] == command == w['saved']['source']['command']
assert identity(slot_bytes) == {'bytes': writer['slot_bytes'], 'sha256': writer['slot_sha256']}
check('Independent raw saved Hospital authority', {'hospital_entry': ENTRY, 'reading_schema': 3,
        'sylvia_source_receipt_ids': sylvia_sources, 'qualifying_cause': fields['qualifying_cause'],
        'command_sha256': command_hash, 'physical_token': token, 'completion_transaction_id': completion_id,
        'catalogue_sha256': reading['catalogue_fingerprint'], 'frontier': reading['frontier'],
        'published_line_ids': LINES, 'pre_completion_witness_count': 0,
        'derivation': 'Command hash, token and shared frame reconstructed from actual raw saved Run request, plan and accepted Contacts/Schedule sources before comparing any report.'})

prior = w['prior_solo']['source']; first = w['hospital_a']['source']; retired = w['prior_retired']
assert prior['lifecycle']['day'] == 1 and [x['line_id'] for x in prior['history']['captions']] == ['fixture.solo.pre.a']
assert retired['day'] == 2 and retired['history']['ok'] is False
assert retired['contacts']['solo_actions']['solo:priscilla:day1']['state'] == 'RESOLVED_ATTENDED'
assert first['command'] == command and first['history']['session_id'] != prior['history']['session_id']
assert [x['line_id'] for x in first['history']['captions']] == [LINES[0]]
assert w['hospital_a']['deferred_pair_preview']['ok'] and w['hospital_a']['deferred_pair_preview']['value']['required'] is False
check('Lawful prior retirement and fresh Hospital entry', {'prior_session_id': prior['history']['session_id'],
         'retired_day': 2, 'prior_state': 'RESOLVED_ATTENDED', 'hospital_session_id': first['history']['session_id'],
         'hospital_initial_lines': [LINES[0]], 'deferred_pair_required': False})

partial = w['paused_b']; transport = partial['transport']; canonical_source = partial['source']
input_protocol(transport, ['Enter', 'Escape'], LINES[0])
assert transport == read(RAW / 'hospital-input.json') and transport['accept_admitted'] and transport['back_admitted']
assert transport['pause_source_admission']['ok'] and transport['tree_paused'] and transport['admitted_frontier'] == reading['frontier']
for name in ['paused_b', 'pause_cancelled', 'pause_continued', 'hospital-partial-history-entered',
             'hospital-partial-history-closed', 'pause_reentered', 'backup_entered', 'saved']:
    observation = w[name]
    assert observation['source'] == canonical_source
    assert all(observation['native'][key] == partial['native'][key] for key in ['line_id', 'caption_id', 'text', 'total_characters'])
    native(observation['native'], name not in ['backup_entered', 'saved'])
assert state(w['pause_cancelled']) == state(partial) == state(w['pause_continued'])
assert w['availability']['observation'] == state(partial) and w['availability']['pause_source']['ok']
assert state(w['saved']) == state(w['backup_entered'])
assert w['saved']['native']['reveal_generation'] == w['pause_reentered']['native']['reveal_generation'] + 1
assert writer['hospital_completions'] == writer['physical_completions'] == [] and writer['speech_admissions'] > 0
for name in ['paused_b', 'pause_cancelled', 'availability', 'pause_reentered', 'backup_entered', 'saved']:
    ui = w[name]['ui']; assert ui['tree_paused'] and ui['pause_visible'] and ui['bridge_pause_handle']
    assert ui['bridge_suspension']['ok'] and ui['bridge_suspension']['value']['state'] == 'Suspended'
assert w['pause_cancelled']['ui']['bridge_pause_handle'] == partial['ui']['bridge_pause_handle']
history_pair(w, 'hospital-partial-history', LINES)
check('Partial B, pure inspection and current-line-only Save', {'partial_visible_characters': partial['native']['visible_characters'],
      'total_characters': partial['native']['total_characters'], 'transport': transport,
      'save_reveal_generation_increment': 1, 'source_preserved': True,
      'writer_speech_admissions_positive_control': writer['speech_admissions'], 'pre_exit_completions': 0})

loaded = r['loaded']; native(loaded['native'], False)
assert reader['writer_process_id'] == pid['write']
assert reader['saved_checkpoint'] == checkpoint == loaded['source']['checkpoint']
assert reader['hospital_command'] == command == loaded['source']['command']
assert loaded['source']['history'] == canonical_source['history']
assert loaded['source']['profile'] == read(ROOT / 'read-input-profile.json')
assert loaded['source']['profile']['preferences']['reading']['read_aloud_enabled'] is True
assert loaded['source']['contacts']['sylvia_hospital_witness_receipts'] == {}
assert loaded['source']['speech_admissions'] == 0 and loaded['source']['hospital_completions'] == loaded['source']['physical_completions'] == []
assert len(loaded['text_starts_during_restore']) == 1 and loaded['text_starts_during_restore'][0]['text'] == cat_entry['lines'][1]['text']
history_pair(r, 'hospital-restored-history', LINES)
assert state(r['hospital-restored-history-entered']) == state(loaded)
check('Fresh Load restores B without A, speech or new witness', {'reader_pid': pid['read'], 'writer_pid': pid['write'],
      'text_starts_during_restore': loaded['text_starts_during_restore'], 'speech_admissions': 0,
      'read_aloud_enabled': True, 'new_witnesses': 0, 'completions': 0, 'raw_profile_equal': True, 'history_lines': LINES})

completion_input = {key: value for key, value in r['completion_input'].items() if key != 'ui'}
input_protocol(completion_input, ['Enter'], LINES[1])
assert completion_input['admitted'] and completion_input == read(RAW / 'hospital-completion-input.json')
settled = r['settled']
assert len(settled['hospital_completions']) == len(settled['physical_completions']) == 1
assert reader['hospital_completions'] == settled['hospital_completions'] and reader['physical_completions'] == settled['physical_completions']
physical = settled['physical_completions'][0]
assert physical == {'owner_kind': 'narrative', 'physical_token': token, 'command_sha256': command_hash,
                    'completion_transaction_id': completion_id, 'status': 'completed', 'result': physical['result']}
assert settled['hospital_completions'][0] == {'command': command, 'result': physical['result']}
events = rows(RAW / 'read-owner-events.jsonl')
expected_kinds = ['native_timeline_started', 'witnessed_normal_accept_requested', 'native_dialogic_action',
                  'resolution_completed', 'hospital_port_completion_ready', 'physical_completion_ready',
                  'hospital_reading_finished', 'native_timeline_ended', 'native_timeline_started', 'native_timeline_ended']
assert [event['kind'] for event in events] == expected_kinds
last_frame = -1
for index, event in enumerate(events, 1):
    assert event['sequence'] == index and event['mode'] == 'read' and event['process_id'] == pid['read']
    assert event['frame'] >= last_frame; last_frame = event['frame']
assert events[0]['frame'] == loaded['text_starts_during_restore'][0]['frame']
assert events[1]['frame'] == events[2]['frame'] == completion_input['events'][0]['frame']
assert events[1]['value'] == events[2]['value'] == {'line_id': LINES[1]}
assert all(event['frame'] == completion_input['events'][1]['frame'] for event in events[3:8])
assert events[5]['value'] == physical and events[6]['value'] == settled['hospital_completions'][0]
assert events[4]['value']['receipt']['physical_completion_receipt'] == physical
assert events[3]['value']['ok'] and events[3]['value']['code'] == 'plan_complete'
assert events[0]['value']['generation'] == events[7]['value']['generation']
assert events[8]['value']['generation'] == events[9]['value']['generation'] != events[0]['value']['generation']
check('Actual ordinary input and one matching Hospital completion', {'input': completion_input,
      'physical_receipt': physical, 'hospital_native_generation': events[0]['value']['generation'],
      'hospital_native_end_frame': events[7]['frame'], 'owner_events': events,
      'qualification': 'Same-frame signal callbacks nest. Later other-generation native end is next-Solo teardown, not a second Hospital completion.'})

auto_path = RAW / 'settled-hospital-autosave.json'; auto = read(auto_path)['current_snapshot']['snapshot']
assert identity(auto_path.read_bytes()) == {'bytes': settled['autosave_bytes'], 'sha256': settled['autosave_sha256']}
assert auto == settled['durable_snapshot'] and auto['lifecycle']['day'] == settled['day'] == 4
assert auto['contacts'] == settled['contacts'] and not settled['gameplay']['pending_hospital'] and not settled['history']['ok']
assert settled['contacts']['solo_actions']['solo:sylvia:day3']['state'] == 'RESOLVED_MISSED'
completed_plan = auto['lifecycle']['active_resolution_plan']; assert completed_plan['resolution_id'] == request['resolution_id']
completed_stage, = [x for x in completed_plan['stages'] if x['stage_id'] == 'hospital_if_triggered']
assert completed_stage['state'] == 'completed'
receipt = completed_stage['receipt']['value']['presentation_completion_receipt']
assert receipt['physical_completion_receipt'] == physical and receipt['receipt_id'] == completion_id
assert receipt['physical_token'] == token and receipt['command_sha256'] == command_hash
witnesses = auto['contacts']['sylvia_hospital_witness_receipts']; assert len(witnesses) == 1
for witness in witnesses.values():
    assert witness['resolution_kind'] == 'schedule_done' and witness['care_followup_day'] == 4
    assert witness['source_receipt_id'] in fields['accepted_record_ids']
assert auto['gameplay']['stats']['health'] == settled['gameplay']['stats']['health'] == 6
assert auto['gameplay']['stats']['pressure'] == settled['gameplay']['stats']['pressure'] == 3
assert auto['route_id'] == 'hospital' and auto['narrative_checkpoint']['reading_session']['boundary'] == 'between_entries'
durable_stages = {x['stage_id']: x['state'] for x in completed_plan['stages']}
live_stages = {x['stage_id']: x['state'] for x in settled['lifecycle']['active_resolution_plan']['stages']}
assert durable_stages['unlock_day'] == 'pending' and live_stages['unlock_day'] == 'completed'
assert '/MainGameScene/' in settled['ui']['focus_owner'] and '/ComputerDesktop/' in settled['ui']['focus_owner']
assert not settled['ui']['tree_paused'] and settled['ui']['bridge_suspension']['value']['state'] == 'Active'
check('Durable Day-4 settlement and separately observed live desktop', {'settled_autosave': fileid(auto_path),
      'durable_day': 4, 'durable_route_id': auto['route_id'], 'durable_stage_states': durable_stages,
      'durable_reading_boundary': 'between_entries', 'live_stage_states': live_stages,
      'live_focus_owner': settled['ui']['focus_owner'], 'health': 6, 'pressure': 3,
      'sylvia_witnesses': witnesses, 'qualification': 'Durable Day4 settlement is proven. The retained Autosave has Hospital route/between_entries and pending unlock; completed unlock/desktop is a separate later live observation.'})

next_source = r['next_solo']['source']
assert next_source['lifecycle']['day'] == 4 and next_source['history']['session_id'] not in [canonical_source['history']['session_id'], prior['history']['session_id']]
assert [x['line_id'] for x in next_source['history']['captions']] == ['fixture.next.solo.pre.a']
assert next_source['checkpoint']['entry_id'] == 'dating.solo.priscilla.day4.pre_challenge'
history_pair(r, 'next-solo-history', ['fixture.next.solo.pre.a'])
check('Fresh next-day Solo History', {'day': 4, 'entry_id': next_source['checkpoint']['entry_id'],
      'session_id': next_source['history']['session_id'], 'line_ids': ['fixture.next.solo.pre.a'],
      'hospital_rows': 0, 'history_inspection_preserves_source_and_returns_focus': True})

assert forged['genuine_admission'] == {'ok': True} and set(forged['cases']) == {'frame', 'caption'}
forge_results = {}
for kind, case in forged['cases'].items():
    assert case == {k: v for k, v in forged['stages']['forge-' + kind].items() if k != 'ui'}
    candidate = read(RAW / ('forge-' + kind + '-candidate.json')); expected = deepcopy(snapshot)
    ck = expected['narrative_checkpoint']
    if kind == 'frame':
        ck['frozen_context']['presentation']['fields']['sylvia_eligible'] = False
        ck['reading_session']['ledger']['entry_contexts'][ENTRY] = deepcopy(ck['frozen_context'])
        assert case['independent']['code'] == 'reading_entry_context_mismatch'
    else:
        ck['reading_session']['ledger']['captions'][0]['beat']['owning_entry_id'] = 'hospital.faint.day4'
    assert candidate == expected and case['before'] == case['after']
    assert case['independent']['ok'] is False and case['independent']['code']
    assert case['admission']['ok'] is False and case['admission']['code'] == 'invalid_narrative_checkpoint'
    assert case['before']['text_starts'] == [] and case['before']['speech_admissions'] == 0
    assert case['before']['hospital_completions'] == case['before']['physical_completions'] == []
    forge_results[kind] = {'candidate': fileid(RAW / ('forge-' + kind + '-candidate.json')),
                           'independent': case['independent'], 'admission': case['admission'], 'before_equals_after': True}
assert forged['text_starts'] == [] and forged['speech_admissions'] == 0
assert forged['hospital_completions'] == forged['physical_completions'] == []
check('Independent saved authority and foreign-caption forgeries refuse before installation', {
      'genuine_prepare_succeeds': True, 'cases': forge_results, 'primary_files_unchanged': True,
      'new_text_starts': 0, 'speech_admissions': 0, 'completions': 0,
      'scope': 'Exact coherent shared-frame mutation retains original saved Run authority; foreign-caption mutation changes only earlier caption owning entry.'})

capture_names = ['hospital-partial-history.png', 'hospital-saved.png', 'hospital-restored-history.png', 'hospital-restored.png', 'next-solo-history.png']
capture_ids = {}
for name in capture_names:
    raw = (ROOT / 'captures' / name).read_bytes()
    assert raw == (RAW / name).read_bytes() and raw.startswith(b'\x89PNG\r\n\x1a\n')
    dimensions = list(struct.unpack('>II', raw[16:24])); assert dimensions == [1280, 720]
    capture_ids[name] = {**identity(raw), 'dimensions': dimensions}
assert (RAW / capture_names[0]).read_bytes() == (RAW / capture_names[2]).read_bytes()
assert before_hashes == {p.relative_to(ART).as_posix(): identity(p.read_bytes()) for p in ART.rglob('*') if p.is_file()}
check('Raw evidence left unchanged', {'audited_artifact_files': len(before_hashes), 'all_pre_post_hashes_equal': True})
assert len(checks) == 15
report = {'schema_version': 1, 'document_id': 'hospital_broad2_semantic_audit',
          'generated_at_utc': datetime.now(timezone.utc).isoformat(), 'hospital_semantic_evidence_passed': True,
          'broad_gate_evidence_review_pending': True, 'final_broad_acceptance_declared': False,
          'run_id': RUN, 'attempt': 1, 'actual_checkout_sha': HEAD, 'runtime_source_sha': SOURCE,
          'job_id': job['id'], 'api_artifact_id': meta['id'], 'evidence_root': str(ROOT),
          'original_zip': fileid(zip_path), 'method': 'Fifteen independent groups applied to this run’s actual bytes, strict JSON, canonical raw saved-authority reconstruction, cross-file/trace joins and process logs. No cloud runner import or execution; result.ok/result.validation and Broad1 acceptance did not decide pass.',
          'engine_or_powershell_executed': False, 'connector_calls': False, 'raw_evidence_modified': False,
          'repository_edited': False, 'checks': checks, 'check_count': 15, 'failures': [],
          'capture_identity_review': {'captures': capture_ids, 'hospital_history_pair_byte_identical': True,
                                      'pixel_inspection': 'Root reviews these Broad2 originals separately; no prior-run visual acceptance is copied.'},
          'remaining_limits': ['Component evidence only; root must complete every Broad2 evidence review before whole acceptance.',
               'Day3 Sylvia-present Schedule-Done uses explicit noncanonical A/B and condition injection after genuine Contacts/Schedule sources.',
               'No production Hospital prose/selectors, no-Sylvia timing/Continue, condition-Hospital reading, immediate pair reading, ordered endings, all Hospital days or Hospital Next/Skip acceptance.',
               'Durable Autosave retains Hospital between_entries and pending unlock; later live desktop is separately observed.',
               'All four primary files unchanged during forge only. Reader Autosave/Profile legitimately progress; no zero-FileOps or whole-reader byte-inert claim.',
               'Injected Godot InputEventKey is not native OS hardware input; Linux software rendering does not establish Windows graphics or accessibility.',
               'Error/lifetime scans passed; nonfatal environment notices remain. Fresh-process restore does not replace separate same-process/native-negative suite coverage.'],
          'audited_input_files': before_hashes, 'archive_entries': archive_entries,
          'audit_script': fileid(Path(__file__))}
OUT.mkdir(exist_ok=True)
out = OUT / 'hospital-broad2-semantic-audit.json'; out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
md = f'''# Broad2 Hospital semantic audit

**All fifteen independent Hospital check groups passed on Broad2’s own bytes.** This component result does not declare whole broad acceptance.

Run `{RUN}`, attempt 1, Hospital job `{job['id']}`, artifact `{meta['id']}`. Actual checkout `{HEAD}`; runtime source `{SOURCE}`. Source9 changes only three PowerShell performance files; all three Hospital runner/helper/verifier identities match both runtime source and actual checkout. The observed Actions checkout agrees.

Original ZIP: {len(zip_raw):,} bytes, SHA256 `{identity(zip_raw)['sha256']}`. All 112 entries, 20 writer-sealed files, 42 raw manifest records and the exact 12-row writer prefix in the final 22-row trace are verified.

| Proof | Broad2 observation |
|---|---|
| Fresh processes | Writer {pid['write']}, reader {pid['read']}, forge {pid['forge']}; distinct, exit zero, one PASS each, no timeout/script/Unicode/lifetime errors |
| Slot3 | {len(slot_bytes):,} bytes; seven identical copies; SHA256 `{identity(slot_bytes)['sha256']}` |
| Raw saved authority | Real accepted Sylvia Schedule-Done sources reconstruct command, physical token and shared frame; strict Hospital schema3 and exact A/B frontier |
| Partial B | {partial['native']['visible_characters']} / {partial['native']['total_characters']} characters; Pause/Cancel/Continue/History preserve source; Save completes only B |
| Fresh Load | One B start at frame {loaded['text_starts_during_restore'][0]['frame']}; no A, speech, new witness or completion; exact input Profile and History |
| Ordinary completion | Enter press/release frames {completion_input['events'][0]['frame']}/{completion_input['events'][1]['frame']}; one matching Hospital native end and physical receipt |
| Settlement | Durable Day4, exact completed Hospital receipt, health6 / pressure3, missed Sylvia date, one witness; separately observed live desktop |
| Next Solo | Fresh Day4 Priscilla session; only `fixture.next.solo.pre.a`, no Hospital rows |
| Forgeries | Both exact mutations independently refuse before installation; all four primary states unchanged; Quick absent |

Command SHA256: `{command_hash}`. Physical token: `{token}`.

Settled Autosave: {auto_path.stat().st_size:,} bytes, SHA256 `{identity(auto_path.read_bytes())['sha256']}`. It retains `route_id=hospital`, `between_entries` and `unlock_day=pending`; later live observation establishes completed unlock and desktop focus. Do not describe the retained Autosave as already containing the desktop route.

The later other-generation native end belongs to next-Solo teardown. Same-frame callback order reflects nested signals and is not a separate causal dispatch-order proof. Reader Autosave/Profile changes are legitimate progression; whole-primary invariance is asserted during forge only.

Five capture identities and 1280×720 dimensions are verified; the two Hospital History images are byte-identical. Root reviews these originals visually. This audit carries over no earlier-run image acceptance.

No engine, PowerShell, connector, repository edit or raw-evidence mutation occurred. The JSON contains all fifteen groups, actual receipts, source identities, input hashes and the archive census. The fixture remains bounded noncanonical Day3/Sylvia Schedule-Done evidence; production content, other ingresses/conditions, pair/ending continuity, all days and native accessibility remain outside this proof.
'''
mdpath = OUT / 'hospital-broad2-semantic-audit.md'; mdpath.write_text(md)
print(json.dumps({'json': fileid(out), 'markdown': fileid(mdpath), 'pids': pid,
                  'slot': identity(slot_bytes), 'check_groups': len(checks)}, indent=2))

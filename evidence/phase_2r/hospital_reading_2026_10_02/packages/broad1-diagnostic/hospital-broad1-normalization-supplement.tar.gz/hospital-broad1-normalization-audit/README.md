# Broad-run normalization evidence audit

## Verdict

**PASS for two bounded components; not a whole-run pass.** Run `37044894986` completed with conclusion `failure`, but its outgoing-normalization and lazy-normalization jobs independently completed successfully. This audit preserves only their positive evidence and does not rehabilitate the failed workflow, failed warm/region jobs, or aggregate gate.

Identity:

- runtime/source commit: `856520f09440d9b47cc272de3363009924ffedca`
- actual workflow checkout: `1bc4f6afd759e969f82b9c2134eb178479c19d13`
- outgoing job `110971489619`: completed / success
- lazy job `110971489767`: completed / success

The exact source8 files used by these benchmarks were read from the named Git commit and hash-checked. The retained job records, checkout output, required steps, transferred inputs, raw process receipts, engine logs, structured console receipts, samples, medians, and reports all agree. `audit.json` contains the machine-readable result and `audit_normalization.py` reproduces the offline checks without launching Godot or PowerShell.

## Transferred payload provenance

| Input | Bytes | SHA-256 | Retained bundles | Provenance |
|---|---:|---|---:|---|
| Day7 | 1,910,538 | `9ee3cfdc…b153` | 66 | same run/head, producer attempt 1; manifest binds exact `results.json` and autosave bytes |
| zh-CN / win | 155,574 | `d88e125b…07d4` | 2 | baseline producer, schema/snapshot 7 |
| zh-HK / loss | 118,740 | `40d5b24d…dc78` | 2 | baseline producer, schema/snapshot 7 |

The Day7 producer report binds seven days, 98 synthetic checkpoints, final retention of 32 line + 32 manual-save + 2 semantic records, and a cold-read retained count of 66. Both consumer jobs retain byte-identical copies of the Day7 manifest; outgoing additionally retains the byte-identical localized manifest. Actual payload hashes were recomputed from the transferred files.

## Outgoing normalization

The report contains exactly six measurements: baseline/candidate × zh-CN/zh-HK/Day7. Each has one successful isolated process, a unique contained test root, one exact engine marker, clean import/engine logs, five nonnegative retained samples after the source-defined two warmups, and an independently recomputed median. Input and output hashes are identical; schema and snapshot versions are 7; validated bundle counts are 2 for localized payloads and 66 for Day7.

| Payload | Baseline median µs | Candidate median µs | Candidate − baseline µs |
|---|---:|---:|---:|
| zh-CN | 21,160 | 16,314 | −4,846 |
| zh-HK | 15,977 | 12,465 | −3,512 |
| Day7 | 157,286 | 83,356 | −73,930 |

The source/report ablation is exact: both variants use the current port and strict schema; only complete-document versus proven-journal normalization differs. This is a seam measurement on strict fixed payloads, not evidence that gameplay supplied a complete splice-proof set. No timing threshold is asserted.

The terminal `OUTGOING_NORMALIZATION_PERFORMANCE_VERIFIED` receipt occurs once, and the structured `OUTGOING_NORMALIZATION_PROOF` payload matches the retained report’s checkout, source hashes, manifest, and ablation.

## Lazy normalization

The report contains eight matched pairs and sixteen fresh isolated processes: four `full` pairs and four `splice` pairs. Odd pairs run baseline→candidate; even pairs run candidate→baseline. All roots are unique and contained, receipts match their suite/arguments/logs, exits are zero, and import/engine logs are strict-clean.

Every process preserves the exact Day7 input/output hash and 1,910,538-byte length, 66 input/output bundles, document/snapshot schema 7, source objects, unchanged-container identity, and replacement identity for changed data. The reference commit is exactly `dae70bf9aa05b6b3debb60f95738e5ffc4e97548`; current candidate port/schema hashes and frozen reference source/helper hashes agree within every pair. Each of the three metrics has two warmups, five nonnegative retained samples, and an exact recomputed median.

Recomputed summaries:

| Mode | Metric | Baseline median µs | Candidate median µs | Median paired delta µs |
|---|---|---:|---:|---:|
| full | schema helper | 87,289.5 | 79,990.0 | −8,672.0 |
| full | port helper | 88,118.5 | 79,494.0 | −8,890.5 |
| full | port seam | 176,530.0 | 165,529.5 | −13,191.0 |
| splice | schema helper | 2,336.0 | 2,155.5 | −180.5 |
| splice | port helper | 2,045.5 | 1,887.5 | −146.5 |
| splice | port seam | 89,950.0 | 89,425.5 | −589.5 |

All report deltas and the six aggregate summaries recompute exactly. One individual splice `port_seam` pair has a positive candidate delta of `+497 µs`; therefore the correct claim is the reported paired sample/median evidence, not that every candidate observation is faster.

The terminal `LAZY_NORMALIZATION_VERIFIED` receipt occurs once, and the structured `LAZY_NORMALIZATION_COMPARISON` payload matches the retained report’s checkout, source hashes, input hash, sampling statement, scope, and summaries.

## Limits

- The whole workflow failed. These two successful jobs are bounded positive evidence only.
- Timings are observations on one shared Windows runner. There is no fixed performance threshold and OS caches were not flushed.
- Helper and seam timers are direct/inclusive boundaries and must not be summed.
- Outgoing normalization does not prove gameplay proof-cache completeness.
- Lazy normalization is not a matched schema-build, full-checkpoint, physical-save, gameplay, real-disk, or input-to-paint comparison.
- This audit does not accept the failed warm-outgoing-proof, history-region-search, Endings, or aggregate components.

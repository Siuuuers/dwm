# Broad run 1 Hospital semantic audit

**All fifteen independent Hospital byte/semantic check groups passed. Other broad-gate jobs and the Endings infrastructure-download retry remain outstanding; no final broad acceptance is declared.**

Run [37044894986](https://github.com/Siuuuers/dwm/actions/runs/37044894986), attempt 1, job `rendered-hospital-reading`, API artifact `11244315370`.

Actual checkout and workflow head: `1bc4f6afd759e969f82b9c2134eb178479c19d13`. Runtime source: `856520f09440d9b47cc272de3363009924ffedca`.

The actual checkout adds only the auxiliary workflow to the runtime source. That runtime source changes only two generated inventories relative to `dca8b35b40e4ba9d80f204c77064357d16f07319`. All three runner/helper/verifier hashes match both actual checkout and runtime source Git bytes.

Original ZIP: 4670079 bytes, SHA256 `55426ac7b4772b98fcd45592947739ba14f519514f1e8af637f72593dcde159b`; all 112 archive file entries match extracted bytes.

Fifteen independent check groups applied to this archive using strict JSON, actual bytes/hashes, canonical request reconstruction, cross-file/trace comparisons, process logs and semantic assertions. The cloud runner was not imported or executed; result.ok and result.validation did not decide success. All fact values come from this run, not Focus5. Git commit bytes bind actual checkout and runtime source.

No engine, PowerShell or connector calls. Raw evidence and repository files were not modified.

## Current-run observations

| Evidence | Audited result |
| --- | --- |
| PIDs | Writer 3882, reader 3960, forge 4026; distinct identities, exit 0, one pass marker each, no timeout/errors/lifetime matches. |
| Writer custody | 20 sealed files and 42 raw manifest hashes match; exact 12-row writer prefix survives in final 22-row trace. |
| Slot | 168696 bytes, SHA256 `8a21c69bbe5255ec845d1f3d6149aa6fa52c5002336144ad2dde751210065c27`; seven actual copies byte-identical. |
| Saved authority | Real accepted Sylvia source and Schedule-Done plan independently reconstruct command/token/frame; strict Hospital schema 3, only A/B, B frontier. |
| Partial B | 8 of 202 characters visible; Pause/Cancel/History preserve source, Save completes B only. |
| Fresh Load | One B start at frame 11; no A, speech or new witness; exact Profile input and History restored. |
| Completion | Fresh Enter at frames 52/53; one matching Hospital native end/physical receipt at frame 53. |
| Settlement | Durable Day 4, exact completed Hospital receipt, health 6/pressure 3, Sylvia date missed and one witness; subsequent live desktop. |
| Next Solo | Fresh Day-4 Priscilla session with only `fixture.next.solo.pre.a`; no Hospital rows. |
| Forge | Both exact reconstructed forgeries refuse before installation; all primary states unchanged across forge; Quick absent. |

Command SHA256: `39a5548c25dff0cee7c44901112804555bbb14b24bc616159f9099d8ccda6c8f`.

Physical token: `narrative_presentation.da2f14dba42fa98d941e8d689a82395269083d462b3cea396f12c8ebbbc0302c`.

Settled Autosave: 234805 bytes, SHA256 `0d873450f5ec6e4334695807b6939a822aeab91ba613d816acc239ada0d9996d`.

## Evidence boundaries

Raw settled Autosave still has `route_id=hospital`, a `between_entries` anchor and `unlock_day=pending`. It proves durable Day-4 settlement. The later live observation has completed unlock and focus under `MainGameScene/ComputerDesktop`; next Solo is additional destination evidence.

The later other-generation native end belongs to next-Solo teardown, not another Hospital completion. Same-frame completion signals nest, so observation callback order is not a separate causal dispatch-order proof.

All primary states are invariant during forge only. Reader Autosave and Profile subsequently change with legitimate progression; no byte-inert whole-reader or zero-FileOps claim is made.

Rendered environment notices are retained; error/lifetime scans passed, but this is not a warning-free claim.

New PNG hashes were checked and the two Hospital History captures are byte-identical. Root is inspecting these new PNGs separately; this audit does not carry over prior Focus5 visual observations.

## Machine checks

- **Original artifact bytes: passed.** Detailed facts and input hashes are in the JSON.
- **Source and workflow binding: passed.** Detailed facts and input hashes are in the JSON.
- **Fresh processes and strict diagnostics: passed.** Detailed facts and input hashes are in the JSON.
- **Writer seal and raw evidence: passed.** Detailed facts and input hashes are in the JSON.
- **Standalone stages and chronological trace: passed.** Detailed facts and input hashes are in the JSON.
- **Primary file boundaries: passed.** Detailed facts and input hashes are in the JSON.
- **Independent raw saved Hospital authority: passed.** Detailed facts and input hashes are in the JSON.
- **Lawful prior retirement and fresh Hospital entry: passed.** Detailed facts and input hashes are in the JSON.
- **Partial B, pure inspection and current-line-only Save: passed.** Detailed facts and input hashes are in the JSON.
- **Fresh Load restores B without A, speech or new witness: passed.** Detailed facts and input hashes are in the JSON.
- **Actual ordinary input and one matching Hospital completion: passed.** Detailed facts and input hashes are in the JSON.
- **Durable Day-4 settlement and separately observed live desktop: passed.** Detailed facts and input hashes are in the JSON.
- **Fresh next-day Solo History: passed.** Detailed facts and input hashes are in the JSON.
- **Independent saved authority and foreign-caption forgeries refuse before installation: passed.** Detailed facts and input hashes are in the JSON.
- **Raw evidence left unchanged: passed.** Detailed facts and input hashes are in the JSON.

## Remaining limits

- Hospital job evidence from the broad workflow only. Other gate jobs remain pending and Endings infrastructure-download retry is needed; no final broad acceptance is declared.
- Day-3 Sylvia-present Schedule-Done with explicit noncanonical A/B and condition injection after genuine Contacts/Schedule receipt acquisition.
- No production Hospital prose/selectors, no-Sylvia timing/Continue conformance, condition-Hospital reading, immediate pair reading, ordered endings, all Hospital days, Hospital Next/Skip or whole-game acceptance.
- Durable settled Autosave retains Hospital between_entries and unlock_day pending. Subsequent live Day-4 desktop and next Solo are separately observed.
- Manual slot remains byte-identical throughout. All four primary files are invariant during forge only; reader Autosave/Profile later change legitimately. No zero-FileOps restore claim.
- Injected InputEventKey uses normal Godot routing, not native OS hardware input. Linux software rendering does not establish Windows graphics or accessibility.
- Fresh-process connected restore does not replace separate same-process re-adoption/native-negative GUT evidence.
- A/B share one immutable frame; forgeries prove coherent shared-frame refusal and foreign-caption membership.
- Zero errors/lifetime matches does not mean warning-free; nonfatal V-Sync/cursor messages and normal loading notices remain recorded.
- New screenshot identities are verified; this auditor does not claim pixel inspection or carry over Focus5 image observations.

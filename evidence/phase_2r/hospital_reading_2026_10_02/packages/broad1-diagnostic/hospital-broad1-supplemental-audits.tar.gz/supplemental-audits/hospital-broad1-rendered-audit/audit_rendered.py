#!/usr/bin/env python3
"""Independent offline audit of run 37044894986 rendered evidence."""
from __future__ import annotations

import hashlib
import json
import pathlib
import re
import struct
import sys

BASE = pathlib.Path(__file__).resolve().parent.parent
ART = BASE / "hospital-broad1-extracted" / "artifacts"
LOGS = BASE / "hospital-broad1-early-logs" / "logs"
JOBS = BASE / "hospital-broad1-early-logs" / "jobs-snapshot.json"
SOURCE = BASE / "dwm"
OUT = pathlib.Path(__file__).resolve().parent
RUN = 37044894986
HEAD = "1bc4f6afd759e969f82b9c2134eb178479c19d13"
SOURCE8 = "856520f09440d9b47cc272de3363009924ffedca"
STRICT = re.compile(r"SCRIPT ERROR:|(?:^|\s)ERROR:|Unicode parsing error|Unexpected NUL character|Parse Error:|\bPLAYABLE_[A-Z0-9_]*_FAIL:", re.M)
LIFETIME = ("Resource still in use", "Leaked instance", "Orphan StringName")

failures: list[str] = []


def check(condition: bool, message: str) -> None:
    if not condition:
        failures.append(message)


def duplicate_key(pairs):
    d = {}
    for key, value in pairs:
        if key in d:
            raise ValueError(f"duplicate JSON key: {key}")
        d[key] = value
    return d


def load(path: pathlib.Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=duplicate_key)
    except Exception as exc:
        failures.append(f"cannot strictly parse {path.relative_to(BASE)}: {exc}")
        return {}


def sha(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def png(path: pathlib.Path) -> tuple[int, int]:
    data = path.read_bytes()
    if len(data) < 24 or data[:8] != b"\x89PNG\r\n\x1a\n" or data[12:16] != b"IHDR":
        raise ValueError("invalid PNG signature/IHDR")
    return struct.unpack(">II", data[16:24])


def clean_log(path: pathlib.Path) -> None:
    text = path.read_text(encoding="utf-8", errors="replace")
    hits = [m.group(0) for m in STRICT.finditer(text)]
    check(not hits, f"strict diagnostic(s) in {path.relative_to(BASE)}: {hits[:3]}")
    for diagnostic in LIFETIME:
        check(diagnostic not in text, f"lifetime diagnostic {diagnostic!r} in {path.relative_to(BASE)}")


def output_lines(text: str, exact: str) -> int:
    # Actions timestamps prefix actual stdout. Shell command echoes contain code before
    # the marker and therefore cannot match this anchored output receipt.
    return len(re.findall(r"(?m)^\d{4}-\d\d-\d\dT[^ ]+Z " + re.escape(exact) + r"\s*$", text))


def artifact(prefix: str) -> pathlib.Path:
    matches = list(ART.glob(prefix + "-37044894986-1"))
    check(len(matches) == 1, f"expected one {prefix} artifact, found {len(matches)}")
    return matches[0] if matches else ART / "MISSING"


jobs_doc = load(JOBS)
jobs = {j.get("id"): j for j in jobs_doc.get("jobs", [])}
job_specs = {
    110965239910: ("Rendered seven-day, ending, Gallery and Dating journeys", [
        "Start and verify native Linux speech service", "Upload native speech environment evidence",
        "Exercise complete rendered journeys in fresh isolated profiles", "Upload journey reports, logs and screenshots"]),
    110965240122: ("Rendered desktop and dialogue / Linux software OpenGL", [
        "Start and verify native Linux speech service", "Upload native speech environment evidence",
        "Render and verify desktop scaling", "Render and verify delivery and dialogue",
        "Render and verify Angela stat overlay", "Validate Japanese and Korean catalogs",
        "Render and verify Japanese and Korean UI", "Render and verify font choices",
        "Verify rendered startup and Logout consent", "Audit all UI literal ownership"]),
    110965240048: ("Rendered Hospital reading / Schedule-Done Save and fresh-process Load", [
        "Start and verify native Linux speech service", "Upload native speech environment evidence"]),
}
job_summary = {}
for job_id, (name, required_steps) in job_specs.items():
    job = jobs.get(job_id, {})
    check(job.get("run_id") == RUN, f"job {job_id} run mismatch")
    check(job.get("head_sha") == HEAD, f"job {job_id} head mismatch")
    check(job.get("name") == name, f"job {job_id} name mismatch")
    check((job.get("status"), job.get("conclusion")) == ("completed", "success"), f"job {job_id} not successful")
    steps = {s.get("name"): s for s in job.get("steps", [])}
    for step in required_steps:
        s = steps.get(step, {})
        check((s.get("status"), s.get("conclusion")) == ("completed", "success"), f"job {job_id} step not successful: {step}")
    log = LOGS / f"{job_id}.log"
    text = log.read_text(encoding="utf-8", errors="replace")
    check(f"[command]/usr/bin/git log -1 --format=%H" in text, f"job {job_id} lacks checkout command")
    check(re.search(r"(?m)^\d{4}-\d\d-\d\dT[^ ]+Z " + re.escape(HEAD) + r"$", text) is not None, f"job {job_id} lacks exact checkout output")
    job_summary[str(job_id)] = {"name": name, "status": "completed/success", "head": HEAD, "required_steps": required_steps}

# Render report/cardinality/log/PNG validation.
render_specs = {
    "desktop-scaling-render": (38, "DESKTOP_SCALING_RENDER_VERIFIED", None),
    "delivery-dialogue-render": (25, "DELIVERY_DIALOGUE_RENDER_VERIFIED", "evidence"),
    "angela-overlay-render": (10, "ANGELA_OVERLAY_RENDER_VERIFIED", "evidence"),
    "japanese-korean-ui-render": (30, "JAPANESE_KOREAN_UI_RENDER_VERIFIED", "states"),
    "font-choices-render": (30, "FONT_CHOICES_RENDER_VERIFIED", "states"),
}
render_summary = {}
all_pngs: list[pathlib.Path] = []
for prefix, (expected, marker, rows_key) in render_specs.items():
    d = artifact(prefix)
    report = load(d / "results.json")
    check(report.get("ok") is True and report.get("failures") == [], f"{prefix} report failed")
    check(report.get("renderer") not in (None, "", "headless", "Headless"), f"{prefix} renderer is absent/headless")
    check(report.get("samples") == expected and report.get("captures") == expected, f"{prefix} report cardinality mismatch")
    files = sorted(d.glob("*.png"))
    check(len(files) == expected, f"{prefix} actual PNG count {len(files)} != {expected}")
    if rows_key:
        rows = report.get(rows_key, [])
        names = [((r.get("name") + ".png") if rows_key == "evidence" and "name" in r else r.get("file")) for r in rows]
        check(len(names) == expected and set(names) == {p.name for p in files}, f"{prefix} report filenames do not exactly bind PNGs")
    for p in files:
        try:
            w, h = png(p)
            check(w > 0 and h > 0 and p.stat().st_size > 24, f"empty PNG geometry: {p.relative_to(BASE)}")
        except Exception as exc:
            failures.append(f"invalid PNG {p.relative_to(BASE)}: {exc}")
    all_pngs.extend(files)
    log = d / "render.log"
    clean_log(log)
    receipts = [line[len(marker) + 1:] for line in log.read_text(encoding="utf-8", errors="replace").splitlines() if line.startswith(marker + " ")]
    check(len(receipts) == 1, f"{prefix} marker count {len(receipts)} != 1")
    if len(receipts) == 1:
        try:
            check(json.loads(receipts[0], object_pairs_hook=duplicate_key) == report, f"{prefix} marker/report mismatch")
        except Exception as exc:
            failures.append(f"{prefix} marker JSON invalid: {exc}")
    render_summary[prefix] = {"expected": expected, "actual_pngs": len(files), "renderer": report.get("renderer"), "scope": report.get("scope") or report.get("fixture")}

desktop = artifact("desktop-scaling-render")
clean_log(desktop / "import.log")

# Startup: exact names plus local and console receipts.
startup = artifact("playable-startup-render")
start_report = load(startup / "results.json")
start_names = ["01-title.png", "02-desktop.png", "03-minesweeper.png", "logout-01-consent.png"]
check(start_report == {"ok": True, "captures": 4, "files": start_names}, "startup report does not exactly match expected receipt")
check(sorted(p.name for p in startup.glob("*.png")) == sorted(start_names), "startup actual filenames mismatch")
for p in startup.glob("*.png"):
    try: png(p)
    except Exception as exc: failures.append(f"invalid startup PNG {p.name}: {exc}")
all_pngs.extend(startup.glob("*.png"))
start_log = (startup / "render.log").read_text(encoding="utf-8", errors="replace")
clean_log(startup / "render.log")
for marker in ("PLAYABLE_STARTUP_PASS", "PLAYABLE_DAY_PASS", "PLAYABLE_LOGOUT_PASS"):
    check(len(re.findall(r"(?m)^" + marker + r"(?::|\s|$)", start_log)) == 1, f"startup marker {marker} count mismatch")
desktop_console = (LOGS / "110965240122.log").read_text(encoding="utf-8", errors="replace")
check(output_lines(desktop_console, "PLAYABLE_STARTUP_RENDER_VERIFIED: 4 captures") == 1, "startup console receipt count mismatch")

# UI literal reports and console receipt.
ui = artifact("ui-literal-audit")
ui_summary = {}
for filename in ("ui_literal_disposition.json", "script_ui_disposition.json"):
    report = load(ui / filename)
    check(isinstance(report.get("records"), list) and len(report.get("records", [])) > 0, f"{filename} has no records")
    check(report.get("failures") == [], f"{filename} has failures")
    ui_summary[filename] = {"source_count": report.get("source_count"), "records": len(report.get("records", [])), "failures": report.get("failures")}
clean_log(ui / "audit.log")
check(output_lines(desktop_console, "UI_LITERAL_AUDIT_VERIFIED") == 1, "UI_LITERAL_AUDIT_VERIFIED console receipt count mismatch")

# Catalogue source-bound receipt; validator itself was also rerun offline by reviewer.
catalog = SOURCE / "tools/localization/validate_japanese_korean_catalogs.py"
journey_runner = SOURCE / "tools/testing/run_cloud_journeys.py"
speech_runner = SOURCE / "tools/testing/start_cloud_speech.sh"
source_hashes = {
    "tools/testing/run_cloud_journeys.py": "d4097de4ca375d82eea44e7cb5e30bac35d0eb3320fef54343620aa309e049a4",
    "tools/localization/validate_japanese_korean_catalogs.py": "8af5a9e4aa6ddc62ba42ed55a2952e0791ab422dd7b59b894a4d4506c746c392",
    "tools/testing/start_cloud_speech.sh": "24ae0eb0f38e04b6063270e29ccba3fd9aab644f39b12e3a853adf68d5717cc7",
}
for rel, expected_hash in source_hashes.items():
    check(sha(SOURCE / rel) == expected_hash, f"source8 file hash mismatch: {rel}")
catalog_lines = [
    "ja: 303 UI messages; IDs, placeholders, line breaks and NFC verified.",
    "ko: 303 UI messages; IDs, placeholders, line breaks and NFC verified.",
]
for line in catalog_lines:
    check(output_lines(desktop_console, line) == 1, f"catalogue console receipt mismatch: {line}")

# Speech capability receipts from all three rendered jobs/artifacts.
speech_summary = {}
for label, job_id in (("journeys", 110965239910), ("desktop", 110965240122), ("hospital-reading", 110965240048)):
    d = artifact("cloud-speech-rendered-" + label)
    voices = (d / "voices.txt").read_text(encoding="utf-8", errors="replace").splitlines()
    # Mirrors start_cloud_speech.sh's language-bearing row count, excluding headers.
    parsed = sum(1 for row in voices if len(row.split()) >= 2 and any(re.fullmatch(r"[a-z]{2,3}(?:[-_][A-Za-z0-9]+)*", x) for x in row.split()[1:]))
    check(parsed == 13151, f"speech {label} parsed voice count {parsed} != 13151")
    check("espeak-ng" in (d / "modules.txt").read_text() and "openjtalk" in (d / "modules.txt").read_text(), f"speech {label} modules missing")
    check("dwm_ci" in (d / "sinks.txt").read_text(), f"speech {label} null sink missing")
    check((d / "voices-attempt-1.stderr.txt").stat().st_size == 0, f"speech {label} enumeration stderr nonempty")
    check("Module espeak-ng started successfully" in (d / "speech-dispatcher.log").read_text(errors="replace"), f"speech {label} dispatcher module not started")
    console = (LOGS / f"{job_id}.log").read_text(encoding="utf-8", errors="replace")
    check(output_lines(console, "CLOUD_SPEECH_NATIVE_VOICES count=13151 attempts=1") == 1, f"speech {label} console receipt mismatch")
    speech_summary[label] = {"parsed_language_rows": parsed, "sink": "dwm_ci", "modules_required": ["espeak-ng", "openjtalk"], "enumeration_stderr_bytes": 0}

# Complete cloud-journey case/process/marker/capture audit.
journeys = artifact("playable-journeys")
run_dirs = [p for p in journeys.iterdir() if p.is_dir()]
check(len(run_dirs) == 1, f"journey raw run directory count {len(run_dirs)} != 1")
run_dir = run_dirs[0]
check((journeys / "results.json").read_bytes() == (run_dir / "results.json").read_bytes(), "journey top/raw results bytes differ")
jdoc = load(journeys / "results.json")
check(jdoc.get("ok") is True, "journey aggregate not ok")
case_specs = {
    "seven-days-ending-gallery": ({"PLAYABLE_STARTUP_PASS", "PLAYABLE_DAY_PASS", "PLAYABLE_SEVEN_DAY_PASS", "PLAYABLE_ENDING_PASS", "PLAYABLE_GALLERY_PASS"}, set(), 4, "No prior ending or reached-presentation fixture."),
    "seven-days-condition-ending": ({"PLAYABLE_STARTUP_PASS", "PLAYABLE_DAY_PASS", "PLAYABLE_SEVEN_DAY_PASS", "PLAYABLE_DAY7_CONDITION_PASS"}, set(), 3, "No prior ending or reached-presentation fixture."),
    "dating-reload": ({"PLAYABLE_STARTUP_PASS", "PLAYABLE_DATING_RELOAD_PASS", "PLAYABLE_DATING_QUICK_PASS", "PLAYABLE_DATING_PASS"}, set(), 7, "No prior ending or reached-presentation fixture; empty DTL earns no signature."),
    "practice-empty-dtl": ({"PRACTICE_FIXTURE", "PLAYABLE_EMPTY_DTL_PRACTICE_PASS"}, {"PRACTICE_LEGACY_FIXTURE", "PLAYABLE_REHEARSAL_LEGACY_PASS"}, 5, "Prior-ending milestone only. Canonical empty DTL must leave Practice empty."),
    "practice-legacy-compatibility": ({"PRACTICE_FIXTURE", "PRACTICE_LEGACY_FIXTURE", "PLAYABLE_REHEARSAL_LEGACY_PASS"}, {"PLAYABLE_EMPTY_DTL_PRACTICE_PASS"}, 8, "Explicit prior-ending and historical reached-signature fixtures. Private-board compatibility evidence only; never evidence that empty canonical DTL was witnessed."),
}
cases = jdoc.get("cases", [])
check([c.get("case_id") for c in cases] == list(case_specs), "journey case IDs/order mismatch")
jsonl = [json.loads(x, object_pairs_hook=duplicate_key) for x in (journeys / "runs.jsonl").read_text().splitlines() if x.strip()]
check(len(jsonl) == 5 and jsonl == cases, "runs.jsonl does not exactly reproduce five cases")
roots, user_dirs = set(), set()
journey_summary = {}
for c in cases:
    cid = c.get("case_id")
    required, forbidden, capture_count, fixture_scope = case_specs.get(cid, (set(), set(), -1, ""))
    cdir = run_dir / cid
    check(load(cdir / "result.json") == c, f"journey {cid} per-case result mismatch")
    check(c.get("ok") is True and c.get("failures") == [], f"journey {cid} failed")
    check(c.get("fixture_scope") == fixture_scope, f"journey {cid} fixture scope mismatch")
    check(c.get("user_dir_strictly_contained") is True, f"journey {cid} user dir not strictly contained")
    roots.add(c.get("isolation_root")); user_dirs.add(c.get("user_dir"))
    markers = c.get("markers", {})
    check(set(markers) == required and all(markers[x] == 1 for x in required), f"journey {cid} marker set/count mismatch")
    stdout = (cdir / "journey.stdout.txt").read_text(encoding="utf-8", errors="replace")
    for marker in required:
        check(len(re.findall(r"(?m)^" + re.escape(marker) + r"(?::|\s|$)", stdout)) == 1, f"journey {cid} stdout marker {marker} count mismatch")
    for marker in forbidden:
        check(marker not in stdout and marker not in markers, f"journey {cid} forbidden marker present: {marker}")
    for kind, key in (("journey", "journey"), ("user-dir-proof", "user_dir_proof")):
        receipt = load(cdir / f"{kind}.process.json")
        check(receipt == c.get(key), f"journey {cid} {kind} process receipt mismatch")
        check(receipt.get("exit_code") == 0 and receipt.get("timed_out") is False, f"journey {cid} {kind} nonzero/timeout")
        check((cdir / f"{kind}.stderr.txt").stat().st_size == 0, f"journey {cid} {kind} stderr nonempty")
        clean_log(cdir / f"{kind}.stdout.txt")
        clean_log(cdir / f"{kind}.log")
    captures = c.get("captures", [])
    actual = sorted((cdir / "captures").glob("*.png"))
    check(len(captures) == capture_count and len(actual) == capture_count, f"journey {cid} capture count mismatch")
    check({pathlib.Path(x.get("file", "")).name for x in captures} == {p.name for p in actual}, f"journey {cid} capture names mismatch")
    by_name = {pathlib.Path(x["file"]).name: x for x in captures}
    for p in actual:
        rec = by_name[p.name]
        try:
            dims = png(p)
            check(dims == (rec.get("width"), rec.get("height")), f"journey {cid}/{p.name} dimensions mismatch")
            check(p.stat().st_size == rec.get("bytes") and sha(p) == rec.get("sha256"), f"journey {cid}/{p.name} byte/hash mismatch")
        except Exception as exc:
            failures.append(f"invalid journey PNG {cid}/{p.name}: {exc}")
    all_pngs.extend(actual)
    journey_summary[cid] = {"ok": c.get("ok"), "fixture_scope": fixture_scope, "required_markers": sorted(required), "forbidden_markers": sorted(forbidden), "captures": len(actual), "isolated": c.get("user_dir_strictly_contained")}
check(len(roots) == 5 and len(user_dirs) == 5, "journey isolation roots/user dirs are not all distinct")
clean_log(journeys / "import.log")
journey_console = (LOGS / "110965239910.log").read_text(encoding="utf-8", errors="replace")
check(output_lines(journey_console, "PLAYABLE_JOURNEYS_VERIFIED: 5 isolated rendered cases") == 1, "journey console receipt count mismatch")

result = {
    "schema": 1,
    "audit": "hospital-broad1-rendered-audit",
    "status": "pass" if not failures else "fail",
    "failures": failures,
    "identity": {"run_id": RUN, "workflow_head": HEAD, "runtime_source": SOURCE8},
    "jobs": job_summary,
    "render_reports": render_summary,
    "startup": {"captures": 4, "files": start_names, "markers": ["PLAYABLE_STARTUP_PASS", "PLAYABLE_DAY_PASS", "PLAYABLE_LOGOUT_PASS"]},
    "ui_literal": ui_summary,
    "source_file_sha256": source_hashes,
    "catalogues": {"validator_sha256": sha(catalog), "receipts": catalog_lines, "offline_rerun": "same two success lines"},
    "speech_capability": speech_summary,
    "journeys": journey_summary,
    "cardinality": {"render_report_pngs": 133, "startup_pngs": 4, "journey_pngs": 27, "total_pngs_structurally_checked": len(all_pngs)},
    "manual_visual_review": {
        "reviewed_count": 14,
        "method": "view_image original-detail representative inspection",
        "files": [
            "desktop-scaling-render/launcher-ja-readable-large-contrast-960.png",
            "delivery-dialogue-render/challenge-group-ko150-640-rules.png",
            "delivery-dialogue-render/dialogue-older-zh-HK150.png",
            "angela-overlay-render/narrow-zh-HK150-high-contrast.png",
            "angela-overlay-render/narrow-en150-last-row.png",
            "japanese-korean-ui-render/ja-settings-150.png",
            "font-choices-render/pixel-ja-minesweeper-150.png",
            "font-choices-render/readable-ja-minesweeper-150.png",
            "playable-startup-render/logout-01-consent.png",
            "playable-journeys/seven-days-ending-gallery/09-gallery.png",
            "playable-journeys/seven-days-condition-ending/03-minesweeper.png",
            "playable-journeys/dating-reload/06-dating-quick-consent.png",
            "playable-journeys/practice-empty-dtl/05-empty-practice-picker.png",
            "playable-journeys/practice-legacy-compatibility/06-practice-board.png",
        ],
        "finding": "No obvious tofu, clipping, overlap, missing control, or inaccessible scroll endpoint in the representative frames; expected wrapping and disabled-control styling observed.",
    },
    "limits": [
        "Representative visual inspection is not exhaustive visual acceptance of all 164 structurally checked PNGs.",
        "Rendered hashes, geometry, logs, and software-display screenshots do not prove native accessibility semantics or hardware/OS rendering.",
        "Speech evidence proves Linux service/module startup, a software null sink, and language-bearing voice enumeration; it does not prove audible playback or Windows/native assistive-technology integration.",
        "This audit excludes Hospital PNG semantics, original reading/selector evidence, ordinary tests, export, and performance evidence, which are assigned to other reviews.",
    ],
}
(OUT / "audit.json").write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(json.dumps({"status": result["status"], "failures": len(failures), "pngs": len(all_pngs)}, sort_keys=True))
sys.exit(0 if not failures else 1)

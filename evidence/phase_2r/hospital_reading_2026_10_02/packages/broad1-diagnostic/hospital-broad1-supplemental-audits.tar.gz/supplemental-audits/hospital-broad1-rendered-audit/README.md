# Broad-run rendered evidence audit

## Verdict

**PASS within the bounded scope below.** The offline audit found no failures. It binds the retained evidence to Actions run `37044894986`, successful jobs at workflow head `1bc4f6afd759e969f82b9c2134eb178479c19d13`, and the inspected source checkout `856520f09440d9b47cc272de3363009924ffedca`.

The machine-readable result is `audit.json`; `audit_rendered.py` reproduces the structural, receipt, process, log, and cardinality checks without launching Godot.

## Evidence binding

| Job | Job ID | Bound evidence | Result |
|---|---:|---|---|
| Rendered seven-day, ending, Gallery and Dating journeys | 110965239910 | journeys and speech | completed / success; exact checkout output; required steps successful |
| Rendered desktop and dialogue / Linux software OpenGL | 110965240122 | five render sets, startup, UI literal, catalogue, speech | completed / success; exact checkout output; required steps successful |
| Rendered Hospital reading / Schedule-Done Save and fresh-process Load | 110965240048 | speech capability only in this audit | completed / success; exact checkout output; required speech steps successful |

The source8 journey runner, catalogue validator, and cloud-speech bootstrap were hash-bound. The catalogue validator was independently rerun offline and reproduced the retained `ja` and `ko` 303-message success lines.

## Rendered cardinality and receipts

| Evidence set | Reported samples | Reported captures | Actual PNGs | Renderer/result |
|---|---:|---:|---:|---|
| Desktop scaling | 38 | 38 | 38 | X11; `ok=true`; no failures |
| Delivery/dialogue | 25 | 25 | 25 | X11; `ok=true`; no failures |
| Angela overlay | 10 | 10 | 10 | X11; `ok=true`; no failures |
| Japanese/Korean UI | 30 | 30 | 30 | X11; `ok=true`; no failures |
| Font choices | 30 | 30 | 30 | X11; `ok=true`; no failures |
| Startup/Logout | — | 4 | 4 | exact four filenames and three PASS markers |
| Five cloud journeys | — | 27 | 27 | exact per-case receipt/hash/dimensions |

All **164** PNGs in scope were structurally parsed with positive dimensions. For each of the five primary render reports, the one retained `*_RENDER_VERIFIED` JSON payload equals `results.json`. Logs were checked for script, parse, Unicode/NUL, PLAYABLE failure, and resource-lifetime diagnostics. None were found.

Startup has exactly `01-title.png`, `02-desktop.png`, `03-minesweeper.png`, and `logout-01-consent.png`; `PLAYABLE_STARTUP_PASS`, `PLAYABLE_DAY_PASS`, and `PLAYABLE_LOGOUT_PASS` each occur once in the retained render log. The completed job has one actual-output `PLAYABLE_STARTUP_RENDER_VERIFIED: 4 captures` receipt; command echo text was excluded from the count.

## Cloud journeys

The top-level and raw UUID `results.json` files are byte-identical. `runs.jsonl` exactly reproduces the five cases in source order. Each case has its own distinct isolation root and user directory, `user_dir_strictly_contained=true`, successful non-timeout journey and user-dir-proof receipts, empty stderr, strict-clean stdout/engine logs, and exact PNG byte/hash/dimension binding.

| Case | Captures | Fixture boundary and semantic receipt |
|---|---:|---|
| `seven-days-ending-gallery` | 4 | No prior ending/reached-presentation fixture; Startup, Day, Seven-Day, Ending and Gallery markers once |
| `seven-days-condition-ending` | 3 | No prior ending/reached-presentation fixture; condition-ending marker is `PLAYABLE_DAY7_CONDITION_PASS` |
| `dating-reload` | 7 | No prior ending/reached-presentation fixture; empty DTL earns no signature; Dating Reload/Quick/final markers once |
| `practice-empty-dtl` | 5 | Prior-ending milestone only; canonical empty DTL leaves Practice empty; legacy fixture/pass markers absent |
| `practice-legacy-compatibility` | 8 | Explicit prior-ending and historical reached-signature fixtures; private-board compatibility only; empty-DTL pass absent |

The completed job contains one actual-output `PLAYABLE_JOURNEYS_VERIFIED: 5 isolated rendered cases` receipt.

## UI literal, catalogue, and speech capability

- `ui_literal_disposition.json`: 31 sources, 53 records, no failures.
- `script_ui_disposition.json`: 317 sources, 330 records, no failures.
- The completed desktop job contains one actual-output `UI_LITERAL_AUDIT_VERIFIED` receipt.
- Japanese and Korean catalogue receipts each report 303 messages with IDs, placeholders, line breaks, and NFC verified; the corresponding job step succeeded and the source8 validator independently reproduced both lines.
- All three rendered jobs retained `espeak-ng` and `openjtalk` module listings, a `dwm_ci` null sink, empty first-attempt enumeration stderr, successful Speech Dispatcher `espeak-ng` startup, 13,151 independently parsed language-bearing voice rows, and one matching console receipt.

The speech bootstrap source explicitly limits this evidence to enumeration: it does not establish audible output or Windows accessibility acceptance.

## Representative visual review

Fourteen representative PNGs were opened at original detail, spanning every evidence family and all five journeys. The sample included narrow/wide and bottom-scrolled Angela states, Japanese/Korean/Traditional Chinese text, 150% layouts, pixel/readable font variants, rules/dialogue, Logout and Dating consent modals, Gallery, board, and empty/legacy Practice states.

No obvious tofu, clipping, unintended overlap, missing control, or unreachable inspected scroll endpoint was visible. Expected label wrapping and disabled-control styling were present. Representative examples included:

- desktop Japanese large/contrast launcher;
- Korean 150% challenge rules and Traditional Chinese older dialogue;
- narrow Traditional Chinese Angela overlay and bottom-scrolled English final stat row;
- Japanese 150% Settings plus pixel/readable Japanese Minesweeper;
- Logout consent;
- one semantically central frame from each of the five journeys.

## Limits and exclusions

- The manual image review is representative, not exhaustive visual acceptance of all 164 PNGs.
- Software-display screenshots, geometry, hashes, and clean logs do not prove native accessibility semantics, hardware/OS rendering, or Windows behavior.
- Speech evidence proves service/module startup, a software audio endpoint, and voice enumeration, not audible playback or native assistive-technology integration.
- Delivery/dialogue, Japanese/Korean, font, and related reports state fixture boundaries: several records/boards/dialogues are synthetic and are not claims of full gameplay acceptance.
- This report deliberately excludes Hospital PNG semantics, original reading/selector evidence, ordinary tests, export, and performance. Those are assigned to separate reviews.

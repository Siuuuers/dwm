# Broad Hospital candidate: independent evidence checklist

Run **37044894986**; expected workflow head/actual checkout **1bc4f6afd759e969f82b9c2134eb178479c19d13**; runtime source **856520f09440d9b47cc272de3363009924ffedca**. This is a source-bound checklist, not evidence acceptance. `checklist-identities.json` binds the source files, helpers, workflow manifest, exact job names and named-test census.

## Identity, completeness and ordinary tests

- Require completed successful run and all **24 exact job names** in the bound manifest, with no failed/cancelled/skipped mandatory jobs or steps. Require all 23 checkout-bearing jobs' observed `git log -1 --format=%H` values to equal the workflow head. The sole checkout-free job is `Windows / seven-day retained history`.
- Independently retain ordered head parents `[e0317e13c226f3c7142ac31d1ae28050561c65b0, 856520f09440d9b47cc272de3363009924ffedca]`. The complete source-to-head tree difference must be only the added `.github/workflows/hospital-reading-cloud.yml`, whose blob bytes match `hospital-broad1.yml`. Do not call the previous auxiliary head `master`.
- Match API run/head/attempt, complete paginated jobs/artifacts, original ZIP API digest/size, ZIP CRC, every extracted member's bytes/hash, and artifact names to the same run/attempt. Preserve duplicate attempts explicitly; do not silently combine older passing components with the current run.
- Require **13 ordinary/public XML reports, 2,421 case executions, 204 script executions, 2,417 unique named cases, 203 unique scripts**. Compare every `(suite, script, test)` multiset against the bound named census, not just totals. No failures/errors/skips/disabled cases; no missing or duplicated ordinary fixture/case. Reconcile each `CLOUD_GUT_RESULT` and runner receipt with its XML.

| Suite | Cases |
|---|---:|
| public_surfaces | 11 |
| minesweeper | 210 |
| shop | 128 |
| desktop | 334 |
| settings | 357 |
| checkpoint_diagnostics | 22 |
| new_account | 179 |
| reading_delivery | 480 |
| localization | 153 |
| dating | 167 |
| persistence | 230 |
| endings | 106 |
| audio | 44 |

- Require public inventory command exactly `Invoke-PublicSurfaceValidation.ps1 -EmitPayloads`, without regeneration; compare emitted inventory bytes with source8 `evidence/phase_2r/runtime/{game_state,save_manager}_surface.json`. Retain public fixture-version census and inspect its findings; it is observational, not an automatic legacy-reference failure.
- Read process/import logs and isolation JSONL, not only job status/XML. Reject silent script-load failures, timeout, engine/parse/Unicode errors and resource-lifetime errors outside the exact intentional controls below. Separate shell command echoes containing error regexes from actual diagnostics.

## Intentional negative controls: exact scope only

- Settings has exactly two negative XMLs, `storage-refusal/empty/tests.xml` and `storage-refusal/whitespace/tests.xml`. Each must report **83 cases, 80 failures containing `test_root_missing`, three storage-free passes, zero errors/skips**, and nonzero child exit. Match `storage-refusal/results.json`, isolated user-dir proof and `STORAGE_REFUSAL_VERIFIED`; compare complete `repository-before.json` and `repository-after.json` bytes/hash for each case. These 166 executions are excluded from the 2,421 ordinary cases. No other failing XML inherits this exemption.
- `new_account` must contain exactly one diagnostic `Unicode parsing error, some characters were replaced with � (U+FFFD): Invalid UTF-8 leading byte (ff)`, attributable to `tests/integration/test_prepared_new_run.gd::test_prepare_counts_nonempty_unreadable_autosave_but_not_zero_bytes`, and one `CORRUPT_SAVE_DIAGNOSTIC_VERIFIED` receipt. No NUL or other Unicode error is exempt.
- Public isolation tooling intentionally expects child exit **124** for forbidden argument/path refusals and its `fixture-timeout`. Timeout JSONL must contain exactly one `suite_id=fixture-timeout`, `exit_code=124`, duration **19–50 seconds**, retained nonempty engine/timeout logs, and cleaned isolated root; require `ISOLATION_HELPER: PASS`. This is not an exemption for an Actions job timeout.
- Settings standalone `cloud-manual-witness-revision-storage.log` needs one `MANUAL_WITNESS_REVISION_STORAGE_PASS`, exit zero and no script/Unicode errors. Persistence needs one `SAVE_LOAD_CAPTURE_PASS <count> checks; failures=0`, exit zero and clean process logs. `new-account-latency.json` needs `ok=true`, exactly fresh/replacement samples, positive `button_to_desktop_us` and nonnegative `max_frame_gap_us`. These assertions are not added to GUT totals.

## Retained original Solo, F5 and F9 controls

- `reading-rail-*` top/raw `result.json` must agree, `ok=true`, `failures=[]`, checkout=head. Require precisely eight original reports: `write, read, repeat, variant, witness-read, next-unseen, next, next-read`, all distinct positive process IDs; process receipt set is these plus `user-dir-proof`. Match one mode PASS per stdout, exit zero/no timeout, strict stdout/stderr/engine logs, exact isolated profile and source identities.
- Require writer/reader equality of canonical transcript, current line, physical record and exact retained Quick bytes; writer live speech positive, fresh Load and History silent. Recompute original Pause/slot3 proof against raw saved document, including partial Cancel/Continue and Save completing only the same current reveal; a retained slot hash alone does not prove an independent fresh slot Load.
- Recheck `sealed-write-read` files and `write-read-seal.json`: exact writer/reader bytes and nine original PNGs preserved; final transactions preserve sealed byte prefix. Supplemental modes must not replace/reseal the original proof. Match exact trace kinds/order/process IDs against source `TRACE_KINDS`, not only sequence numbers.
- Recompute exact-repeat/changed-revision witness identity against physical `witness-profile.json`; retain distinct causal sessions, same stable beat, failed Profile write with neutral retry, exact durable witness receipt and zero restored speech. Recompute Next proof and exact saved Autosave: exclusive versioned operation, suppressed intermediate presentation/frontier/credit, correct unseen refusal, exact destination challenge and fresh Load without transport replay.
- Independently check `challenge_layout` raw observations/minimums: source demands **120 required visible samples**, no dropped events, distinct frame sequences, finite nonempty geometry and no clipped challenge title. Verify all three Next captures against identities/PNG dimensions. Generic reading audit does not cover this.
- F5 is nested `settings_quick_save`, with separate isolated Settings profile and fresh `settings-write`/`settings-read` processes. Require `ok=true`, no failures, writer seal intact, exact seven-row F5 transaction/report binding, one physical Quick candidate, only Quick-family mutations, unchanged Autosave/Profile. Literal partial A remains through Settings entry; F5 finishes only A, preserving checkpoint/history/physical identity and host/focus/suspension. Fresh reader restores exact saved checkpoint/history/physical/app with zero speech.
- F9 is nested `settings_quick_save.settings_load`, its own fresh process and independent `settings-load-transactions.jsonl`. Require all seven raw stages (`initial, advanced, entered, prepared, cancelled, reprepared, confirmed`) to equal trace/report observations and contain exactly the source-defined all-true check sets. Match released Enter then Escape `InputEventKey` packets on increasing frames. Source B is partial/different from saved A; Prepare/Cancel preserve exact source, scene, focus, scroll, suspension and primary files, and reprepare uses a new token. Confirm restores saved A/history/physical/app, closes old Settings/Pause, no restored speech, no primary-file mutation.
- F9 primary input/baseline/final Quick/Autosave/Profile copies must satisfy the source-specific boundaries; do not claim recovery files are unchanged. Recovery proof requires **224 ordered FileOps = 16 atomic commits × 14 operations**, exact raw before/after issuer and continuation endpoints, preserved prior records, exactly one completed restore operation, nine participant receipts, exact retained Quick bundle/document hashes and request fingerprint, one allocation, contiguous appended issuer receipts, and zero primary-file operation attempts.

## Other rendered evidence

- `solo-authored-selector-*`: require fresh write/read, source-bound result, writer seal/trace prefix, exact retained Quick/Profile/Next source/destination bytes, selected programmes independently derived from authority frames, unseen/next witness rules and zero replay. Require coherent earlier PRE-frame forgery to remain internally valid yet refused by writer/route authority (`reading_context_invalid`) and actual restore participant (`invalid_narrative_checkpoint`, `reading_entry_context_mismatch`), with live state/files unchanged. Match 8 writer + 4 reader trace rows and nine original captures.
- `hospital-reading-*`: apply the independent bounded Hospital semantic checklist to this run's own write/read/forge bytes, fresh processes, seals, raw authority refusals, unchanged slot3 and forge primary files, exactly-once completion, durable day4 settlement and next Solo fresh History. Prior focus5 acceptance cannot substitute for broad-head evidence.
- `cloud journeys`: require five exact cases `seven-days-ending-gallery`, `seven-days-condition-ending`, `dating-reload`, `practice-empty-dtl`, `practice-legacy-compatibility`; each fresh isolated profile, required marker counts exactly one, forbidden fixture markers absent, exit zero/no timeout and strict logs/captures. Preserve explicit prior-ending/legacy fixture scope; empty canonical DTL does not earn an ending/signature.
- Desktop render reports: `ok=true`, `failures=[]`, renderer non-headless; report samples=captures=actual nonempty PNG count: desktop scaling **38**, delivery/dialogue **25**, Angela overlay **10**, Japanese/Korean UI **30**, font choices **30**. Startup/Logout needs four exact named captures and Startup/Day/Logout PASS markers. Both UI-literal disposition reports must contain records and no failures; require `UI_LITERAL_AUDIT_VERIFIED`. Retain Japanese/Korean catalogue validation and speech capability receipts from all three rendered jobs. Hashes and markers do not establish visual quality or native accessibility.

## Export, performance and retained history

- Export `validation.json`: `ok=true`, `commit=head`, `engine=4.6.3.stable`, `architecture=x86_64`, `signed=false`, exact pinned templates hash, smoke and pack-audit `ok=true`, isolated Profile created, 240 headless iterations, positive runtime-data verified count. Match `WINDOWS_PACK_DATA_VERIFIED`, `WINDOWS_EXPORT_RECEIPT`, executable/PCK/file hashes, nested archive bytes/SHA256 and `SHA256SUMS.txt` to actual package files; verify export/smoke/pack-audit console and engine logs. This is unsigned headless startup/data acceptance, not graphical Windows or release acceptance.
- Apply `performance-checklist.md` to raw results, profiles, process JSONL and transferred payloads. Every `checkout_ref` is the **workflow head**, never source8. Timings are evidence; no fixed speedup/budget is implied. Require both controls and candidate measurements with exact source ablation/retention boundaries.

## Generic auditor limits and correct invocation

- Use `cloud_evidence.py audit` with source8, **checkout=workflow head**, `--expected-jobs 24 --expected-xml 13 --allow-source-diff .github/workflows/hospital-reading-cloud.yml --no-checkout-job 'Windows / seven-day retained history' --reading-modes write,read,repeat,variant,witness-read,next-unseen,next,next-read` and every original ZIP directory. The default five reading modes is wrong for this full gate.
- Independently verify run head equals expected checkout and the ordered auxiliary parents; generic audit records run head and parents but does not enforce those equalities without additional caller assertions. Its `--master` option is specifically labeled for PR merge ancestry and should not misdescribe this auxiliary parent.
- Generic job/XML audits validate counts, status and observed checkout, but do not compare exact expected job names or source-derived named test census. Its storage-refusal path exclusion is broad and does not establish the specific two negative controls above.
- Generic original reading checks cover baseline restoration, bytes/seals/PIDs and selected witness joins. They do **not** independently verify all trace semantics, Next/layout, nested F5/F9, authored selector, Hospital, complete journeys, storage-fault semantics, performance, export, rendering or visual inspection.
- Packaging verifies every original extracted member before omission, but omits binaries/nested ZIPs, public inventory duplicates, some speech diagnostics and non-reading PNGs. In particular Hospital PNGs are omitted by the generic artifact-prefix rule. Retain original ZIPs and separately retained source-bound public inventories/Hospital visuals where needed; a package receipt is not acceptance of omitted payload semantics.
- Keep PR draft/unmerged at its accepted checkpoint until this full evidence review finishes. Passing this bounded candidate does not close remaining production-content/ingress/condition/pair/ending/native-accessibility work or all Beads tasks.

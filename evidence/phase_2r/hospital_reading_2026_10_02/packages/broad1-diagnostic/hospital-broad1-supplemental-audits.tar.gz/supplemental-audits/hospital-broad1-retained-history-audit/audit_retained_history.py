#!/usr/bin/env python3
"""Offline, read-only review of the source-bound Day7 retained-history producer."""
from pathlib import Path, PureWindowsPath
from copy import deepcopy
from collections import Counter, defaultdict
from statistics import median
from datetime import datetime
import hashlib
import json
import re
import subprocess
import sys
import zipfile

BASE=Path('/workspace/scratch/e58f796fe7a3')
REPO=BASE/'dwm'
CAPTURE=BASE/'hospital-broad1-history'
ARTIFACT=CAPTURE/'artifacts/seven-day-history-37044894986-1'
INPUTS=CAPTURE/'artifacts/seven-day-inputs-37044894986'
DATA=ARTIFACT/'ci/seven-day-history'
LOGS=ARTIFACT/'phase2r_logs'
JOBLOG=BASE/'hospital-broad1-history-logs/logs/110965240070.log'
OUT=BASE/'hospital-broad1-retained-history-audit'
SOURCE='856520f09440d9b47cc272de3363009924ffedca'
HEAD='1bc4f6afd759e969f82b9c2134eb178479c19d13'
sys.dont_write_bytecode=True
sys.path.insert(0,str(REPO/'tools/testing'))
import derive_save_admission_baseline as admission_deriver
import derive_save_prepare_baseline as prepare_deriver

checks=[]
def check(ok,name):
    if not ok: raise AssertionError(name)
    checks.append(name)
def sha(raw): return hashlib.sha256(raw).hexdigest()
def ident(path):
    raw=path.read_bytes()
    return {'bytes':len(raw),'sha256':sha(raw)}
def pairs_hook(pairs):
    result={}
    for key,value in pairs:
        if key in result: raise ValueError('duplicate JSON key: '+key)
        result[key]=value
    return result
def strict(text):
    return json.loads(text,object_pairs_hook=pairs_hook,parse_constant=lambda s: (_ for _ in ()).throw(ValueError(s)))
def read(path): return strict(path.read_text(encoding='utf-8-sig'))
def canonical(value): return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def numeric(value): return type(value) in (int,float) and value>=0
def hexhash(value): return isinstance(value,str) and re.fullmatch('[0-9a-f]{64}',value) is not None
def markers(lines,prefix): return [strict(line[len(prefix):]) for line in lines if line.startswith(prefix)]
def only_marker(lines,prefix):
    values=markers(lines,prefix)
    check(len(values)==1,'exact single marker '+prefix)
    return values[0]

raw_before={str(p):ident(p) for root in (ARTIFACT,INPUTS) for p in sorted(root.rglob('*')) if p.is_file()}
manifest=read(CAPTURE/'artifact-manifest.json')
artifact_meta=[]
for root in (ARTIFACT,INPUTS):
    row=next(row for row in manifest if row['name']==root.name)
    zpath=Path(row['local_zip'])
    check(ident(zpath)=={'bytes':row['size_in_bytes'],'sha256':row['digest'].removeprefix('sha256:')},root.name+' original ZIP identity matches API')
    check(row['workflow_run']['id']==37044894986 and row['workflow_run']['head_sha']==HEAD,root.name+' API run and head binding')
    with zipfile.ZipFile(zpath) as archive:
        check(archive.testzip() is None,root.name+' ZIP CRC')
        members=[item for item in archive.infolist() if not item.is_dir()]
        check({p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}=={item.filename for item in members},root.name+' exact ZIP extraction membership')
        for item in members:
            check((root/item.filename).read_bytes()==archive.read(item),root.name+' exact extracted member '+item.filename)
    artifact_meta.append(row)

result=read(DATA/'results.json')
admission=read(DATA/'admission-pairs.json')
manual=read(DATA/'manual-prepare-pairs.json')
transfer=read(DATA/'consumer-input-manifest.json')
payload=read(DATA/'day7-autosave.json')
check(result['checkout_ref']==HEAD,'producer actual checkout identity')
check(result['save_admission_comparison']==admission and result['manual_prepare_comparison']==manual,'standalone paired files exactly equal producer embedded reports')
check('manual_write_comparison' not in result and manual['metric']=='prepare_us','canonical preparation comparison rather than write comparison')
check(transfer['schema_version']==1 and transfer['checkout_ref']==HEAD and transfer['producer_run_id']=='37044894986' and transfer['producer_run_attempt']==1,'producer manifest source run and attempt')
check(set(transfer['files'])=={'results.json','day7-autosave.json'},'exact two transferred payload files')
for name,hashvalue in transfer['files'].items():
    check(ident(DATA/name)['sha256']==hashvalue,'manifest actual bytes '+name)
for name in ('results.json','day7-autosave.json','consumer-input-manifest.json'):
    check((DATA/name).read_bytes()==(INPUTS/name).read_bytes(),'consumer input artifact exact producer copy '+name)
payload_sha=ident(DATA/'day7-autosave.json')['sha256']
check(result['payload_sha256']==result['write']['autosave_sha256']==result['cold_read']['autosave_sha256']==payload_sha,'writer cold reader and actual payload SHA256 join')
check(payload['schema_version']==7 and payload['current_snapshot']['snapshot']['schema_version']==7,'actual document and snapshot schema7')
snapshot=payload['current_snapshot']['snapshot']
check(snapshot['lifecycle']['day']==7,'actual retained snapshot day7')
raw_counts=dict(Counter(bundle['checkpoint_kind'] for bundle in payload['recovery_journal']))
check(raw_counts=={'line':32,'manual_save':32,'pre_board':1,'safe_marker':1},'actual retained source checkpoint kinds')
counts=dict(Counter(bundle['checkpoint_kind'] if bundle['checkpoint_kind'] in ('line','manual_save') else 'semantic' for bundle in payload['recovery_journal']))
check(counts=={'line':32,'manual_save':32,'semantic':2} and len(payload['recovery_journal'])==66,'actual payload 32 line 32 manual and 2 semantic retained checkpoints')

source_files=[
 'tools/testing/Invoke-SevenDayHistoryPerformance.ps1','tools/testing/Invoke-IsolatedGodot.ps1',
 'tools/testing/derive_save_admission_baseline.py','tools/testing/derive_save_prepare_baseline.py',
 'tests/manual/benchmark_seven_day_history.gd','tests/manual/benchmark_manual_save_write.gd',
 'tests/manual/benchmark_minesweeper_click_latency.gd','tests/support/ManualSaveWitnessPort.gd',
 'autoload/SaveManager.gd','scripts/infrastructure/storage/JsonFileStorage.gd',
 *admission['source_code_sha256']['shared'].keys()]
source_ids={}
for name in source_files:
    raw=(REPO/name).read_bytes()
    for revision in (SOURCE,HEAD):
        check(raw==subprocess.check_output(['git','show',f'{revision}:{name}'],cwd=REPO),'exact source '+revision[:12]+' '+name)
    source_ids[name]=ident(REPO/name)
candidate=(REPO/'autoload/SaveManager.gd').read_bytes()
for name,derive,recorded in (
    ('baseline-SaveManager.gd',admission_deriver.derive_baseline,admission['source_code_sha256']['baseline']),
    ('baseline-prepare-SaveManager.gd',prepare_deriver.derive_baseline,manual['source_code_sha256']['baseline'])):
    derived=derive(candidate)
    check(derived==(DATA/name).read_bytes() and sha(derived)==recorded,'exact current-source ablation derivation '+name)
check(admission['source_code_sha256']['candidate']==manual['source_code_sha256']['candidate']==sha(candidate),'candidate SaveManager source SHA256')
for name,expected in admission['source_code_sha256']['shared'].items():
    check(ident(REPO/name)['sha256']==expected,'shared schema source '+name)
check(manual['shared_schema_sha256']==admission['source_code_sha256']['shared'],'preparation and admission shared schema equality')
for key,name in {'storage':'scripts/infrastructure/storage/JsonFileStorage.gd','harness':'tests/manual/benchmark_manual_save_write.gd','witness_port':'tests/support/ManualSaveWitnessPort.gd'}.items():
    check(manual['source_code_sha256'][key]==ident(REPO/name)['sha256'],'manual exact current '+key+' source SHA256')

expected=['write','read-cache-disabled','read-cache-enabled']
for family in ('read-admission','prepare'):
    for pair in range(1,9):
        for variant in (('baseline','candidate') if pair%2 else ('candidate','baseline')):
            expected.append(f'{family}-pair-{pair}-{variant}')
check(len(expected)==35 and {p.stem for p in DATA.glob('*.jsonl')}==set(expected),'exact 35 isolated probe files')
probe_records={}
probe_lines={}
error=re.compile(r'SCRIPT ERROR:|(?:^|\s)ERROR:|Unicode parsing error|Unexpected NUL|Parse Error:|Resource still in use:|Leaked instance:|Orphan StringName:|ObjectDB instances leaked|SEVEN_DAY_HISTORY_FAIL|MANUAL_SAVE_WRITE_FAIL|CLICK_LATENCY_FAIL')
for name in expected:
    rows=[strict(line) for line in (DATA/f'{name}.jsonl').read_text(encoding='utf-8-sig').splitlines() if line.strip()]
    check(len(rows)==1,name+' exact isolated process record')
    receipt=rows[0]
    check(receipt['suite_id']=='cloud-seven-day-history-'+name and receipt['exit_code']==0,name+' suite identity and zero exit')
    root=PureWindowsPath(receipt['test_root']); user=PureWindowsPath(receipt['user_dir'])
    check(root.is_absolute() and root.parent==PureWindowsPath('D:/a/dwm/dwm/.godot/phase2r_tests') and user.is_relative_to(root/'appdata') and user.name=='DWM',name+' unique contained Windows isolated user root')
    argv=receipt['argv']; logname='cloud-seven-day-history-'+name+'.log'
    check(PureWindowsPath(receipt['log_path'])==PureWindowsPath('D:/a/dwm/dwm/.godot/phase2r_logs')/logname and PureWindowsPath(argv[argv.index('--log-file')+1])==PureWindowsPath(receipt['log_path']),name+' exact log receipt path')
    check(argv[:3]==['--headless','--path','D:\\a\\dwm\\dwm'],name+' expected cloud headless invocation')
    if name.startswith('prepare'):
        check(argv[argv.index('-s')+1]=='res://tests/manual/benchmark_manual_save_write.gd' and '--phase2r-bootstrap-mode=test_manual' in argv,name+' real manual-save harness')
        sourcearg=next(arg.split('=',1)[1] for arg in argv if arg.startswith('--write-source='))
        check(PureWindowsPath(sourcearg)==PureWindowsPath(probe_records['write']['user_dir'])/'saves',name+' exact retained writer saves source')
    else:
        check(argv[argv.index('-s')+1]=='res://tests/manual/benchmark_seven_day_history.gd' and '--phase2r-bootstrap-mode=final' in argv and '--history-phase='+('write' if name=='write' else 'read') in argv,name+' actual history harness phase')
        if name!='write':
            sourcearg=next(arg.split('=',1)[1] for arg in argv if arg.startswith('--user-data='))
            check(PureWindowsPath(sourcearg)==PureWindowsPath(probe_records['write']['user_dir']),name+' exact retained writer source')
    start=datetime.fromisoformat(receipt['started_at_utc'].replace('Z','+00:00')); end=datetime.fromisoformat(receipt['ended_at_utc'].replace('Z','+00:00'))
    check(0<(end-start).total_seconds()<(660 if name=='write' else 180),name+' bounded recorded duration')
    lines=(LOGS/logname).read_text(encoding='utf-8-sig').splitlines()
    check(bool(lines) and not any(error.search(line) or '\x00' in line for line in lines),name+' no engine script Unicode NUL timeout failure or lifetime diagnostics')
    probe_records[name]=receipt; probe_lines[name]=lines
check(len({r['test_root'] for r in probe_records.values()})==35 and len({r['user_dir'] for r in probe_records.values()})==35,'all 35 probes have distinct isolated roots')
ordered=sorted(expected,key=lambda name:probe_records[name]['started_at_utc'])
check(ordered==expected,'cold controls then exact alternating admission and preparation process execution order')
for prior,later in zip(expected,expected[1:]):
    check(probe_records[prior]['ended_at_utc']<=probe_records[later]['started_at_utc'],'nonoverlapping sequential probes '+prior+' -> '+later)
import_text=(ARTIFACT/'ci/import.log').read_text(encoding='utf-8-sig')
check(not error.search(import_text) and '\x00' not in import_text,'clean import log')

write_lines=probe_lines['write']
check(only_marker(write_lines,'SEVEN_DAY_HISTORY_WRITE_PASS: ')==result['write'],'writer terminal receipt matches results')
check(markers(write_lines,'SEVEN_DAY_HISTORY_DAY: ')==result['days'],'raw seven day receipts match results')
check(result['write']['days']==7 and result['write']['synthetic_checkpoints']==98 and result['write']['retained']==counts,'seven day writer declared fixture and retained counts')
check([row['day'] for row in result['days']]==list(range(1,8)),'exact ascending day1 through day7')
for row in result['days']:
    day=row['day']
    check(row['retained']=={'line':min(day*7,32),'manual_save':min(day*8,32),'semantic':2},f'day{day} exact retention curve')
    check(all(numeric(row[key]) for key in ('first_reveal_sync_us','terminal_reveal_sync_us','terminal_settlement_us','manual_slot_save_us','manual_slot_prepare_us','manual_slot_commit_us')),f'day{day} nonnegative timing observations')
    check(row['terminal_settlement_us']>=row['terminal_reveal_sync_us'],f'day{day} settlement includes terminal command')
    check(set(row['synthetic_checkpoint_us'])=={'line','manual_save'} and all(len(v)==7 and all(numeric(x) for x in v) for v in row['synthetic_checkpoint_us'].values()),f'day{day} fourteen synthetic checkpoint samples')
    check(hexhash(row['autosave_sha256']) and all(type(x) is int and x>=0 for x in row['files'].values()),f'day{day} physical file metrics and hash')
check(result['days'][-1]['autosave_sha256']==payload_sha and result['days'][-1]['files']['saves/autosave.json']==ident(DATA/'day7-autosave.json')['bytes'],'day7 actual retained payload hash and length')

parse=result['parse_cache_comparison']; cold=result['cold_read']
for variant in ('disabled','enabled'):
    observed=only_marker(probe_lines['read-cache-'+variant],'SEVEN_DAY_HISTORY_READ_PASS: ')
    check(observed==parse[variant],variant+' raw cold control equals result')
    check(observed['parse_cache_enabled']==(variant=='enabled') and observed['save_manager_sha256']==sha(candidate),variant+' only parse cache control and actual source')
check(cold==parse['enabled'],'cold_read is enabled control')
restored_hashes={}
gameplay=deepcopy(snapshot['gameplay'])
gameplay['route_context'].update({'run_id':snapshot['run_id'],'day':snapshot['lifecycle']['day'],'lifecycle_state':snapshot['lifecycle']['state'],'active_app_id':snapshot['active_app_id'],'ending_plan':snapshot['lifecycle']['ending_plan'],'contacts':snapshot['contacts'],'committed_schedule':snapshot['committed_schedule'],'dating':snapshot['dating']})
for key,value in {'restored_gameplay_sha256':gameplay,'restored_board_sha256':snapshot['desktop']['board']['board'],'restored_recovery_journal_sha256':payload['recovery_journal']}.items():
    expected_hash=sha(canonical(value)); restored_hashes[key]=expected_hash
    check(cold[key]==parse['disabled'][key]==expected_hash,'raw physical payload independently recomputes '+key)
source_json=parse['source_json_sha256']
check(source_json==admission['source_json_sha256'] and source_json['saves/autosave.json']==payload_sha and all(hexhash(v) for v in source_json.values()),'same valid retained source JSON manifests and actual Autosave bytes')
proof={'autosave_sha256':payload_sha,'snapshot':snapshot,'retained':counts,'days':result['days'],'fixture':'Seven synthetic line and seven synthetic manual checkpoint records per day; one real Slot 1 save and App loss per day. No authored dialogue playthrough.'}
check(sha(canonical(proof))==source_json['seven-day-history-proof.json'],'independent reconstruction of raw writer proof hash')
for variant in ('disabled','enabled'):
    v=parse[variant]
    check(v['day']==7 and v['retained_checkpoint_count']==66 and v['retained']==counts and v['autosave_sha256']==payload_sha and numeric(v['login_us']),variant+' exact day7 cold restore semantics')

invariants=['candidate_sha256','source_revision','source_files_sha256','output_files_sha256','prior_journal_sha256','journal_sha256','output_sha256','output_bytes','retained_checkpoint_count','parse_cache_before']
reference=manual['pairs'][0]['baseline']
pair_summaries={}
for family,comparison,metric,prefix in [('admission',admission,'login_us','SEVEN_DAY_HISTORY_READ_PASS: '),('prepare',manual,'prepare_us','MANUAL_SAVE_WRITE_PASS: ')]:
    check(len(comparison['pairs'])==8 and [p['pair'] for p in comparison['pairs']]==list(range(1,9)),family+' exact eight sequential pairs')
    for pair in comparison['pairs']:
        number=pair['pair']; check(pair['order']==(['baseline','candidate'] if number%2 else ['candidate','baseline']),family+f' pair{number} alternating order')
        for variant in ('baseline','candidate'):
            name=f'read-admission-pair-{number}-{variant}' if family=='admission' else f'prepare-pair-{number}-{variant}'
            observed=only_marker(probe_lines[name],prefix)
            check(observed==pair[variant],name+' raw terminal receipt equals pair')
            check(numeric(observed[metric]) and observed['parse_cache_enabled'] is True and observed['retained_checkpoint_count']==66 and observed['save_manager_sha256']==comparison['source_code_sha256'][variant],name+' timing cache retention and exact variant hash')
            profiles=[v for v in markers(probe_lines[name],'DWM_SAVE_LOAD_PROFILE ') if v['context']!='']
            if family=='admission':
                check(observed['day']==7 and observed['retained']==counts and observed['autosave_sha256']==payload_sha and all(observed[key]==value for key,value in restored_hashes.items()),name+' exact restored raw state hashes')
            else:
                profiles=[v for v in profiles if v['context']=='manual-write-prepare']
                check(observed['strict_validation_calls']==1 and observed['prepare_validation_calls']==0 and observed['write_variant']=='production' and observed['timing_mode']=='legacy-phase-context' and numeric(observed['commit_us']),name+' production preparation with one strict commit validation')
                check(all(observed[key]==reference[key] for key in invariants),name+' all ten preparation invariants equal across sixteen samples')
                check(all(observed[key+'_sha256']==comparison['source_code_sha256'][key] for key in ('storage','harness','witness_port')),name+' exact measured support source hashes')
                check(observed['source_files_sha256']['autosave.json']==payload_sha and observed['source_files_sha256']['slot_1.json']==source_json['saves/slot_1.json'] and observed['source_revision']==observed['source_files_sha256']['slot_1.json'] and observed['output_sha256']==observed['output_files_sha256']['slot_1.json'],name+' measured source and output physical file identity joins')
            check(profiles==pair['profiles'][variant] and bool(profiles),name+' complete raw profile binding')
        check(pair['candidate_minus_baseline_us']==pair['candidate'][metric]-pair['baseline'][metric],family+f' pair{number} recomputed paired difference')
    summary={'pair_count':8,'median_paired_candidate_minus_baseline_us':median(p['candidate_minus_baseline_us'] for p in comparison['pairs']),f'baseline_median_{metric}':median(p['baseline'][metric] for p in comparison['pairs']),f'candidate_median_{metric}':median(p['candidate'][metric] for p in comparison['pairs'])}
    check(summary==comparison['summary'],family+' recomputed all medians and pair count')
    pair_summaries[family]=summary

families={
 'checkpoint':('checkpoint_profiles',markers(write_lines,'DWM_CHECKPOINT_PROFILE ')),
 'consequence':('consequence_profiles',markers(write_lines,'DWM_CONSEQUENCE_PROFILE ')),
 'save_load_write':('save_load_write_profiles',[v for v in markers(write_lines,'DWM_SAVE_LOAD_PROFILE ') if v['context']!='']),
 'save_load_read':('save_load_read_profiles',[v for v in markers(probe_lines['read-cache-enabled'],'DWM_SAVE_LOAD_PROFILE ') if v['context']!='']),
 'save_load_read_cache_disabled':('save_load_read_control_profiles',[v for v in markers(probe_lines['read-cache-disabled'],'DWM_SAVE_LOAD_PROFILE ') if v['context']!=''])}
for family,(key,rows) in families.items():
    check(rows==result[key] and bool(rows),family+' all raw records equal structured report')
    check(all(numeric(value) for row in rows for key,value in row.items() if key.endswith('_us')),family+' all profile times nonnegative')
ps=(REPO/'tools/testing/Invoke-SevenDayHistoryPerformance.ps1').read_text()
diagnostic_fields={key:re.findall("'([^']+)'",re.search(r'\$'+key+r' = @\((.*?)\)',ps,re.S).group(1)) for key in ('prepareFields','commitFields')}
diag={'diagnostics_version':2,'prepare_records':0,'commit_records':0}
for row in result['checkpoint_profiles']:
    if row['scope'] not in ('save_checkpoint_prepare','save_checkpoint') or not row.get('ok') or not row.get('autosave'): continue
    check(row['diagnostics_version']==2,'checkpoint version2 diagnostic row')
    preparing=row['scope']=='save_checkpoint_prepare';diag['prepare_records' if preparing else 'commit_records']+=1
    required=diagnostic_fields['prepareFields' if preparing else 'commitFields'][:]
    bools=['document_schema_journal_proven'] if preparing else ['journal_current_proof_available','journal_current_proof_matches']
    if not preparing: required+=['outgoing_schema_compose_proven_journal_us' if row['journal_spliced'] else 'outgoing_schema_validate_journal_us']
    check(all(key in row and numeric(row[key]) for key in required),'all source-defined numeric checkpoint subdiagnostics')
    check(all(type(row[key]) is bool for key in bools),'all source-defined checkpoint proof outcomes boolean')
check(diag==result['checkpoint_diagnostics'] and diag['prepare_records']==diag['commit_records']==35,'35 matched successful autosave prepare commit version2 diagnostic rows')

ansi=re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
job_lines=[re.sub(r'^\d{4}-\d\d-\d\dT\S+\s','',ansi.sub('',line)) for line in JOBLOG.read_text().splitlines()]
check(any(line=='./tools/testing/Invoke-SevenDayHistoryPerformance.ps1 -ComparePreparation' for line in job_lines),'actual job invokes canonical ComparePreparation')
check(only_marker(job_lines,'CHECKPOINT_PHASE_DIAGNOSTICS_VERIFIED: ')==diag,'job diagnostic terminal receipt matches recomputed diagnostics')
for family,comparison,prefix in [('admission',admission,'SAVE_ADMISSION'),('prepare',manual,'MANUAL_SAVE_PREPARE')]:
    printed=markers(job_lines,prefix+'_PAIR: ')
    expected_printed=[{k:v for k,v in pair.items() if k!='profiles'} for pair in comparison['pairs']]
    check(printed==expected_printed,family+' all eight job pair receipts match raw probes')
    summary=only_marker(job_lines,prefix+'_COMPARISON: ')
    expected_summary={key:comparison[key] for key in (('control','sampling','source_code_sha256','source_json_sha256','summary') if family=='admission' else ('control','sampling','metric','source_code_sha256','summary'))}
    check(summary==expected_summary,family+' terminal comparison receipt matches complete source provenance and medians')
check(sum(line.startswith('SEVEN_DAY_HISTORY_PERFORMANCE_VERIFIED: ') for line in job_lines)==1,'exact producer final verification receipt')
job_proof=only_marker(job_lines,'SEVEN_DAY_HISTORY_PROOF: ')
check(job_proof=={**{key:result[key] for key in ('checkout_ref','payload_sha256','write','cold_read','fixture','timing_policy','timing_boundaries','parse_cache_comparison')},'payload_bytes':ident(DATA/'day7-autosave.json')['bytes']},'job compact proof exact result and physical payload identity')
measurements=markers(job_lines,'SEVEN_DAY_HISTORY_MEASUREMENT: ')
check(measurements==[{key:row[key] for key in ('day','retained','files','first_reveal_sync_us','terminal_reveal_sync_us','terminal_settlement_us','manual_slot_save_us','manual_slot_prepare_us','manual_slot_commit_us','autosave_sha256')} for row in result['days']],'all seven compact job measurements match raw day records')
expected_trace=[]
for number,line in enumerate(write_lines,1):
    for family,prefix in [('checkpoint','DWM_CHECKPOINT_PROFILE '),('consequence','DWM_CONSEQUENCE_PROFILE '),('day','SEVEN_DAY_HISTORY_DAY: ')]:
        if not line.startswith(prefix): continue
        value=strict(line[len(prefix):])
        if family=='consequence' and value['scope']!='first_reveal_durable': continue
        if family=='day': value={'day':value['day']}
        expected_trace.append({'log_line':number,'family':family,'value':value})
check(markers(job_lines,'SEVEN_DAY_HISTORY_TRACE: ')==expected_trace,'complete source-defined ordered checkpoint first-reveal and day job trace matches raw write log line numbers')

summary_rows=[]
for family,(_,rows) in families.items():
    groups=defaultdict(list)
    for row in rows:
        key='|'.join(str(row.get(k,'')) for k in (('context','scope','action','locator') if family.startswith('save_load') else ('scope','phase','checkpoint_kind')))
        groups[key].append(row)
    for key,items in sorted(groups.items()):
        summary={'family':family,'group':key,'count':len(items),'phases':{}}
        for metric in sorted({key for row in items for key in row if key.endswith('_us')}):
            values=[row[metric] for row in items if metric in row]
            summary['phases'][metric]={'sum':sum(values),'median':median(values),'max':max(values)}
        for field,yes,no in [('journal_spliced','spliced','full_document'),('cache_hit','cache_hits','parse_calls')]:
            measured=[row[field] for row in items if field in row]
            if measured: summary.update({yes:sum(bool(v) for v in measured),no:sum(not bool(v) for v in measured)})
        fields={key for row in items for key in row if re.fullmatch(r'(document_proof|journal_current|history_proof)_(entries|hits|misses|skipped|emit_failures|region_misses|learn_attempts|learn_successes)',key)}
        if fields: summary['proof_counts']={field:sum(row.get(field,0) for row in items) for field in sorted(fields)}
        summary_rows.append(summary)
check(markers(job_lines,'SEVEN_DAY_HISTORY_PROFILE_SUMMARY: ')==summary_rows,'every inclusive raw profile aggregate sum median max splice cache and proof-count summary recomputes exactly')

raw_after={str(p):ident(p) for root in (ARTIFACT,INPUTS) for p in sorted(root.rglob('*')) if p.is_file()}
check(raw_before==raw_after,'every original producer and transfer byte unchanged by offline audit')
report={
 'schema_version':1,'status':'pass_bounded_retained_history_producer_audit','run_id':37044894986,'run_attempt':1,
 'runtime_source':SOURCE,'checkout_sha':HEAD,'job_id':110965240070,
 'checks':checks,'check_count':len(checks),'source_identities':source_ids,'artifact_metadata':artifact_meta,
 'original_file_identities':raw_before,'job_log_identity':ident(JOBLOG),
 'payload':ident(DATA/'day7-autosave.json'),'retained':counts,'synthetic_checkpoints':98,'days':7,
 'isolated_probes':35,'checkpoint_diagnostics':diag,'profile_counts':{family:len(rows) for family,(_,rows) in families.items()},
 'recomputed_profile_summaries':summary_rows,'paired_summaries':pair_summaries,'restored_state_hashes':restored_hashes,
 'transfer_manifest':transfer,
 'limits':[
  'Only the Day7 producer and its exported inputs are accepted here; four comparison jobs and checkout-free aggregate are audited separately.',
  'Seven real gameplay days use 98 explicitly synthetic history checkpoints; this is not an authored-dialogue playthrough.',
  'One shared Windows runner, process-cold Login, unflushed OS caches, inclusive overlapping timers; no frame-time or speed threshold guarantee.',
  'Admission and preparation ablation source bytes are independently reproduced from current candidate source. Preparation uses fixed-clock capture fixture and actual storage; it excludes live UI/issuer-flush callbacks and rendering.',
  'The retained writer source root is not fully exported. Its eight JSON hashes and unchanged-after-each-probe assertions are source-bound cloud observations; Autosave and reconstructed writer-proof hashes are independently recomputed from retained evidence.',
  'Preparation output Slot bytes are not exported individually; all sixteen raw terminal receipts bind equal candidate/output/journal/source identities, while the exported Day7 payload supplies the independently retained input.',
  'No Godot or PowerShell process was run for this audit; only offline Python reads and SHA256/JSON/Git source checks.'
 ]}
OUT.mkdir(exist_ok=True)
(OUT/'retained-history-audit.json').write_text(json.dumps(report,indent=2)+'\n')
markdown=f'''# Day7 retained-history producer audit

**Pass for this bounded producer evidence review:** run `37044894986`, attempt 1, job `110965240070`, checkout `{HEAD}`, runtime source `{SOURCE}`. Four comparison consumers and the checkout-free aggregate remain outside this audit.

All **{len(checks)} checks** passed. Original ZIP digests/lengths/CRC and every extracted member were rechecked. Producer and transfer copies of `results.json`, `day7-autosave.json`, and the manifest are byte-identical.

- **35 isolated probes:** writer, disabled/enabled cold controls, 16 admission samples, and 16 manual-preparation samples. Unique contained roots, source arguments, execution order, bounded durations, zero exits, and clean import/engine/lifetime logs agree with their JSONL receipts.
- Days **1–7**, **98 synthetic checkpoint records**, and actual retained Autosave counts **32 line / 32 manual / 2 semantic**. Day7 is schema7 with 66 retained records. Its **1,910,538 bytes** hash to `{payload_sha}`.
- Raw saved-state reconstruction independently reproduces cold restored gameplay, board, and journal hashes. The enabled/disabled controls and all admission samples restore those exact values. Writer-proof bytes were reconstructed and their hash independently matched.
- Eight alternating admission pairs and eight alternating **prepare_us** pairs reproduce all raw receipts, exact source ablations, profiles, differences, and medians. Each of the 16 preparation samples retains exactly **one strict write validation**, production write variant, all ten invariant values, and identical source/output identity joins.
- All **190 checkpoint**, **349 consequence**, **40 writer save/load**, **35 enabled reader**, and **35 disabled reader** profile rows match raw logs. Version2 diagnostics contain **35 matched successful autosave prepare/commit records**, complete nonnegative source-defined fields, proof Booleans, and the required splice-dependent timing. Every emitted profile aggregate and source-defined trace row was recomputed.

| Observed metric | Baseline median µs | Candidate median µs | Median paired candidate − baseline µs |
|---|---:|---:|---:|
| Cold Login admission | 10,536,520 | 9,181,308.5 | −1,312,394 |
| Manual preparation | 2,218,017 | 2,203,457 | −15,292.5 |

These are shared-runner observations, not fixed speed or frame-time guarantees. Timers are inclusive and must not be added. The history fixture is explicitly synthetic; production gameplay, restore, and storage owners are exercised.

The complete writer source directory and every manual Slot output are not exported. Their unchanged/equal hashes are retained cloud observations backed by the inspected source checks; the exported Autosave, reconstructed writer proof, baseline source bytes, and consumer transfer bytes are independently recomputed. No Godot or PowerShell ran locally, and no original evidence changed.
'''
(OUT/'retained-history-audit.md').write_text(markdown)
print(json.dumps({'status':report['status'],'checks':len(checks),'profile_summaries':len(summary_rows),'trace_rows':len(expected_trace),'report':str(OUT/'retained-history-audit.json')}))

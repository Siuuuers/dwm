# Paired checkpoint performance audit

Bounded contract checks passed for run37044894986, checkout1bc4f6afd759e969f82b9c2134eb178479c19d13, source856520f09440d9b47cc272de3363009924ffedca. This is not full-gate acceptance.

- Original artifact11244755311: 159,366 bytes, SHA256 `b2834713fe6c6aa48b9202e5122a9233122b108a78d130ebcc092e46383f1f38`. CRC and every one of 22 extracted members verified.
- Exact current-source baseline ablation and both schema hashes verified. Four localized fresh journeys and four fixed-payload probes have eight unique isolated roots and exit0 receipts.
- Raw journey summaries/settlements/profiles match reports; all1,145 raw clicks independently reconstruct all46 summary groups and their source-defined upper-middle medians. CN exercises Dating win; HK exercises Dating loss; each journey exercises App win and loss.
- Both retained localized payloads match manifest and all fixed input/output hashes; schema7 and two journal bundles preserved. All100 timing samples and20 medians recomputed.
- All eight measured engine logs have zero script/error/Unicode/resource-lifetime matches.

**Retained diagnostic:** import.log line11 contains GUT optional version-query HTTP403 (GitHub API rate limit), with update_detector.gd:195 stack. The canonical import failure regex does not reject it. The complete artifact is therefore not error-free.

Final full-run capture still needs actual job checkout/status and CHECKPOINT_PERFORMANCE_VERIFIED receipt. Retained-history comparisons and all other gate components are outside this audit.

| Locale | Variant | Parse median μs | Schema median μs | Outgoing validation median μs |
|---|---|---:|---:|---:|
| zh-CN | baseline | 107095 | 22945 | 20041 |
| zh-HK | baseline | 74201 | 16420 | 13371 |
| zh-CN | candidate | 106326 | 22078 | 13607 |
| zh-HK | candidate | 74173 | 16508 | 10462 |

Timing observations have no fixed speed threshold; fresh journey boards can differ and profiling adds overhead.

#!/usr/bin/env python3
"""Read-only bounded audit of the captured paired checkpoint artifact."""
import hashlib
import json
from pathlib import Path, PureWindowsPath
import re
import statistics
import subprocess
import zipfile

ROOT = Path('/workspace/scratch/e58f796fe7a3')
REPO = ROOT / 'dwm'
SOURCE = '856520f09440d9b47cc272de3363009924ffedca'
HEAD = '1bc4f6afd759e969f82b9c2134eb178479c19d13'
RUN = 37044894986
NAME = f'checkpoint-performance-{RUN}-1'
CAPTURE = ROOT / 'hospital-broad1-early'
FOLDER = CAPTURE / 'artifacts' / NAME
DATA = FOLDER / 'ci/performance'
OUT = Path(__file__).resolve().parent


def check(condition, detail):
    if not condition:
        raise ValueError(detail)


def strict(text):
    def pairs(items):
        result = {}
        for key, value in items:
            check(key not in result, 'duplicate JSON key: ' + key)
            result[key] = value
        return result
    def invalid(value):
        raise ValueError('nonfinite JSON number: ' + value)
    return json.loads(text, object_pairs_hook=pairs, parse_constant=invalid)


def read(path):
    return strict(path.read_text(encoding='utf-8-sig'))


def identity(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def markers(text, prefix):
    return [strict(line[len(prefix):]) for line in text.splitlines() if line.startswith(prefix)]


source_paths = ('tools/testing/Invoke-CheckpointPerformance.ps1', 'tools/testing/Invoke-IsolatedGodot.ps1',
                'tests/manual/benchmark_checkpoint_json.gd', 'tests/manual/benchmark_minesweeper_click_latency.gd',
                'scripts/infrastructure/save/SaveDocumentSchema.gd')
source_identities = {}
for relative in source_paths:
    path = REPO / relative
    committed = subprocess.check_output(['git', '-C', str(REPO), 'show', SOURCE + ':' + relative])
    check(path.read_bytes() == committed, 'working source mismatch: ' + relative)
    check(subprocess.check_output(['git', '-C', str(REPO), 'diff', '--name-only', SOURCE, HEAD, '--', relative]) == b'',
          'workflow head changes audited source: ' + relative)
    source_identities[relative] = identity(path)

metadata = [item for item in read(CAPTURE / 'artifact-manifest.json') if item['name'] == NAME]
check(len(metadata) == 1, 'exactly one checkpoint artifact required')
metadata = metadata[0]
check(metadata['id'] == 11244755311 and metadata['workflow_run']['id'] == RUN
      and metadata['workflow_run']['head_sha'] == HEAD, 'artifact source binding')
archive = Path(metadata['local_zip'])
zip_identity = identity(archive)
check(zip_identity == {'bytes': metadata['size_in_bytes'], 'sha256': metadata['digest'].removeprefix('sha256:')},
      'original ZIP API identity mismatch')
files = {}
with zipfile.ZipFile(archive) as opened:
    check(opened.testzip() is None, 'original ZIP CRC failure')
    names = [info.filename for info in opened.infolist() if not info.is_dir()]
    check(len(names) == len(set(names)), 'duplicate ZIP member')
    check(set(names) == {path.relative_to(FOLDER).as_posix() for path in FOLDER.rglob('*') if path.is_file()},
          'ZIP/extraction member set mismatch')
    for name in names:
        path = FOLDER / name
        check(path.read_bytes() == opened.read(name), 'extracted bytes mismatch: ' + name)
        files[name] = identity(path)

report = read(DATA / 'results.json')
payload_manifest = read(DATA / 'payload-manifest.json')
check(report['checkout_ref'] == payload_manifest['checkout_ref'] == HEAD, 'report checkout mismatch')
check(payload_manifest['producer_run_id'] == str(RUN) and payload_manifest['producer_run_attempt'] == 1,
      'payload producer identity mismatch')
candidate = (REPO / 'scripts/infrastructure/save/SaveDocumentSchema.gd').read_bytes()
needle = b'if key == "current_snapshot" or (use_proven_journal and key == "recovery_journal"):'
check(candidate.count(needle) == 1, 'exact current normalization condition required')
baseline = candidate.replace(needle, b'if key == "current_snapshot":')
check((DATA / 'baseline-SaveDocumentSchema.gd').read_bytes() == baseline, 'single-condition ablation mismatch')
schema_hashes = {key: hashlib.sha256(value).hexdigest() for key, value in (('baseline', baseline), ('candidate', candidate))}
check(report['schema_sha256'] == schema_hashes, 'reported schema hashes mismatch')
expected_pairs = [(variant, locale) for variant in ('baseline', 'candidate') for locale in ('zh-CN', 'zh-HK')]
check([(item['variant'], item['locale']) for item in report['journeys']] == expected_pairs, 'journey membership/order')
check([(item['variant'], item['locale']) for item in report['fixed_payloads']] == expected_pairs, 'fixed membership/order')
check([item['locale'] for item in payload_manifest['payloads']] == ['zh-CN', 'zh-HK'], 'payload manifest membership/order')
payloads = {}
for item in payload_manifest['payloads']:
    locale = item['locale']
    expected_name = f'fixed-{locale}-autosave.json'
    check(item['file'] == expected_name, 'payload filename')
    path = DATA / expected_name
    document = read(path)
    ident = identity(path)
    check(item['sha256'] == ident['sha256'], 'payload hash')
    check(item['producer_variant'] == 'baseline' and item['producer_schema_sha256'] == schema_hashes['baseline'],
          'payload source variant')
    check(item['schema_version'] == document['schema_version'] == 7
          and item['snapshot_schema_version'] == document['current_snapshot']['snapshot']['schema_version'] == 7,
          'payload schema identity')
    check(item['journal_bundles'] == len(document['recovery_journal']) == 2, 'retained bundle count')
    check(item['dating_ending'] == ('win' if locale == 'zh-CN' else 'loss'), 'localized terminal outcome')
    payloads[locale] = ident

error_pattern = re.compile(r'SCRIPT ERROR:|(?:^|\s)ERROR:|Unicode parsing error|Unexpected NUL character|Parse Error:|Resource still in use:|Leaked instance:|Orphan StringName:|ObjectDB instances leaked', re.M)
receipt_rows = []
root_paths = set()
metric_rows = []
journey_rows = []
for variant, locale in expected_pairs:
    ending = 'win' if locale == 'zh-CN' else 'loss'
    for suffix in ('', '-fixed'):
        label = f'{variant}-{locale}{suffix}'
        receipt_path = DATA / f'{label}.jsonl'
        lines = receipt_path.read_text(encoding='utf-8-sig').splitlines()
        check(len(lines) == 1, 'one isolated process receipt: ' + label)
        receipt = strict(lines[0])
        check(receipt['suite_id'] == 'cloud-performance-' + label and receipt['exit_code'] == 0, 'process failed')
        check(PureWindowsPath(receipt['user_dir']).is_relative_to(PureWindowsPath(receipt['test_root']))
              and receipt['user_dir'] != receipt['test_root'], 'isolated containment')
        check(receipt['test_root'] not in root_paths, 'reused isolated root')
        root_paths.add(receipt['test_root'])
        log_name = 'cloud-performance-' + label + '.log'
        check(PureWindowsPath(receipt['log_path']).name == log_name, 'log receipt mismatch')
        log = (FOLDER / 'phase2r_logs' / log_name).read_text(encoding='utf-8-sig')
        check(error_pattern.search(log) is None, 'measured process diagnostic: ' + label)
        args = receipt['argv']
        check(args[args.index('-s') + 1] == ('res://tests/manual/benchmark_checkpoint_json.gd' if suffix else
                                          'res://tests/manual/benchmark_minesweeper_click_latency.gd'), 'probe script')
        if suffix:
            document_arg = [arg for arg in args if arg.startswith('--document=')]
            check(len(document_arg) == 1 and PureWindowsPath(document_arg[0].split('=', 1)[1]).name
                  == f'fixed-{locale}-autosave.json', 'fixed input argument')
            measurements = markers(log, 'CHECKPOINT_JSON_BENCHMARK: ')
            check(len(measurements) == 1, 'fixed benchmark marker')
            measurement = measurements[0]
            recorded = next(item['measurement'] for item in report['fixed_payloads']
                            if (item['variant'], item['locale']) == (variant, locale))
            check(measurement == recorded, 'fixed raw/report mismatch')
            check(measurement['input_sha256'] == measurement['output_sha256'] == payloads[locale]['sha256']
                  and measurement['bytes'] == payloads[locale]['bytes'], 'fixed byte/hash identity')
            check(measurement['journal_bundles'] == measurement['validated_journal_bundles'] == 2
                  and measurement['schema_version'] == measurement['snapshot_schema_version'] == 7, 'fixed schema/retention')
            phases = ('parse_us', 'schema_us', 'stringify_us', 'value_validation_us', 'outgoing_validation_us')
            check(set(measurement['samples']) == set(phases), 'fixed metric set')
            medians = {}
            for phase in phases:
                samples = measurement['samples'][phase]
                check(len(samples) == 5 and all(type(value) is int and value >= 0 for value in samples), 'fixed sample shape')
                median = statistics.median(samples)
                check(measurement[phase + '_median'] == median, 'fixed median mismatch')
                medians[phase] = median
            metric_rows.append({'variant': variant, 'locale': locale, 'medians_us': medians,
                                'sample_count_per_metric': 5, 'exact_payload': payloads[locale]})
        else:
            check('--phase2r-bootstrap-mode=final' in args and '--reply-locale=' + locale in args
                  and '--dating-ending=' + ending in args, 'journey arguments')
            check(sum(line.startswith('CLICK_LATENCY_PASS:') for line in log.splitlines()) == 1, 'journey PASS marker')
            reply = markers(log, 'CLICK_LATENCY_REPLY: ')
            mode = markers(log, 'CLICK_LATENCY_MODE: ')
            check(len(reply) == len(mode) == 1 and reply[0]['locale'] == locale
                  and reply[0]['contains_non_ascii'] is True and mode[0]['mode'] == 'fresh-account', 'localized/fresh control')
            row = next(item for item in report['journeys'] if (item['variant'], item['locale']) == (variant, locale))
            check(row['dating_ending'] == ending, 'journey ending')
            for key, prefix in (('summary', 'CLICK_LATENCY_SUMMARY: '), ('settlement', 'CLICK_LATENCY_SETTLED: '),
                                ('checkpoint_profiles', 'DWM_CHECKPOINT_PROFILE '), ('consequence_profiles', 'DWM_CONSEQUENCE_PROFILE ')):
                check(row[key] == markers(log, prefix) and row[key], 'journey raw/report mismatch: ' + key)
            clicks = markers(log, 'CLICK_LATENCY: ')
            grouped = {}
            for click in clicks:
                check(type(click['sync_us']) is int and type(click['two_frames_us']) is int
                      and 0 <= click['sync_us'] <= click['two_frames_us'], 'raw click timing')
                grouped.setdefault(click['surface'] + ':' + click['label'], []).append(click)
            reconstructed = []
            for key in sorted(grouped):
                group = grouped[key]
                sync = sorted(item['sync_us'] for item in group)
                frames = sorted(item['two_frames_us'] for item in group)
                reconstructed.append({'key': key, 'count': len(group), 'sync_min_us': sync[0],
                                      'sync_median_us': sync[len(sync) // 2], 'sync_max_us': sync[-1],
                                      'two_frames_median_us': frames[len(frames) // 2], 'two_frames_max_us': frames[-1]})
            check(reconstructed == row['summary'], 'raw click summary/upper-middle median mismatch')
            checkpoints = row['checkpoint_profiles']
            check(len(checkpoints) == 60 and all(item['ok'] is True and item['diagnostics_version'] == 2
                                                for item in checkpoints), 'checkpoint diagnostic contracts')
            check(sum(item['scope'] == 'save_checkpoint_prepare' for item in checkpoints) == 30
                  and sum(item['scope'] == 'save_checkpoint' for item in checkpoints) == 30, 'prepare/commit parity')
            check(len(row['consequence_profiles']) == 99
                  and all(item.get('ok', True) is True for item in row['consequence_profiles']), 'consequence profiles')
            for item in checkpoints + row['consequence_profiles']:
                check(all(type(value) in (int, float) and value >= 0 for name, value in item.items() if name.endswith('_us')),
                      'nonnegative profile timers')
            check([(item['surface'], item['ending']) for item in row['settlement']]
                  == [('app', 'win'), ('app', 'loss'), ('dating', ending)], 'terminal outcome controls')
            check(all(item.get('settled', True) is True and item['end_to_end_us'] >= 0 and item['settled_after_us'] >= 0
                      for item in row['settlement']), 'settlement measurements')
            journey_rows.append({'variant': variant, 'locale': locale, 'dating_ending': ending,
                                 'raw_click_count': len(clicks), 'all_summary_fields_independently_recomputed': True,
                                 'summary_count': len(row['summary']), 'settlement_count': len(row['settlement']),
                                 'checkpoint_profile_count': len(row['checkpoint_profiles']),
                                 'consequence_profile_count': len(row['consequence_profiles']),
                                 'localized_reply': reply[0], 'mode': mode[0]})
        receipt_rows.append(receipt)

check(len(list(DATA.glob('*.jsonl'))) == len(receipt_rows) == 8, 'unexpected probe evidence membership')
import_log = (FOLDER / 'ci/import.log').read_text(encoding='utf-8-sig')
import_errors = [{'line': index, 'text': line} for index, line in enumerate(import_log.splitlines(), 1)
                 if error_pattern.search(line)]
check(len(import_errors) == 1 and import_errors[0]['line'] == 11 and
      import_errors[0]['text'].startswith('ERROR: [GUT] Could not get version info, response code:  403 (API rate limit exceeded'),
      'unexpected import diagnostics')
check('res://addons/gut/update_detector.gd:195' in import_log, 'import diagnostic owner')
canonical_import = re.compile(r'SCRIPT ERROR:|ERROR: Failed to load|Unicode parsing error|Unexpected NUL character')
check(canonical_import.search(import_log) is None, 'canonical import error')

audit = {
    'schema_version': 1, 'scope': 'Paired checkpoint performance artifact only; retained-history/full-gate acceptance remains separate.',
    'bounded_contract_checks_passed': True, 'all_logs_error_free': False,
    'run_id': RUN, 'run_attempt': 1, 'source_commit': SOURCE, 'expected_and_reported_checkout': HEAD,
    'source_identities': source_identities, 'audit_helper': identity(Path(__file__)),
    'artifact': {'id': metadata['id'], 'name': NAME, 'zip': zip_identity, 'local_zip': str(archive),
                 'api_digest_size_match': True, 'crc_verified': True,
                 'all_extracted_members_byte_identical': True, 'member_count': len(files)},
    'source_ablation': {'only_change': 'Reverse the single outgoing proven-journal normalization shortcut.',
                       'exact_derived_baseline': True, 'schema_sha256': schema_hashes},
    'payload_manifest_verified': True, 'payloads': payloads,
    'journeys': journey_rows, 'fixed_measurements': metric_rows, 'isolated_processes': receipt_rows,
    'measured_process_count': 8, 'measured_log_error_or_lifetime_matches': 0,
    'fixed_metric_samples_verified': 100, 'fixed_medians_recomputed': 20,
    'raw_report_profile_equality_verified': True,
    'raw_click_records_verified': sum(row['raw_click_count'] for row in journey_rows),
    'raw_click_summary_groups_recomputed': sum(row['summary_count'] for row in journey_rows),
    'retained_diagnostics': [{'severity': 'ERROR emitted during editor import; outside canonical failure regex',
                             'owner': 'GUT optional version/update query', 'kind': 'GitHub API rate-limit HTTP403',
                             'observed': import_errors[0], 'source_stack': 'res://addons/gut/update_detector.gd:195',
                             'scope': 'Do not describe the full artifact/import log as error-free; no blanket HTTP403 exemption.'}],
    'artifact_file_identities': files,
    'limits': [
        'No engine, PowerShell or network execution occurred during this audit.',
        'API/job conclusion and actual checkout log verification belongs to final full-run capture; this audit binds saved artifact metadata and reported checkout.',
        'Terminal CHECKPOINT_PERFORMANCE_VERIFIED is emitted to the job log, which is not included in this artifact; require it from final job-log capture.',
        'Fresh baseline/candidate journeys can use different random boards; only fixed-payload probes share exact inputs.',
        'Measurements are from one Windows runner and retain profiling overhead; no speed threshold or native input-to-paint guarantee.',
        'This does not accept retained Day7/history comparisons, exported build, other rendered journeys, ordinary suites or the complete gate.',
    ],
}
(OUT / 'audit.json').write_text(json.dumps(audit, indent=2, ensure_ascii=False) + '\n')
lines = [
    '# Paired checkpoint performance audit', '',
    'Bounded contract checks passed for run37044894986, checkout1bc4f6afd759e969f82b9c2134eb178479c19d13, source856520f09440d9b47cc272de3363009924ffedca. This is not full-gate acceptance.', '',
    f'- Original artifact11244755311: {zip_identity["bytes"]:,} bytes, SHA256 `{zip_identity["sha256"]}`. CRC and every one of {len(files)} extracted members verified.',
    '- Exact current-source baseline ablation and both schema hashes verified. Four localized fresh journeys and four fixed-payload probes have eight unique isolated roots and exit0 receipts.',
    '- Raw journey summaries/settlements/profiles match reports; all1,145 raw clicks independently reconstruct all46 summary groups and their source-defined upper-middle medians. CN exercises Dating win; HK exercises Dating loss; each journey exercises App win and loss.',
    '- Both retained localized payloads match manifest and all fixed input/output hashes; schema7 and two journal bundles preserved. All100 timing samples and20 medians recomputed.',
    '- All eight measured engine logs have zero script/error/Unicode/resource-lifetime matches.', '',
    '**Retained diagnostic:** import.log line11 contains GUT optional version-query HTTP403 (GitHub API rate limit), with update_detector.gd:195 stack. The canonical import failure regex does not reject it. The complete artifact is therefore not error-free.', '',
    'Final full-run capture still needs actual job checkout/status and CHECKPOINT_PERFORMANCE_VERIFIED receipt. Retained-history comparisons and all other gate components are outside this audit.', '',
    '| Locale | Variant | Parse median μs | Schema median μs | Outgoing validation median μs |',
    '|---|---|---:|---:|---:|',
]
for row in metric_rows:
    values = row['medians_us']
    lines.append(f'| {row["locale"]} | {row["variant"]} | {values["parse_us"]} | {values["schema_us"]} | {values["outgoing_validation_us"]} |')
lines += ['', 'Timing observations have no fixed speed threshold; fresh journey boards can differ and profiling adds overhead.', '']
(OUT / 'audit.md').write_text('\n'.join(lines))
print(json.dumps({'audit_json': str(OUT / 'audit.json'), 'audit': identity(OUT / 'audit.json'),
                  'artifact_members': len(files), 'bounded_checks_passed': True,
                  'retained_import_diagnostics': len(import_errors), 'full_gate_accepted': False}))

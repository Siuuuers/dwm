#!/usr/bin/env python3
"""Read-only semantic replay of the broad-run authored Solo evidence."""
from pathlib import Path
from copy import deepcopy
import hashlib
import json
import re
import struct
import subprocess
import sys

BASE = Path('/workspace/scratch/e58f796fe7a3')
REPO = BASE / 'dwm'
ROOT = BASE / 'hospital-broad1-early/artifacts/solo-authored-selector-37044894986-1'
OUT = BASE / 'hospital-broad1-selector-audit'
SOURCE = '856520f09440d9b47cc272de3363009924ffedca'
HEAD = '1bc4f6afd759e969f82b9c2134eb178479c19d13'
sys.dont_write_bytecode = True
sys.path.insert(0, str(REPO / 'tools/testing'))
import run_solo_authored_selector_journey as owner
import run_cloud_journeys as cloud

checks = []
def check(ok, name):
    if not ok:
        raise AssertionError(name)
    checks.append(name)

def identity(path):
    raw = path.read_bytes()
    return {'bytes':len(raw), 'sha256':hashlib.sha256(raw).hexdigest()}

def read(path):
    return owner.strict_json(path.read_text(encoding='utf-8'))

raw_before = {str(p.relative_to(ROOT)):identity(p) for p in sorted(ROOT.rglob('*')) if p.is_file()}
folders = [p for p in ROOT.iterdir() if p.is_dir()]
check(len(folders) == 1, 'one artifact process evidence root')
folder = folders[0]
result = read(ROOT / 'result.json')
check((ROOT/'result.json').read_bytes() == (folder/'result.json').read_bytes(), 'top and nested result bytes agree')
check(result['ok'] is True and result['failures'] == [], 'runner success without failures')
check(result['checkout_sha'] == HEAD and result['workflow'] == {
    'GITHUB_RUN_ID':'37044894986','GITHUB_RUN_ATTEMPT':'1','GITHUB_JOB':'rendered-journeys','GITHUB_SHA':HEAD},
    'exact run attempt checkout and job binding')
source_files = [
    'tools/testing/run_solo_authored_selector_journey.py',
    'tools/testing/run_cloud_journeys.py',
    'tests/integration/verify_solo_authored_selector_journey.gd',
    'tests/integration/verify_playable_startup.gd',
    'tests/support/SoloAuthoredSelectorTimelineCatalog.gd',
    'tests/fixtures/dialogic/solo_authored_selector_catalogue.json',
    'tests/fixtures/dialogic/solo_authored_selector.dtl',
    'scripts/application/restore/NarrativeRestoreParticipant.gd',
    'scripts/narrative/SoloReadingSession.gd',
    'scripts/narrative/ReadingTraversalOperation.gd',
]
source_identities = {}
for name in source_files:
    path = REPO / name
    raw = path.read_bytes()
    for revision in (SOURCE, HEAD):
        expected = subprocess.check_output(['git','show',f'{revision}:{name}'], cwd=REPO)
        check(raw == expected, f'source bytes match {revision[:12]}: {name}')
    source_identities[name] = identity(path)

reports = {mode:read(folder/f'{mode}.json') for mode in owner.MODES}
check(result['reports'] == reports, 'embedded reports equal standalone report bytes')
check(len({r['process_id'] for r in reports.values()}) == 2 and all(type(r['process_id']) is int and r['process_id'] > 0 for r in reports.values()), 'distinct positive writer reader OS process IDs')
for mode,report in reports.items():
    check(report['mode'] == mode and report['schema_version'] == 1 and Path(report['user_dir']) == Path(result['user_dir']), f'{mode} schema and isolated user directory')
check(result['user_dir_strictly_contained'] is True and Path(result['user_dir']).is_relative_to(Path(result['isolated_environment']['XDG_DATA_HOME'])) and Path(result['user_dir']) != Path(result['isolated_environment']['XDG_DATA_HOME']), 'isolated user directory contained under data root')
check(set(result['processes']) == {'user-dir-proof','write','read'}, 'exact three process receipt set')
process_results = {}
for mode in ('user-dir-proof','write','read'):
    receipt = read(folder/f'{mode}.process.json')
    check(receipt == result['processes'][mode], f'{mode} embedded process receipt binding')
    local_receipt = deepcopy(receipt)
    for key in ('stdout','stderr'):
        local_receipt[key] = str(folder/Path(receipt[key]).name)
    failures = cloud.process_failures(local_receipt, folder/f'{mode}.log')
    check(not failures, f'{mode} strict process logs zero exit no timeout no lifetime diagnostics')
    stdout = cloud.read_log(folder/f'{mode}.stdout.txt')
    if mode != 'user-dir-proof':
        check(cloud.marker_count(stdout, f'SOLO_AUTHORED_SELECTOR_{mode.upper()}_PASS') == 1, f'{mode} exact success marker')
        argv = receipt['argv']
        check('--headless' not in argv and '--rendering-method' in argv and argv[argv.index('--rendering-method')+1] == 'gl_compatibility' and f'--solo-authored-selector-mode={mode}' in argv, f'{mode} real rendered process invocation')
    else:
        proof = re.findall(r'^PHASE2R_USER_DIR=(.+)$', stdout, re.MULTILINE)
        check(len(proof) == 1 and Path(proof[0].strip()) == Path(result['user_dir']), 'independent user directory proof matches report')
    process_results[mode] = {'exit_code':receipt['exit_code'],'timed_out':receipt['timed_out'],'elapsed_seconds':receipt['elapsed_seconds'],'strict_log_failures':failures}

# Reuse source validators as pure evidence readers; their archival copies go only
# to a new audit directory. Source and original evidence are never rewritten.
retained_folder = OUT/'validator-copies'
retained_folder.mkdir(exist_ok=True)
retained = owner.validate_saved_state(reports, REPO, folder, retained_folder)
checks.append('source saved-state validator: physical Quick Profile authority selection history witnesses and zero replay')
next_proof = owner.validate_next(reports['write'], folder, retained_folder)
checks.append('source Next validator: literal partial unseen source then exclusive source/destination durable endpoints')
owner.validate_forgery(reports['read'])
checks.append('source forgery validator: coherent alternate PRE refused by independent authorities and restore participant')
owner.validate_trace(reports, folder)
checks.append('source trace validator: exact 8 writer plus 4 reader ordered observations bound to reports')
check(result['retained_files'] == retained and result['next_proof'] == next_proof, 'recomputed retained identities and Next proof equal runner results')

# Independently derive frames from the physical saved Run, rather than trusting
# report-provided frames as the catalogue input.
quick = read(folder/'saved-quick.json')
snapshot = quick['current_snapshot']['snapshot']
route = snapshot['gameplay']['route_context']
raw_frames = route['dating_frozen_contexts_v1']['entries']
selected = owner.select_programmes(REPO, raw_frames)
check(selected == reports['write']['selected_programmes'] == reports['read']['selected_programmes'], 'independent physical saved Run frames select exact writer reader programmes')
physical = route['active_dating_challenge']
contexts = {}
for entry in (owner.PRE, owner.POST):
    phase = 'pre_challenge' if entry == owner.PRE else 'post_challenge'
    contexts[entry] = {'expected_stage':phase, 'playback_id':physical['physical_token']+':'+phase,
      'role':'dating_phase','transaction_id':physical['completion_transaction_id']+':'+phase,
      'presentation':raw_frames[entry]}
check(contexts == reports['read']['authoritative_entry_contexts'] == snapshot['narrative_checkpoint']['reading_session']['ledger']['entry_contexts'], 'independent physical token transaction phase and saved Run build exact authoritative entry contexts')
forged = reports['read']['forged_checkpoint']['forged_checkpoint']
forged_session = forged['reading_session']
forged_frames = {entry:forged_session['ledger']['entry_contexts'][entry]['presentation'] for entry in (owner.PRE,owner.POST)}
forged_programmes = owner.select_programmes(REPO, forged_frames)
check(raw_frames[owner.PRE]['fields']['tone'] == 'sweet' and forged_frames[owner.PRE]['fields']['tone'] == 'dark', 'coherent forgery changes earlier PRE tone sweet to dark')
expected_frames = deepcopy(raw_frames)
expected_frames[owner.PRE]['fields']['tone'] = 'dark'
check(forged_frames == expected_frames, 'forgery presentation frames alter only earlier PRE tone')
expected_beats = [beat for entry in (owner.PRE,owner.POST) for beat in forged_programmes[entry]['beats']]
check([r['beat'] for r in forged_session['ledger']['captions']] == expected_beats, 'forged ledger captions independently match alternate finite catalogue selection')
plan = forged_session['next_operation']['plan']
check(plan['source_ledger']['entry_contexts'] == forged_session['ledger']['entry_contexts'] and forged_session['ledger']['captions'] == plan['source_ledger']['captions']+[plan['destination']['caption']], 'forged regenerated destination is coherent with rewritten source ledger')
check(forged_session['next_operation']['operation_id'] == owner.canonical_sha256(plan), 'independently recomputed coherent forged Next operation hash')
check(contexts[owner.PRE] != forged_session['ledger']['entry_contexts'][owner.PRE] and contexts[owner.POST] == forged_session['ledger']['entry_contexts'][owner.POST], 'physical saved Run independently disagrees only with earlier PRE entry context')

seal = read(folder/'write-seal.json')
check(seal == result['write_seal'] and seal['sealed_after_mode'] == 'write' and seal['before_mode'] == 'read', 'writer seal metadata exact binding')
expected_seal = {'write.json',*owner.RETAINED_JSON,'transactions.jsonl',*owner.CAPTURES[:7]}
check(set(seal['files']) == expected_seal, 'exact 13 writer-sealed evidence files')
for name, expected in seal['files'].items():
    sealed = folder/'sealed-write'/name
    actual = folder/('captures' if name.endswith('.png') else '')/name
    check(identity(sealed) == expected, f'sealed original identity: {name}')
    check(actual.read_bytes().startswith(sealed.read_bytes()) if name == 'transactions.jsonl' else actual.read_bytes() == sealed.read_bytes(), f'writer evidence unchanged after reader: {name}')
sealed_rows = [readline for readline in (folder/'sealed-write/transactions.jsonl').read_text().splitlines()]
trace = [owner.strict_json(line) for line in (folder/'transactions.jsonl').read_text().splitlines()]
check(len(sealed_rows) == 8 and len(trace) == 12, 'eight sealed writer trace rows and twelve final rows')
for row in trace:
    if row['kind'] == 'history_inspected':
        count = 2 if row['value']['label'] == '04-pre-history' else 4
        check(row['value']['history']['captions'] == reports[row['mode']]['canonical_transcript'][:count], f'exact rendered History trace {row["value"]["label"]}')
    if row['kind'] == 'quick_committed':
        check(row['value']['sha256'] == retained['quick']['sha256'] and row['value']['profile_sha256'] == retained['profile']['sha256'], 'writer Quick trace physical identities')
    if row['kind'] == 'fresh_restore_prepared':
        check(row['value']['process_id'] == reports['read']['process_id'] and row['value']['quick_sha256'] == retained['quick']['sha256'], 'reader prepare trace physical identity and fresh PID')
    if row['kind'] == 'fresh_restore_verified':
        check(row['value']['speech_admissions'] == 0, 'reader final trace zero speech replay')

check(sorted(p.name for p in (folder/'captures').iterdir()) == sorted(owner.CAPTURES), 'exact nine original rendered captures')
capture_results = []
for receipt in result['captures']:
    name = Path(receipt['file']).name
    path = folder/'captures'/name
    raw = path.read_bytes()
    check(raw[:8] == b'\x89PNG\r\n\x1a\n', f'capture PNG signature {name}')
    dimensions = struct.unpack('>II', raw[16:24])
    check(dimensions == (receipt['width'],receipt['height']) == (1280,720), f'capture dimensions {name}')
    check(identity(path) == {k:receipt[k] for k in ('bytes','sha256')}, f'capture exact bytes {name}')
    capture_results.append({'name':name,'width':dimensions[0],'height':dimensions[1],**identity(path)})
check(len(capture_results) == 9 and len({r['name'] for r in capture_results}) == 9, 'nine unique capture receipts')
raw_after = {str(p.relative_to(ROOT)):identity(p) for p in sorted(ROOT.rglob('*')) if p.is_file()}
check(raw_before == raw_after, 'audit leaves every original artifact byte unchanged')

audit = {
 'schema_version':1, 'status':'pass_bounded_semantic_audit',
 'runtime_source':SOURCE,'checkout_sha':HEAD,'run_id':37044894986,'run_attempt':1,
 'artifact':'solo-authored-selector-37044894986-1','artifact_root':str(ROOT),
 'audit_scope':'Independent offline source-bound authored Solo selector evidence review; excludes whole broad-run acceptance and visual judgment.',
 'checks':checks,'check_count':len(checks),'source_identities':source_identities,
 'processes':process_results,'process_ids':{k:v['process_id'] for k,v in reports.items()},
 'speech_admissions':{k:v['speech_admissions'] for k,v in reports.items()},
 'history_observations':{k:v['history_observations'] for k,v in reports.items()},
 'retained_files':retained,'next_proof':next_proof,
 'programmes':{entry:{'label':v['label'],'selectors':v['selectors'],'line_ids':[line['line_id'] for line in v['lines']]} for entry,v in selected.items()},
 'forgery':{'changed_field':'PRE presentation.fields.tone','original':'sweet','forged':'dark',
     'internally_coherent':True,'writer_authority_refusal':'reading_context_invalid','route_authority_refusal':'reading_context_invalid',
     'restore_participant_refusal':{'code':'invalid_narrative_checkpoint','message':'reading_entry_context_mismatch'},
     'live_unchanged':True,'files_unchanged_scope':['Quick','Profile']},
 'trace_rows':{'write':8,'read':4,'total':12},'writer_sealed_files':len(expected_seal),'captures':capture_results,
 'artifact_file_identities':raw_before,
 'limitations':[
   'Root owns visual PNG inspection; dimensions and hashes do not prove visual quality.',
   'Noncanonical finite Priscilla Day 1 prose fixture; production gameplay/save/restore owners are exercised, not all authored days or production content.',
   'Next, History, and F5 use Godot InputEventKey press/release paths; pre-prose advancement uses actual native runtime reveal/advance methods. No hardware input or OS accessibility claim.',
   'Unchanged persisted files in this proof are Quick and Profile, not all primary/recovery files.',
   'Final post-B remains the saved frontier. Teardown completes only its reveal then aborts without fabricating a natural final scene completion receipt.',
   'Successful source validators were replayed without launching Godot/PowerShell; original engine execution occurred in GitHub Actions.',
   'This component passing does not establish whole broad-run, merge, release, or all-Beads acceptance.'
 ]
}
(OUT/'selector-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
markdown = f'''# Broad-run authored Solo selector audit

**Pass for this bounded semantic evidence review.** Run `37044894986`, attempt 1; checkout `{HEAD}`; runtime source `{SOURCE}`. This does not accept the full broad gate. Visual PNG review remains with the root agent.

- Replayed the source Python saved-state, Next, forgery, and trace validators offline, then separately reconstructed entry authority and programme selection from the retained physical Quick document. All **{len(checks)}** checks passed.
- Writer PID **5113** and reader PID **5186** are fresh processes in the same independently proven isolated profile. All three process receipts, stdout/stderr/engine logs, timeout state, exit codes, and lifetime diagnostics pass. Writer speech admissions are **4**; fresh restoration and History admit **0**.
- The physical Quick retains the four selected captions, exact post-B frontier, native text, terminal exploded board effect, and immutable PRE/POST authority frames. Profile contains exactly their four selected witnesses. Both before/after reader copies match exact Quick/Profile writer bytes.
- First Next finishes literal partial post-A (**27/167** characters) without advancing, replay, or checkpoint writes. Second Next commits ordered source/destination Autosaves, moves only to post-B, publishes it once, and retains the exact versioned operation identity. Both endpoints and their receipts were verified against physical Autosave bytes.
- An internally coherent earlier PRE forgery changes tone from `sweet` to `dark`, rewrites its selected beat, and regenerates the Next hash. The independent saved Run still requires `sweet`; writer and restored-route authority both return `reading_context_invalid`. The actual restore participant returns `invalid_narrative_checkpoint` / `reading_entry_context_mismatch`; source-backed observations show unchanged live state and Quick/Profile.
- All **13 writer-sealed files** remain exact; the final trace preserves the eight-row sealed prefix and adds precisely four reader rows. Nine original PNGs have verified bytes and 1280×720 dimensions. Every original artifact byte stayed unchanged during audit.

The fixture exercises real native runtime prose and Godot input paths for Next/History/F5. It uses noncanonical Priscilla Day 1 content; it is not proof of hardware input, native accessibility, all authored days, arbitrary cancellation, or final post-B natural completion. Teardown deliberately aborts at the saved frontier after finishing only its reveal. Quick/Profile immutability must not be broadened to other save/recovery files.

`selector-audit.json` binds each checked source file and original artifact member by SHA-256 and records all checks. `audit_selector.py` reproduces the audit without running Godot or PowerShell.
'''
(OUT/'selector-audit.md').write_text(markdown)
print(json.dumps({'status':audit['status'],'checks':len(checks),'report':str(OUT/'selector-audit.json'),'original_files':len(raw_before)}))

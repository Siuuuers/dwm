# Broad1 supplemental bounded reviews

These records supplement `hospital-broad1-diagnostic-evidence.tar.gz`. They do not change that archive's failed-run diagnostic status and do not establish whole-gate acceptance.

Included records cover the independent original-reading, Hospital semantic, selector, performance, rendered-frame, retained-history producer, negative-control/suite, and Windows-export audits; the source-bound review checklists; and the root visual review plus its input inventory. Each audit retains only its own stated scope and limitations.

The generic diagnostic package deliberately excludes the 98,898,813-byte nested Windows binary archive, 176 non-reading PNGs, two duplicate public inventories, and six large native-speech diagnostics while retaining their verified identities and explicit reasons in its manifest. Original GitHub artifact ZIPs are not duplicated here. Durable retention of those original archives is a separate publication decision.

The failed broad run had four failed jobs: the first Endings attempt failed during engine installation before Godot/game execution; two comparison jobs failed the stale whole-port baseline guard caused by the reviewed cold-lease method; and the checkout-free retained-history aggregate propagated those comparison failures.

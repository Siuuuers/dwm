# Broad1 original Windows export audit

Result: **PASS — bounded export component only**.

The exact original GitHub artifact `11244640103` from run `37044894986`, job `110965239936` (`Windows / exported release startup`), was reconstructed from the transport capture and statically audited. Its `98,850,774` bytes and SHA-256 `e2739823bc11ab4a336072c1a437af8711f54c3dee248a6e388b42c6947d8cc9` match the GitHub API record, and both the transport receipt and direct ZIP test report complete CRC verification.

The job checked out workflow head `1bc4f6afd759e969f82b9c2134eb178479c19d13`. The validation helper matches the source8 checklist identity (`a2bb7215…`), and the derived workflow's jobs block is byte-identical to the canonical workflow according to the retained derivation manifest.

## Validated facts

- `validation.json`: `ok=true`, expected commit, Godot `4.6.3.stable`, `x86_64`, unsigned.
- Pinned templates SHA-256: `3fbe2c0e2dec9d537ab9ec97bcf8da91dcf23357fc51f67092dd068d839290a8`; the exact source helper requires `version.txt` to equal `4.6.3.stable`.
- Headless smoke: `ok=true`, `240` iterations, isolated Profile created.
- Pack audit: `ok=true`, `111` runtime-data files, with `WINDOWS_PACK_DATA_VERIFIED count=111` in both retained console and engine logs.
- The job log contains the source-bound `WINDOWS_EXPORT_RECEIPT` and `WINDOWS_EXPORT_VALIDATED` markers and finished successfully.
- Nested `DWM-windows-x86_64-validation.zip`: `98,898,813` bytes, SHA-256 `a272f0da2b0421581b0c21d3310a6cbf16566c35d85c2dee66dbf5b926bcd5a4`, full CRC pass, 18 members.
- All 17 payload members listed by validation match their exact sizes and SHA-256 values, including `DWM.exe` and `DWM.pck`; `SHA256SUMS.txt` matches the actual nested archive.
- Export, smoke, pack-audit, version, and import logs were inspected. No actual forbidden script-load, resource-load, Unicode-parse, or NUL diagnostic was present. Controller-mapping, system-certificate, and Node action deprecation warnings are retained as nonfatal observations.

The validation JSON inside the nested archive has SHA-256 `f9678729…`; the outer copy is `cc922302…`. Their only semantic/byte difference is expected: after constructing the archive, the helper adds the archive filename, byte count, and SHA-256 to the outer copy. This is not a mismatch in the packaged payload claims.

## Boundary

This audit only accepts evidence for an unsigned Windows export, packaged data verification, and isolated headless startup. It did not execute `DWM.exe` or Godot locally. It does not establish graphical Windows behavior, UI Automation, screen-reader behavior, signing, release readiness, whole-reading-rail acceptance, or whole-gate acceptance.

The canonical broad run's later stale warm-baseline comparison failure remains separate and unresolved. This successful export component must not be used to convert the failed broad run into an accepted whole gate.

Machine-readable findings and exact identities are in `windows-export-audit.json`.

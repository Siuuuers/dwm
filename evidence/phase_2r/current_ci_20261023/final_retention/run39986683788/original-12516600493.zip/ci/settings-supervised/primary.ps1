$ErrorActionPreference = 'Stop'
$folder = Join-Path $env:GITHUB_WORKSPACE '.godot/ci/settings-supervised'
[IO.File]::WriteAllText((Join-Path $folder 'wrapper-entered.txt'), [DateTime]::UtcNow.ToString('o'))
$code = 1
try {
    & (Join-Path $env:GITHUB_WORKSPACE 'tools/testing/Invoke-CloudTests.ps1') -Suite settings
    $code = $LASTEXITCODE
} catch {
    $_ | Out-String | Write-Output
} finally {
    @{ exit_code = $code; completed_utc = [DateTime]::UtcNow.ToString('o') } |
        ConvertTo-Json | Set-Content (Join-Path $folder 'exit-status.tmp') -Encoding utf8
    Move-Item (Join-Path $folder 'exit-status.tmp') (Join-Path $folder 'exit-status.json')
}
exit $code

import datetime,hashlib,json,os,pathlib,subprocess,sys,time,xml.etree.ElementTree as ET
sys.stdout.reconfigure(encoding='utf-8',errors='backslashreplace')
sys.stderr.reconfigure(encoding='utf-8',errors='backslashreplace')
root=pathlib.Path(os.environ['GITHUB_WORKSPACE']);folder=root/'.godot/ci/settings-supervised'
started=time.monotonic();deadline=started+600
pwsh=os.environ['SETTINGS_PWSH_PATH']
report={'source_sha':os.environ['SETTINGS_SOURCE_SHA'],'pwsh':pwsh,'outer_seconds':600,'inner_godot_seconds':480,
 'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'wrapper_sha256':hashlib.sha256((folder/'primary.ps1').read_bytes()).hexdigest()}
process=None;timed_out=False
logs=[folder/'primary.stdout.log',folder/'primary.stderr.log',root/'.godot/phase2r_logs/cloud-settings.log']
def heartbeat():
 print('SETTINGS_SUPERVISOR_HEARTBEAT '+json.dumps({'elapsed_seconds':round(time.monotonic()-started,3),
  'pid':process.pid if process else None,'returncode':process.poll() if process else None,
  'wrapper_entered':(folder/'wrapper-entered.txt').exists()}),flush=True)
 for path in logs:
  if path.exists():
   # Read only a bounded trailing window, retaining the complete on-disk logs.
   with path.open('rb') as stream:
    stream.seek(max(0,path.stat().st_size-65536));tail=stream.read().decode('utf-8',errors='replace').splitlines()[-20:]
   print('SETTINGS_LOG_TAIL '+str(path)+'\n'+'\n'.join(line[-2000:] for line in tail),flush=True)
try:
 # Capture executable startup evidence before running any product tests.
 probe=subprocess.run([pwsh,'-NoLogo','-NoProfile','-NonInteractive','-Command',"Write-Output 'SETTINGS_PWSH_READY'"],
  stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20,creationflags=subprocess.CREATE_NO_WINDOW)
 report['pwsh_probe']={'returncode':probe.returncode,'stdout':probe.stdout.decode(errors='replace'),'stderr':probe.stderr.decode(errors='replace')}
 (folder/'pwsh-probe.json').write_text(json.dumps(report['pwsh_probe'],indent=2))
 assert probe.returncode==0 and probe.stdout.decode().strip()=='SETTINGS_PWSH_READY','pwsh startup proof failed'
 with logs[0].open('wb') as out,logs[1].open('wb') as err:
  process=subprocess.Popen([pwsh,'-NoLogo','-NoProfile','-NonInteractive','-File',str(folder/'primary.ps1')],
   cwd=root,stdin=subprocess.DEVNULL,stdout=out,stderr=err,close_fds=True,creationflags=subprocess.CREATE_NO_WINDOW)
  report['pid']=process.pid
  print('SETTINGS_SUPERVISOR_STARTED '+json.dumps(report),flush=True)
  next_heartbeat=time.monotonic()
  while process.poll() is None:
   now=time.monotonic()
   # Reserve the final15seconds inside the600second absolute cap for tree cleanup.
   if now>=deadline-15:
    timed_out=True
    killed=subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True,timeout=10)
    report['tree_cleanup']={'returncode':killed.returncode,'stdout':killed.stdout.decode(errors='replace'),'stderr':killed.stderr.decode(errors='replace')}
    process.wait(timeout=max(0.1,deadline-time.monotonic()))
    break
   if now>=next_heartbeat:
    heartbeat();next_heartbeat=now+30
   time.sleep(min(1,max(0.01,deadline-15-now)))
  report['returncode']=process.poll();report['timed_out']=timed_out
 heartbeat()
 assert not timed_out,'primary exceeded bounded diagnostic operation window'
 assert process.returncode==0,'primary pwsh exited unsuccessfully'
 status_path=folder/'exit-status.json';assert status_path.exists(),'primary never published its finally status'
 status=json.loads(status_path.read_text(encoding='utf-8-sig'));report['wrapper_status']=status
 assert status['exit_code']==0,'primary suite failed'
 xml=ET.parse(root/'.godot/ci/settings.xml');cases=xml.findall('.//testcase')
 assert cases and not any(xml.findall('.//'+tag) for tag in ['failure','error','skipped']),'missing/failed/skipped primary JUnit'
 report['cases']=len(cases);report['ok']=True
 print('SETTINGS_SUPERVISED_PRIMARY_PASS cases='+str(len(cases)),flush=True)
except BaseException as error:
 report['ok']=False;report['error']=repr(error)
 if process is not None and process.poll() is None:
  # The retained process handle prevents PID reuse while tree cleanup is requested.
  try:
   cleanup=subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True,timeout=max(0.1,min(5,deadline-time.monotonic())))
   report['fallback_tree_cleanup_returncode']=cleanup.returncode
  except BaseException as cleanup_error:report['cleanup_error']=repr(cleanup_error)
 heartbeat()
 raise
finally:
 report['elapsed_seconds']=time.monotonic()-started
 report['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 if process is not None:report['returncode']=process.poll()
 (folder/'supervisor-result.json').write_text(json.dumps(report,indent=2)+'\n')
 print('SETTINGS_SUPERVISOR_RESULT '+json.dumps(report),flush=True)

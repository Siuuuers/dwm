extends SceneTree

func _initialize() -> void:
    var cache := ConfigFile.new()
    if cache.load("res://.godot/global_script_class_cache.cfg") != OK:
        fail("Cannot read generated class map")
        return
    var entries: Variant = cache.get_value("", "list", null)
    if not entries is Array:
        fail("Invalid generated class map")
        return
    var wanted := {
        "EndingScene": "res://scripts/ui/EndingScene.gd",
        "SaveManagerCheckpointPort": "res://scripts/application/run/SaveManagerCheckpointPort.gd"
    }
    var seen := {}
    for entry: Variant in entries:
        if not entry is Dictionary:
            fail("Malformed class entry")
            return
        var path := str(entry.get("path", ""))
        var name := str(entry.get("class", ""))
        if path.begins_with("res://evidence/phase_2r/title_timing_20261019/source/"):
            fail("Retained source registered: " + path)
            return
        if wanted.has(name):
            if seen.has(name) or path != wanted[name]:
                fail("Duplicate or noncanonical class: " + name)
                return
            seen[name] = path
    if seen.size() != wanted.size():
        fail("Missing canonical classes")
        return
    var root := "res://evidence/phase_2r/title_timing_20261019/"
    var manifest: Variant = JSON.parse_string(FileAccess.get_file_as_string(root + "source-manifest.json"))
    if not manifest is Dictionary or not manifest.get("files") is Array:
        fail("Invalid retained manifest")
        return
    var count := 0
    for row: Variant in manifest["files"]:
        var path: String = root + str(row["path"])
        var file := FileAccess.open(path, FileAccess.READ)
        if file == null or file.get_length() != int(row["bytes"]) or FileAccess.get_sha256(path) != str(row["sha256"]):
            fail("Retained evidence missing or changed: " + path)
            return
        file.close()
        count += 1
    if count != 20:
        fail("Unexpected retained manifest census")
        return
    print("DISCOVERY_AND_RAW_EVIDENCE_VERIFIED count=20")
    quit(0)

func fail(message: String) -> void:
    push_error(message)
    quit(1)


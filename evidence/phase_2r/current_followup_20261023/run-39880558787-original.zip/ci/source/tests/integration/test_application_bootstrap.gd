extends "res://addons/gut/test.gd"

var _scene_validation_scope := preload("res://tests/support/SceneValidationScope.gd").new()

const TEMPORARY_STORAGE := preload("res://tests/support/TemporaryStorage.gd")

# Task 2 (dwm-p2r.9 Plan 06) freezes the FINAL production bootstrap graph.
#
# WHY THIS FILE EXISTS. Task 3 hashes these exact Bootstrap/project bytes into both Phase-3
# handoff artifacts, and Task 4 then treats them as immutable bindings. Every identity claim the
# artifact makes has to be asserted here first, or the artifact would be recording a wiring that
# nothing actually checks.
#
# WHAT A SECOND INSTANCE WOULD COST:
#   * A second MUTATION GATE: the fatal fence would stop being process-wide -- one subsystem could
#     keep mutating after another had latched.
#   * A second DESKTOP HOST: the persisted active_app_id and the evicted app list would disagree,
#     so a restored save could name an app the host never had open.
#   * A second CHECKPOINT PORT: two journals/sequences, so a restart could resume a checkpoint id
#     the other port never issued.
#
# HOW IT DRIVES BOOTSTRAP. Stages are invoked directly with injected targets rather than through a
# full start(): this suite is about object identity and dispatch counts, and dragging in root
# selection and profile IO would not sharpen a single claim. Bootstrap is built with .new() and
# never added to the tree, so _ready() -- which defers into start() -- never fires.
#
# PARSE HAZARD: GUT treats an inferred-Variant `:=` as a parse error, so locals are annotated.

const BOOTSTRAP := preload("res://autoload/ApplicationBootstrap.gd")
const GAME_STATE := preload("res://autoload/GameState.gd")
const SAVE_MANAGER := preload("res://autoload/SaveManager.gd")
const PROFILE_MANAGER := preload("res://autoload/ProfileManager.gd")
const LOCALIZATION_MANAGER := preload("res://autoload/LocalizationManager.gd")
const AUDIO_MANAGER := preload("res://autoload/AudioManager.gd")
const WINDOW_MODE_MANAGER := preload("res://autoload/WindowModeManager.gd")
const SCENE_ROUTER := preload("res://autoload/SceneRouter.gd")
const INPUT_MANAGER := preload("res://autoload/InputManager.gd")
const ACCESSIBILITY_MANAGER := preload("res://autoload/AccessibilityManager.gd")
const DIALOGIC_BRIDGE := preload("res://autoload/DialogicBridge.gd")
const JSON_STORAGE := preload("res://scripts/infrastructure/storage/JsonFileStorage.gd")
const FAKE_AUDIO_PORT := preload("res://tests/support/FakeAudioPlaybackPort.gd")
const SAVE_CHECKPOINT_PORT := preload("res://scripts/application/run/SaveManagerCheckpointPort.gd")
const DAY_RESOLUTION_STATE_PORT := preload("res://scripts/application/run/GameStateDayResolutionPort.gd")
const MINESWEEPER_COORDINATOR := preload("res://scripts/domain/minesweeper/MinesweeperRoundCoordinator.gd")
const FAKE_GATE := preload("res://tests/support/FakeApplicationMutationGate.gd")
const FAKE_EVICTION := preload("res://tests/support/FakeDesktopEvictionPort.gd")
const DAY_IDENTITY_PORT := preload("res://scripts/application/run/CausalDayAdvanceIdentityPort.gd")

## The exact literal autoload order project.godot must reach in this task.
const EXPECTED_AUTOLOAD_ORDER: Array[String] = [
	"ProfileManager", "GameState", "SaveManager", "LocalizationManager", "AudioManager",
	"SystemTtsCoordinator", "WindowModeManager", "EffectResolver", "SceneRouter", "InputManager", "AccessibilityManager", "Dialogic",
	"DialogicBridge", "ApplicationBootstrap",
]

const EXPECTED_STAGE_ORDER: Array[StringName] = [
	&"select_and_prove_roots",
	&"construct_and_inject_mutation_gate",
	&"construct_identity_issuer_and_contact_commands",
	&"initialize_saves",
	&"initialize_profile",
	&"initialize_localization",
	&"initialize_input",
	&"initialize_accessibility",
	&"initialize_audio",
	&"initialize_window_mode",
	&"initialize_dialogic_bridge",
	&"configure_restore_participants",
	&"configure_day_resolution",
	&"configure_minesweeper_rounds",
	&"publish_application_ready",
]

var _root_counter := 0


class InjectableBootstrap:
	extends "res://autoload/ApplicationBootstrap.gd"
	var injected_targets: Dictionary = {}

	func _target(target_name: StringName) -> Node:
		return injected_targets.get(target_name)


class UnavailableWindowOutput:
	extends RefCounted

	func capture_output() -> Dictionary:
		return {"ok": false, "code": &"window_output_unavailable", "details": {}, "receipt": {}}

	func apply_mode(_mode: String) -> Dictionary:
		return {"ok": false, "code": &"window_output_unavailable", "details": {}, "receipt": {}}

	func output_matches(_mode: String) -> bool:
		return false

	func restore_output(_snapshot: Dictionary) -> Dictionary:
		return {"ok": false, "code": &"window_output_unavailable", "details": {}, "receipt": {}}


class FakeContactsDesktop:
	extends Node
	var configured := false
	var configured_day := 0
	var evictions: Array[Dictionary] = []

	func configure_contacts(_presentation: RefCounted, _localization: Object, _profile: Object,
			_desktop_host: RefCounted, day: int) -> Dictionary:
		configured = true
		configured_day = day
		return {"ok": true, "code": &"ok", "value": {}, "receipt": {}}

	func dispatch_desktop_eviction(command: Dictionary) -> Dictionary:
		evictions.append(command.duplicate(true))
		return {"ok": true, "code": &"ok", "value": {}, "receipt": {}}


func _isolated_root(label: String) -> String:
	_root_counter += 1
	var result: Dictionary = TEMPORARY_STORAGE.create("%s-%d" % [label, _root_counter])
	assert_true(result.get("ok", false), result.get("message", ""))
	return str(result.get("value", "")) if result.get("ok", false) else ""


## Builds the nine gate targets plus the bootstrap, with the gate and retained identity issuer
## injected exactly as the production stages do. Profile, Audio, and WindowMode then run in their
## production order so WindowMode retains Audio's exact shared Settings transaction owner.
func _make_graph(label: String) -> Dictionary:
	_scene_validation_scope.clear_validation_bindings()
	var root: String = _isolated_root(label)
	if root.is_empty():
		return {}
	var targets := {
		&"ProfileManager": autofree(PROFILE_MANAGER.new()),
		&"GameState": autofree(GAME_STATE.new()),
		&"SaveManager": autofree(SAVE_MANAGER.new()),
		&"LocalizationManager": autofree(LOCALIZATION_MANAGER.new()),
		&"AudioManager": autofree(AUDIO_MANAGER.new(FAKE_AUDIO_PORT.new())),
		&"WindowModeManager": autofree(WINDOW_MODE_MANAGER.new(UnavailableWindowOutput.new())),
		&"SceneRouter": autofree(SCENE_ROUTER.new()),
		&"InputManager": autofree(INPUT_MANAGER.new()),
		&"AccessibilityManager": autofree(ACCESSIBILITY_MANAGER.new()),
		&"DialogicBridge": autofree(DIALOGIC_BRIDGE.new()),
	}
	add_child(targets[&"GameState"])
	targets[&"GameState"].call(&"reset_game")
	var bootstrap: Node = autofree(InjectableBootstrap.new())
	bootstrap.injected_targets = targets
	bootstrap.set("_selected_root", root)
	bootstrap.set("_profile_storage", JSON_STORAGE.new(root))
	var injected: Dictionary = bootstrap.call(&"_construct_and_inject_mutation_gate", &"final")
	assert_true(injected.get("ok", false), str(injected))
	var identity_constructed: Dictionary = bootstrap.call(
		&"_construct_identity_issuer_and_contact_commands")
	assert_true(identity_constructed.get("ok", false), str(identity_constructed))
	var profile_initialized: Dictionary = bootstrap.call(&"_run_stage", &"initialize_profile", &"final")
	assert_true(profile_initialized.get("ok", false), str(profile_initialized))
	var audio_initialized: Dictionary = bootstrap.call(&"_run_stage", &"initialize_audio", &"final")
	assert_true(audio_initialized.get("ok", false), str(audio_initialized))
	var window_initialized: Dictionary = bootstrap.call(&"_run_stage", &"initialize_window_mode", &"final")
	assert_true(window_initialized.get("ok", false), str(window_initialized))
	assert_same(targets[&"WindowModeManager"].call(&"get_settings_output_transactions"),
		targets[&"AudioManager"].call(&"get_settings_output_transactions"))
	assert_true(targets[&"SaveManager"].call(&"initialize",
		JSON_STORAGE.new(root.path_join("saves"))).get("ok", false))
	var checkpoint_port: RefCounted = SAVE_CHECKPOINT_PORT.new(targets[&"SaveManager"])
	assert_true(checkpoint_port.configure_fatal_latch(bootstrap.get("_application_gate")).get("ok", false))
	bootstrap.set("_retained_checkpoint_port", checkpoint_port)
	return {"bootstrap": bootstrap, "targets": targets, "checkpoint_port": checkpoint_port, "root": root}


func test_project_autoload_order_is_the_exact_final_literal_sequence() -> void:
	# project.godot reaches its final literal order in THIS task; Task 3 hashes these bytes.
	var text := FileAccess.get_file_as_string("res://project.godot")
	var section := text.get_slice("[autoload]", 1).get_slice("[", 0)
	var found: Array[String] = []
	for line: String in section.split("\n"):
		var trimmed := line.strip_edges()
		if trimmed.is_empty() or not trimmed.contains("="):
			continue
		found.append(trimmed.get_slice("=", 0).strip_edges())
	assert_eq(found, EXPECTED_AUTOLOAD_ORDER,
		"the production autoload order is frozen for the Phase 3 handoff")


func test_master_stage_order_is_frozen() -> void:
	var bootstrap: Node = autofree(BOOTSTRAP.new())
	assert_eq(bootstrap.get("STAGE_ORDER"), EXPECTED_STAGE_ORDER)
	assert_eq(bootstrap.get("FINAL_GATE_TARGETS").size(), 9, "exactly nine gate targets")


func test_exactly_nine_targets_retain_one_shared_gate_identity() -> void:
	var made := _make_graph("gate-identity")
	if made.is_empty():
		return
	var bootstrap: Node = made["bootstrap"]
	var gate: Object = bootstrap.get("_application_gate")
	assert_not_null(gate)
	var state: Dictionary = bootstrap.call(&"get_startup_state")
	var injection: Dictionary = state["gate_injection"]
	assert_eq(int(injection["factory_invocation_count"]), 1, "the gate is constructed exactly once")
	assert_eq((injection["targets"] as Array).size(), 9)
	assert_eq((injection["target_instance_ids"] as Array).size(), 9)
	for retained_id: Variant in injection["target_instance_ids"]:
		assert_eq(int(retained_id), gate.get_instance_id(), "every target retained the ONE gate")
	assert_eq(injection["targets"], Array(bootstrap.get("FINAL_GATE_TARGETS")),
		"the nine targets are injected in the frozen order")
	# GameState reports that same identity to its adapters, without exposing the fence.
	assert_eq(int(made["targets"][&"GameState"].call(&"get_mutation_gate_instance_id")),
		gate.get_instance_id())


func test_one_desktop_host_is_shared_by_route_restore_and_the_direct_checkpoint_provider() -> void:
	var made := _make_graph("desktop-host")
	if made.is_empty():
		return
	var bootstrap: Node = made["bootstrap"]
	var participants: Dictionary = bootstrap.call(&"_configure_restore_participants")
	assert_true(participants.get("ok", false), str(participants))
	var host: Object = bootstrap.get("_desktop_host_state")
	assert_not_null(host, "the restore stage constructs the ONE process-lifetime host")
	# The direct checkpoint provider reads that SAME host.
	assert_true(made["checkpoint_port"].configure_desktop_context_provider(host).get("ok", false))
	assert_same(made["checkpoint_port"].get("_desktop_context_provider"), host)
	# Replay never builds a second host.
	assert_true(bootstrap.call(&"_configure_restore_participants").get("ok", false))
	assert_same(bootstrap.get("_desktop_host_state"), host)


func test_the_stable_active_app_callable_keeps_its_identity_and_returns_raw_json_values() -> void:
	var made := _make_graph("active-app-callable")
	if made.is_empty():
		return
	var bootstrap: Node = made["bootstrap"]
	# BEFORE host injection the stable Callable returns raw JSON null -- never a wrapper.
	var before: Variant = bootstrap.call(&"_active_app_id_context")
	assert_null(before, "an uninjected host reports raw JSON null")
	var day_port: RefCounted = DAY_RESOLUTION_STATE_PORT.new(made["targets"][&"GameState"])
	assert_true(bootstrap.call(&"_configure_day_resolution_providers", day_port).get("ok", false))
	var first_bundle: Dictionary = bootstrap.get("_checkpoint_provider_bundle")
	var first_callable: Callable = first_bundle["active_app_id"]
	assert_true(bootstrap.call(&"_configure_restore_participants").get("ok", false))
	# AFTER host injection the SAME Callable object answers; nothing was replaced.
	var second_bundle: Dictionary = bootstrap.get("_checkpoint_provider_bundle")
	var second_callable: Callable = second_bundle["active_app_id"]
	assert_eq(second_callable.get_object_id(), first_callable.get_object_id(),
		"the stable Callable identity is never replaced by host injection")
	assert_eq(String(second_callable.get_method()), String(first_callable.get_method()))
	var after: Variant = bootstrap.call(&"_active_app_id_context")
	assert_true(after == null or typeof(after) == TYPE_STRING,
		"the provider returns a raw registered app-ID String or JSON null, never a CommandResult")
	assert_false(typeof(after) == TYPE_DICTIONARY, "never a CommandResult wrapper")


func test_the_retained_checkpoint_port_and_gate_are_shared_by_both_coordinators() -> void:
	var made := _make_graph("shared-coordinators")
	if made.is_empty():
		return
	var bootstrap: Node = made["bootstrap"]
	var game_state: Node = made["targets"][&"GameState"]
	# The Schedule foundation inside day resolution reuses the retained issuer, so that stage
	# has to have run first -- exactly as it does in the production stage order.
	assert_true(bootstrap.call(&"_construct_identity_issuer_and_contact_commands").get("ok", false))
	assert_true(bootstrap.call(&"_configure_restore_participants").get("ok", false))
	var resolved: Dictionary = bootstrap.call(&"configure_day_resolution", game_state,
		made["targets"][&"SaveManager"])
	assert_true(resolved.get("ok", false), str(resolved))
	# Day resolution reused the ONE retained checkpoint port rather than building a second.
	assert_same(bootstrap.get("_retained_checkpoint_port"), made["checkpoint_port"])
	var day_coordinator: Object = bootstrap.get("_retained_day_resolution_coordinator")
	assert_not_null(day_coordinator)
	var minesweeper: Dictionary = bootstrap.call(&"_configure_minesweeper_rounds", game_state,
		made["targets"][&"SaveManager"])
	assert_true(minesweeper.get("ok", false), str(minesweeper))
	var round_coordinator: Object = bootstrap.get("_retained_minesweeper_coordinator")
	assert_true(round_coordinator is MINESWEEPER_COORDINATOR)
	# Both coordinators answer to the SAME fatal fence, and the round adapters to the SAME port.
	var gate: Object = bootstrap.get("_application_gate")
	assert_eq(int(minesweeper["value"]["gate_instance_id"]), gate.get_instance_id())
	assert_same(bootstrap.get("_retained_minesweeper_state_port").get("_gate"), gate)
	assert_same(bootstrap.get("_retained_minesweeper_save_port").get("_checkpoint_port"),
		made["checkpoint_port"])
	assert_same(game_state.get("_minesweeper_round_coordinator"), round_coordinator)
	assert_not_same(round_coordinator, day_coordinator, "two distinct coordinators, one gate")


func test_day_resolution_installs_route_independent_eviction_before_desktop_mount() -> void:
	var made := _make_graph("route-independent-eviction")
	if made.is_empty():
		return
	var bootstrap: Node = made["bootstrap"]
	var game_state: Node = made["targets"][&"GameState"]
	if not _allocate_fixture_run_identity(bootstrap, game_state): return
	assert_true(bootstrap.call(&"_configure_restore_participants").get("ok", false))
	assert_null(bootstrap.get("_contacts_desktop_eviction_port"))
	assert_null(bootstrap.get("_desktop_eviction_port"))

	var resolved: Dictionary = bootstrap.call(&"_run_stage", &"configure_day_resolution", &"final")
	assert_true(resolved.get("ok", false), str(resolved))
	var route_port: RefCounted = bootstrap.get("_contacts_desktop_eviction_port")
	assert_not_null(route_port, "the adapter exists before any desktop scene")
	assert_same(bootstrap.get("_desktop_eviction_port"), route_port)
	assert_null(route_port.get("view"), "the route-independent adapter starts unbound")
	assert_eq(game_state.day_changed.get_connections().size(), 1,
		"the adapter is registered before the sole day-change connection")
	var host: RefCounted = bootstrap.get("_desktop_host_state")
	assert_true(host.open_app(&"contacts", 1).get("ok", false))

	if not _publish_fixture_day_change(bootstrap, game_state, 2): return
	assert_false(bootstrap.get("_application_gate").is_fatal_latched(),
		"a direct Hospital completion can change day before the desktop mounts")
	assert_eq(int(host.get_state()["current_day"]), 2)
	assert_true(host.get_state()["cached_app_ids"].is_empty(),
		"the retained host clears its cache even before a physical desktop exists")
	assert_null(route_port.get("view"), "headless eviction remains a successful no-op")

	var startup_state: Dictionary = bootstrap.get("_state")
	startup_state["ready"] = true
	bootstrap.set("_state", startup_state)
	var desktop: Node = autofree(FakeContactsDesktop.new())
	var mounted: Dictionary = bootstrap.call(&"configure_contacts_desktop", desktop)
	assert_true(mounted.get("ok", false), str(mounted))
	assert_true(desktop.get("configured"))
	assert_eq(desktop.get("configured_day"), 2)
	assert_same(bootstrap.get("_contacts_desktop_eviction_port"), route_port,
		"desktop mount reuses the adapter that protected direct Hospital Load")
	assert_same((route_port.get("view") as WeakRef).get_ref(), desktop)
	assert_true(host.open_app(&"contacts", 2).get("ok", false))
	if not _publish_fixture_day_change(bootstrap, game_state, 3): return
	assert_eq(desktop.get("evictions").size(), 1,
		"the later mounted view receives exactly one dispatch through the same adapter")
	if desktop.get("evictions").size() == 1:
		assert_eq(desktop.get("evictions")[0]["app_ids"], [&"contacts"])
		assert_eq(desktop.get("evictions")[0]["day"], 3)
	assert_true(host.get_state()["cached_app_ids"].is_empty())
	assert_false(bootstrap.get("_application_gate").is_fatal_latched())


func _allocate_fixture_run_identity(bootstrap: Node, game_state: Node) -> bool:
	var issuer: RefCounted = bootstrap.get("_desktop_identity_nonce_issuer")
	var transaction: Dictionary = issuer.issue(&"transaction_id")
	assert_true(transaction.get("ok", false), str(transaction))
	if not transaction.get("ok", false): return false
	var prepared: Dictionary = issuer.prepare_continuation_allocation({
		"kind": "new_run", "transaction_id": transaction.value.token,
		"transaction_issuer_receipt": transaction.value.issuer_receipt,
		"existing_run_id": null, "source_desktop_timeline_generation": null,
		"remap_source_transaction_ids": [],
	})
	assert_true(prepared.get("ok", false), str(prepared))
	if not prepared.get("ok", false): return false
	var committed: Dictionary = issuer.commit_continuation_allocation(prepared.value)
	assert_true(committed.get("ok", false), str(committed))
	if not committed.get("ok", false): return false
	var identity: Dictionary = committed.value
	game_state.get("_run_lifecycle").reset(identity.run_id, identity.branch_id,
		identity.desktop_timeline_generation, identity.causal_day_instance, identity, false)
	return true


func _publish_fixture_day_change(bootstrap: Node, game_state: Node, day: int) -> bool:
	# This fixture supplies the committed day/identity boundary; the connected Hospital
	# journey owns the actual day-resolution transaction that precedes publication. Use
	# the real allocator: causal-day identities cannot be minted by issuer.issue().
	var issuer: RefCounted = bootstrap.get("_desktop_identity_nonce_issuer")
	var lifecycle: RefCounted = game_state.get("_run_lifecycle")
	var identity: Dictionary = lifecycle.get_desktop_identity_context()
	assert_eq(day, int(game_state.get("day")) + 1)
	var transaction: Dictionary = issuer.issue(&"transaction_id")
	assert_true(transaction.get("ok", false), str(transaction))
	if not transaction.get("ok", false): return false
	var child: Dictionary = issuer.derive_child({
		"parent_receipt_id": transaction.value.issuer_receipt.receipt_id,
		"child_kind": "day_resolution_stage", "ordinal": 0, "source_ids": [],
	})
	assert_true(child.get("ok", false), str(child))
	if not child.get("ok", false): return false
	var allocator: RefCounted = DAY_IDENTITY_PORT.new()
	var configured: Dictionary = allocator.configure(issuer)
	assert_true(configured.get("ok", false), str(configured))
	if not configured.get("ok", false): return false
	var prepared: Dictionary = allocator.prepare_advance({
		"resolution_kind": "schedule_done",
		"source_resolution_receipt": {"receipt_id": child.value.child_id,
			"provenance": child.value.provenance},
		"run_id": identity.run_id, "branch_id": identity.branch_id,
		"desktop_timeline_generation": identity.desktop_timeline_generation,
		"source_day": day - 1, "source_causal_day_instance": identity.causal_day_instance,
		"source_causal_day_instance_issuer_receipt": identity.causal_day_instance_issuer_receipt,
	})
	assert_true(prepared.get("ok", false), str(prepared))
	if not prepared.get("ok", false): return false
	var committed: Dictionary = allocator.commit_advance(prepared.value.day_advance_identity_candidate)
	assert_true(committed.get("ok", false), str(committed))
	if not committed.get("ok", false): return false
	var receipt: Dictionary = committed.value.day_advance_identity_receipt
	assert_eq(int(receipt.target_day), day)
	lifecycle.set("_day", day)
	lifecycle.set("_causal_day_instance", receipt.target_causal_day_instance)
	lifecycle.set("_causal_day_instance_issuer_receipt", receipt.target_causal_day_instance_issuer_receipt)
	game_state.emit_signal("day_changed", day)
	return true


func test_exactly_one_day_changed_connection_dispatches_one_eviction_command() -> void:
	var made := _make_graph("day-change")
	if made.is_empty():
		return
	var bootstrap: Node = made["bootstrap"]
	var game_state: Node = made["targets"][&"GameState"]
	assert_true(bootstrap.call(&"_configure_restore_participants").get("ok", false))
	assert_eq(game_state.day_changed.get_connections().size(), 0, "nothing connected yet")
	bootstrap.call(&"_connect_desktop_day_change", game_state)
	assert_eq(game_state.day_changed.get_connections().size(), 1,
		"Bootstrap owns exactly one day_changed connection")
	# An identical replay never adds a second connection.
	bootstrap.call(&"_connect_desktop_day_change", game_state)
	assert_eq(game_state.day_changed.get_connections().size(), 1)

	var eviction: RefCounted = FAKE_EVICTION.new()
	var registered: Dictionary = bootstrap.call(&"register_desktop_eviction_port", eviction)
	assert_true(registered.get("ok", false), str(registered))
	# The same port is idempotent; a different one is refused.
	assert_true(bootstrap.call(&"register_desktop_eviction_port", eviction)
		.get("value", {}).get("already_configured", false))
	assert_eq(bootstrap.call(&"register_desktop_eviction_port", FAKE_EVICTION.new()).get("code"),
		&"desktop_eviction_port_already_configured")

	game_state.emit_signal("day_changed", 2)
	assert_eq(int(eviction.get_call_counts()["dispatch_desktop_eviction"]), 1,
		"one day change dispatches exactly one eviction command")
	var command: Dictionary = eviction.get("_last_command")
	assert_eq(str(command["command_id"]), "desktop-day:2")
	assert_eq(str(command["kind"]), "evict_cached_apps")
	assert_eq(int(command["day"]), 2)
	assert_eq(typeof(command["app_ids"]), TYPE_ARRAY)
	assert_false(bootstrap.get("_application_gate").is_fatal_latched(),
		"a successful dispatch latches nothing")


func test_a_missing_eviction_port_latches_one_primitive_validated_fatal() -> void:
	var made := _make_graph("eviction-missing")
	if made.is_empty():
		return
	var bootstrap: Node = made["bootstrap"]
	var game_state: Node = made["targets"][&"GameState"]
	assert_true(bootstrap.call(&"_configure_restore_participants").get("ok", false))
	bootstrap.call(&"_connect_desktop_day_change", game_state)
	var gate: Object = bootstrap.get("_application_gate")
	game_state.emit_signal("day_changed", 3)
	assert_true(gate.is_fatal_latched(), "a missing dispatch port is fatal")
	# The retained failure is primitive-validated, and every later guard returns it unchanged.
	var guarded: Dictionary = gate.guard_external(&"any_later_operation")
	assert_false(guarded.get("ok", false))
	assert_eq(guarded.get("code"), &"APPLICATION_FATAL")
	var failure: Dictionary = guarded["details"]["failure"]
	for key: String in ["source", "phase", "code", "details"]:
		assert_true(failure.has(key), "retained failure key " + key)
	assert_eq(typeof(failure["details"]), TYPE_DICTIONARY)
	assert_eq(str(failure["source"]), "desktop")


func test_each_stage_failure_returns_one_fatal_result_and_never_reaches_readiness() -> void:
	# Injecting a missing target at each stage must stop startup there: no later stage runs and
	# readiness is never published.
	var failures := {
		&"initialize_window_mode": &"WindowModeManager",
		&"initialize_saves": &"SaveManager",
		&"configure_restore_participants": &"SaveManager",
		&"configure_day_resolution": &"SaveManager",
		&"configure_minesweeper_rounds": &"SaveManager",
	}
	for stage_id: StringName in failures:
		var made := _make_graph("stage-fail-%s" % stage_id)
		if made.is_empty():
			return
		var bootstrap: Node = made["bootstrap"]
		var targets: Dictionary = bootstrap.injected_targets.duplicate()
		targets.erase(failures[stage_id])
		bootstrap.injected_targets = targets
		var result: Dictionary = bootstrap.call(&"_run_stage", stage_id, &"final")
		assert_false(result.get("ok", false), String(stage_id))
		assert_true(result.has("code"), String(stage_id))
		var state: Dictionary = bootstrap.call(&"get_startup_state")
		assert_false(bool(state["ready"]), "%s never publishes readiness" % stage_id)
		assert_false(&"publish_application_ready" in (state["completed_stages"] as Array))
		assert_null(bootstrap.get("_retained_minesweeper_coordinator"),
			"%s leaves no partially configured round graph" % stage_id)


class RecoveryProfile extends Node:
	var trace: Array = []
	var bound_storage: RefCounted
	var registry_bound := false
	func configure_new_run_storage(storage: RefCounted) -> Dictionary:
		bound_storage = storage
		trace.append("bind_profile")
		return {"ok": true}
	func configure_line_registry(registry: Dictionary) -> Dictionary:
		trace.append("bind_line_registry")
		registry_bound = registry.get("reply_lines") is Array and registry.get("atoms") is Array
		return {"ok": registry_bound}
	func initialize(storage: RefCounted) -> Dictionary:
		trace.append("initialize_profile")
		return {"ok": storage == bound_storage and registry_bound}


class RecoverySaves extends Node:
	func configure_scene_new_run(_bridge: Object) -> Dictionary:
		return {"ok": true}
	func configure_scene_title_new_run(_target: String) -> Dictionary:
		return {"ok": true}
	var trace: Array = []
	var fail_settlement := false
	var profile: Object
	func initialize(_storage: RefCounted) -> Dictionary:
		trace.append("initialize_saves")
		return {"ok": true}
	func configure_new_run_profile_owner(owner: Object) -> Dictionary:
		profile = owner
		trace.append("bind_recovery")
		return {"ok": true}
	func reconcile_new_run_storage() -> Dictionary:
		trace.append("settle_pair")
		return {"ok": not fail_settlement, "code": &"NEW_RUN_RECOVERY_PENDING"}


class RecoveryBootstrap extends InjectableBootstrap:
	var trace: Array = []
	func _run_stage(stage_id: StringName, mode: StringName) -> Dictionary:
		# Exercise real save/profile stages inside the real start() sequencing loop;
		# unrelated graph construction is outside this storage-order regression.
		if stage_id in [&"initialize_saves", &"initialize_profile"]:
			return super._run_stage(stage_id, mode)
		if stage_id == &"initialize_localization": trace.append("first_consumer")
		return {"ok": true}


func test_new_acc_storage_settles_before_profile_and_failure_stops_all_consumers() -> void:
	for fail_settlement: bool in [false, true]:
		var trace: Array = []
		var profile: Node = autofree(RecoveryProfile.new())
		var saves: Node = autofree(RecoverySaves.new())
		var bootstrap: Node = autofree(RecoveryBootstrap.new())
		profile.trace = trace
		saves.trace = trace
		saves.fail_settlement = fail_settlement
		bootstrap.trace = trace
		bootstrap.injected_targets = {&"ProfileManager": profile, &"SaveManager": saves}
		var root: String = _isolated_root("new-acc-storage-order")
		if root.is_empty():
			return
		var storage: RefCounted = JSON_STORAGE.new(root)
		bootstrap.set("_selected_root", root)
		bootstrap.set("_profile_storage", storage)
		bootstrap.set("_application_gate", FAKE_GATE.new())
		watch_signals(bootstrap)
		var result: Dictionary = bootstrap.start()
		assert_eq(result.get("ok", false), not fail_settlement)
		assert_same(profile.bound_storage, storage)
		assert_same(saves.profile, profile)
		var expected: Array = ["initialize_saves", "bind_profile", "bind_recovery", "settle_pair"]
		if not fail_settlement:
			expected.append_array(["bind_line_registry", "initialize_profile", "first_consumer"])
			assert_signal_emitted(bootstrap, "application_ready")
		else:
			assert_eq(result.get("code"), &"NEW_RUN_RECOVERY_PENDING")
			assert_signal_not_emitted(bootstrap, "application_ready")
		assert_eq(trace, expected)
		assert_eq(bootstrap.get_startup_state().ready, not fail_settlement)

func before_each() -> void:
	_scene_validation_scope.install()

func after_each() -> void:
	_scene_validation_scope.restore()

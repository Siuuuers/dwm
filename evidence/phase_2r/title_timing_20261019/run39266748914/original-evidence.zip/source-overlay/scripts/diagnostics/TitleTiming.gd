extends RefCounted
# Diagnostic overlay only. No save payloads, recovery records or product state.
static var ending_depth: int = 0
static var sequence: int = 0
static var disabled: bool = false
const MAX_RECORDS: int = 256
const MAX_BYTES: int = 262144

static func enabled() -> bool:
	return not disabled and not OS.get_environment("DWM_TITLE_TIMING_PATH").is_empty()

static func emit_record(phase: String, edge: String, detail: Dictionary = {}) -> void:
	if not enabled(): return
	if sequence >= MAX_RECORDS:
		_fail("record bound reached")
		return
	var tick: int = Time.get_ticks_usec()
	var utc: float = Time.get_unix_time_from_system()
	var path: String = OS.get_environment("DWM_TITLE_TIMING_PATH")
	if not path.is_absolute_path():
		_fail("output path must be absolute")
		return
	var mode: int = FileAccess.READ_WRITE if FileAccess.file_exists(path) else FileAccess.WRITE_READ
	var file: FileAccess = FileAccess.open(path, mode)
	if file == null:
		_fail("open failed: " + str(FileAccess.get_open_error()))
		return
	sequence += 1
	var row: Dictionary = {"schema_version": 1, "source": "game", "phase": phase,
		"edge": edge, "ticks_usec": tick, "utc_unix": utc,
		"pid": OS.get_process_id(), "sequence": sequence, "detail": detail}
	var line: String = JSON.stringify(row) + "\n"
	if file.get_length() + line.to_utf8_buffer().size() > MAX_BYTES:
		file.close()
		_fail("byte bound reached")
		return
	file.seek_end()
	file.store_string(line)
	file.flush()
	var error: int = file.get_error()
	file.close()
	if error != OK: _fail("append/flush failed: " + str(error))

static func result_detail(result: Dictionary) -> Dictionary:
	var value: Variant = result.get("value", {})
	return {"ok": result.get("ok", false), "code": str(result.get("code", "")),
		"committed": result.get("committed", false),
		"checkpoint_id": str(value.get("checkpoint_id", "")) if value is Dictionary else ""}

static func observe_menu(tree: SceneTree) -> Callable:
	if not enabled() or tree == null: return Callable()
	var observer: Callable = func() -> void:
		var menu: Node = tree.current_scene
		if menu == null or menu.scene_file_path != "res://scenes/menu/MenuScene.tscn":
			emit_record("menu_mount", "other_scene")
			return
		var menu_id: int = menu.get_instance_id()
		emit_record("menu_mount", "observed", {"instance_id": menu_id, "ready": menu.is_node_ready()})
		tree.process_frame.connect(func() -> void:
			var current: Node = tree.current_scene
			var same: bool = current != null and current.get_instance_id() == menu_id
			emit_record("menu_first_idle", "observed", {"same_menu": same,
				"meaning": "first process_frame after scene_changed; not control responsiveness"})
		, CONNECT_ONE_SHOT)
	tree.scene_changed.connect(observer, CONNECT_ONE_SHOT)
	return observer

static func _fail(reason: String) -> void:
	disabled = true
	push_warning("DWM_TITLE_TIMING_WRITE_FAILURE: " + reason)

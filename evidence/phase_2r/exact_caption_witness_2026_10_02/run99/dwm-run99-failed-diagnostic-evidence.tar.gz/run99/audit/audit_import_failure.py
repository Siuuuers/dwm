#!/usr/bin/env python3
"""Read-only independent Run99 import-failure diagnosis; no engine execution."""
import argparse
import json
from pathlib import Path
import re
import subprocess

from cloud_evidence import clean, encoded, identity, read, require


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-root', type=Path, required=True)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--source', required=True)
    args = parser.parse_args()
    root = args.run_root
    run, jobs = read(root / 'run.json'), read(root / 'jobs.json')['jobs']
    require(run['id'] == 36893609060 and run['run_attempt'] == 1 and run['conclusion'] == 'failure', 'RUN99_ATTEMPT1_FAILURE_REQUIRED')
    require(len(jobs) == 7 and all(j['conclusion'] == 'failure' for j in jobs), 'SEVEN_FAILED_JOBS_REQUIRED')
    error = 'SCRIPT ERROR: Parse Error: Assigned value for constant "ROOT_KEYS" isn\'t a constant expression.'
    source = subprocess.check_output(['git', '-C', str(args.repo), 'show', args.source + ':scripts/profile/ProfileSchema.gd'], text=True)
    statement = source.splitlines()[23]
    require(statement == 'const ROOT_KEYS := V9_ROOT_KEYS + ["witnessed_caption_variants"]', 'FROZEN_SOURCE_ROOT_KEYS_CONCATENATION_MISMATCH')
    observed = []
    for job in jobs:
        path = root / 'logs' / f'{job["id"]}.log'
        lines = [clean(line) for line in path.read_text(encoding='utf-8-sig').splitlines()]
        matches = [i for i, line in enumerate(lines) if line == error]
        require(matches and any(i + 1 < len(lines) and 'res://scripts/profile/ProfileSchema.gd:24' in lines[i + 1] for i in matches), 'ROOT_KEYS_ERROR_AND_LOCATION_REQUIRED: ' + job['name'])
        require(any('Failed to load script "res://autoload/ProfileManager.gd" with error "Parse error".' in line for line in lines), 'DEPENDENT_AUTOLOAD_ERROR_REQUIRED')
        import_steps = [s for s in job['steps'] if s['name'] == 'Import project']
        require(len(import_steps) == 1 and import_steps[0]['conclusion'] == 'failure', 'IMPORT_STEP_FAILURE_REQUIRED')
        following = [s for s in job['steps'] if s['number'] > import_steps[0]['number']]
        engine_steps = [s for s in following if s['name'] in (
            'Run focused regression suite', 'Exercise real Solo reading Save and fresh-process Load',
            'Verify isolated runner contracts and timeout diagnostics', 'Generate affected public inventories for review',
            'Verify public inventory drift and read-only contracts')]
        require(engine_steps and all(s['conclusion'] == 'skipped' for s in engine_steps), 'POST_IMPORT_ENGINE_STEPS_MUST_BE_SKIPPED')
        require(not any(re.match(r'^(?:CLOUD_GUT_RESULT\b|READING_RAIL_.*_PASS:)', line) for line in lines), 'UNEXPECTED_TEST_SUCCESS_MARKER')
        observed.append({'job_id': job['id'], 'job_name': job['name'], 'job_conclusion': job['conclusion'],
            'log': path.relative_to(root).as_posix(), 'log_identity': identity(path),
            'root_keys_parse_error_occurrences': len(matches), 'source_location_verified': 'scripts/profile/ProfileSchema.gd:24',
            'failed_step': import_steps[0]['name'], 'skipped_engine_steps': [s['name'] for s in engine_steps]})
    xml = list((root / 'artifacts').rglob('*.xml'))
    require(not xml, 'UNEXPECTED_GUT_XML')
    import_logs = list((root / 'artifacts').rglob('import.log'))
    require(len(import_logs) == 7, 'SEVEN_RETAINED_IMPORT_LOGS_REQUIRED')
    for path in import_logs:
        require(error in path.read_text(encoding='utf-8-sig'), 'RETAINED_IMPORT_LOG_ROOT_KEYS_ERROR_REQUIRED')
    report = {'schema_version': 1, 'run_id': run['id'], 'run_number': run['run_number'], 'run_attempt': 1,
        'source': args.source, 'workflow_head': run['head_sha'], 'diagnostic_only': True, 'acceptance': False,
        'verified_diagnosis': 'Every job failed its project-import step after ProfileSchema ROOT_KEYS array concatenation was rejected as a nonconstant expression. The dependent ProfileManager autoload also failed to compile.',
        'frozen_source_statement': statement, 'failed_jobs': observed, 'failed_job_count': len(observed),
        'gut_executions': 0, 'gut_xml_files': 0, 'reading_journey_executed': False,
        'no_test_execution_basis': 'All five regression-suite steps and the rendered journey were skipped by GitHub after import failure; no GUT XML or runtime success markers exist. Public-surface engine steps were also skipped.',
        'retained_import_logs': [{'path': p.relative_to(root).as_posix(), **identity(p)} for p in sorted(import_logs)],
        'limits': ['Pre-import static checks, including fixture-version census, did run; this is not a claim that no preparatory command executed.',
                   'The rendered import also records an ObjectDB exit warning; raw failed-import evidence preserves it without claiming lifetime acceptance.',
                   'No passing behavior, witness persistence, save/recovery or test acceptance is attributed to this failed source.']}
    (root / 'audit/import-failure-diagnosis.json').write_bytes(encoded(report))
    print(json.dumps({'failed_jobs': len(observed), 'gut_executions': 0, 'import_logs': len(import_logs), 'acceptance': False}))


if __name__ == '__main__':
    main()

DIAGNOSTIC ONLY: completed failed run. No passing tests, behavioral success or acceptance is claimed.

Source-bound downloaded cloud evidence. Verify every retained payload against manifest.json. Original artifact ZIP digest and size matched GitHub metadata; every extracted member was compared byte-for-byte, including excluded files. Source, checkout and workflow head are distinct records. Archive hash is external to avoid self-reference. No engines or PowerShell ran during audit or packaging.

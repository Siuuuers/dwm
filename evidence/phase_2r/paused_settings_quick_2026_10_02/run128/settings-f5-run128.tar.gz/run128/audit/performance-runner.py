#!/usr/bin/env python3
"""Audit completed broad cloud evidence with unchanged accepted inner helpers.

No Godot, PowerShell, downloaded binary, or project source is executed. All run
identities are explicit; historical helper provenance is never rebound to a run.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import fnmatch
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
HISTORICAL = ('226d3da868784baacc6fc33f58823f95b5815a51',
              '5c3368dbba14475a3749bd71df971bfed353699f',
              'dae70bf9aa05b6b3debb60f95738e5ffc4e97548')
EXPECTED_HELPERS = frozenset({
    'performance-auditors/README.md', 'performance-auditors/audit_context.py',
    'performance-auditors/audit_history_comparisons.py',
    'performance-auditors/audit_next_checkpoint_export.py',
    'performance-auditors/audit_region_warm_measurements.py',
    'performance-auditors/audit_retained_performance.py',
    'performance-auditors/audit_warm_source_guard.py',
    'performance-auditors/finish_retained_history.py',
    'performance-auditors/join_non_gut.py', 'performance-auditors/origin-manifest.json',
    'lazy-auditors/audit_context.py', 'lazy-auditors/audit_lazy.py',
    'lazy-auditors/auditor-origin.json',
})
LAZY_WORKTREE_PATHS = (
    'scripts/infrastructure/save/SaveDocumentSchema.gd',
    'scripts/application/run/SaveManagerCheckpointPort.gd',
    'tests/support/EagerNormalizationReference.gd',
    'tests/manual/benchmark_lazy_normalization.gd',
)


def read(path: Path):
    def pairs(items):
        value = {}
        for key, item in items:
            if key in value:
                raise ValueError(f'Duplicate JSON key: {key}')
            value[key] = item
        return value
    return json.loads(path.read_text(encoding='utf-8-sig'), object_pairs_hook=pairs)


def identity(path: Path) -> dict:
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def full_sha(value: str) -> str:
    if not re.fullmatch(r'[0-9a-f]{40}', value):
        raise argparse.ArgumentTypeError('expected a full lowercase 40-hex Git SHA')
    return value


def positive_int(value: str) -> int:
    number = int(value)
    if number < 1:
        raise argparse.ArgumentTypeError('expected a positive integer')
    return number


@dataclass(frozen=True)
class Config:
    run: Path
    repo: Path
    source: str
    checkout: str
    master: str
    run_id: int
    run_number: int

    def binding(self) -> dict:
        return {'run_root': str(self.run), 'repo': str(self.repo), 'source': self.source,
                'checkout': self.checkout, 'master': self.master, 'run_id': self.run_id,
                'run_number': self.run_number, 'run_attempt': 1}

    def environment(self) -> dict:
        environment = os.environ.copy()
        environment.update({
            'DWM_AUDIT_RUN_ROOT': str(self.run), 'DWM_AUDIT_REPO': str(self.repo),
            'DWM_AUDIT_SOURCE': self.source, 'DWM_AUDIT_CHECKOUT': self.checkout,
            'DWM_AUDIT_ATTEMPT': '1', 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONOPTIMIZE': '0',
        })
        return environment


def parse_args(description: str) -> Config:
    if not __debug__:
        raise RuntimeError('Assertion-based auditors must run without Python optimization')
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument('--run-root', type=Path, required=True)
    parser.add_argument('--repo', type=Path, required=True)
    for flag in ('source', 'checkout', 'master'):
        parser.add_argument('--' + flag, type=full_sha, required=True)
    for flag in ('run-id', 'run-number'):
        parser.add_argument('--' + flag, type=positive_int, required=True)
    args = parser.parse_args()
    for path in (args.run_root, args.repo):
        if not path.is_dir():
            parser.error(f'Existing directory required: {path}')
    return Config(args.run_root.resolve(), args.repo.resolve(), args.source,
                  args.checkout, args.master, args.run_id, args.run_number)


def git(config: Config, *arguments: str) -> bytes:
    return subprocess.check_output(['git', '-C', str(config.repo), *arguments])


def preflight(config: Config) -> dict:
    """Read-only actual metadata and Git boundary checks before any audit output."""
    metadata = read(config.run / 'run.json')
    assert metadata['id'] == config.run_id and metadata['run_number'] == config.run_number
    assert metadata['head_sha'] == config.source and metadata['run_attempt'] == 1
    assert metadata['status'] == 'completed' and metadata['conclusion'] == 'success'
    generic = read(config.run / 'audit/generic-evidence-audit.json')
    assert generic['generic_audit_pass'] is True
    for key in ('id', 'run_number', 'head_sha', 'run_attempt', 'status', 'conclusion'):
        assert generic['run'][key] == metadata[key], ('generic metadata binding', key)
    assert set(generic['raw_metadata_identities']) == {'run.json', 'jobs.json', 'artifacts-api.json'}
    for filename, expected in generic['raw_metadata_identities'].items():
        assert identity(config.run / filename) == expected, ('changed raw metadata', filename)
    assert len(generic['jobs']) == 23 and generic['gut']['xml_count'] == 13
    assert all(generic['gut'][key] == 0 for key in ('errors', 'failures', 'skipped'))
    boundary = read(config.run / 'audit/source-provenance.json')
    assert generic['source_boundary'] == boundary
    assert boundary['source'] == config.source and boundary['tested_checkout'] == config.checkout
    assert boundary['master'] == config.master and boundary['all_unlisted_paths_byte_identical'] is True
    for revision in (config.source, config.checkout, config.master, *HISTORICAL):
        assert git(config, 'rev-parse', revision + '^{commit}').decode().strip() == revision
    headers = git(config, 'cat-file', 'commit', config.checkout).split(b'\n\n', 1)[0].splitlines()
    parents = [line[len(b'parent '):].decode() for line in headers if line.startswith(b'parent ')]
    assert parents == boundary['checkout_parents'] == [config.master, config.source]
    assert boundary['explicit_allowed_difference_patterns'] == ['AGENTS.md', 'docs/*', 'story/*']
    differences = []
    pieces = git(config, 'diff', '--raw', '--no-abbrev', '--no-renames', '-z',
                 config.source, config.checkout).split(b'\0')
    for index in range(0, len(pieces) - 1, 2):
        header = pieces[index].decode().split()
        path = pieces[index + 1].decode()
        assert any(fnmatch.fnmatchcase(path, pattern)
                   for pattern in boundary['explicit_allowed_difference_patterns']), path
        differences.append({'path': path, 'old_mode': header[0][1:], 'new_mode': header[1],
                            'source_blob': header[2], 'checkout_blob': header[3], 'status': header[4]})
    assert differences == boundary['source_checkout_differences']
    for relative in LAZY_WORKTREE_PATHS:
        assert (config.repo / relative).read_bytes() == git(config, 'show', config.checkout + ':' + relative), relative
    provenance = read(HERE / 'helper-provenance.json')
    assert provenance['schema_version'] == 2 and provenance['modified_helpers'] == []
    paths = [helper['path'] for helper in provenance['helpers']]
    assert len(paths) == len(set(paths)) == len(EXPECTED_HELPERS) and set(paths) == EXPECTED_HELPERS
    for helper in provenance['helpers']:
        assert helper['byte_identical_to_run127'] is True
        assert identity(HERE / helper['path']) == {key: helper[key] for key in ('bytes', 'sha256')}
    return provenance


def copy_helpers(config: Config, provenance: dict) -> None:
    for helper in provenance['helpers']:
        original = HERE / helper['path']
        target = config.run / 'audit' / helper['path']
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            assert target.read_bytes() == original.read_bytes(), f'Changed copied auditor: {target}'
        else:
            shutil.copyfile(original, target)


def main() -> None:
    config = parse_args(__doc__)
    provenance = preflight(config)
    audit = config.run / 'audit'
    output = audit / 'performance-export-audit.json'
    for name in ('performance-export-audit.json', 'lazy-normalization-audit.json',
                 'warm-source-provenance.json', 'performance-helper-identities.json',
                 'performance-runner.py', 'performance-helper-provenance.json'):
        assert not (audit / name).exists(), f'Retain earlier diagnostic deliberately before rerun: {name}'
    logs = audit / 'performance-execution-logs'
    assert not logs.exists(), 'Retain earlier performance execution logs deliberately before rerun'
    copy_helpers(config, provenance)
    shutil.copyfile(HERE / 'helper-provenance.json', audit / 'performance-helper-provenance.json')
    shutil.copyfile(__file__, audit / 'performance-runner.py')
    logs.mkdir()
    working = audit / 'performance-auditors'
    steps = [
        ['audit_next_checkpoint_export.py', '--run-root', str(config.run), '--repo', str(config.repo),
         '--source', config.source, '--checkout', config.checkout, '--master', config.master],
        ['audit_warm_source_guard.py'], ['audit_retained_performance.py'],
        ['audit_history_comparisons.py'],
        ['audit_region_warm_measurements.py', 'history-region-search'],
        ['audit_region_warm_measurements.py', 'warm-outgoing-proof'],
        ['../lazy-auditors/audit_lazy.py'], ['finish_retained_history.py'],
    ]
    executions = []
    for ordinal, arguments in enumerate(steps, 1):
        command = [sys.executable, *arguments]
        result = subprocess.run(command, cwd=working, env=config.environment(), text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        log = logs / f'{ordinal:02d}-{Path(arguments[0]).stem}.log'
        log.write_text(result.stdout, encoding='utf-8')
        executions.append({'ordinal': ordinal, 'arguments': arguments,
                           'exit_code': result.returncode, 'log': str(log), **identity(log)})
        print(json.dumps({'step': ordinal, 'audit': arguments[0], 'exit_code': result.returncode,
                          'output': result.stdout[-4000:]}), flush=True)
        if result.returncode != 0:
            (logs / 'partial-execution.json').write_text(json.dumps({
                'binding': config.binding(), 'execution': executions,
                'launcher': identity(Path(__file__)),
                'helper_provenance': identity(HERE / 'helper-provenance.json')}, indent=2) + '\n')
            raise RuntimeError(f'Component audit failed at step {ordinal}; diagnostics retained')
    performance = read(output)
    lazy = read(audit / 'lazy-normalization-audit.json')
    warm = read(audit / 'warm-source-provenance.json')
    assert performance['source_head'] == config.source and performance['tested_merge'] == config.checkout
    assert performance['run_id'] == config.run_id and performance['audit_complete'] is True
    assert performance['run_number'] == config.run_number and performance['run_attempt'] == 1
    assert performance['master'] == config.master
    assert performance['status'] == 'verified' and performance['runtime_proof_failures'] == []
    assert performance['pending_areas'] == []
    assert lazy['candidate_source'] == config.source and lazy['tested_merge'] == config.checkout
    assert lazy['run_id'] == config.run_id and lazy['audit_complete'] is True
    assert lazy['run_attempt'] == 1
    assert lazy['runtime_proof_failures'] == [] and lazy['pending_areas'] == []
    assert warm['tested_merge'] == config.checkout and warm['status'] == 'verified'
    retained = {'schema_version': 2, 'binding': config.binding(), 'provenance': provenance,
                'execution': executions, 'launcher': identity(Path(__file__)),
                'helper_provenance': identity(HERE / 'helper-provenance.json'),
                'outputs': {name: identity(audit / name) for name in
                            ('performance-export-audit.json', 'lazy-normalization-audit.json',
                             'warm-source-provenance.json')},
                'scope': 'Independent performance/export/history/lazy components only; final non-GUT and broad joins remain separate.'}
    (audit / 'performance-helper-identities.json').write_text(json.dumps(retained, indent=2) + '\n')
    print(json.dumps({'performance_components_verified': True, **config.binding(),
                      'steps': len(steps)}), flush=True)


if __name__ == '__main__':
    main()

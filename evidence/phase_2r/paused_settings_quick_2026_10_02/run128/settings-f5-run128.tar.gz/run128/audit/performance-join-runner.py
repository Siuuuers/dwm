#!/usr/bin/env python3
"""Join completed broad-run independent components with unchanged strict helper."""
from __future__ import annotations

import json
from pathlib import Path
import shutil
import subprocess
import sys

from run_audits import HERE, identity, parse_args, preflight, read


def main() -> None:
    config = parse_args(__doc__)
    provenance = preflight(config)
    audit = config.run / 'audit'
    join_record = next(item for item in provenance['helpers']
                       if item['path'] == 'performance-auditors/join_non_gut.py')
    helper = audit / join_record['path']
    for record in provenance['helpers']:
        assert identity(audit / record['path']) == {key: record[key] for key in ('bytes', 'sha256')}
    retained = read(audit / 'performance-helper-identities.json')
    assert retained['binding'] == config.binding() and retained['provenance'] == provenance
    assert set(retained['outputs']) == {'performance-export-audit.json',
                                       'lazy-normalization-audit.json',
                                       'warm-source-provenance.json'}
    for name, expected in retained['outputs'].items():
        assert identity(audit / name) == expected, ('changed component output', name)
    required = ('rendered-functional-audit.json', 'settings-storage-audit.json',
                'next-reading-trace-audit.json', 'performance-export-audit.json',
                'next-component-audit.json', 'generic-evidence-audit.json')
    before = {name: identity(audit / name) for name in required}
    output = audit / 'non-gut-summary.json'
    record_path = audit / 'performance-join-execution.json'
    log = audit / 'performance-execution-logs/09-join_non_gut.log'
    launcher = audit / 'performance-join-runner.py'
    for path in (output, record_path, log, launcher):
        assert not path.exists(), f'Do not overwrite a previous component join: {path}'
    shutil.copyfile(__file__, launcher)
    command = [sys.executable, str(helper)]
    result = subprocess.run(command, cwd=helper.parent, env=config.environment(), text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log.parent.mkdir(exist_ok=True)
    log.write_text(result.stdout, encoding='utf-8')
    print(result.stdout, end='', flush=True)
    assert result.returncode == 0, 'Non-GUT join failed; log retained'
    assert before == {name: identity(audit / name) for name in required}
    summary = read(output)
    assert summary['run_id'] == config.run_id and summary['run_number'] == config.run_number
    assert summary['run_attempt'] == 1 and summary['candidate_source'] == config.source
    assert summary['tested_merge'] == config.checkout and summary['audit_complete'] is True
    assert summary['runtime_proof_failures'] == [] and summary['pending_areas'] == []
    execution = {'binding': config.binding(), 'command': command,
                 'exit_code': result.returncode, 'log': identity(log),
                 'helper': identity(helper), 'inputs_unchanged': before,
                 'launcher': identity(Path(__file__)),
                 'helper_provenance': identity(HERE / 'helper-provenance.json'),
                 'output': identity(output), 'required_broad_shape': {'xml_count': 13, 'job_count': 23},
                 'scope': 'Independent non-GUT component join only; root owns final broad acceptance.'}
    record_path.write_text(json.dumps(execution, indent=2) + '\n')
    print(json.dumps({'independent_non_gut_audit_complete': True, **config.binding()}), flush=True)


if __name__ == '__main__':
    main()

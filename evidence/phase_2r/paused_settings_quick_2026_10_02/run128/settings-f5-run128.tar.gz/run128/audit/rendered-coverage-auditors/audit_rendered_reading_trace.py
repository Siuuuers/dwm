#!/usr/bin/env python3
"""Audit the frozen eight-process reading trace without running game engines.

Preserves Run102's exact original five-mode trace, Pause-state and canonical
witness-key checks. Reuses its generic reading audit for raw reports/processes,
original WRITE/READ seal and witness semantics. Next operation/autosave semantics
remain the separate next_component_audit.py responsibility.
The separately isolated Settings pair has its own independent audit; its two
literal trace definitions are admitted without altering this original trace.
"""
import argparse
import ast
import hashlib
import json
import importlib.util
from pathlib import Path, PurePosixPath
import subprocess

HELPER = Path(__file__).with_name("cloud_evidence.py")
_spec = importlib.util.spec_from_file_location('retained_reading_cloud_evidence', HELPER)
if _spec is None or _spec.loader is None:
    raise RuntimeError('RETAINED_CLOUD_EVIDENCE_HELPER_REQUIRED')
_helper = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_helper)
encoded, identity, read, require, strict_json, reading_audit = (
    getattr(_helper, name) for name in
    ('encoded', 'identity', 'read', 'require', 'strict_json', 'reading_audit')
)

ORIGINAL_MODES = ('write', 'read', 'repeat', 'variant', 'witness-read')
EXPECTED_NEXT_MODES = ('next-unseen', 'next', 'next-read')
EXPECTED_SETTINGS_MODES = ('settings-write', 'settings-read')
EXPECTED_SETTINGS_KINDS = {
    'settings-write': ('settings_pause_entered', 'settings_host_entered', 'settings_quick_committed', 'settings_continue_verified'),
    'settings-read': ('settings_restore_prepared', 'history_inspected', 'settings_restore_verified'),
}
ORIGINAL_PAUSE_STAGES = (
    'ordinary_pause_entered', 'ordinary_pause_cancelled', 'ordinary_pause_continued',
    'ordinary_pause_reentered', 'ordinary_backup_previewed', 'ordinary_backup_entered',
    'ordinary_pause_save_committed', 'ordinary_pause_save_continued',
)
ORIGINAL_CAPTURES = (
    '01-title.png', '02-desktop.png', '03-minesweeper.png',
    '04-pre-history.png', '05-dating-board.png', '06-post-history.png',
    '07-post-save.png', '08-restored-history.png', '09-restored-line.png',
)
ORIGINAL_TRACE_KINDS = {
    'write': (
        'fixture_registered', *ORIGINAL_PAUSE_STAGES, 'history_inspected', 'pre_history',
        'automatic_board_handoff', 'committed_result_then_post_prose', 'quick_committed',
        'history_inspected', 'reading_quick_load_cancelled', 'stale_candidate_refused',
    ),
    'read': ('fresh_restore_prepared', 'history_inspected', 'fresh_restore_verified'),
    'repeat': ('witness_repeat_entered', 'witness_repeat_verified'),
    'variant': (
        'witness_variant_refused', 'witness_neutrality_verified', 'witness_retry_committed',
        'history_inspected', 'witness_unseen_stop_verified',
    ),
    'witness-read': ('witness_restart_verified',),
}


def constants_from_source(source):
    values = {}
    wanted = {'PAUSE_STAGES', 'MODES', 'NEXT_MODES', 'SETTINGS_MODES', 'TRACE_KINDS', 'CAPTURES', 'NEXT_CAPTURES'}
    allowed = (ast.Expression, ast.Constant, ast.Tuple, ast.List, ast.Dict, ast.Name, ast.Load, ast.Starred)
    for node in ast.parse(source).body:
        if not isinstance(node, ast.Assign) or len(node.targets) != 1 or not isinstance(node.targets[0], ast.Name):
            continue
        name = node.targets[0].id
        if name not in wanted:
            continue
        require(all(isinstance(n, allowed) for n in ast.walk(node.value)), 'LITERAL_DRIVER_CONSTANT_REQUIRED')
        values[name] = eval(compile(ast.Expression(node.value), '<literal-driver-constants>', 'eval'), {'__builtins__': {}}, values)
    require(set(values) == wanted, 'ALL_DRIVER_TRACE_CONSTANTS_REQUIRED')
    return values


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-root', type=Path, required=True)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--source', required=True)
    parser.add_argument('--checkout', required=True)
    args = parser.parse_args()
    root = args.run_root.resolve()
    run = read(root / 'run.json')
    provenance = read(root / 'audit/source-provenance.json')
    generic = read(root / 'audit/generic-evidence-audit.json')
    require(generic.get('generic_audit_pass') is True and generic['source_boundary'] == provenance, 'BOUND_GENERIC_AUDIT_REQUIRED')
    require(run['head_sha'] == provenance['source'] == args.source and provenance['tested_checkout'] == args.checkout, 'EXACT_RUN_SOURCE_CHECKOUT_REQUIRED')
    require(run['status'] == 'completed' and run['conclusion'] == 'success', 'SUCCESSFUL_FINAL_RUN_REQUIRED')
    driver_path = 'tools/testing/run_reading_rail_journey.py'
    source = subprocess.check_output(['git', '-C', str(args.repo), 'show', args.source + ':' + driver_path])
    constants = constants_from_source(source.decode())
    original_modes, kinds, stages = (constants[name] for name in ('MODES', 'TRACE_KINDS', 'PAUSE_STAGES'))
    require(original_modes == ORIGINAL_MODES, 'FIVE_WITNESS_MODES_REQUIRED')
    require(constants['NEXT_MODES'] == EXPECTED_NEXT_MODES, 'THREE_NEXT_MODES_REQUIRED')
    require(stages == ORIGINAL_PAUSE_STAGES and constants['CAPTURES'] == ORIGINAL_CAPTURES,
            'ORIGINAL_PAUSE_AND_CAPTURE_CONTRACT_MUST_REMAIN_UNCHANGED')
    require({mode: kinds[mode] for mode in original_modes} == ORIGINAL_TRACE_KINDS,
            'ORIGINAL_FIVE_MODE_TRACE_CONTRACT_MUST_REMAIN_UNCHANGED')
    modes = original_modes + constants['NEXT_MODES']
    require(constants['SETTINGS_MODES'] == EXPECTED_SETTINGS_MODES
            and {mode: kinds[mode] for mode in EXPECTED_SETTINGS_MODES} == EXPECTED_SETTINGS_KINDS,
            'EXACT_SEPARATE_SETTINGS_TRACE_CONTRACT_REQUIRED')
    require(set(kinds) == set(modes + EXPECTED_SETTINGS_MODES), 'ORIGINAL_EIGHT_PLUS_SEPARATE_SETTINGS_TRACE_CONTRACT_REQUIRED')
    checkout_driver = subprocess.check_output([
        'git', '-C', str(args.repo), 'show', args.checkout + ':' + driver_path])
    require(checkout_driver == source, 'SOURCE_AND_CHECKOUT_DRIVER_BYTES_DIFFER')
    # Existing audit independently checks all raw mode/process reports and logs,
    # unique positive process IDs, original Save/Load, screenshots, seal and exact
    # Profile witness/refusal/retry/restart semantics. Never import the driver.
    baseline_audit = reading_audit(root, args.checkout, modes)
    records = []
    for top in sorted((root / 'artifacts').glob('reading-rail-*/result.json')):
        result = read(top)
        require(result['ok'] is True and result['failures'] == [] and result['checkout_sha'] == args.checkout, 'SUCCESSFUL_BOUND_READING_RESULT_REQUIRED')
        folder = top.parent / PurePosixPath(result['artifact_root']).name
        trace_path = folder / 'transactions.jsonl'
        trace = [strict_json(line) for line in trace_path.read_text().splitlines()]
        expected = [(mode, kind) for mode in modes for kind in kinds[mode]]
        require([(e['mode'], e['kind']) for e in trace] == expected, 'EXACT_FULL_TRACE_ORDER_MISMATCH')
        for mode in modes:
            observed = [e for e in trace if e['mode'] == mode]
            report = result['reports'][mode]
            require([e['sequence'] for e in observed] == list(range(1, len(observed) + 1))
                    and all(e['process_id'] == report['process_id'] for e in observed), 'TRACE_PID_OR_SEQUENCE_MISMATCH')
            if mode not in ('write', 'read'):
                require(observed[-1]['value'] == report, 'TERMINAL_TRACE_AND_RAW_REPORT_MISMATCH: ' + mode)
        seal = read(folder / 'write-read-seal.json')
        expected_seal = {'write.json', 'read.json', 'saved-quick.json',
                         'saved-pause-slot.json', 'transactions.jsonl', *constants['CAPTURES']}
        require(set(seal['files']) == expected_seal and len(expected_seal) == 14
                and seal['sealed_after_mode'] == 'read' and seal['before_mode'] == 'repeat',
                'EXACT_ORIGINAL_FOURTEEN_FILE_WRITE_READ_SEAL_REQUIRED')
        sealed = folder / PurePosixPath(seal['root']).name
        sealed_trace = [strict_json(line) for line in
                        (sealed / 'transactions.jsonl').read_text().splitlines()]
        original_prefix = [(mode, kind) for mode in original_modes[:2] for kind in kinds[mode]]
        require([(entry['mode'], entry['kind']) for entry in sealed_trace] == original_prefix
                and sealed_trace == trace[:len(sealed_trace)], 'EXACT_SEALED_WRITE_READ_TRACE_PREFIX_REQUIRED')
        written = result['reports']['write']
        pause = written['ordinary_pause_save']
        first = pause[stages[0]]
        native = first['native']
        require(pause['foreign_handle_refused'] is True, 'FOREIGN_HANDLE_REFUSAL_REQUIRED')
        for stage in stages:
            sample = pause[stage]
            entry = next(e for e in trace if e['kind'] == stage)
            require(entry['value'] == sample and sample['source'] == first['source'], 'PAUSE_TRACE_OR_IMMUTABLE_SOURCE_MISMATCH')
            require(all(sample['native'][key] == native[key] for key in ('line_id', 'caption_id', 'text', 'total_characters')), 'PAUSE_CHANGED_NATIVE_LINE_IDENTITY')
        for stage in stages[:5]:
            view = pause[stage]['native']
            require(view['revealing'] is True and view['reveal_generation'] == native['reveal_generation']
                    and 0 <= view['visible_characters'] < view['total_characters'] and 0 <= view['visible_ratio'] < 1,
                    'PAUSE_CANCEL_CONTINUE_AND_FOCUS_PREVIEW_MUST_RETAIN_PARTIAL_LINE')
        require(pause[stages[1]] == first == pause[stages[2]] and pause[stages[3]] == pause[stages[4]], 'LITERAL_PAUSE_STATE_CHANGED')
        for stage in stages[5:]:
            view = pause[stage]['native']
            require(pause[stage] == pause[stages[5]] and view['revealing'] is False
                    and view['reveal_generation'] == native['reveal_generation'] + 1 and view['visible_ratio'] == 1
                    and (view['visible_characters'] == -1 or view['visible_characters'] >= view['total_characters']),
                    'EXPLICIT_BACKUP_SAVE_AND_CONTINUE_MUST_RETAIN_FULL_SAME_LINE')
        physical_pause = read(folder / 'saved-pause-slot.json')['current_snapshot']['snapshot']
        require(physical_pause['narrative_checkpoint'] == pause['saved_checkpoint'] == first['source']['checkpoint']
                and physical_pause['gameplay']['route_context']['active_dating_challenge'] == first['source']['physical_record'],
                'PHYSICAL_PAUSE_SLOT_CHECKPOINT_OR_SOURCE_MISMATCH')
        physical_quick = read(folder / 'saved-quick.json')['current_snapshot']['snapshot']
        require(physical_quick['narrative_checkpoint'] == written['saved_checkpoint'], 'PHYSICAL_QUICK_CHECKPOINT_MISMATCH')
        witnesses = read(folder / 'witness-profile.json')['witnessed_caption_variants']
        for key, beat in witnesses.items():
            # Finite fixture uses printable ASCII strings only, so Python's sorted,
            # compact JSON is byte-identical to the frozen canonical writer here.
            raw = json.dumps(beat, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
            require(all(32 <= ord(c) <= 126 for c in raw), 'ASCII_FIXTURE_HASH_SCOPE_EXCEEDED')
            require(hashlib.sha256(raw.encode()).hexdigest() == key, 'PHYSICAL_WITNESS_KEY_NOT_EXACT_BEAT_HASH')
        records.append({'report': top.relative_to(root).as_posix(), 'report_identity': identity(top),
            'trace_identity': identity(trace_path), 'trace_entries': len(trace), 'modes': list(modes),
            'exact_trace_kinds': {mode: list(kinds[mode]) for mode in modes},
            'terminal_supplemental_trace_values_match_raw_reports': True,
            'process_ids': {mode: result['reports'][mode]['process_id'] for mode in modes},
            'raw_report_identities': {mode: identity(folder / (mode + '.json')) for mode in modes},
            'original_write_read_seal_files': len(expected_seal),
            'original_five_mode_trace_contract_preserved': True, 'pause_source_unchanged': True,
            'pause_preview_partial_backup_full_same_line': True, 'physical_pause_and_quick_checkpoints_match': True,
            'canonical_witness_keys_recomputed': len(witnesses),
            'original_reading_capture_names': list(constants['CAPTURES']),
            'original_capture_file_count': len(constants['CAPTURES']),
            'original_capture_distinct_sha256_count': len({identity(folder / 'captures' / name)['sha256'] for name in constants['CAPTURES']})})
    require(records, 'READING_ARTIFACT_REQUIRED')
    output = {'schema_version': 1, 'run_id': run['id'], 'run_attempt': run['run_attempt'], 'source': args.source, 'checkout': args.checkout,
        'frozen_driver': {'path': driver_path, 'sha256': hashlib.sha256(source).hexdigest()},
        'audit_complete': True, 'runtime_proof_failures': [], 'readings': records,
        'original_proof_and_process_audit': baseline_audit,
        'retained_audit_helper': {'path': str(HELPER), **identity(HELPER)},
        'limits': ['Read-only inspection of downloaded cloud outputs; no Godot or PowerShell execution.',
                   'Canonical token recomputation is deliberately limited to this printable-ASCII fixture.',
                   'Physical Pause save is retained and checked but not separately fresh-loaded; original Quick READ supplies the fresh-load proof.',
                   'Finite v1 noncanonical Solo fixture only; no production dialogue or complete native all-input acceptance.',
                   'This original v1 physical journey does not itself establish v2 physical Save/Load; the separate v2 artifact is audited independently.',
                   'Next durable operation/autosave semantics require the separate Next component audit; this audit binds their modes, reports and exact trace order.']}
    destination = root / 'audit/next-reading-trace-audit.json'
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(encoded(output))
    print(json.dumps({'output': str(destination), 'reading_artifacts': len(records), 'trace_entries': sum(x['trace_entries'] for x in records)}))


if __name__ == '__main__':
    main()

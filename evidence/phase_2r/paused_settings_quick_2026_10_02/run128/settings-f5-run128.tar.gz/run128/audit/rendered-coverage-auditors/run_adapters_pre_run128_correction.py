#!/usr/bin/env python3
"""Run only rendered, original-reading and Settings/storage auditors after a completed broad gate."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import re
import subprocess
import sys

HERE = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_text())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-root', type=Path, required=True)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--source', required=True)
    parser.add_argument('--checkout', required=True)
    args = parser.parse_args()
    root = args.run_root.resolve()
    assert all(re.fullmatch(r'[0-9a-f]{40}', value) for value in (args.source, args.checkout))
    run = read(root / 'run.json')
    generic = read(root / 'audit/generic-evidence-audit.json')
    assert run['status'] == 'completed' and run['conclusion'] == 'success'
    assert generic['generic_audit_pass'] is True
    assert generic['source_boundary']['source'] == args.source and generic['source_boundary']['tested_checkout'] == args.checkout
    assert generic['run']['id'] == run['id']
    jobs = read(root / 'jobs.json')['jobs']
    settings = [row for row in jobs if row['name'] == 'Windows / settings and profile persistence' and row['run_attempt'] == run['run_attempt']]
    assert len(settings) == 1 and settings[0]['status'] == 'completed' and settings[0]['conclusion'] == 'success'
    archives = read(root / 'artifact-manifest.json')
    matches = [row for row in archives if row['name'] == f"windows-settings-{run['id']}-{run['run_attempt']}"]
    assert len(matches) == 1
    common = ['--run-root', str(root), '--repo', str(args.repo.resolve()), '--source', args.source, '--checkout', args.checkout]
    commands = [
        ('rendered-functional-audit.json', 'audit_rendered_functional.py', common),
        ('next-reading-trace-audit.json', 'audit_rendered_reading_trace.py', common),
        ('next-component-audit.json', 'audit_rendered_next_component.py', [str(root)]),
        ('settings-storage-audit.json', 'audit_coverage_settings_storage.py', common + ['--job-id', str(settings[0]['id']), '--artifact-zip', matches[0]['local_zip']]),
    ]
    retained = root / 'audit/rendered-coverage-auditors'
    retained.mkdir(exist_ok=True)
    def execute(item):
        name, script, arguments = item
        command = [sys.executable, '-B', str(HERE / script), *arguments]
        process = subprocess.run(command, text=True, capture_output=True)
        (retained / (script + '.stdout.txt')).write_text(process.stdout)
        (retained / (script + '.stderr.txt')).write_text(process.stderr)
        report_path = root / 'audit' / name
        report = read(report_path) if report_path.exists() else {}
        complete = report.get('audit_complete', report.get('next_component_audit_pass', False))
        passed = process.returncode == 0 and complete is True and not report.get('runtime_proof_failures') and not report.get('pending_areas')
        return {'auditor': script, 'report': str(report_path), 'exit_code': process.returncode, 'audit_pass': passed,
                'reported_failures': report.get('runtime_proof_failures', report.get('failure'))}
    with ThreadPoolExecutor(max_workers=4) as executor:
        results = list(executor.map(execute, commands))
    if any(row['audit_pass'] and row['auditor'] == 'audit_coverage_settings_storage.py' for row in results):
        raw = (root / 'audit/settings-storage-audit.json').read_bytes()
        (root / 'audit/physical-selector-settings-storage-audit.json').write_bytes(raw)
    summary = {'run_id': run['id'], 'source': args.source, 'checkout': args.checkout,
               'audit_pass': all(row['audit_pass'] for row in results), 'components': results}
    for source in HERE.glob('*.py'):
        (retained / source.name).write_bytes(source.read_bytes())
    (retained / 'adapter-provenance.json').write_bytes((HERE / 'adapter-provenance.json').read_bytes())
    (retained / 'component-execution-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))
    return 0 if summary['audit_pass'] else 1


if __name__ == '__main__':
    raise SystemExit(main())

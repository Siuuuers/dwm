from pathlib import Path
import hashlib,json,re,subprocess,xml.etree.ElementTree as ET,zipfile
ROOT=Path('/workspace/scratch/e58f796fe7a3');R=ROOT/'hold-red2';REPO=ROOT/'dwm'
S='95a514919ddd4abf44dbb26362e9d91e1ec0cdc0';OLD='cdd08426e5d7f43aa2ad43caa508ab0d353018f6';F='tests/integration/test_dialogic_timed_hold_runtime.gd'
def ident(p):
 b=p.read_bytes();return {'path':str(p.relative_to(ROOT)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def git(*a):return subprocess.check_output(['git',*a],cwd=REPO)
def functions(s):
 parts=re.split(r'(?m)^func (\w+)\(',s);return {parts[i]:parts[i+1] for i in range(1,len(parts),2)}
run=json.loads((R/'run.json').read_text());jobs=json.loads((R/'jobs.json').read_text());m=json.loads((R/'artifact-manifest.json').read_text())[0];api=json.loads((R/'artifacts-api.json').read_text())
assert run['id']==37092157492 and run['conclusion']=='failure' and run['run_attempt']==1 and run['head_sha']=='b7fcb3eb8007bce202426390770e2f7381d2d489'
assert jobs['total_count']==1 and len(jobs['jobs'])==1 and jobs['jobs'][0]['id']==111114589404 and jobs['jobs'][0]['conclusion']=='failure'
assert json.loads((R/'omissions.json').read_text())=={}
assert api['total_count']==1 and api['artifacts'][0]['id']==m['id']==11263081186
archive=Path(m['local_zip']);raw=archive.read_bytes();assert len(raw)==m['size_in_bytes']==20324 and 'sha256:'+hashlib.sha256(raw).hexdigest()==m['digest']==api['artifacts'][0]['digest']
p=R/'artifacts'/m['name']
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 members=[i for i in z.infolist()if not i.is_dir()];assert len(members)==5
 assert all((p/i.filename).read_bytes()==z.read(i)for i in members)
job=(R/'logs/111114589404.log').read_text();log=(p/'phase2r_logs/cloud-timed-hold-fixture.log').read_text();imp=(p/'ci/import.log').read_text()
assert S in job and 'HEAD is now at 95a5149' in job and 'Godot Engine v4.6.3.stable.official.7d41c59c4' in log
xml=ET.parse(p/'ci/timed-hold-fixture.xml').getroot();cases=xml.findall('.//testcase');source=git('show',S+':'+F).decode();before=git('show',OLD+':'+F).decode()
names=re.findall(r'^func (test_\w+)\(',source,re.M)
assert len(cases)==len(names)==4 and [c.attrib['name']for c in cases]==names
assert [c.attrib['status']for c in cases]==['pass','fail','fail','fail']
assert len(xml.findall('.//failure'))==3 and not xml.findall('.//error')and not xml.findall('.//skipped')
assert sum(int(c.attrib['assertions'])for c in cases)==134 and xml.find('testsuite').attrib['failures']=='13'
primary=log.split('= Run Summary')[0];assert primary.count('[Failed]')==13
chunks=re.split(r'(?m)^\* (test_\w+)\n',primary);fails={chunks[i]:chunks[i+1].count('[Failed]')for i in range(1,len(chunks),2)};assert list(fails.values())==[0,3,5,5]
assert not re.search(r'SCRIPT ERROR:|(?:^|\s)ERROR:|Parse Error:|Unicode parsing error|Unexpected NUL character|ObjectDB instances leaked|Resource[s]? still in use',log,re.M)
assert 'ObjectDB instances leaked'not in imp and job.count('WARNING: ObjectDB instances leaked at exit')==1
assert not re.search(r'SCRIPT ERROR:|(?:^|\s)ERROR:|Parse Error:|Unicode parsing error|Unexpected NUL character',imp,re.M)
summary=json.loads((p/'ci/timed-hold-fixture-result.json').read_text(encoding='utf-8-sig'));assert summary['actual_cases']==4 and summary['failures']==3 and summary['errors']==0 and summary['engine_exit']==1
obs={}
for k in ['REPLACEMENT','PAUSE','DEFERRED']:
 v=re.findall(r'^TIMED_HOLD_'+k+r'_OBSERVATION (.+)$',log,re.M);assert len(v)==1;obs[k.lower()]=json.loads(v[0])
a=obs['replacement'];assert a['old_event_instance_id']!=a['replacement_event_instance_id'] and a['observed_msec']-a['first_started_msec']==2276 and a['observed_msec']-a['replacement_started_msec']==1392 and a['event_finishes']==a['semantic_completions']==0
b=obs['pause'];assert b['elapsed_before_pause']==0.2511 and b['elapsed_after_resume']>2 and b['semantic_completions']==1
c=obs['deferred'];assert c['observed_msec']-c['cancellations'][0]['at_msec']==2281 and c['observed_msec']-c['replacement_started_msec']==1403 and c['semantic_completions']==1
assert git('diff','--name-only',OLD,S).decode().splitlines()==[F]
f1,f2=functions(before),functions(source);changed=[k for k in f1 if f1[k]!=f2[k]];assert changed==[names[1]]
assert 'assert_same(replacement, old_event'not in f2[names[1]] and 'first_locator' in f2[names[1]]
assert 'assert_same(replacement, event)'in f2[names[3]] # deliberately retained Timeline proves this reuse
wait=git('show',S+':addons/dialogic/Modules/Wait/event_wait.gd');assert wait==git('show',OLD+':addons/dialogic/Modules/Wait/event_wait.gd')
result={'status':'verified_intended_red_baseline_ready_for_fixed_runtime_comparison',
 'run':{'id':run['id'],'attempt':1,'workflow_head':run['head_sha'],'actual_checkout':S,'job_id':111114589404,'conclusion':'failure','engine':'4.6.3.stable.official.7d41c59c4'},
 'source_boundary':{'red1_source':OLD,'only_changed_path':F,'only_changed_function':changed[0],'test_sha256':hashlib.sha256(source.encode()).hexdigest(),'unchanged_wait_sha256':hashlib.sha256(wait).hexdigest(),'runtime_changed':False,'local_engine_or_powershell_execution':False},
 'artifact':{'id':m['id'],'name':m['name'],'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'zip_crc':'pass','all_5_extracted_members_byte_equal':True},
 'census':{'scripts':1,'cases':4,'passed_cases':1,'failed_cases':3,'errors':0,'skips':0,'assertions':134,'failed_assertions':13,'failed_assertions_by_case':fails,'xml_note':'GUT suite failures=13 is assertion count; testcase failure elements=3.'},
 'findings':[
 {'case':names[0],'status':'positive_control_pass','meaning':'Native Wait/Return produces one natural completion; zero native text_started/simple History.'},
 {'case':names[1],'status':'real_stale_callback_failure','meaning':'Same locator and newer generation are proved; distinct actual Wait IDs are recorded without requiring equality. At old+2276ms/new+1392ms old callback stops replacement animation, increments interruption count2→3 and sets IDLE instead of ANIMATING. Cursor/generation, zero premature completion, and later replacement-owned natural completion remain valid.','red1_fixture_error_removed':True},
 {'case':names[2],'status':'real_pause_failure','meaning':'Same native Tween consumes .2511→2.00646666666666s while native paused. Runtime becomes IDLE; timeline end stays zero until Resume, then one completion occurs before the early remaining-duration observation. No production Pause-controller claim.'},
 {'case':names[3],'status':'real_deferred_cancellation_failure','meaning':'Native event_handled cancellation leaves null timeline, but retired deferred body creates live tween and WAITING state. Same retained Wait resource is genuinely observed here. At old+2281ms/new+1403ms old timer has prematurely completed the replacement once and advanced native end count1→2.'}],
 'observations':obs,
 'diagnostics':{'fixture_log_unexpected_error_or_lifetime':[],'import_process_console_warning':'One ObjectDB instances leaked at exit warning in job console after import; absent from import.log artifact and fixture log. No warning-free/leak-free import acceptance.','source_assumption_failures_remaining':False,'profile_limit':'Native fixture Profile baseline is empty; this is not initialized durable Profile-byte proof.'},
 'decision':'The corrected fixture reproduces the intended three baseline failure cases. Adopt the bounded fix for independent focused cloud verification; preserve both red runs and their distinct source boundaries.',
 'inputs':[ident(R/q)for q in ['run.json','jobs.json','artifacts-api.json','artifact-manifest.json','omissions.json','logs/111114589404.log']]+[ident(p/i.filename)for i in members]}
out=ROOT/'hold-contract-review/red2-evidence-review.json';out.write_text(json.dumps(result,indent=2)+'\n');print(out);print(hashlib.sha256(out.read_bytes()).hexdigest())

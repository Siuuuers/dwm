# Timed-hold red2 diagnostic evidence

Run 37092157492, attempt 1, is intentionally retained as **failure**: one
positive control and three failing test cases, with no XML errors or skips.
GUT reports 13 failed assertions, not that many failed cases.

Corrected test-only baseline reproduces the three intended native failure cases without the Red1 resource-identity assumption.

The executed checkout is `95a514919ddd4abf44dbb26362e9d91e1ec0cdc0`. The auxiliary workflow head is
`b7fcb3eb8007bce202426390770e2f7381d2d489`; its sole tree addition is `.github/workflows/timed-hold-cloud.yml`.
The native Wait implementation is the unchanged baseline. No fixed-runtime or
rendered/UI acceptance is claimed by this archive.

The package includes every captured API record, job log, the exact original
artifact ZIP, all five extracted artifact files, every published source-snapshot
file, workflow and publication records, historical generator dependencies and
independent audit scripts/reports. No in-scope captured file is excluded.
Source-context copies are bound to the executed commit, never current worktree
content. Candidate/green sources and unpublished preliminary snapshots are
explicitly outside this failed-run evidence scope.

One ObjectDB shutdown warning occurs in the import process job console, while
the import.log and fixture log artifacts do not contain it. This is not warning-
free or leak-free import acceptance. Native fixture Profile snapshots began as
empty dictionaries; they are not initialized durable Profile-byte evidence.

inventory.json lists every payload byte identity except itself. Its identity
and the complete archive identity are bound by the external package manifest.
The original auditors are preserved without rewriting their workspace paths;
rerunning them requires these captured paths and the cited repository commits.
Package construction/round-trip verification uses only Python and read-only Git.

#!/usr/bin/env python3
"""Prepare source-bound cloud-only timed-hold diagnostics; never publish or run engines.

red: one canonical Windows install/import job, one explicitly named GUT fixture.
focus: canonical public/selected Windows jobs and existing reading/Hospital render jobs,
       plus a bounded hold render job derived from Hospital's unchanged infrastructure.
broad: canonical jobs block byte-for-byte after the hold command is integrated there.
"""
from __future__ import annotations

import argparse
import ast
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

import yaml

HERE = Path(__file__).resolve().parent
HELPERS = HERE.parent / 'hospital-tools'
sys.path.insert(0, str(HELPERS))
import build_hospital_broad_workflow as broad
from build_paused_settings_f9_workflow import Source, identity, require

BASELINE = 'f08403d5e3a96fe161d4209939016090072f5ac0'
CANONICAL = '.github/workflows/windows-tests.yml'
WORKFLOW = '.github/workflows/timed-hold-cloud.yml'
BRANCH = 'codex/timed-hold-cloud-20261003'
SUITES = ('reading_delivery', 'settings', 'persistence', 'localization')
PUBLIC_COMMAND = './tools/testing/Invoke-PublicSurfaceValidation.ps1 -EmitPayloads'
LIVE_ADMISSION = 'tests/integration/test_dialogic_live_admission.gd'
OLD_RUNNER = 'tools/testing/run_hospital_reading_journey.py'


def relative(value: str, prefix: str, suffix: str) -> str:
    require(re.fullmatch(r'[A-Za-z0-9_./-]+', value) and value.startswith(prefix)
            and value.endswith(suffix) and '..' not in Path(value).parts
            and not Path(value).is_absolute(), 'Invalid repository path: ' + value)
    return value


def pin(job: dict, sha: str) -> None:
    checkouts = [step for step in job['steps'] if step.get('uses') == 'actions/checkout@v7']
    require(len(checkouts) == 1, 'Exactly one canonical checkout@v7 required')
    checkouts[0].setdefault('with', {}).update({'ref': sha, 'fetch-depth': 0})
    for step in job['steps']:
        if step.get('uses', '').startswith('actions/upload-artifact@'):
            require(step.get('if') == 'always()' and step['with'].get('include-hidden-files') is True,
                    'Evidence must always upload with hidden files')


def fixture_record(census: dict, fixture: str) -> dict:
    records = [record for suite in census['suites'].values() for record in suite['scripts']
               if record['path'] == fixture]
    require(len(records) == 1, 'One registration required for isolated hold fixture: ' + fixture)
    return records[0]


def isolated_command(fixture: str, names: list[str]) -> str:
    # Paths/methods have validated literal-only domains; no user-provided shell text.
    require(all(re.fullmatch(r'test_\w+', name) for name in names), 'Literal method names required')
    expected = ', '.join("'" + name + "'" for name in names)
    return f'''$ErrorActionPreference = 'Stop'
$fixture = '{fixture}'
$expectedNames = @({expected})
$output = Join-Path $env:GITHUB_WORKSPACE '.godot/ci'
$log = Join-Path $env:GITHUB_WORKSPACE '.godot/phase2r_logs/cloud-timed-hold-fixture.log'
$report = Join-Path $output 'timed-hold-fixture.xml'
& ./tools/testing/Invoke-IsolatedGodot.ps1 `
    -SuiteId 'cloud-timed-hold-fixture' `
    -LogName 'cloud-timed-hold-fixture.log' `
    -EvidenceLogPath '.godot/ci/timed-hold-fixture.jsonl' `
    -TimeoutSeconds 240 `
    -GodotArgs @('-s', 'res://addons/gut/gut_cmdln.gd', '-gconfig=',
        "-gtest=res://$fixture", '-gexit', '-glog=2',
        '-gjunit_xml_file=res://.godot/ci/timed-hold-fixture.xml')
$engineResult = $LASTEXITCODE
if (Test-Path -LiteralPath $log) {{ Get-Content -LiteralPath $log }}
if (-not (Test-Path -LiteralPath $report -PathType Leaf)) {{ throw 'TIMED_HOLD_JUNIT_MISSING' }}
[xml]$xml = Get-Content -LiteralPath $report -Raw
$suites = @($xml.SelectNodes('//testsuite'))
if ($suites.Count -ne 1 -or $suites[0].GetAttribute('name') -cne $fixture) {{
    throw 'TIMED_HOLD_EXACT_SCRIPT_REQUIRED'
}}
$cases = @($suites[0].SelectNodes('./testcase'))
$actualNames = @($cases | ForEach-Object {{ $_.GetAttribute('name') }})
$actualNameKey = ($actualNames | Sort-Object) -join "`n"
$expectedNameKey = ($expectedNames | Sort-Object) -join "`n"
if ($actualNameKey -cne $expectedNameKey) {{
    throw 'TIMED_HOLD_EXACT_NAMED_CASE_MULTISET_REQUIRED'
}}
foreach ($case in $cases) {{
    if ($case.GetAttribute('classname') -cne $fixture) {{ throw 'TIMED_HOLD_CASE_CLASS_MISMATCH' }}
}}
if ($xml.SelectNodes('//skipped').Count -ne 0 -or
    @($cases | Where-Object {{ $_.GetAttribute('status') -in @('skip','skipped','disabled') }}).Count -ne 0) {{
    throw 'TIMED_HOLD_SKIPPED_CASE_FORBIDDEN'
}}
$summary = [ordered]@{{fixture=$fixture; expected_cases=$expectedNames.Count; actual_cases=$cases.Count;
    failures=$xml.SelectNodes('//failure').Count; errors=$xml.SelectNodes('//error').Count;
    engine_exit=$engineResult; names=$actualNames}}
$summary | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $output 'timed-hold-fixture-result.json') -Encoding utf8
Write-Host ('TIMED_HOLD_FIXTURE_RESULT ' + ($summary | ConvertTo-Json -Depth 4 -Compress))
if (Select-String -LiteralPath $log -Pattern 'SCRIPT ERROR:|(?:^|\\s)ERROR:|Unicode parsing error|Unexpected NUL character|Parse Error:|ObjectDB instances leaked|Resources still in use' -Quiet) {{
    throw 'TIMED_HOLD_UNEXPECTED_RUNTIME_DIAGNOSTIC'
}}
if ($engineResult -ne 0) {{ exit $engineResult }}
if ($xml.SelectNodes('//failure | //error').Count -ne 0) {{ throw 'TIMED_HOLD_GUT_FAILURE' }}
'''


def build(args: argparse.Namespace) -> tuple[bytes, dict]:
    require(re.fullmatch(r'codex/[A-Za-z0-9][A-Za-z0-9_/-]*', args.branch)
            and '//' not in args.branch and not args.branch.endswith('/'), 'Explicit codex branch required')
    source = Source(args.repo, args.source, args.baseline)
    canonical_raw = source.read(CANONICAL)
    canonical = broad.parse(canonical_raw)
    require(canonical['permissions'] == {'contents': 'read'}, 'Canonical read-only permission required')
    require(canonical['jobs']['focused-tests']['strategy']['matrix'].keys() == {'suite'},
            'Canonical matrix changed')
    fixture = relative(args.fixture, 'tests/', '.gd')
    selected = tuple(args.suites)
    require(set(selected).issubset(canonical['jobs']['focused-tests']['strategy']['matrix']['suite']),
            'Selected canonical suite is absent')
    changed = source.changed_fixtures()
    # Red directly names the isolated fixture and requires no premature canonical
    # registration. Green focus must register it and the shared lifecycle suite.
    if args.stage == 'red':
        fixture_raw = source.read(fixture)
        declarations = broad.gdscript_declarations(fixture_raw)
        require(re.findall(r'^extends\s+(.+?)\s*$', declarations, re.M) == ['GutTest'],
                'Isolated red fixture must directly extend GutTest; other ancestry needs review')
        names = re.findall(r'^func (test_\w+)\(', declarations, re.M)
        require(names and len(names) == len(set(names)), 'Unique static red test methods required')
        fixture_data = {'path': fixture, **identity(fixture_raw),
                        'static_test_names': names, 'static_case_count': len(names),
                        'ancestry': [fixture, 'addons/gut/test.gd']}
        gut_root = broad.gdscript_declarations(source.read('addons/gut/test.gd'))
        require(re.search(r'^extends Node\s*$', gut_root, re.M)
                and re.search(r'^class_name GutTest\s*$', gut_root, re.M)
                and not re.search(r'^func test_\w+\(', gut_root, re.M),
                'GUT root ancestry changed')
        census = {'executed_suites': ['timed-hold-fixture'], 'predicted_case_executions': len(names),
                  'predicted_script_executions': 1, 'registration_required_before_green': [fixture, LIVE_ADMISSION]}
    else:
        affected = tuple(dict.fromkeys((fixture, LIVE_ADMISSION, *changed)))
        census = broad.inherited_suite_census(source, selected, affected)
        fixture_data = fixture_record(census, fixture)
    runner = None
    driver = None
    if args.stage != 'red':
        require(args.render_runner and args.render_driver, 'Focused/broad mode needs explicit hold runner and driver')
        runner = relative(args.render_runner, 'tools/testing/', '.py')
        driver = relative(args.render_driver, 'tests/', '.gd')
        ast.parse(source.read(runner), filename=runner)
        source.read(driver)
    source.read('tools/testing/Invoke-IsolatedGodot.ps1')
    changes = subprocess.check_output(['git', '-C', str(source.repo), 'diff', '--name-only',
                                      '--diff-filter=ACMRT', '-z', args.baseline, args.source]).decode().split('\0')
    for path in sorted(set(changes) - {''}): source.read(path)
    derivation = {}
    if args.stage == 'broad':
        require(not args.regenerate_public, 'Broad gate must validate committed inventories')
        require(sum(step.get('run', '').strip() == 'python3 ' + runner
                    for job in canonical['jobs'].values() for step in job.get('steps', [])) == 1,
                'Broad requires exactly one hold runner already registered in canonical workflow')
        pieces = broad.sections(canonical_raw)
        replacements = {
            'name': b'name: Timed hold complete canonical candidate\n\n',
            'on': ('on:\n  push:\n    branches: [' + args.branch + ']\n\n').encode(),
            'concurrency': b'concurrency:\n  group: timed-hold-${{ github.ref }}\n  cancel-in-progress: true\n\n',
        }
        raw = b''.join(replacements.get(key, value) for key, value in pieces.items())
        workflow = broad.parse(raw)
        require(workflow['jobs'] == canonical['jobs'] and broad.sections(raw)['jobs'] == pieces['jobs'],
                'Broad canonical jobs must be byte-identical')
        selected = tuple(canonical['jobs']['focused-tests']['strategy']['matrix']['suite'])
        census = broad.inherited_suite_census(source, selected, tuple(dict.fromkeys((fixture, LIVE_ADMISSION, *changed))))
        derivation = {'jobs_byte_identical': True, 'jobs_block': identity(pieces['jobs']),
                      'checkout': 'Actual workflow head; never a source pin',
                      'job_census': broad.job_census(workflow['jobs'])}
    else:
        workflow = {'name': 'Timed hold ' + args.stage + ' candidate',
                    'on': {'push': {'branches': [args.branch]}},
                    'permissions': {'contents': 'read'},
                    'concurrency': {'group': 'timed-hold-${{ github.ref }}', 'cancel-in-progress': True},
                    'jobs': {}}
        jobs = workflow['jobs']
        if args.stage == 'red':
            job = deepcopy(canonical['jobs']['focused-tests'])
            job.pop('needs')
            job.pop('strategy')
            job['name'] = 'Windows / timed hold isolated fixture'
            test_steps = [step for step in job['steps'] if step.get('run', '').strip() == './tools/testing/Invoke-CloudTests.ps1 -Suite $env:DWM_CI_SUITE']
            require(len(test_steps) == 1, 'Exact canonical focused command required')
            test_steps[0]['name'] = 'Run native timed hold fixture with strict named census'
            test_steps[0].pop('env')
            test_steps[0]['run'] = isolated_command(fixture, fixture_data['static_test_names'])
            for step in job['steps']:
                if step.get('uses') == 'actions/upload-artifact@v4':
                    step['with']['name'] = 'timed-hold-fixture-${{ github.run_id }}-${{ github.run_attempt }}'
            jobs['timed-hold-fixture'] = job
            derivation = {'expected_xml': 1, 'expected_scripts': 1,
                          'expected_cases': fixture_data['static_case_count'],
                          'failure_policy': 'Expected regression stays a failed job; no tolerance, retry masking, or continue-on-error.',
                          'public_gate': 'Not run in isolated red diagnostic; required for focused/broad acceptance.'}
        else:
            for name in ('public-surfaces', 'focused-tests', 'rendered-journeys', 'rendered-hospital-reading'):
                jobs[name] = deepcopy(canonical['jobs'][name])
            jobs['focused-tests']['strategy']['matrix']['suite'] = list(selected)
            if args.regenerate_public:
                matches = [step for step in jobs['public-surfaces']['steps'] if step.get('run', '').strip() == PUBLIC_COMMAND]
                require(len(matches) == 1, 'Canonical read-only public command required')
                matches[0]['run'] = './tools/testing/Invoke-PublicSurfaceValidation.ps1 -Regenerate -EmitPayloads'
            hold = deepcopy(canonical['jobs']['rendered-hospital-reading'])
            hold['name'] = 'Rendered captionless timed hold / Pause and cancellation'
            artifact_root = '.godot/ci/timed-hold/'
            hold['env'].update({
                'XDG_DATA_HOME': '${{ github.workspace }}/.godot/phase2r_tests/cloud-timed-hold-import/data',
                'DWM_TEST_ROOT': '${{ github.workspace }}/.godot/phase2r_tests/cloud-timed-hold-import/test-root',
                'DWM_RENDER_OUTPUT': '${{ github.workspace }}/' + artifact_root.rstrip('/'),
            })
            matches = [step for step in hold['steps'] if step.get('run', '').strip() == 'python3 ' + OLD_RUNNER]
            require(len(matches) == 1, 'One canonical Hospital command required as derivation seam')
            matches[0].update({'name': 'Exercise captionless native hold Pause and cancellation', 'run': 'python3 ' + runner})
            uploads = [step for step in hold['steps'] if step.get('with', {}).get('path') == '.godot/ci/hospital-reading/']
            require(len(uploads) == 1, 'One canonical Hospital evidence upload required')
            uploads[0]['name'] = 'Upload timed hold raw traces, process logs, reports and captures'
            uploads[0]['with'].update({'name': 'timed-hold-${{ github.run_id }}-${{ github.run_attempt }}', 'path': artifact_root})
            jobs['rendered-timed-hold'] = hold
            derivation = {'expected_xml': len(selected) + 1,
                          'ordinary_and_public_cases': census['predicted_case_executions'],
                          'job_count': len(selected) + 4,
                          'existing_render_commands_retained': [
                              'python3 tools/testing/run_cloud_journeys.py',
                              'python3 tools/testing/run_reading_rail_journey.py',
                              'python3 tools/testing/run_solo_authored_selector_journey.py',
                              'python3 tools/testing/run_hospital_reading_journey.py'],
                          'new_hold_command': 'python3 ' + runner, 'artifact_root': artifact_root,
                          'existing_canonical_job_commands_unchanged_except_explicit_inventory_regeneration': True}
        for job in jobs.values(): pin(job, args.source)
        raw = yaml.safe_dump(workflow, sort_keys=False, width=120).encode()
        require(broad.parse(raw) == workflow, 'Workflow must roundtrip with exact on/boolean semantics')
    require('${{ matrix.' not in raw.decode() if args.stage == 'red' else True,
            'Isolated red job must contain no unresolved matrix references')
    for job in workflow['jobs'].values():
        require('continue-on-error' not in job, 'No job failure tolerance allowed')
        require(not any(step.get('continue-on-error') for step in job.get('steps', [])),
                'No step failure tolerance allowed')
    manifest = {'schema_version': 1, 'stage': args.stage, 'source_commit': args.source,
                'source_tree': subprocess.check_output(['git', '-C', str(source.repo), 'rev-parse', args.source + '^{tree}'], text=True).strip(),
                'accepted_baseline': args.baseline, 'trigger_branch': args.branch,
                'workflow_repository_path': WORKFLOW, 'workflow_sha256': hashlib.sha256(raw).hexdigest(),
                'canonical_workflow': {'path': CANONICAL, **identity(canonical_raw)},
                'hold_fixture': fixture_data, 'shared_lifecycle_fixture': LIVE_ADMISSION,
                'changed_fixtures': list(changed), 'suite_census': census,
                'public_regeneration': args.regenerate_public, 'derivation': derivation,
                'source_file_identities': source.inventory,
                'helpers': [{'path': str(path), **identity(path.read_bytes())} for path in (
                    Path(__file__), Path(broad.__file__), HELPERS / 'build_paused_settings_f9_workflow.py',
                    HELPERS / 'build_layout_workflow.py')],
                'limits': [
                    'Static derivation/census only; no Godot or PowerShell execution occurred locally.',
                    'Red failure must be attributable to named intended behavior, not import, missing fixture, timeout, or lifetime errors.',
                    'Focused jobs check out source_commit; broad jobs check out actual workflow head. Bind logs and artifact identities accordingly.',
                    'Publish workflow as auxiliary commit with source ancestry; verify actual parent order and sole allowed workflow tree difference.',
                    'Rendered runner needs independent semantic audit; naming a runner is not evidence of Pause/cancellation correctness.',
                    'No production duration, no-Sylvia production registration, durable timer cursor, or arbitrary mid-hold Save/Load acceptance.',
                    'Existing Run131 is prior checkpoint regression evidence, never acceptance for this later hold source.',
                ]}
    return raw, manifest


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo', type=Path, default=HERE.parent / 'dwm')
    p.add_argument('--source', required=True)
    p.add_argument('--baseline', default=BASELINE)
    p.add_argument('--branch', default=BRANCH)
    p.add_argument('--stage', choices=('red', 'focus', 'broad'), required=True)
    p.add_argument('--fixture', required=True)
    p.add_argument('--suites', nargs='+', default=list(SUITES))
    p.add_argument('--render-runner')
    p.add_argument('--render-driver')
    p.add_argument('--regenerate-public', action='store_true')
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    require(not args.regenerate_public or args.stage == 'focus', 'Only focused mode permits explicit inventory regeneration')
    raw, manifest = build(args)
    outputs = ((args.output, raw), (args.output.with_name(args.output.name + '.manifest.json'),
                 (json.dumps(manifest, indent=2, ensure_ascii=False) + '\n').encode()))
    for path, data in outputs:
        require(not path.exists() or path.read_bytes() == data, 'Refuse differing retained output: ' + str(path))
    for path, data in outputs:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    print(json.dumps({'workflow': str(args.output.resolve()), 'manifest': str(outputs[1][0].resolve()),
                      'source': args.source, 'stage': args.stage, 'sha256': manifest['workflow_sha256'],
                      'derivation': manifest['derivation']}, indent=2))


if __name__ == '__main__': main()

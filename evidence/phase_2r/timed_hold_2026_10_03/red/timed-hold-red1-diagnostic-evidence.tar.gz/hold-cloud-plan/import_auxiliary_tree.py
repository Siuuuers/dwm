#!/usr/bin/env python3
"""Verify an auxiliary workflow tree against its exact source with an isolated index."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--repo', type=Path, required=True)
p.add_argument('--publication', type=Path, required=True)
p.add_argument('--workflow', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
m = json.loads(a.publication.read_text())
raw = a.workflow.read_bytes()
expected = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
assert expected == m['blob'], 'Workflow blob differs from published identity'
env = dict(os.environ)
def git(*args, input=None):
    return subprocess.check_output(['git', '-C', str(a.repo), *args], env=env, input=input).decode().strip()
with tempfile.TemporaryDirectory(prefix='hold-auxiliary-') as tmp:
    env['GIT_INDEX_FILE'] = str(Path(tmp) / 'index')
    git('read-tree', m['source'])
    assert git('hash-object', '-w', '--stdin', input=raw) == expected
    git('update-index', '--add', '--cacheinfo', '100644', expected, '.github/workflows/timed-hold-cloud.yml')
    actual = git('write-tree', '--missing-ok')
    assert actual == m['tree'], 'Auxiliary tree differs outside exact workflow addition'
    changes = git('diff-tree', '--no-commit-id', '--name-status', '-r', m['source'] + '^{tree}', actual)
    assert changes == 'A\t.github/workflows/timed-hold-cloud.yml', changes
record = {'source':m['source'], 'workflow_head':m.get('workflow', m.get('workflow_commit')), 'verified_tree':actual,
          'workflow_blob':expected, 'workflow_sha256':hashlib.sha256(raw).hexdigest(),
          'sole_tree_change':changes, 'real_index_refs_worktree_changed':False}
a.output.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))

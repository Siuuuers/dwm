# Timed-hold red1 diagnostic evidence

Run 37091802987, attempt 1, is intentionally retained as **failure**: one
positive control and three failing test cases, with no XML errors or skips.
GUT reports 14 failed assertions, not that many failed cases.

Includes an invalid same-resource assumption alongside observed native defects; Red2 corrects only that assertion boundary.

The executed checkout is `cdd08426e5d7f43aa2ad43caa508ab0d353018f6`. The auxiliary workflow head is
`ab49046d36679b1cca6f4c40766a7ff501ed9b21`; its sole tree addition is `.github/workflows/timed-hold-cloud.yml`.
The native Wait implementation is the unchanged baseline. No fixed-runtime or
rendered/UI acceptance is claimed by this archive.

The package includes every captured API record, job log, the exact original
artifact ZIP, all five extracted artifact files, every published source-snapshot
file, workflow and publication records, historical generator dependencies and
independent audit scripts/reports. No in-scope captured file is excluded.
Source-context copies are bound to the executed commit, never current worktree
content. Candidate/green sources and unpublished preliminary snapshots are
explicitly outside this failed-run evidence scope.

One ObjectDB shutdown warning occurs in the import process job console, while
the import.log and fixture log artifacts do not contain it. This is not warning-
free or leak-free import acceptance. Native fixture Profile snapshots began as
empty dictionaries; they are not initialized durable Profile-byte evidence.

inventory.json lists every payload byte identity except itself. Its identity
and the complete archive identity are bound by the external package manifest.
The original auditors are preserved without rewriting their workspace paths;
rerunning them requires these captured paths and the cited repository commits.
Package construction/round-trip verification uses only Python and read-only Git.

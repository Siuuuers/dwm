from pathlib import Path
import hashlib,json,re,subprocess,xml.etree.ElementTree as ET,zipfile
ROOT=Path('/workspace/scratch/e58f796fe7a3')
R=ROOT/'hold-red1'; REPO=ROOT/'dwm'; OUT=ROOT/'hold-contract-review/red1-evidence-review.json'
SOURCE='cdd08426e5d7f43aa2ad43caa508ab0d353018f6'; BASE='f08403d5e3a96fe161d4209939016090072f5ac0'
def ident(p):
 b=p.read_bytes();return {'path':str(p.relative_to(ROOT)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
run=json.loads((R/'run.json').read_text());jobs=json.loads((R/'jobs.json').read_text());meta=json.loads((R/'artifact-manifest.json').read_text())[0]
assert run['id']==37091802987 and run['conclusion']=='failure' and run['run_attempt']==1
assert jobs['total_count']==1 and jobs['jobs'][0]['id']==111113526600 and jobs['jobs'][0]['conclusion']=='failure'
assert json.loads((R/'omissions.json').read_text())=={}
folder=R/'artifacts'/meta['name']; archive=Path(meta['local_zip']); raw=archive.read_bytes()
assert len(raw)==meta['size_in_bytes']==20397 and 'sha256:'+hashlib.sha256(raw).hexdigest()==meta['digest']
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 members=[i for i in z.infolist() if not i.is_dir()]
 assert len(members)==5
 assert all((folder/i.filename).read_bytes()==z.read(i) for i in members)
joblog=(R/'logs/111113526600.log').read_text();log=(folder/'phase2r_logs/cloud-timed-hold-fixture.log').read_text();imp=(folder/'ci/import.log').read_text()
assert SOURCE in joblog and "HEAD is now at cdd08426" in joblog
assert 'Godot Engine v4.6.3.stable.official.7d41c59c4' in log
xml=ET.parse(folder/'ci/timed-hold-fixture.xml').getroot();cases=xml.findall('.//testcase')
source=git('show',SOURCE+':tests/integration/test_dialogic_timed_hold_runtime.gd')
expected=re.findall(r'^func (test_\w+)\(',source.decode(),re.M)
assert len(cases)==len(expected)==4 and [c.attrib['name'] for c in cases]==expected
assert len(xml.findall('.//failure'))==3 and len(xml.findall('.//error'))==0 and not xml.findall('.//skipped')
assert sum(int(c.attrib['assertions']) for c in cases)==133
assert xml.find('testsuite').attrib['failures']=='14'
# GUT repeats failures in its summary; primary sections give unique assertion count.
primary=log.split('= Run Summary')[0]
assert primary.count('[Failed]')==14
assert not re.search(r'SCRIPT ERROR:|(?:^|\s)ERROR:|Parse Error:|Unicode parsing error|Unexpected NUL character|ObjectDB instances leaked|Resource[s]? still in use',log,re.M)
assert imp.count('WARNING: ObjectDB instances leaked at exit')==0
assert joblog.count('WARNING: ObjectDB instances leaked at exit')==1
assert not re.search(r'SCRIPT ERROR:|(?:^|\s)ERROR:|Parse Error:|Unicode parsing error|Unexpected NUL character',imp,re.M)
observations={}
for kind in ['REPLACEMENT','PAUSE','DEFERRED']:
 found=re.findall(r'^TIMED_HOLD_'+kind+r'_OBSERVATION (.+)$',log,re.M);assert len(found)==1
 observations[kind.lower()]=json.loads(found[0])
a=observations['replacement'];assert a['observed_msec']-a['first_started_msec']==2252 and a['observed_msec']-a['replacement_started_msec']==1380 and a['event_finishes']==a['semantic_completions']==0
b=observations['pause'];assert b['elapsed_before_pause']==0.2553 and b['elapsed_after_resume']>2 and b['semantic_completions']==1
c=observations['deferred'];assert c['observed_msec']-c['cancellations'][0]['at_msec']==2261 and c['observed_msec']-c['replacement_started_msec']==1394 and c['semantic_completions']==1
changed=git('diff','--name-only',BASE,SOURCE).decode().splitlines();assert changed==['tests/fixtures/dialogic/timed_hold_runtime.dtl','tests/integration/test_dialogic_timed_hold_runtime.gd']
wait=git('show',SOURCE+':addons/dialogic/Modules/Wait/event_wait.gd');assert wait==git('show',BASE+':addons/dialogic/Modules/Wait/event_wait.gd')
result={
 'status':'verified_diagnostic_failure_not_acceptance','run':{'id':run['id'],'attempt':1,'workflow_head':run['head_sha'],'actual_checkout':SOURCE,'job_id':111113526600,'conclusion':'failure','engine':'4.6.3.stable.official.7d41c59c4'},
 'source':{'baseline':BASE,'changed_paths':changed,'test_sha256':hashlib.sha256(source).hexdigest(),'unchanged_wait_sha256':hashlib.sha256(wait).hexdigest(),'engines_executed_by_this_audit':False},
 'artifact':{'id':meta['id'],'name':meta['name'],'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'original_zip_crc':'pass','all_5_extracted_members_byte_equal':True},
 'census':{'scripts':1,'cases':4,'passed_cases':1,'failed_cases':3,'error_elements':0,'skipped_cases':0,'assertions':133,'failed_assertions':14,'caution':'GUT suite failures=14 counts assertion failures; XML has three failing testcase elements and preserves only each case first failure.'},
 'cases':[
 {'name':expected[0],'status':'pass','meaning':'Ordinary two-second native Wait ends once through the actual native Return and fake completion recorder; no native text_started or simple History. This is a positive control, not production Hold/Pause acceptance.'},
 {'name':expected[1],'status':'failure_mixed_fixture_assumption_and_real_defect','failed_assertions':4,'fixture_error':'Same path and label did not guarantee same resource instance: old/new Wait IDs differ. This assertion is invalid and must be corrected without changing runtime.','observed_defect':'At old+2252ms/new+1380ms, old callback stopped replacement animation, increased interruptions 2 to 3 and changed state ANIMATING(2) to IDLE(0). Replacement cursor/generation and zero completion stayed intact; its own later timer produced exactly one completion.','excluded_claim':'This case does not prove cached-resource premature completion; resource reuse was not observed.'},
 {'name':expected[2],'status':'real_pause_defect','failed_assertions':5,'observed_defect':'Same native Tween advanced from 0.2553s to 2.00646666666666s while Dialogic.paused. Wait current state became IDLE before resume. Native timeline end stayed zero while paused, then one completion occurred before early 0.35s post-resume observation.','qualification':'Direct Adapter/native pause, not the full production Pause controller.'},
 {'name':expected[3],'status':'real_pending_cancellation_defect','failed_assertions':5,'observed_defect':'After actual native event_handled cancellation and null current timeline, retired deferred body set WAITING and left a live tween. The intentionally retained Timeline yielded the same Wait resource on restart. At old+2261ms/new+1394ms the retired timer prematurely completed replacement once; native end count increased 1 to 2.','qualification':'Native dispatch window and retained-resource reuse are observed; no synthetic event_finished or timeline-end signals were emitted.'}],
 'observations':observations,
 'diagnostics':{'fixture_log_script_error_or_lifetime_findings':[],'import_process_console_warning':'Exactly one WARNING: ObjectDB instances leaked at exit appears in the job console after import. The import.log artifact and actual fixture log do not contain that warning. Import had no scanned script/parse/structured-error diagnostic. This run is not warning-free or leak-free.','fixture_cleanup':'All exact layout-retirement assertions passed. Profile snapshot comparisons were empty-dictionary baselines, so they do not prove initialized durable Profile bytes; separate rendered proof is required.'},
 'next_required':'Preserve Red1. Repeat baseline with only invalid resource-identity assumption corrected; then compare independently with fixed-runtime focused proof.',
 'inputs':[ident(R/p) for p in ['run.json','jobs.json','artifact-manifest.json','omissions.json','logs/111113526600.log']]+[ident(folder/i.filename) for i in members]
}
OUT.write_text(json.dumps(result,indent=2)+'\n');print(OUT);print(hashlib.sha256(OUT.read_bytes()).hexdigest())

#!/usr/bin/env python3
"""Package one fully audited successful capture without inferring semantic acceptance."""
from __future__ import annotations
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import tarfile
import zipfile

LIMIT=8*1024*1024
EXPORT_REASON='Original export artifact ZIP and its nested distributable are intentionally excluded from repository storage; exact verified identities, bounded raw logs/receipts and transport reassembly receipt are retained. Actions expiry may remove binary availability.'
LIMITS=[
 'Packaging does not create runtime, whole-game, release or PR test-merge acceptance.',
 'Captionless hold evidence uses an authorized noncanonical fixture duration; no production-authored duration is established.',
 'No durable mid-hold save/restore cursor, canonical no-Sylvia Hospital completion or production timeline registration is established.',
 'No native hardware-input, OS accessibility-tree, screen-reader or audible speech-quality acceptance.',
 'Windows export scope is unsigned cloud export, packaged data and isolated headless startup; known ObjectDB exporter warning remains an explicit unresolved lifetime exclusion.',
 'No fixed performance threshold, universal speedup, physical-disk or input-to-paint guarantee.',
 'Original Windows export binaries and transport wrapper/chunk bytes remain outside repository storage; exact identities are not permanent binary archival.',
]

def require(value,label):
 if not value:raise ValueError(label)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def ident(path):
 with path.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return {'bytes':path.stat().st_size,'sha256':h}
def read(path):
 def pairs(items):
  d={}
  for k,v in items:require(k not in d,'duplicate JSON key '+k);d[k]=v
  return d
 return json.loads(path.read_text(encoding='utf-8-sig'),object_pairs_hook=pairs,
                   parse_constant=lambda v:(_ for _ in ()).throw(ValueError('nonfinite JSON '+v)))
def json_bytes(value):return (json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode()
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args])
def safe(name):return bool(name) and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts and '\\' not in name and '\x00' not in name

def pointer(value,path):
 require(path.startswith('/'),'JSON pointer required')
 for part in path[1:].split('/'):
  key=part.replace('~1','/').replace('~0','~')
  value=value[int(key)] if isinstance(value,list) else value[key]
 return value


def package(config_path,out):
 cfg=read(config_path)
 require(cfg.get('audits_complete') is True,'Refuse package before parent declares all bounded audits complete')
 require(cfg.get('audit_bindings'),'Explicit independent audit bindings required')
 require(not out.exists(),'Refuse existing stage directory')
 base=Path(cfg['workspace_root']).resolve();repo=base/cfg['repo'];capture=base/cfg['capture_root']
 source=cfg['source'];head=cfg['workflow_head'];actual=cfg['actual_checkout'];run_id=cfg['run_id'];attempt=cfg['run_attempt']
 require(all(re.fullmatch('[0-9a-f]{40}',x) for x in (source,head,actual)),'exact source, workflow head and actual checkout SHAs')
 require(type(run_id) is int and run_id>0 and type(attempt) is int and attempt>0,'exact positive run/attempt')
 audits=[]
 for binding in cfg['audit_bindings']:
  path=base/binding['path'];doc=read(path)
  require(binding.get('assertions'),'Explicit audit JSON assertions required')
  for assertion in binding['assertions']:
   observed=pointer(doc,assertion['pointer']);expected=assertion['equals']
   require(type(observed) is type(expected) and observed==expected,'audit assertion '+binding['path']+assertion['pointer'])
  if binding.get('sha256'):require(ident(path)['sha256']==binding['sha256'],'audit exact expected hash')
  audits.append({'path':binding['path'],'assertions':binding['assertions'],**ident(path)})
 run=read(capture/'run.json');jobsdoc=read(capture/'jobs.json');jobs=jobsdoc['jobs'];api_doc=read(capture/'artifacts-api.json');apis=api_doc['artifacts'];downloads=read(capture/'artifact-manifest.json')
 require((run['id'],run['head_sha'],run['run_attempt'],run['status'],run['conclusion'])==(run_id,head,attempt,'completed','success'),'successful exact completed run required')
 require(jobsdoc['total_count']==len(jobs) and len({j['id'] for j in jobs})==len(jobs),'complete unique jobs')
 require({j['name'] for j in jobs}==set(cfg['expected_job_names']) and len(jobs)==len(cfg['expected_job_names']),'exact intended job set')
 require(all((j['run_id'],j['head_sha'],j['run_attempt'],j['status'],j['conclusion'])==(run_id,head,attempt,'completed','success') for j in jobs),'every exact job succeeded')
 require(api_doc['total_count']==len(apis)==len(downloads),'complete artifact census')
 require(read(capture/'omissions.json')=={},'no captured artifact/log omissions')
 require({p.name for p in (capture/'logs').iterdir() if p.is_file()}=={str(j['id'])+'.log' for j in jobs},'all and only actual job logs')
 checkout_exempt=cfg.get('checkout_free_jobs',[]);require(set(checkout_exempt)<=set(cfg['expected_job_names']),'known checkout-free jobs only')
 checkout_rows={}
 for j in jobs:
  text=(capture/'logs'/f"{j['id']}.log").read_text(encoding='utf-8-sig')
  lines=[re.sub(r'^\d{4}-\S+\s+','',re.sub(r'\x1b\[[0-9;]*m','',x)).strip() for x in text.splitlines()]
  values=[lines[i+1] for i,x in enumerate(lines[:-1]) if 'log -1 --format=%H' in x]
  require(values==([] if j['name'] in checkout_exempt else [actual]),'exact actual checkout for '+j['name'])
  checkout_rows[str(j['id'])]=values
 workflow_path=cfg['workflow_path'];diff=git(repo,'diff','--name-status',source,head).decode().strip()
 require(diff=='A\t'+workflow_path,'sole source/workflow-head tree change is auxiliary workflow')
 require(actual in (source,head),'actual checkout must be exact runtime source or workflow-only descendant')
 out.mkdir(parents=True);payload=out/'payload';payload.mkdir();records=[];exclusions=[]
 def write(dest,data,kind,origin):
  require(safe(dest),'safe package member');p=payload/dest;require(not p.exists(),'unique package member '+dest);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
  records.append({'archive_path':dest,'source':origin,'kind':kind,'bytes':len(data),'sha256':sha(data)})
 def copy(path,dest,kind):
  require(path.is_file() and not path.is_symlink(),'regular input required '+str(path));write(dest,path.read_bytes(),kind,str(path))
 for p in sorted(capture.rglob('*')):
  if p.is_file() and p.relative_to(capture).parts[0]!='artifacts':copy(p,'capture/'+p.relative_to(capture).as_posix(),'complete_capture_record')
 apimap={x['id']:x for x in apis};require(len(apimap)==len(apis) and set(apimap)=={x['id'] for x in downloads},'unique exact original artifacts')
 artifacts=[];extracted=[];represented=set();member_hashes={};export_seen=False
 for row in sorted(downloads,key=lambda x:x['id']):
  api=apimap[row['id']];require(all(api[k]==row[k] for k in ('id','name','digest','size_in_bytes','workflow_run')),'API/download join')
  require(api['workflow_run']['id']==run_id and api['workflow_run']['head_sha']==head,'artifact source run')
  zpath=Path(row['local_zip']);identity=ident(zpath);require(identity=={'bytes':api['size_in_bytes'],'sha256':api['digest'].removeprefix('sha256:')},'exact original ZIP API bytes')
  exported=row['name']==f'windows-export-{run_id}-{attempt}';dest=f"original-artifacts/{row['id']}-{row['name']}.zip"
  folder=capture/'artifacts'/row['name'];member_rows=[];names=set();nested_export=None
  if exported:
   require(not export_seen,'one Windows export artifact');export_seen=True
   require(cfg.get('export_transport_receipt') and cfg.get('export_audit'),'export transport receipt and bounded export audit required')
   transport=read(base/cfg['export_transport_receipt']);audit=read(base/cfg['export_audit'])
   require(transport['original_artifact']['id']==row['id'] and transport['ordered_reassembly_verified'] and transport['all_chunks_verified'] and transport['zip_crc_verified'],'verified exact original export transport')
   require(transport['original_zip']['bytes']==identity['bytes'] and transport['original_zip']['sha256']==identity['sha256'],'transport original identity')
   require(audit['run_id']==run_id and audit['source']==source and audit['checkout']==actual and audit['status'] in ('pass_qualified_bounded_export_only','pass_bounded_export_only'),'exact bounded export audit')
   require(audit['exporter_lifetime_acceptance'] is False,'export lifetime remains excluded')
   validation=read(folder/'windows-export/validation.json');nested_export='windows-export/'+validation['archive']['file']
   exclusions.append({'kind':'original_export_artifact_zip','artifact_id':row['id'],'name':row['name'],**identity,'reason':EXPORT_REASON})
  else:copy(zpath,dest,'original_artifact_zip_once')
  with zipfile.ZipFile(zpath) as z:
   require(z.testzip() is None and len(z.namelist())==len(set(z.namelist())),'all original ZIP CRCs and unique member names')
   for info in z.infolist():
    require(safe(info.filename) and (info.external_attr>>16)&0o170000!=0o120000,'safe regular ZIP member')
    if info.is_dir():member_rows.append({'member':info.filename,'directory':True});continue
    p=folder/info.filename;raw=z.read(info);require(p.is_file() and not p.is_symlink() and p.read_bytes()==raw,'exact original/extracted byte join')
    rel=p.relative_to(capture).as_posix();require(rel not in represented,'member represented once');represented.add(rel);names.add(info.filename)
    entry={'capture_path':rel,'artifact_id':row['id'],'member':info.filename,'bytes':len(raw),'sha256':sha(raw),'zip_crc32':f'{info.CRC:08x}'}
    if not exported:entry.update(storage='original_zip',archive_path=dest,reproducible_from_repository=True)
    elif info.filename==nested_export:
     entry.update(storage='explicit_binary_exclusion',reproducible_from_repository=False,reason=EXPORT_REASON);exclusions.append(dict(entry))
    else:
     require(Path(info.filename).suffix in ('.json','.txt','.log'),'unclassified export member requires explicit review')
     kept='export-records/'+info.filename;write(kept,raw,'bounded_export_raw_record',rel);entry.update(storage='direct_export_record',archive_path=kept,reproducible_from_repository=True)
    extracted.append(entry);member_rows.append(entry);member_hashes.setdefault((len(raw),sha(raw)),[]).append(entry)
  require(names=={p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file()},'complete extraction member set')
  artifacts.append({'id':row['id'],'name':row['name'],**identity,'original_zip_included':not exported,'archive_path':None if exported else dest,'members':member_rows,'all_original_crc_and_extracted_bytes_verified':True})
 require(represented=={p.relative_to(capture).as_posix() for p in (capture/'artifacts').rglob('*') if p.is_file()},'all extracted files represented with storage policy')
 require(export_seen==bool(cfg.get('expects_export')),'explicit expected export presence')
 # Source snapshots and full object identities are distinct from workflow-head/actual checkout.
 paths=sorted(set(git(repo,'diff','--name-only',cfg['accepted_baseline'],source).decode().splitlines()+cfg.get('source_context_paths',[])))
 for path in paths:write('source-context/'+path,git(repo,'show',source+':'+path),'frozen_source',source+':'+path)
 write('workflow/published.yml',git(repo,'show',head+':'+workflow_path),'published_workflow',head+':'+workflow_path)
 for ref,name in ((source,'source'),(head,'workflow-head')):
  write('provenance/'+name+'.commit.txt',git(repo,'cat-file','commit',ref),'git_commit',ref)
  write('provenance/'+name+'.tree.txt',git(repo,'ls-tree','-r',ref),'complete_git_tree_identity_inventory',ref)
 provenance={'runtime_source':source,'workflow_head':head,'actual_checkout':actual,'source_tree':git(repo,'rev-parse',source+'^{tree}').decode().strip(),'workflow_tree':git(repo,'rev-parse',head+'^{tree}').decode().strip(),'ordered_workflow_parents':git(repo,'show','-s','--format=%P',head).decode().strip().split(),'actual_checkout_by_job':checkout_rows,'auxiliary_workflow_only_difference':workflow_path,'source_context_paths':paths}
 write('provenance/source-workflow-checkout.json',json_bytes(provenance),'source_provenance','exact Git objects and actual checkout logs')
 support=set(cfg.get('support_files',[]))|{a['path'] for a in audits}
 if export_seen:support|={cfg['export_transport_receipt'],cfg['export_audit']}
 for relative in sorted(support):
  p=base/relative;require(p.is_file() and not p.is_symlink(),'exact support file required '+relative)
  info=ident(p)
  if relative in cfg.get('support_sha256',{}):require(info['sha256']==cfg['support_sha256'][relative],'frozen support identity '+relative)
  matches=member_hashes.get((info['bytes'],info['sha256']),[])
  if matches:
   exclusions.append({'kind':'duplicate_support_artifact_copy','path':relative,**info,'original_member_representations':matches,'reason':'Exact bytes already inventoried through their original artifact storage policy; no duplicate copy.'})
  else:
   require(p.suffix.lower() not in ('.zip','.part','.gz') and re.search(r'\.part\d+$',p.name) is None,'raw archive/transport wrappers are not supplementary audit records')
   copy(p,'support/'+relative,'independent_audit_or_provenance')
 write('packaging-config.json',config_path.read_bytes(),'exact_packaging_configuration',str(config_path))
 write('stage_audited_capture.py',Path(__file__).read_bytes(),'packaging_helper',str(Path(__file__).resolve()))
 extraction={'artifacts':artifacts,'extracted_files':extracted,'capture_file_count':len(extracted),'all_captured_files_represented':True,'binary_exclusions_explicit':True,'original_zip_storage_once':True,'limits':LIMITS}
 write('extraction-inventory.json',json_bytes(extraction),'complete_extraction_inventory','all original ZIP members')
 receipt={'status':'AUDITED_SUCCESSFUL_CAPTURE_PACKAGED_NOT_NEW_ACCEPTANCE','source':source,'workflow_head':head,'actual_checkout':actual,'run_id':run_id,'run_attempt':attempt,'job_count':len(jobs),'artifact_count':len(artifacts),'original_zips_retained':sum(a['original_zip_included'] for a in artifacts),'parent_audit_bindings':audits,'exclusions':exclusions,'capture_omissions':{},'runtime_acceptance_inferred':False,'limits':LIMITS}
 write('bounded-packaging-receipt.json',json_bytes(receipt),'bounded_packaging_receipt','verified capture plus explicit parent audit assertions')
 inventory={'files':records,'self_identity_recorded_in_external_manifest':True};(payload/'archive-inventory.json').write_bytes(json_bytes(inventory))
 archive=out/(cfg['label']+'-evidence.tar.gz');files=sorted(p for p in payload.rglob('*') if p.is_file())
 with archive.open('wb') as output,gzip.GzipFile(fileobj=output,filename='',mode='wb',mtime=0,compresslevel=9) as gz,tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as tar:
  for p in files:
   info=tarfile.TarInfo(p.relative_to(payload).as_posix());info.size=p.stat().st_size;info.mode=0o644;info.mtime=0
   with p.open('rb') as f:tar.addfile(info,f)
 with tarfile.open(archive,'r:gz') as tar:
  require(tar.getnames()==[p.relative_to(payload).as_posix() for p in files],'exact archive membership')
  for p in files:require(hashlib.file_digest(tar.extractfile(p.relative_to(payload).as_posix()),'sha256').hexdigest()==ident(p)['sha256'],'every archive payload roundtrip')
 archive_id=ident(archive);parts=[]
 if archive_id['bytes']>LIMIT:
  with archive.open('rb') as f:
   offset=0
   while data:=f.read(LIMIT):
    index=len(parts)+1;name=archive.name+f'.part{index:03d}';(out/name).write_bytes(data);parts.append({'file':name,'index':index,'offset':offset,'bytes':len(data),'sha256':sha(data)});offset+=len(data)
  combined=hashlib.sha256();count=0
  for part in parts:
   require(part['offset']==count,'ordered part offsets');raw=(out/part['file']).read_bytes();combined.update(raw);count+=len(raw)
  require({'bytes':count,'sha256':combined.hexdigest()}==archive_id,'exact ordered raw-part reassembly')
 manifest={'status':receipt['status'],'label':cfg['label'],'run_id':run_id,'source':source,'workflow_head':head,'actual_checkout':actual,'archive':{'file':archive.name,**archive_id},'archive_members':len(files),'archive_inventory':ident(payload/'archive-inventory.json'),'extraction_inventory':ident(payload/'extraction-inventory.json'),'parts':parts,'part_size_limit':LIMIT,'archive_roundtrip_and_ordered_parts_verified':True,'excluded_export_original_zip':export_seen,'limits':LIMITS}
 (out/'package-manifest.json').write_bytes(json_bytes(manifest))
 for name in ('archive-inventory.json','extraction-inventory.json','bounded-packaging-receipt.json'):shutil.copyfile(payload/name,out/name)
 delivery=[p['file'] for p in parts] if parts else [archive.name]
 delivery+=['package-manifest.json','archive-inventory.json','extraction-inventory.json','bounded-packaging-receipt.json']
 (out/'adoption-inventory.json').write_bytes(json_bytes({'status':'SCRATCH_ONLY_NOT_ADOPTED','label':cfg['label'],'files':[{'file':name,**ident(out/name)} for name in delivery],'unsplit_archive_excluded_when_parts_used':bool(parts),'expanded_payload_excluded':True,'original_export_binary_and_transport_chunks_excluded':export_seen,'runtime_acceptance_inferred':False}))
 print(json.dumps({'stage':str(out),'run_id':run_id,'archive':manifest['archive'],'delivery_parts':len(parts),'retained_original_zips':receipt['original_zips_retained'],'excluded_export':export_seen,'runtime_acceptance_inferred':False}))

if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--config',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args();package(args.config.resolve(),args.output.resolve())

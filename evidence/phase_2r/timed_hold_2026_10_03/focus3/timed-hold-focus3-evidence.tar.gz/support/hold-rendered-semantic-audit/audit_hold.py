#!/usr/bin/env python3
"""Independent, read-only audit of the noncanonical rendered native hold proof.

Does not import its runner or execute Godot/PowerShell. ZIP/API bytes, source
blobs, traces and observations are checked separately from runner verdicts.
Visual review is recorded separately after opening all three raw PNGs.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import re
import struct
import subprocess
import zlib
import zipfile


SOURCE = "75d129b1c8a79f7cb11dc0d5de75a02ea55f8965"
JOB = "Rendered captionless timed hold / Pause and fresh-input continuation"
SILENT = ["hold", "after_inert_inputs", "paused", "paused_after_deadline", "resumed"]
STAGES = SILENT + ["caption_held", "caption_released", "completed"]
SOURCES = [
    "tools/testing/run_timed_hold_journey.py", "tools/testing/run_cloud_journeys.py",
    "tests/fixtures/dialogic/timed_hold_journey.dtl", "tests/integration/verify_timed_hold_journey.gd",
    "addons/dialogic/Modules/Wait/event_wait.gd", "scripts/narrative/DialogicRuntimeAdapter.gd",
    "scripts/ui/witnessed/WitnessedCaptionLayer.gd",
]
FORBIDDEN = re.compile(r"SCRIPT ERROR:|(?m:^\s*ERROR:)|STARTUP_FAILED|Unicode parsing error|Unexpected NUL|"
                       r"ObjectDB instances leaked|Leaked instance:|Resource still in use:|Orphan StringName:|"
                       r"resources still in use at exit|TIMED_HOLD_JOURNEY_FAIL:", re.I)
CHECKS: list[str] = []


def check(value: object, detail: str) -> None:
    if not value:
        raise ValueError(detail)
    CHECKS.append(detail)


def identity(raw: bytes) -> dict:
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def parse(raw: bytes | str) -> dict:
    def pairs(values):
        result = {}
        for key, value in values:
            if key in result:
                raise ValueError("duplicate JSON member: " + key)
            result[key] = value
        return result
    def finite(text):
        result = float(text)
        if not math.isfinite(result):
            raise ValueError("nonfinite JSON number")
        return result
    def constant(text):
        raise ValueError("nonfinite JSON constant: " + text)
    result = json.loads(raw, object_pairs_hook=pairs, parse_float=finite, parse_constant=constant)
    if not isinstance(result, dict):
        raise ValueError("JSON object required")
    return result


def read(path: Path) -> dict:
    return parse(path.read_bytes())


def png(raw: bytes) -> dict:
    check(raw[:8] == b"\x89PNG\r\n\x1a\n", "PNG signature")
    cursor, chunks, raster = 8, [], bytearray()
    dimensions = None
    while cursor < len(raw):
        length = struct.unpack_from(">I", raw, cursor)[0]
        kind = raw[cursor + 4:cursor + 8]
        payload = raw[cursor + 8:cursor + 8 + length]
        crc = struct.unpack_from(">I", raw, cursor + 8 + length)[0]
        check((zlib.crc32(kind + payload) & 0xffffffff) == crc, "PNG chunk CRC " + kind.decode("ascii"))
        chunks.append(kind)
        if kind == b"IHDR":
            dimensions = struct.unpack_from(">II", payload)
        if kind == b"IDAT":
            raster.extend(payload)
        cursor += 12 + length
        if kind == b"IEND":
            break
    check(cursor == len(raw) and chunks[0] == b"IHDR" and chunks[-1] == b"IEND", "PNG exact framing")
    check(dimensions == (1280, 720) and len(zlib.decompress(raster)) > 1280 * 720, "PNG full logical canvas")
    return {**identity(raw), "width": 1280, "height": 720}


def audit(args) -> dict:
    capture, repo = args.capture.resolve(), args.repo.resolve()
    diagnostic = args.early_diagnostic or args.failed_pipeline
    artifact_name = f"timed-hold-{args.run}-1"
    if args.early_diagnostic:
        manifest = json.loads((capture / "manifest.json").read_bytes())
        api_rows = [row for row in manifest if row["name"] == artifact_name]
        check(len(api_rows) == 1, "one original early-captured artifact metadata record")
        run = api_rows[0]["workflow_run"]
        job = {"id": None}
        check(run["id"] == args.run, "early artifact exact Focus run")
    else:
        run, jobs = read(capture / "run.json"), read(capture / "jobs.json")["jobs"]
        check(run["id"] == args.run and run["run_attempt"] == 1, "exact Focus run and first attempt")
        selected_jobs = [job for job in jobs if job["name"] == JOB]
        check(len(selected_jobs) == 1, "one rendered hold job")
        job = selected_jobs[0]
        check(job["conclusion"] == ("failure" if diagnostic else "success") and job["status"] == "completed"
              and job["run_id"] == args.run and job["head_sha"] == run["head_sha"] and job["run_attempt"] == 1,
              "exact rendered hold job verdict bound to workflow head and first attempt")
        api_rows = [row for row in read(capture / "artifacts-api.json")["artifacts"] if row["name"] == artifact_name]
        manifest = json.loads((capture / "artifact-manifest.json").read_bytes())
    rows = [row for row in manifest if row["name"] == artifact_name]
    check(len(api_rows) == len(rows) == 1, "one original rendered artifact in API and capture manifest")
    api, record = api_rows[0], rows[0]
    archive = Path(record["local_zip"])
    raw_zip = archive.read_bytes()
    check(identity(raw_zip) == {"bytes": api["size_in_bytes"], "sha256": api["digest"].removeprefix("sha256:")},
          "original ZIP size and SHA256 equal GitHub API identity")
    check(record["id"] == api["id"] and record["digest"] == api["digest"]
          and api["workflow_run"]["id"] == args.run and api["workflow_run"]["head_sha"] == run["head_sha"],
          "artifact is owned by exact run and head")
    if not args.early_diagnostic:
        job_log = (capture / "logs" / (str(job["id"]) + ".log")).read_text(encoding="utf-8")
        check(re.search(r"git checkout[^\n]+" + re.escape(args.checkout), job_log) is not None,
              "actual job checkout command pins exact accepted source")
        check(f"Artifact {artifact_name}.zip successfully finalized. Artifact ID {api['id']}" in job_log
              and f"Final size is {api['size_in_bytes']} bytes. Artifact ID is {api['id']}" in job_log,
              "actual job upload ID and ZIP byte count join API artifact")
        exercise = [step for step in job["steps"] if step["name"] == "Exercise captionless native hold Pause and fresh-input continuation"]
        check(len(exercise) == 1 and exercise[0]["conclusion"] == ("failure" if diagnostic else "success"),
              "specific rendered exercise step retains actual verdict")
        if diagnostic:
            check(job_log.count("TIMED_HOLD_RENDERED_FAIL: UNCHANGED_INSTALLED_COMPLETION_OWNER_REQUIRED") == 1
                  and "Process completed with exit code 1." in job_log,
                  "failed postprocessor cause and failing exit preserved in actual job log")
    artifact = capture / "artifact" if args.early_diagnostic else capture / "artifacts" / artifact_name
    with zipfile.ZipFile(archive) as zipped:
        check(zipped.testzip() is None, "original ZIP CRC check")
        members = [item for item in zipped.infolist() if not item.is_dir()]
        check(len({item.filename for item in members}) == len(members), "unique original ZIP members")
        for item in members:
            parts = PurePosixPath(item.filename).parts
            check(not item.filename.startswith("/") and ".." not in parts, "contained original ZIP member " + item.filename)
            check((artifact / item.filename).read_bytes() == zipped.read(item), "exact extracted bytes " + item.filename)
        check({str(path.relative_to(artifact)) for path in artifact.rglob("*") if path.is_file()}
              == {item.filename for item in members}, "no unarchived extracted files")
    roots = list(artifact.rglob("journey.json"))
    check(len(roots) == 1, "one complete native observation report")
    folder = roots[0].parent
    result, report = read(folder / "results.json"), read(folder / "journey.json")
    check((artifact / "results.json").read_bytes() == (folder / "results.json").read_bytes(), "outer and per-process runner receipt bytes match")
    check(result["checkout_sha"] == args.checkout, "runner exact checkout identity")
    if diagnostic:
        check(result["ok"] is False and result["failures"] == ["UNCHANGED_INSTALLED_COMPLETION_OWNER_REQUIRED"],
              "original failed runner verdict preserved; diagnostic semantics are not pipeline acceptance")
    else:
        check(result["ok"] is True and result["failures"] == [], "successful runner verdict")
    check(result["workflow"] == {"GITHUB_RUN_ID": str(args.run), "GITHUB_RUN_ATTEMPT": "1",
                                "GITHUB_JOB": "rendered-timed-hold", "GITHUB_SHA": run["head_sha"]},
          "runner exact workflow identity")
    check(set(result["source_identity"]) == set(SOURCES), "seven source identities retained")
    source_ids = {}
    for name in SOURCES:
        raw = subprocess.check_output(["git", "show", args.source + ":" + name], cwd=repo)
        source_ids[name] = identity(raw)
        check(result["source_identity"][name] == source_ids[name], "actual source equals accepted commit: " + name)
    driver = subprocess.check_output(["git", "show", args.source + ":tests/integration/verify_timed_hold_journey.gd"], cwd=repo).decode()
    check('_wait.get("_tween") == _tween' in driver and 'await _pause.request_pause()' in driver
          and 'await _pause.request_continue()' in driver and 'Input.parse_input_event(event)' in driver,
          "raw same-Tween, Pause and native input observations bound to driver source")
    fixture = subprocess.check_output(["git", "show", args.source + ":tests/fixtures/dialogic/timed_hold_journey.dtl"], cwd=repo).decode()
    expected_text = next(line.split(" #id:")[0] for line in fixture.splitlines() if "#id:fixture.timed_hold.after" in line)
    check('[wait time="2.0" hide_text="true" skippable="false"]' in fixture, "exact fixture duration and native Wait configuration")
    files = read(folder / "file-manifest.json")
    actual_files = {str(path.relative_to(folder)): identity(path.read_bytes()) for path in folder.rglob("*")
                    if path.is_file() and path.name != "file-manifest.json"}
    check(actual_files == files, "complete raw artifact file manifest independently recomputed")
    for name in ["journey.json", "profile-before.json", "profile-after-hold.json"]:
        check((folder / name).read_bytes() == (folder / ("raw-" + name)).read_bytes(), "original user evidence copy: " + name)
    process_names = ["engine-version", "user-dir-proof", "journey"]
    check(set(result["processes"]) == set(process_names), "exact three cloud process receipts")
    for name in process_names:
        process = read(folder / (name + ".process.json"))
        check(process == result["processes"][name] and process["exit_code"] == 0 and process["timed_out"] is False,
              "successful independent process receipt: " + name)
        for suffix in ["stdout.txt", "stderr.txt"]:
            content = (folder / (name + "." + suffix)).read_text(encoding="utf-8")
            check(not FORBIDDEN.search(content) and "\x00" not in content, "clean diagnostic log: " + name + "." + suffix)
    version = (folder / "engine-version.stdout.txt").read_text().strip()
    check(re.fullmatch(r"4\.6\.3\.stable\.official\.[0-9a-f]+", version) is not None
          and result["engine_version"] == version and not (folder / "engine-version.stderr.txt").read_text().strip(),
          "actual Godot 4.6.3 standard engine identity")
    for name in ["journey.log", "user-dir-proof.log"]:
        check(not FORBIDDEN.search((folder / name).read_text(encoding="utf-8")), "clean engine diagnostic log: " + name)
    check(not FORBIDDEN.search((artifact / "import.log").read_text(encoding="utf-8")), "clean artifact import diagnostics")
    stdout = (folder / "journey.stdout.txt").read_text()
    identities = re.findall(r"^TIMED_HOLD_PROCESS: (.+)$", stdout, re.M)
    check(len(identities) == 1 and parse(identities[0]) == {"process_id": report["process_id"], "user_dir": report["user_dir"]},
          "real OS process and isolated user directory join console to raw report")
    check(type(report["process_id"]) is int and report["process_id"] > 0
          and PurePosixPath(report["user_dir"]) == PurePosixPath(result["user_dir"]),
          "positive process ID and exact user directory")
    check(len(re.findall(r"^TIMED_HOLD_JOURNEY_PASS:", stdout, re.M)) == 1, "one completed native proof marker")
    proof = (folder / "user-dir-proof.stdout.txt").read_text()
    check(re.findall(r"^PHASE2R_USER_DIR=(.+)$", proof, re.M) == [report["user_dir"]], "independent engine user-directory proof")
    user = PurePosixPath(report["user_dir"])
    isolation = PurePosixPath(result["isolation_root"])
    check(user.is_absolute() and user.is_relative_to(isolation)
          and user.is_relative_to(PurePosixPath(result["isolated_environment"]["XDG_DATA_HOME"])),
          "native writes contained in fresh isolated cloud data directory")
    check(report["schema_version"] == 1 and report["hold_seconds"] == 2.0 and report["pause_seconds"] == 2.4
          and report["entry_id"] == "contact.ordinary.lavinia.day1" and report["line_id"] == "fixture.timed_hold.after",
          "bounded noncanonical fixture identities and durations")
    baseline = (folder / "profile-before.json").read_bytes()
    check(baseline == (folder / "profile-after-hold.json").read_bytes(), "exact raw Profile bytes preserved through hold and Pause")
    check(parse(baseline) == report["baseline_profile"], "baseline Profile bytes join native snapshot")
    preferences = report["baseline_profile"]["preferences"]["reading"]
    check(preferences["auto_enabled"] is True and preferences["read_aloud_enabled"] is True
          and preferences["reveal_speed"] == "slow", "positive Auto and Read Aloud preferences are enabled during hold")
    check(report["baseline_native_history"] == [] and report["baseline_native_visits"] == {}, "empty fresh native History baseline")
    states = report["stages"]
    check(set(states) == set(STAGES), "exact eight native observation stages")
    ticks = [states[name]["tick_msec"] for name in STAGES]
    check(all(type(tick) is int for tick in ticks) and ticks == sorted(ticks), "monotonic native observation order")
    owner = report["baseline_completion_owner"]
    check(type(owner["instance_id"]) is int and -(2 ** 63) <= owner["instance_id"] < 2 ** 63
          and owner["instance_id"] != 0 and owner["instance_id"] == owner["bridge_owner_id"] and owner["_status"] == "idle",
          "unchanged installed canonical completion owner baseline")
    frontier = states["hold"]["frontier"]
    check(set(frontier) == {"kind", "request_id", "generation", "event_index", "execution_token"}
          and frontier["kind"] == "timed_hold" and type(frontier["execution_token"]) is int
          and frontier["execution_token"] > 0 and frontier["request_id"] and frontier["generation"] > 0,
          "stable hold owner frontier excludes changing elapsed time")
    geometry = None
    for name in SILENT:
        state, projection = states[name], states[name]["projection"]
        check(state["frontier"] == frontier, "same Bridge hold frontier: " + name)
        native = state["native_pause_frontier"]
        check(native["ok"] is True and native["value"]["paused"] == state["native_paused"]
              and {key: value for key, value in native["value"].items() if key != "paused"} == frontier
              and state["native_timer_identity_matches"] is True, "same native timer and normalized owner frontier: " + name)
        check(projection["timed_hold"] is True and projection["caption_visible"] is False and projection["revealing"] is False
              and projection["leaf_rects"] == projection["visible_leaf_rects"] == projection["caption_window"] == []
              and projection["caption_rect"]["width"] == projection["caption_rect"]["height"] == 0,
              "absent caption presentation geometry: " + name)
        check(state["caption_text"] == "" and state["caption_focus"] is False and state["caption_visible"] is False
              and state["caption_revealing"] is False and state["retained"] == state["scrollback"] == []
              and state["background_filter"] == 2, "no hidden text/reveal/focus/activation target: " + name)
        check(state["text_counts"] == {"about": 0, "started": 0, "finished": 0}
              and state["speech_admissions"] == state["wait_finishes"] == state["native_ends"] == 0,
              "zero native publication and completion events: " + name)
        check(state["native_history"] == [] and state["native_visits"] == {}
              and all(state[key]["ok"] is False for key in ["reading_history", "reading_checkpoint", "speech_publication"])
              and state["can_save_backup"] is False and state["can_capture_reading_checkpoint"] is False,
              "History/speech/checkpoint queries remain unavailable without durable hold cursor: " + name)
        check(state["profile"] == report["baseline_profile"] and state["profile_bytes_equal"] is True
              and state["completion_owner"] == owner, "no Profile or canonical completion mutation: " + name)
        rail = state["rail"]
        check([button["key"] for button in rail] == ["history", "skip", "auto", "save", "load", "next"]
              and all(button["disabled"] is True and button["focus_mode"] == 0 and button["focused"] is False for button in rail),
              "six Disabled rail actions absent from Focus traversal: " + name)
        current_geometry = [button["rect"] for button in rail]
        if geometry is None:
            geometry = current_geometry
        check(current_geometry == geometry and all(rect["y"] >= 656 and rect["width"] > 0 and rect["height"] > 0 for rect in geometry),
              "stationary rail geometry: " + name)
    early, late, resumed = [states[name] for name in ["paused", "paused_after_deadline", "resumed"]]
    for name in ["paused", "paused_after_deadline"]:
        state = states[name]
        check(state["tree_paused"] is True and state["native_paused"] is True and state["pause_state"]["ok"] is True
              and state["pause_state"]["value"]["state"] == "Suspended" and state["can_load_backup"] is True,
              "actual production Pause custody and independent Load admission: " + name)
    freeze_msec = late["tick_msec"] - early["tick_msec"]
    check(freeze_msec >= 2300 and abs(late["elapsed_seconds"] - early["elapsed_seconds"]) < 0.000001,
          "same native timer frozen beyond its full authored 2-second duration")
    check(resumed["tree_paused"] is False and resumed["native_paused"] is False and resumed["pause_state"]["ok"] is True
          and resumed["pause_state"]["value"]["state"] == "Active" and 0 <= resumed["elapsed_seconds"] < 2
          and 0 <= resumed["elapsed_seconds"] - early["elapsed_seconds"] < 0.15,
          "actual Continue releases custody and preserves elapsed timer time")
    for name in ["caption_held", "caption_released"]:
        state = states[name]
        check(state["caption_text"] == expected_text and state["caption_visible"] is True and state["caption_focus"] is True
              and state["projection"]["timed_hold"] is False and state["text_counts"]["about"] == state["text_counts"]["started"] == 1
              and state["wait_finishes"] == 1 and state["native_ends"] == 0 and state["completion_owner"] == owner,
              "one exact real caption takes Focus; hold-era input cannot accept it: " + name)
    hold_to_caption = (states["caption_held"]["tick_msec"] - resumed["tick_msec"]) / 1000
    check(hold_to_caption >= 2.0 - resumed["elapsed_seconds"] - 0.15, "caption cannot precede native remaining duration")
    check(states["caption_released"]["speech_admissions"] == 1 and states["caption_released"]["speech_publication"]["ok"] is True,
          "positive real caption speech publication and one native admission")
    completed = states["completed"]
    check(completed["native_ends"] == completed["wait_finishes"] == completed["speech_admissions"] == 1
          and completed["text_counts"] == {"about": 1, "started": 1, "finished": 1} and completed["completion_owner"] == owner,
          "one Wait finish, caption reveal finish and native end after fresh input; canonical owner unchanged")
    events = report["events"]
    check([event["sequence"] for event in events] == list(range(1, len(events) + 1))
          and [event["tick_msec"] for event in events] == sorted(event["tick_msec"] for event in events), "contiguous monotonic raw event trace")
    check([event["value"]["name"] for event in events if event["kind"] == "stage"] == STAGES[:-1], "raw stage trace joins observation sequence")
    check({event["kind"] for event in events} == {"stage", "text_about", "text_started", "text_finished", "speech_admitted"},
          "no unexplained raw event kinds")
    for kind in ["text_about", "text_started", "text_finished", "speech_admitted"]:
        selected = [event for event in events if event["kind"] == kind]
        check(len(selected) == 1 and selected[0]["tick_msec"] >= resumed["tick_msec"], "one post-resume raw event: " + kind)
    text_events = [event for event in events if event["kind"] in ["text_about", "text_started", "text_finished"]]
    check([event["kind"] for event in text_events] == ["text_about", "text_started", "text_finished"]
          and all(event["value"]["text"] == expected_text for event in text_events), "exact public text and lifecycle order in raw events")
    captures = []
    capture_rows = result.get("captures", [])
    if diagnostic:
        capture_rows = [{"file": str(path)} for path in sorted(folder.glob("raw-*.png"))]
        check({Path(row["file"]).name for row in capture_rows} == {"raw-01-hold.png", "raw-02-pause.png", "raw-03-caption.png"},
              "all three original native screenshots retained before runner postprocessing failure")
    else:
        check({Path(row["file"]).name for row in capture_rows} == {"01-hold.png", "02-pause.png", "03-caption.png"},
              "exact three required cloud screenshots")
    for row in capture_rows:
        name = Path(row["file"]).name
        path = folder / name if diagnostic else folder / "captures" / name
        raw = path.read_bytes()
        value = png(raw)
        if not diagnostic:
            check(all(row[key] == value[key] for key in value) and raw == (folder / ("raw-" + name)).read_bytes(),
                  "raw screenshot bytes join capture receipt: " + name)
        captures.append({"path": str(path.resolve()), **value})
    check(len({row["sha256"] for row in captures}) == 3, "three distinct rendered observations")
    return {"status": "pass_raw_semantics_failed_pipeline" if diagnostic else "pass_bounded_ephemeral_hold",
            "pipeline_verdict": "failed_runner_object_id_sign_assumption" if diagnostic else "passed",
            "run_id": args.run, "run_head": run["head_sha"], "job_id": job["id"],
            "source_commit": args.source, "actual_checkout": args.checkout, "source_identity": source_ids,
            "artifact": {"id": api["id"], "name": artifact_name, **identity(raw_zip)},
            "process_id": report["process_id"], "engine_version": version, "native_frontier": frontier,
            "raw_profile_identity": identity(baseline), "freeze_msec": freeze_msec,
            "freeze_at_least_configured_2400_msec": freeze_msec >= 2400,
            "native_elapsed_before_pause": early["elapsed_seconds"], "native_elapsed_after_pause": late["elapsed_seconds"],
            "native_remaining_at_resume": 2.0 - resumed["elapsed_seconds"], "resume_to_caption_seconds": hold_to_caption,
            "screenshots": captures, "raw_event_count": len(events), "native_wait_finishes": 1, "native_ends": 1,
            "positive_caption_speech_admissions": 1,
            "scope": "Noncanonical ephemeral contact Wait; blank main-scene proxy; installed production Pause/Bridge/native timer and caption owners.",
            "exclusions": ["Production authored duration or Hospital no-Sylvia integration", "Semantic reading ledger admission",
                           "Mid-hold save/restore or durable hold cursor", "Canonical contact/Hospital completion",
                           "Native hardware input", "Audible speech quality", "OS accessibility tree or screen-reader behavior",
                           "Cancellation/replacement after old deadline (separate native regression)",
                           "Profile byte equality after explicit post-caption Auto-Off command"],
            "visual_status": "pending independent opening of all three raw screenshots"}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--capture", type=Path, required=True)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--source", default=SOURCE)
    parser.add_argument("--checkout", default=SOURCE)
    parser.add_argument("--early-diagnostic", action="store_true")
    parser.add_argument("--failed-pipeline", action="store_true")
    parser.add_argument("--run", type=int, default=37092368181)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        result = audit(args)
    except Exception as error:
        result = {"status": "fail", "error": str(error)}
    result["checks"] = CHECKS
    result["check_count"] = len(CHECKS)
    result["auditor_identity"] = identity(Path(__file__).read_bytes())
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({key: result[key] for key in ["status", "check_count"]} | ({"error": result["error"]} if "error" in result else {})))
    return 0 if result["status"].startswith("pass_") else 1


if __name__ == "__main__":
    raise SystemExit(main())

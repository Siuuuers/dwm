#!/usr/bin/env python3
"""Independent frozen repair-source/workflow audit; no generator imports or engines."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import subprocess
import re

import audit_focus1_source as independent

HERE=Path(__file__).resolve().parent
REPO=HERE.parent/'dwm'
SOURCE='abb7a3cac46ef3499fd797edd164ab8c1ac078f7'
PRIOR='058f817e587e0fc333ae66b769702d5cf0a68ebc'
AUX='d5652c4c8b9391cc57d5f5a7b1c1fc950a4db465'
PRIOR_AUX='f22f187d77190be74d60c2ad491407f3f6daef84'
BASELINE='f08403d5e3a96fe161d4209939016090072f5ac0'
CANONICAL='.github/workflows/windows-tests.yml'
WORKFLOW='.github/workflows/timed-hold-cloud.yml'
IDENTITIES={}


def identity(raw):return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])
def read(path,source=SOURCE):
    raw=git('show',source+':'+path)
    if source==SOURCE:IDENTITIES[path]=identity(raw)
    return raw


def main():
    independent.read=read
    checks={}
    def check(name,condition):
        assert condition,name
        checks[name]=True
    manifest_path=HERE/'timed-hold-focus3-repair.yml.manifest.json'
    workflow_path=HERE/'timed-hold-focus3-repair.yml'
    m=json.loads(manifest_path.read_text());raw=workflow_path.read_bytes()
    check('source_and_tree',m['source_commit']==SOURCE and m['source_tree']==git('rev-parse',SOURCE+'^{tree}').decode().strip())
    check('accepted_baseline',m['accepted_baseline']==BASELINE)
    check('workflow_identity',identity(raw)['sha256']==m['workflow_sha256'])
    for path,expected in m['source_file_identities'].items():
        check('source_identity:'+path,identity(read(path))==expected and (REPO/path).read_bytes()==read(path))
    for item in m['helpers']:
        check('helper_identity:'+item['path'],identity(Path(item['path']).read_bytes())=={k:item[k] for k in ('bytes','sha256')})
    changed=git('diff','--name-only',PRIOR,SOURCE).decode().splitlines()
    check('exact_incremental_paths',changed==['addons/dialogic/Modules/Wait/event_wait.gd',
        'tests/integration/test_dialogic_timed_hold_runtime.gd','tests/tooling/Test-InvokeIsolatedGodot.ps1',
        'tools/testing/Invoke-IsolatedGodot.ps1'])
    new_wait=read('addons/dialogic/Modules/Wait/event_wait.gd').decode()
    new_guard='if _owns_execution(token) and _active and not _finishing and is_instance_valid(_tween) and _tween.is_valid():'
    old_guard='if _owns_execution(token) and _active and not _finishing and is_instance_valid(_tween):'
    check('runtime_exact_two_validity_guards',new_wait.count(new_guard)==2 and new_wait.replace(new_guard,old_guard).encode()==read('addons/dialogic/Modules/Wait/event_wait.gd',PRIOR))
    check('other_runtime_project_bytes_unchanged',git('diff','--name-only',PRIOR,SOURCE,'--','autoload/','scripts/','scenes/','project.godot')==b'')
    old_native=read('tests/integration/test_dialogic_timed_hold_runtime.gd',PRIOR).decode()
    new_native=read('tests/integration/test_dialogic_timed_hold_runtime.gd').decode()
    check('same_ten_native_test_names',re.findall(r'^func (test_\w+)\(',old_native,re.M)==re.findall(r'^func (test_\w+)\(',new_native,re.M)
          and len(re.findall(r'^func test_\w+\(',new_native,re.M))==10)
    check('active_invalid_timer_challenge_present',all(part in new_native for part in ('killed_tween.kill()',
        'assert_false(killed_tween.is_valid()', 'assert_engine_error_count(0, "native Pause and Resume must not operate an invalid Tween")',
        'assert_same(foreign_wait._tween, killed_tween', 'assert_eq(_native_hold_state(), before')))
    harness=read('tools/testing/Invoke-IsolatedGodot.ps1').decode()
    check('exact_invalid_timer_diagnostic_gate',"if ($line.Contains('ERROR: Tween invalid.')) { $failures += ('TWEEN_INVALID: ' + $line.Trim()) }" in harness
          and 'if ($resultCode -eq 0) { $resultCode = 126 }' in harness)
    probe=read('tests/tooling/Test-InvokeIsolatedGodot.ps1').decode()
    check('negative_probe_requires_one_real_error_and_rejection',all(part in probe for part in (
        '$invalidTween.ExitCode -ne 126','$invalidTweenErrors.Count -ne 1',
        "'ERROR: Tween invalid. Either finished or created outside scene tree.'",'$invalidTweenRecord.exit_code -ne 126',
        "'ISOLATION_INVALID_TWEEN_CLEANUP: GUID root survived diagnostic rejection.'")))
    canonical_raw=read(CANONICAL);canonical=independent.parse(canonical_raw);workflow=independent.parse(raw)
    check('canonical_workflow_unchanged',canonical_raw==read(CANONICAL,PRIOR))
    wanted=deepcopy(canonical)
    jobs=('public-surfaces','focused-tests','rendered-timed-hold')
    wanted['jobs']={name:wanted['jobs'][name] for name in jobs}
    wanted['jobs']['focused-tests']['strategy']['matrix']['suite']=['reading_delivery']
    public=wanted['jobs']['public-surfaces']['steps']
    seam=[s for s in public if s.get('run','').strip()=='./tools/testing/Invoke-PublicSurfaceValidation.ps1 -EmitPayloads']
    check('one_public_regeneration_seam',len(seam)==1)
    seam[0]['run']='./tools/testing/Invoke-PublicSurfaceValidation.ps1 -Regenerate -EmitPayloads'
    check('new_negative_probe_remains_invoked',any('./tests/tooling/Test-InvokeIsolatedGodot.ps1' in s.get('run','') for s in public))
    for name,job in wanted['jobs'].items():
        steps=[s for s in job['steps'] if s.get('uses')=='actions/checkout@v7']
        check('normal_canonical_checkout:'+name,len(steps)==1 and 'ref' not in steps[0].get('with',{}))
        steps[0].setdefault('with',{}).update({'ref':SOURCE,'fetch-depth':0})
    wanted.update({'name':'Timed hold three-job repair diagnostic',
        'on':{'push':{'branches':['codex/timed-hold-focus2-20261003']}},
        'concurrency':{'group':'timed-hold-${{ github.ref }}','cancel-in-progress':True}})
    check('whole_workflow_exact_mechanical_derivation',workflow==wanted)
    check('no_hidden_error_tolerance','continue-on-error' not in str(workflow))
    selected=independent.suite_census(('public_surfaces','reading_delivery'))
    check('actual_selected_census_526_39',selected['case_executions']==526 and selected['script_executions']==39
          and selected['unique_cases']==526 and selected['unique_scripts']==39)
    for name,row in selected['suites'].items():
        record=m['suite_census']['suites'][name]
        check('named_selected_census:'+name,{path:set(names) for path,names in row['scripts'].items()}==
              {s['path']:set(s['static_test_names']) for s in record['scripts']})
    full=independent.suite_census(('public_surfaces',*canonical['jobs']['focused-tests']['strategy']['matrix']['suite']))
    check('full_census_unchanged_2472_207',(full['case_executions'],full['script_executions'],full['unique_cases'],full['unique_scripts'])==(2472,207,2468,206))
    job_names=independent.expanded_jobs(workflow['jobs']);canonical_names=independent.expanded_jobs(canonical['jobs'])
    check('three_selected_twenty_five_canonical',len(job_names)==3 and len(canonical_names)==25)
    check('diagnostic_xml_two',m['expected_ordinary_xml_count']==2 and m['job_count']==3)
    check('later_canonical_is_explicit',m['mandatory_later_canonical_gate']['job_count']==25
          and m['mandatory_later_canonical_gate']['expected_ordinary_xml_count']==13)
    for name,row in full['suites'].items():
        future=m['mandatory_later_canonical_gate']['suite_census']['suites'][name]
        check('future_named_census:'+name,{path:set(names) for path,names in row['scripts'].items()}==
              {s['path']:set(s['static_test_names']) for s in future['scripts']})
    parents=git('show','-s','--format=%P',AUX).decode().strip().split()
    check('ordered_auxiliary_parents',parents==[PRIOR_AUX,SOURCE])
    check('source_to_auxiliary_sole_workflow_path',git('diff','--name-only',SOURCE,AUX).decode().splitlines()==[WORKFLOW])
    check('actual_auxiliary_workflow_blob',git('show',AUX+':'+WORKFLOW)==raw)
    result={'status':'pass_static_frozen_repair_source_and_derivation_only','source':SOURCE,'source_tree':m['source_tree'],
        'prior_source':PRIOR,'incremental_changed_paths':changed,'workflow_head':AUX,'workflow_tree':git('rev-parse',AUX+'^{tree}').decode().strip(),
        'ordered_parents':parents,'workflow':identity(raw),'manifest':identity(manifest_path.read_bytes()),'canonical_workflow':identity(canonical_raw),
        'checks':checks,'source_identity_count':len(m['source_file_identities']),'selected_jobs':job_names,'selected_census':selected,
        'later_canonical_job_count':25,'later_canonical_census':full,'audited_source_identities':IDENTITIES,
        'auditors':{str(path):identity(path.read_bytes()) for path in (Path(__file__),Path(independent.__file__))},
        'no_engine_or_powershell_execution':True,'no_repository_or_remote_writes':True,
        'limitations':['Static source/workflow review does not establish actual cloud acceptance.',
                       'Current source intentionally carries stale prior-source inventory references; repair uses explicit regeneration.',
                       'After exact next artifact adoption, run source-reference compatibility preflight before final committed-inventory/full canonical gate.',
                       'Three repair jobs do not replace the mandatory later 25-job canonical evidence.']}
    output=HERE/'focus3-frozen-repair-source-audit.json';output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'receipt':str(output),**identity(output.read_bytes()),'checks':len(checks),'selected_cases':526,'later_canonical_cases':2472},indent=2))


if __name__=='__main__':main()

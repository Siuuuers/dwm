#!/usr/bin/env python3
"""Prepare exactly three cloud diagnostic jobs for the timed-hold repair.

Canonical public regeneration, full Reading GUT suite, and native rendered hold.
The canonical 25-job acceptance gate remains unchanged and mandatory afterward.
Reads frozen source and writes scratch workflow/manifest only. Never publishes,
changes repository files, or executes Godot/PowerShell.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

import yaml

HERE=Path(__file__).resolve().parent
HELPERS=HERE.parent/'hospital-tools'
sys.path.insert(0,str(HELPERS))
import build_hospital_broad_workflow as broad
from build_paused_settings_f9_workflow import Source,identity,require

BASELINE='f08403d5e3a96fe161d4209939016090072f5ac0'
CANONICAL='.github/workflows/windows-tests.yml'
WORKFLOW='.github/workflows/timed-hold-cloud.yml'
BRANCH='codex/timed-hold-focus3-20261003'
JOBS=('public-surfaces','focused-tests','rendered-timed-hold')
PUBLIC='./tools/testing/Invoke-PublicSurfaceValidation.ps1 -EmitPayloads'
REGENERATE='./tools/testing/Invoke-PublicSurfaceValidation.ps1 -Regenerate -EmitPayloads'
FIXTURES=('tests/integration/test_dialogic_timed_hold_runtime.gd',
          'tests/integration/test_dialogic_live_admission.gd',
          'tests/unit/test_witnessed_timed_hold.gd',
          'tests/integration/test_narrative_pause_frontier.gd')
RUNNER='tools/testing/run_timed_hold_journey.py'
DRIVER='tests/integration/verify_timed_hold_journey.gd'


def derive(canonical_raw:bytes,source_sha:str,branch:str)->dict:
    require(re.fullmatch(r'[0-9a-f]{40}',source_sha),'Exact source SHA required')
    require(re.fullmatch(r'codex/[A-Za-z0-9][A-Za-z0-9_/-]*',branch)
            and '//' not in branch and not branch.endswith('/'),'Explicit codex auxiliary branch required')
    canonical=broad.parse(canonical_raw)
    require(canonical['permissions']=={'contents':'read'},'Read-only canonical permissions required')
    jobs={name:deepcopy(canonical['jobs'][name]) for name in JOBS}
    public=[step for step in jobs['public-surfaces']['steps'] if step.get('run','').strip()==PUBLIC]
    require(len(public)==1,'One canonical public validation command required')
    require(not any('-Regenerate' in step.get('run','') for step in jobs['public-surfaces']['steps']),
            'Canonical source must retain read-only inventory validation')
    public[0]['run']=REGENERATE
    ordinary=jobs['focused-tests']
    require(ordinary['needs']=='public-surfaces' and set(ordinary['strategy']['matrix'])=={'suite'}
            and 'reading_delivery' in ordinary['strategy']['matrix']['suite'],'Canonical Reading matrix/dependency required')
    ordinary['strategy']['matrix']['suite']=['reading_delivery']
    hold=jobs['rendered-timed-hold']
    require(hold['needs']=='public-surfaces' and hold['runs-on']=='ubuntu-24.04','Canonical rendered hold infrastructure required')
    require(sum(step.get('run','').strip()=='python3 '+RUNNER for step in hold['steps'])==1,
            'One complete canonical rendered hold command required')
    for name,job in jobs.items():
        checkout=[step for step in job['steps'] if step.get('uses')=='actions/checkout@v7']
        require(len(checkout)==1 and 'ref' not in checkout[0].get('with',{}),'Normal unpinned canonical checkout required: '+name)
        checkout[0].setdefault('with',{}).update({'ref':source_sha,'fetch-depth':0})
        require('continue-on-error' not in job and not any(step.get('continue-on-error') for step in job['steps']),
                'No diagnostic failure tolerance allowed')
        for step in job['steps']:
            if step.get('uses','').startswith('actions/upload-artifact@'):
                require(step.get('if')=='always()' and step['with'].get('include-hidden-files') is True,
                        'All raw evidence uploads must remain always/hidden')
        # Independently reverse the only declared mechanical modifications.
        restored=deepcopy(job)
        for index,step in enumerate(restored['steps']):
            if step.get('uses')=='actions/checkout@v7':
                restored['steps'][index]=deepcopy(canonical['jobs'][name]['steps'][index])
            elif step.get('run','').strip()==REGENERATE:
                restored['steps'][index]['run']=PUBLIC
        if name=='focused-tests':restored['strategy']=deepcopy(canonical['jobs'][name]['strategy'])
        require(restored==canonical['jobs'][name],'No undeclared canonical job alteration: '+name)
    return {'name':'Timed hold three-job repair diagnostic',
            'on':{'push':{'branches':[branch]}},'permissions':{'contents':'read'},
            'concurrency':{'group':'timed-hold-${{ github.ref }}','cancel-in-progress':True},'jobs':jobs}


def build(repo:Path,sha:str,baseline:str,branch:str)->tuple[bytes,dict]:
    source=Source(repo,sha,baseline)
    canonical_raw=source.read(CANONICAL)
    canonical=broad.parse(canonical_raw)
    workflow=derive(canonical_raw,sha,branch)
    changed_fixtures=source.changed_fixtures()
    affected=tuple(dict.fromkeys((*FIXTURES,*changed_fixtures)))
    selected=broad.inherited_suite_census(source,('reading_delivery',),affected)
    changed=subprocess.check_output(['git','-C',str(source.repo),'diff','--name-only','--diff-filter=ACMRT','-z',baseline,sha]).decode().split('\0')
    for path in sorted(set(changed)-{''}):source.read(path)
    for path in (RUNNER,DRIVER,'tools/testing/run_cloud_journeys.py','tools/testing/start_cloud_speech.sh',
                 'tools/evidence/print_user_dir.gd','tools/testing/Invoke-IsolatedGodot.ps1',
                 'tests/fixtures/dialogic/timed_hold_journey.dtl'):
        source.read(path)
    canonical_suites=tuple(canonical['jobs']['focused-tests']['strategy']['matrix']['suite'])
    later_census=broad.inherited_suite_census(source,canonical_suites,affected)
    canonical_jobs=broad.job_census(canonical['jobs'])
    require(canonical_jobs['job_count']==25,'Expected unchanged complete canonical 25-job gate')
    raw=yaml.safe_dump(workflow,sort_keys=False,width=120).encode()
    require(broad.parse(raw)==workflow,'Strict workflow YAML roundtrip')
    manifest={'schema_version':1,'stage':'repair_diagnostic','source_commit':sha,
              'source_tree':subprocess.check_output(['git','-C',str(source.repo),'rev-parse',sha+'^{tree}'],text=True).strip(),
              'accepted_baseline':baseline,'trigger_branch':branch,'workflow_repository_path':WORKFLOW,
              'workflow_sha256':hashlib.sha256(raw).hexdigest(),'canonical_workflow':{'path':CANONICAL,**identity(canonical_raw)},
              'job_definition_count':3,'job_count':3,'expected_ordinary_xml_count':2,
              'focused_suites':['reading_delivery'],'public_regeneration':True,'all_selected_jobs_required':True,
              'canonical_job_ids':list(JOBS),'suite_census':selected,
              'changed_fixtures':list(changed_fixtures),'source_file_identities':source.inventory,
              'canonical_job_content_verification':'Only exact source pin/fetch depth, Reading-only matrix and explicit public regeneration differ from full canonical job objects.',
              'diagnostic_exclusions':['Other eleven Windows ordinary suites','Existing original Solo/F5/F9/full-journey/selector/Hospital rendered jobs',
                                      'Export, performance, retained-history producer/comparisons/aggregate and remaining desktop/UI renders'],
              'mandatory_later_canonical_gate':{'jobs_byte_unchanged_in_source':True,'job_count':canonical_jobs['job_count'],
                    'expected_ordinary_xml_count':len(canonical_suites)+1,'suite_census':later_census,
                    'source_inventory_adoption_and_read_only_validation_required':True,
                    'note':'This census is future coverage, never executions claimed by the three-job diagnostic.'},
              'publication_contract':{'checkout':'Each selected job checks out exact source_commit; workflow head remains distinct.',
                    'source_to_workflow_allowed_tree_diff':[WORKFLOW],'ordered_parents':['Observed previous auxiliary head',sha]},
              'helpers':[{'path':str(path),**identity(path.read_bytes())} for path in
                         (Path(__file__),Path(broad.__file__),HELPERS/'build_paused_settings_f9_workflow.py',HELPERS/'build_layout_workflow.py')],
              'limits':['No engine or PowerShell was run by this scratch-only derivation; no repository or remote mutation occurred.',
                        'Every selected job and exact named case must actually pass; no hidden tolerance or skipped mandatory job is accepted.',
                        'Public regeneration must be reviewed/adopted from exact cloud payloads after all current source/test edits are frozen.',
                        'Check adopted inventories against any later changed scanner input before the read-only full gate.',
                        'Previous Focus1/Focus2 successes/failures remain diagnostic history, not acceptance for this source.',
                        'The complete canonical 25-job workflow remains required after this repair gate.']}
    return raw,manifest


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=HERE.parent/'dwm')
    p.add_argument('--source',required=True)
    p.add_argument('--baseline',default=BASELINE)
    p.add_argument('--branch',default=BRANCH)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();raw,m=build(args.repo,args.source,args.baseline,args.branch)
    outputs=((args.output,raw),(args.output.with_name(args.output.name+'.manifest.json'),(json.dumps(m,indent=2)+'\n').encode()))
    for path,data in outputs:require(not path.exists() or path.read_bytes()==data,'Refuse differing retained output: '+str(path))
    for path,data in outputs:path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
    print(json.dumps({'workflow':str(args.output.resolve()),'manifest':str(outputs[1][0].resolve()),
                      'source':args.source,'workflow_sha256':m['workflow_sha256'],'diagnostic_jobs':3,'diagnostic_xml':2,
                      'diagnostic_cases':m['suite_census']['predicted_case_executions'],
                      'mandatory_later_jobs':25,'mandatory_later_cases':m['mandatory_later_canonical_gate']['suite_census']['predicted_case_executions']},indent=2))


if __name__=='__main__':main()

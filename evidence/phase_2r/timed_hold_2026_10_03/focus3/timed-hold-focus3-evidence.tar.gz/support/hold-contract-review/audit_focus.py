#!/usr/bin/env python3
"""Independent focused evidence audit; consumes captured bytes only, never engines/PS.

Always writes a diagnostic report on missing/failed evidence. A nonzero exit means
this exact captured run is not accepted. Rendered semantic/visual audits remain
separate; successful jobs and GUT tests cannot substitute for those proofs.
"""
from __future__ import annotations
import argparse
from collections import Counter
import datetime as dt
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
from types import SimpleNamespace
import xml.etree.ElementTree as ET
import yaml

SOURCE='75d129b1c8a79f7cb11dc0d5de75a02ea55f8965'
WORKFLOW='e91e0b50bd5e8720a3c40d48d02dbd3439dd04ef'
PRIOR_AUX='b7fcb3eb8007bce202426390770e2f7381d2d489'
TARGETS={'tests/integration/test_dialogic_timed_hold_runtime.gd':10,
         'tests/unit/test_witnessed_timed_hold.gd':4,
         'tests/integration/test_dialogic_live_admission.gd':21}
GUT_SUITES=['public_surfaces','reading_delivery','settings','persistence','localization']
ERROR=re.compile(r'SCRIPT ERROR:|(?:^|\s)ERROR:|Parse Error:|Unicode parsing error|Unexpected NUL character|ObjectDB instances leaked|Resource[s]? still in use|Leaked instance:|Orphan StringName:',re.I)
INVALID_TWEEN='ERROR: Tween invalid. Either finished or created outside scene tree.'

def require(value,message):
    if not value: raise ValueError(message)

def digest(raw):return hashlib.sha256(raw).hexdigest()
def identity(p):return {'bytes':p.stat().st_size,'sha256':digest(p.read_bytes())}
def read(p):
    def pairs(items):
        out={}
        for key,value in items:
            require(key not in out,'duplicate JSON key '+key);out[key]=value
        return out
    return json.loads(p.read_text(encoding='utf-8-sig'),object_pairs_hook=pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError('nonfinite JSON '+value)))
def write(p,value):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo',type=Path,default=Path('/workspace/scratch/e58f796fe7a3/dwm'))
    parser.add_argument('--run-root',type=Path,default=Path('/workspace/scratch/e58f796fe7a3/hold-focus1'))
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--prepare-only',action='store_true')
    parser.add_argument('--source',default=SOURCE)
    parser.add_argument('--workflow-head',default=WORKFLOW)
    parser.add_argument('--prior-aux',default=PRIOR_AUX)
    parser.add_argument('--run-id',type=int,default=37092368181)
    parser.add_argument('--mode',choices=['full8','repair3'],default='full8')
    args=parser.parse_args()
    repair=args.mode=='repair3'
    job_count=3 if repair else 8
    gut_suites=['public_surfaces','reading_delivery']if repair else GUT_SUITES
    helper=Path(__file__).resolve().parents[1]/'hospital-tools/cloud_evidence.py'
    spec=importlib.util.spec_from_file_location('hold_cloud_evidence',helper)
    cloud=importlib.util.module_from_spec(spec);spec.loader.exec_module(cloud)
    result={'schema_version':3,'status':'diagnostic_incomplete','mode':args.mode,'source':args.source,
            'actual_checkout':args.source,'expected_run_id':args.run_id,
            'workflow_head':args.workflow_head,'local_engine_or_powershell_execution':False,
            'auditor':identity(Path(__file__)),'cloud_helper':identity(helper),'checks':{},'failures':[],
            'limits':['Rendered journeys, Hospital and timed-hold semantic/visual acceptance require separate audits.',
                      'No production duration, no-Sylvia Hospital implementation, semantic hold ledger or durable timer cursor.',
                      'Import warnings remain separately reported; no global warning-free or leak-free claim.']}
    def git(*a):return subprocess.check_output(['git','-C',str(args.repo),*a])
    def attempt(name,fn):
        try:
            value=fn();result['checks'][name]={'status':'pass','value':value};return value
        except Exception as exc:
            result['checks'][name]={'status':'failure','error':str(exc)};result['failures'].append(name+': '+str(exc));return None
    def source_check():
        require(re.fullmatch('[0-9a-f]{40}',args.source) is not None,'exact source SHA required')
        boundary=cloud.source_boundary(SimpleNamespace(repo=args.repo,source=args.source,checkout=args.workflow_head,
                      master=None,allow_source_diff=['.github/workflows/timed-hold-cloud.yml']))
        require(boundary['checkout_parents']==[args.prior_aux,args.source],'ordered workflow parents mismatch')
        require([d['path']for d in boundary['source_checkout_differences']]==['.github/workflows/timed-hold-cloud.yml'],
                'only auxiliary workflow may differ from source')
        workflow_raw=git('show',args.workflow_head+':.github/workflows/timed-hold-cloud.yml')
        w=yaml.safe_load(workflow_raw)
        names=[]
        for job in w['jobs'].values():
            refs=[s.get('with',{}).get('ref')for s in job['steps']if s.get('uses','').startswith('actions/checkout@')]
            require(refs==[args.source],'all focused jobs must check out actual source')
            matrix=job.get('strategy',{}).get('matrix',{}).get('suite')
            names.extend([job['name'].replace('${{ matrix.suite }}',x)for x in matrix]if matrix else [job['name']])
        require(len(names)==job_count and len(set(names))==job_count,'exact focused job count required: '+str(job_count))
        if repair:
            require(set(names)=={'Windows / public API surface contracts','Windows / reading_delivery',
                    'Rendered captionless timed hold / Pause and fresh-input continuation'},'exact repair job names required')
        targets={}
        for path,count in TARGETS.items():
            raw=git('show',args.source+':'+path);text=raw.decode()
            require(re.search(r'^extends GutTest\s*$',text,re.M) is not None,'unexpected inherited target fixture')
            tests=re.findall(r'^func (test_\w+)\(',text,re.M)
            require(len(tests)==len(set(tests))==count,'source target case count mismatch: '+path)
            targets[path]={'names':tests,'count':count,'source_identity':{'bytes':len(raw),'sha256':digest(raw)}}
        require(sum(t['count']for t in targets.values())==35,'exact 35 targeted cases required')
        refusal_path='tests/integration/test_narrative_pause_frontier.gd'
        refusal_raw=git('show',args.source+':'+refusal_path);refusal_text=refusal_raw.decode()
        alternatives=['test_native_nontext_wait_refuses_pause_without_changing_playback',
                      'test_native_visible_wait_refuses_pause_without_changing_playback']
        refusal_names=[n for n in alternatives if re.search(r'^func '+n+r'\(',refusal_text,re.M)]
        require(len(refusal_names)==1,'exact one old or revised native refusal control required')
        refusal_name=refusal_names[0]
        refusal_body=re.search(r'^func '+refusal_name+r'\([^\n]*\).*?(?=^func |\Z)',refusal_text,re.M|re.S).group()
        required_assertions=['assert_false(_adapter.capture_pause_frontier().ok)',
                             'assert_false(_bridge.begin_suspend(HANDLE).ok)',
                             'assert_false(_runtime.paused)',
                             'assert_eq(_runtime.get_timeline_generation(), generation)',
                             'assert_eq(_runtime.current_event_idx, index)',
                             'assert_eq(_bridge.get_state().value.state, &"Active")']
        require(all(assertion in refusal_body for assertion in required_assertions),'native refusal invariants weakened')
        if refusal_name==alternatives[1]:
            require('hide_text="false" skippable="false"' in refusal_body,'revised refusal control must execute visible non-skippable Wait')
        if repair:require(refusal_name==alternatives[1],'repair requires revised visible-Wait control')
        refusal={'path':refusal_path,'name':refusal_name,'absent_name':next(n for n in alternatives if n!=refusal_name),
                 'source_identity':{'bytes':len(refusal_raw),'sha256':digest(refusal_raw)},
                 'preserved_refusal_assertions':required_assertions}
        value={'actual_checkout':args.source,'workflow_head':args.workflow_head,'workflow_tree_boundary':boundary,
                'workflow_tree_boundary_note':'Inherited helper field tested_checkout identifies the auxiliary workflow Git tree only. '
                    'Actual engine/test checkout is actual_checkout and is independently required in every Actions job log.',
                'workflow_identity':{'bytes':len(workflow_raw),'sha256':digest(workflow_raw)},
                'expected_jobs':names,'target_fixtures':targets,'native_refusal_control':refusal,
                'expected_ordinary_xml':len(gut_suites)}
        if repair:
            value['expected_case_executions']=526;value['expected_script_executions']=39
            paths=['tools/testing/Invoke-IsolatedGodot.ps1','tests/tooling/Test-InvokeIsolatedGodot.ps1',
                   'addons/dialogic/Modules/Wait/event_wait.gd']
            blobs={p:git('show',args.source+':'+p)for p in paths}
            runner=blobs[paths[0]].decode();probe=blobs[paths[1]].decode();wait=blobs[paths[2]].decode()
            guard="if ($line.Contains('ERROR: Tween invalid.')) { $failures += ('TWEEN_INVALID: ' + $line.Trim()) }"
            require(guard in runner and 'if ($resultCode -eq 0) { $resultCode = 126 }'in runner and
                    runner.count('$resultCode = 126')==1,'exact zero-exit diagnostic gate required')
            body=re.search(r'    \$invalidTweenScript = @\x27\n(.*?)\n\x27@',probe,re.S)
            require(body is not None,'generated native GUT probe body required')
            expected_body='''extends GutTest

func test_passes_before_invalid_tween_teardown() -> void:
    assert_true(true)

func after_each() -> void:
    var tween := create_tween()
    tween.tween_interval(1.0)
    tween.kill()
    print("ISOLATION_INVALID_TWEEN_TEARDOWN_STARTED")
    tween.play()
    print("ISOLATION_INVALID_TWEEN_TEARDOWN_COMPLETED")'''
            require(body.group(1)==expected_body,'exact actual native teardown probe required')
            guards=["$invalidTween = Invoke-HelperProcess -SuiteId 'fixture-invalid-tween'",
                    "$invalidTween.ExitCode -ne 126 -or -not $invalidTween.Stdout.Contains('TWEEN_INVALID: ERROR: Tween invalid.')",
                    '$invalidTweenErrors.Count -ne 1',"$invalidTweenErrors[0].Trim() -cne '"+INVALID_TWEEN+"'",
                    '$invalidTweenRecords.Count -ne 1','$invalidTweenRecord.exit_code -ne 126',
                    "$invalidTweenRecord.suite_id -cne 'fixture-invalid-tween'",
                    'if (Test-Path -LiteralPath ([string]$invalidTweenRecord.test_root))',
                    'if (Test-Path -LiteralPath $invalidTweenProbe) { Remove-Item -LiteralPath $invalidTweenProbe -Force }']
            require(all(g in probe for g in guards),'negative probe source assertions absent')
            require(probe.count("Write-Output 'ISOLATION_HELPER: PASS'")==1 and
                    all(probe.index(g)<probe.index("Write-Output 'ISOLATION_HELPER: PASS'")for g in guards),
                    'probe guards must precede terminal success')
            for name in ['_on_pause','_on_resume']:
                fn=re.search(r'^func '+name+r'\([^\n]*\).*?(?=^func |\Z)',wait,re.M|re.S)
                require(fn is not None and 'is_instance_valid(_tween) and _tween.is_valid()'in fn.group(),
                        'both native timer signal callbacks must reject killed Tweens')
            native=git('show',args.source+':tests/integration/test_dialogic_timed_hold_runtime.gd').decode()
            require('killed_tween.kill()'in native and
                    'assert_engine_error_count(0, "native Pause and Resume must not operate an invalid Tween")'in native,
                    'active-test invalid-Tween regression required')
            value['repair_source_contract']={'source_files':{p:{'bytes':len(b),'sha256':digest(b)}for p,b in blobs.items()},
                                            'probe_body_sha256':digest(expected_body.encode()),'probe_guard_statements':guards}
        return value
    source=attempt('source_boundary_and_expected_census',source_check)
    if args.prepare_only:
        result['status']='prepared_source_bound_expectations'if not result['failures']else'diagnostic_source_failure'
        write(args.output,result);print(args.output);return int(bool(result['failures']))
    def run_check():
        run=read(args.run_root/'run.json');require(run['status']=='completed','run incomplete')
        require(run['id']==args.run_id,'exact expected run ID required')
        require(run['head_sha']==args.workflow_head,'workflow head mismatch')
        require(run['run_attempt']==1,'this focused capture requires attempt one, not mixed reruns')
        return {k:run.get(k)for k in ['id','head_sha','run_attempt','status','conclusion','html_url']}
    run=attempt('run_identity',run_check)
    if run and run['conclusion']!='success':result['failures'].append('captured run conclusion is '+str(run['conclusion']))
    def artifacts_check():
        manifest=read(args.run_root/'artifact-manifest.json')
        attachments={Path(record['local_zip']).parent for record in manifest}
        inventory=cloud.artifact_inventory(args.run_root,attachments,read(args.run_root/'omissions.json'))
        require(not inventory['not_downloaded_artifacts'],'no evidence omissions admitted')
        return {'artifacts':inventory['artifacts'],'verified_member_count':len(inventory['files'])}
    attempt('original_artifact_identity',artifacts_check)
    def jobs_check():
        require(source is not None,'source proof absent')
        records=read(args.run_root/'jobs.json')['jobs']
        actual=[j['name']for j in records]
        require(Counter(actual)==Counter(source['expected_jobs']),'exact job-name multiset mismatch')
        return cloud.job_audit(args.run_root,args.source,job_count,[],require_success=False)
    jobs=attempt('job_checkout_identity',jobs_check)
    if jobs:
        result['failed_or_skipped_jobs']=[j for j in jobs if j['conclusion']!='success']
        if result['failed_or_skipped_jobs']:result['failures'].append('one or more focused jobs did not succeed')
    def xml_check():
        paths=[p for p in (args.run_root/'artifacts').rglob('*.xml')if 'storage-refusal'not in p.parts]
        require(len(paths)==len(gut_suites),'exact ordinary XML report count required')
        if repair:require({p.name for p in paths}=={'public_surfaces.xml','reading_delivery.xml'},'exact repair XML names required')
        all_suites=[];reports=[]
        for path in sorted(paths):
            root=ET.parse(path).getroot();suites=list(root.iter('testsuite'));cases=list(root.iter('testcase'))
            require(cases,'empty XML '+str(path))
            require(int(root.get('tests',str(len(cases))))==len(cases),'XML test census mismatch')
            errors=[{'case':case.get('name'),'status':case.get('status'),
                     'details':[{'kind':c.tag,'text':c.text or ''}for c in case if c.tag in ['failure','error','skipped']]}for case in cases
                    if case.get('status','pass')not in ['pass','passed','run']or any(c.tag in ['failure','error','skipped']for c in case)]
            declared={key:sum(int(n.get(key,'0'))for n in root.iter())for key in ['failures','errors','skipped','disabled']}
            reports.append({'path':str(path.relative_to(args.run_root)),**identity(path),'cases':len(cases),'scripts':len(suites),
                            'case_failures':errors,'declared_nonzero':{k:v for k,v in declared.items()if v}})
            all_suites.extend(suites)
        targets={}
        require(source is not None,'source proof absent')
        for script,expected in source['target_fixtures'].items():
            matches=[s for s in all_suites if s.get('name')==script]
            require(len(matches)==1,'exactly one XML script execution required: '+script)
            cases=matches[0].findall('./testcase')
            require(Counter(c.get('name')for c in cases)==Counter(expected['names']),'exact named case multiset mismatch: '+script)
            require(all(c.get('classname')==script for c in cases),'case class mismatch: '+script)
            require(all(int(c.get('assertions','0'))>0 for c in cases),'case executed no assertions: '+script)
            targets[script]={'cases':[{'name':c.get('name'),'assertions':int(c.get('assertions','0')),'status':c.get('status'),
                                      'failure':[f.text or ''for f in c if f.tag in ['failure','error','skipped']]}for c in cases]}
        result['ordinary_xml_reports']=reports;result['targeted_cases']=targets
        refusal=source['native_refusal_control']
        controls=[s for s in all_suites if s.get('name')==refusal['path']]
        require(len(controls)==1,'exactly one native refusal-control fixture execution required')
        control_cases=controls[0].findall('./testcase')
        control=[c for c in control_cases if c.get('name')==refusal['name']]
        require(len(control)==1 and all(c.get('name')!=refusal['absent_name'] for c in control_cases),
                'exact source-bound native refusal control required; old/new control names cannot mix')
        c=control[0];require(c.get('classname')==refusal['path']and int(c.get('assertions','0'))>0,'refusal control must execute assertions')
        result['native_refusal_control']={'name':c.get('name'),'assertions':int(c.get('assertions','0')),
                                          'status':c.get('status'),'failure':[f.text or ''for f in c if f.tag in ['failure','error','skipped']]}
        if repair:
            require(sum(p['cases']for p in reports)==526 and sum(p['scripts']for p in reports)==39,'exact repair 526-case/39-script census required')
            require({Path(p['path']).name:p['cases']for p in reports}=={'public_surfaces.xml':11,'reading_delivery.xml':515},
                    'exact repair case allocation required')
        bad=[p for p in reports if p['case_failures']or p['declared_nonzero']]
        require(not bad,'ordinary GUT diagnostic failure: '+', '.join(p['path']for p in bad))
        return {'xml_count':len(gut_suites),'case_executions':sum(p['cases']for p in reports),'script_executions':sum(p['scripts']for p in reports),
                'target_case_executions':35,'target_scripts':3}
    attempt('ordinary_xml_and_exact_target_cases',xml_check)
    def raw_logs_check():
        reports=[]
        for suite in gut_suites:
            matches=list((args.run_root/'artifacts').rglob('cloud-'+suite+'.log'))
            require(len(matches)==1,'one actual suite log required: '+suite)
            path=matches[0];text=path.read_text(encoding='utf-8-sig')
            require('Godot Engine v4.6.3.stable.official.7d41c59c4'in text,'wrong/unobserved engine: '+suite)
            findings=[{'line':i,'text':line}for i,line in enumerate(text.splitlines(),1)if ERROR.search(line)]
            failed_assertions=[{'line':i,'text':line}for i,line in enumerate(text.splitlines(),1)if '[Failed]'in line]
            reports.append({'suite':suite,'path':str(path.relative_to(args.run_root)),**identity(path),
                            'diagnostics':findings,'failed_assertion_lines':failed_assertions})
        result['ordinary_raw_logs']=reports
        require(all(not r['diagnostics']and not r['failed_assertion_lines']for r in reports),'ordinary suite raw diagnostics/assertions failed')
        return {'suite_logs':len(reports),'unexpected_diagnostics':0}
    attempt('ordinary_raw_logs',raw_logs_check)
    def invalid_tween_probe():
        require(source is not None and 'repair_source_contract'in source,'source-bound repair probe absent')
        public=args.run_root/'artifacts'/f'public-surfaces-{args.run_id}-1'
        receipt_path=public/'ci/public-surfaces/isolation-invalid-tween.jsonl'
        log_path=public/'phase2r_logs/cloud-public-surface-invalid-tween.log'
        require(len(receipt_path.read_text(encoding='utf-8-sig').splitlines())==1,'exact one negative-probe receipt required')
        row=read(receipt_path)
        require(list(row)==['suite_id','argv','exit_code','log_path','test_root','user_dir','started_at_utc','ended_at_utc'],
                'negative-probe receipt schema changed')
        require(row['suite_id']=='fixture-invalid-tween'and row['exit_code']==126,'exact intended negative outcome required')
        argv=row['argv']
        require(len(argv)==11 and argv[:2]==['--headless','--path']and argv[3]=='--log-file'and
                argv[4]==row['log_path']and argv[5:8]==['-s','res://addons/gut/gut_cmdln.gd','-gconfig=']and
                argv[9:]==['-gexit','-glog=2'],'exact negative-probe Godot/GUT argv required')
        require(re.fullmatch(r'-gtest=res://\.godot/ci/public-surfaces/test_isolation_invalid_tween_[0-9a-f]{32}\.gd',argv[8])is not None,
                'generated native probe identity required')
        resource=argv[8].removeprefix('-gtest=')
        def winpath(value):return str(value).replace('\\','/').rstrip('/').casefold()
        require(winpath(row['log_path'])==winpath(argv[2]+'/.godot/phase2r_logs/cloud-public-surface-invalid-tween.log'),
                'negative-probe log must belong to exact checkout')
        require(winpath(row['test_root']).startswith(winpath(argv[2])+'/.godot/phase2r_tests/')and
                winpath(row['user_dir']).startswith(winpath(row['test_root'])+'/'),'isolated negative-probe user root required')
        duration=(dt.datetime.fromisoformat(row['ended_at_utc'].replace('Z','+00:00'))-
                  dt.datetime.fromisoformat(row['started_at_utc'].replace('Z','+00:00'))).total_seconds()
        require(0<duration<60,'negative probe must exit within child timeout')
        text=log_path.read_text(encoding='utf-8-sig')
        require('\x00'not in text and 'Godot Engine v4.6.3.stable.official.7d41c59c4'in text,'valid pinned-engine negative log required')
        lines=[cloud.clean(line)for line in text.splitlines()]
        diagnostics=[{'line':n,'text':line}for n,line in enumerate(lines,1)if ERROR.search(line)]
        require([d['text']for d in diagnostics]==[INVALID_TWEEN],'only one exact intentional native error permitted in probe')
        require(sum(line.strip()==resource for line in lines)==1 and
                lines.count('* test_passes_before_invalid_tween_teardown')==1 and lines.count('1/1 passed.')==1,
                'exact generated passing test must execute before teardown error')
        require(lines.count('[INFO]:  Exiting with code 0')==1,'raw GUT zero-exit marker must corroborate wrapper126')
        start=[n for n,line in enumerate(lines,1)if line=='ISOLATION_INVALID_TWEEN_TEARDOWN_STARTED']
        end=[n for n,line in enumerate(lines,1)if line=='ISOLATION_INVALID_TWEEN_TEARDOWN_COMPLETED']
        require(len(start)==len(end)==1 and start[0]<diagnostics[0]['line']<end[0],'native error must be inside exact teardown markers')
        public_jobs=[j for j in read(args.run_root/'jobs.json')['jobs']if j['name']=='Windows / public API surface contracts']
        require(len(public_jobs)==1,'exact public job required')
        job=public_jobs[0]
        require(job['conclusion']=='success'and job['status']=='completed','successful public gate required')
        steps=[s for s in job['steps']if s['name']=='Verify isolated runner contracts and timeout diagnostics']
        require(len(steps)==1 and steps[0]['status']=='completed'and steps[0]['conclusion']=='success','runner-contract step must succeed')
        console_path=args.run_root/'logs'/f"{job['id']}.log"
        console=[cloud.clean(line)for line in console_path.read_text(encoding='utf-8-sig').splitlines()]
        require(console.count('ISOLATION_HELPER: PASS')==1,'source-bound cleanup and rejection assertions must reach final PASS')
        return {'status':'pass_exact_intended_negative_probe','receipt':{'path':str(receipt_path.relative_to(args.run_root)),
                **identity(receipt_path),'record':row},'raw_log':{'path':str(log_path.relative_to(args.run_root)),**identity(log_path)},
                'public_job_id':job['id'],'job_console':identity(console_path),'generated_resource':resource,
                'diagnostics':diagnostics,'started_line':start[0],'completed_line':end[0],'duration_seconds':duration,
                'zero_child_exit_promoted_to_126_source_bound':True,'raw_gut_zero_exit_marker':True,'ordinary_diagnostic_exemption':False,
                'negative_test_executions_excluded_from_ordinary_census':1,
                'cleanup_proof':'Frozen helper checks isolated root absence and removes generated fixture before its observed final PASS.'}
    if repair:attempt('invalid_tween_runner_negative_probe',invalid_tween_probe)
    def native_observations():
        logs=list((args.run_root/'artifacts').rglob('cloud-reading_delivery.log'));require(len(logs)==1,'reading delivery log absent')
        text=logs[0].read_text(encoding='utf-8-sig');obs={}
        for name,count in [('REPLACEMENT',1),('PAUSE',1),('DEFERRED',1),('LEGACY_SKIP',2)]:
            values=re.findall(r'^TIMED_HOLD_'+name+r'_OBSERVATION (.+)$',text,re.M)
            require(len(values)==count,'exact native observation multiplicity: '+name)
            obs[name.lower()]=[json.loads(v)for v in values]
        result['native_observations']=obs
        r=obs['replacement'][0];require(r['observed_msec']-r['first_started_msec']>r['hold_msec']and
            0<r['observed_msec']-r['replacement_started_msec']<r['hold_msec']and
            r['event_finishes']==r['semantic_completions']==0,'retired deadline altered replacement')
        p=obs['pause'][0];require(p['resumed_msec']-p['pause_started_msec']>2000 and
            p['elapsed_before_pause']>.15 and .20<p['elapsed_after_resume']-p['elapsed_before_pause']<.8 and
            p['semantic_completions']==0,'resume did not retain partial native duration')
        d=obs['deferred'][0];require(len(d['cancellations'])==1 and d['cancellations'][0]['result']['ok']is True and
            d['observed_msec']-d['cancellations'][0]['at_msec']>2000 and
            0<d['observed_msec']-d['replacement_started_msec']<2000 and d['semantic_completions']==0,'retired deferred body affected replacement')
        require({x['label']for x in obs['legacy_skip']}=={'skippable_wait','visible_wait'},'both legacy controls required')
        require(all(x['authored_msec']==2000 and x['native_skip_msec']==250 and
                    0<x['observed_elapsed_msec']<1800 and x['semantic_completions']==1 for x in obs['legacy_skip']),
                'legacy wait delay was changed')
        return {'real_deadline_observations':5,'retired_completions':0,'legacy_min_delay_controls':2,
                'scope':'Clock observations plus exact source-bound XML assertions; full production Pause/rendered evidence separate.'}
    attempt('native_clock_and_control_observations',native_observations)
    def import_warnings():
        warnings=[]
        for p in sorted((args.run_root/'logs').glob('*.log')):
            for n,line in enumerate(p.read_text(encoding='utf-8-sig').splitlines(),1):
                clean=cloud.clean(line)
                if clean.startswith('WARNING:'):
                    warnings.append({'path':str(p.relative_to(args.run_root)),'line':n,'text':clean})
        return {'job_console_warnings':warnings,'note':'Import and other warnings retained here; this list is not a waiver for executed fixture diagnostics.'}
    attempt('job_console_warning_inventory',import_warnings)
    result['status']='pass_focused_gut_and_source_boundary_rendered_semantics_separate'if not result['failures']else'diagnostic_failure_not_acceptance'
    write(args.output,result);print(args.output);print(result['status']);return int(bool(result['failures']))

if __name__=='__main__':raise SystemExit(main())

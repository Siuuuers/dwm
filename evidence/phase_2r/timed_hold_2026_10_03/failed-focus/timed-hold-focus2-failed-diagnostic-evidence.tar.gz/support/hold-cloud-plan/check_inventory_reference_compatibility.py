#!/usr/bin/env python3
"""Read-only source preflight for previously cloud-generated inventory bytes.

Checks reference completeness only within changed scanner inputs relative to the
receipt's generating source. Emits a compatibility report, never inventory bytes.
This static guard supplements the mandatory cloud committed-inventory check.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOTS = ('autoload','scripts','scenes','tests')


def identity(raw):
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,default=Path(__file__).resolve().parent.parent/'dwm')
    p.add_argument('--source',required=True)
    p.add_argument('--inventory-commit',help='Default: source. Explicit override permits a historical origin control.')
    p.add_argument('--inventory-working-tree',action='store_true',
                   help='Read only the two just-adopted inventory files from working tree; runtime source remains frozen.')
    p.add_argument('--adoption-receipt',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args(); inventory_commit=args.inventory_commit or args.source
    assert not (args.inventory_working_tree and args.inventory_commit), 'Choose working inventory bytes or a commit, not both'
    receipt=json.loads(args.adoption_receipt.read_text());origin=receipt['source_commit']
    assert all(re.fullmatch(r'[0-9a-f]{40}',sha) for sha in (args.source,inventory_commit,origin))
    assert receipt['status']=='exact_reviewed_cloud_inventory_bytes_adopted'
    def git(*parts):return subprocess.check_output(['git','-C',str(args.repo),*parts])
    cache={}
    def read(sha,path):
        key=(sha,path)
        if key not in cache:cache[key]=git('show',sha+':'+path)
        return cache[key]
    subprocess.run(['git','-C',str(args.repo),'merge-base','--is-ancestor',origin,args.source],check=True)
    changed=set(git('diff','--name-only','-z',origin,args.source).decode().split('\0'))-{''}
    previous=set(git('ls-tree','-r','--name-only',origin,'--',*ROOTS).decode().splitlines())
    current=set(git('ls-tree','-r','--name-only',args.source,'--',*ROOTS).decode().splitlines())
    relevant={path for path in changed.intersection(previous|current) if Path(path).suffix in ('.gd','.tscn')}
    old={item['repository_path']:item['new'] for item in receipt['adopted']}
    assert set(old)=={'evidence/phase_2r/runtime/game_state_surface.json','evidence/phase_2r/runtime/save_manager_surface.json'}
    mismatches=[];inventories={}
    for path in ('tools/runtime/PublicSurfaceInventory.gd','tools/runtime/generate_public_surface_inventory.gd',
                 'tools/testing/Invoke-PublicSurfaceValidation.ps1'):
        assert read(origin,path)==read(args.source,path), 'Scanner changed; review semantics before using this preflight'
    for path,expected in old.items():
        raw=(args.repo/path).read_bytes() if args.inventory_working_tree else read(inventory_commit,path)
        assert identity(raw)==expected,'Inventory bytes do not match exact supplied adoption receipt'
        doc=json.loads(raw);target=doc['script'].removeprefix('res://')
        assert read(origin,target)==read(args.source,target),'Public facade changed; cloud regeneration and contract review required'
        inventories[path]=identity(raw)
        for row in doc['records']:
            symbol=row['symbol'];pattern=re.compile(r'\b'+re.escape(symbol)+r'\b')
            for kind,sites in (('static',row['call_sites']),('dynamic',doc['dynamic_references'].get(symbol,[]))):
                present={site for site in sites if site.rsplit(':',1)[0] in relevant}
                expected_sites=set()
                for changed_path in relevant.intersection(current):
                    if changed_path==target:continue
                    for index,line in enumerate(read(args.source,changed_path).decode('utf-8-sig').split('\n'),1):
                        if pattern.search(line) and ('"'+symbol+'"' in line)==(kind=='dynamic'):
                            expected_sites.add(f'{changed_path}:{index}')
                if present!=expected_sites:
                    mismatches.append({'inventory_path':path,'symbol':symbol,'kind':kind,
                                       'stale_sites':sorted(present-expected_sites),
                                       'missing_current_sites':sorted(expected_sites-present)})
    result={'status':'compatible_static_reference_delta' if not mismatches else 'stale_static_reference_delta',
            'compatible':not mismatches,'source_commit':args.source,
            'inventory_commit':None if args.inventory_working_tree else inventory_commit,
            'inventory_bytes_from_working_tree':args.inventory_working_tree,
            'inventory_reference_origin_source':origin,'adoption_receipt':identity(args.adoption_receipt.read_bytes()),
            'inventory_identities':inventories,'changed_scanner_inputs':sorted(relevant),'mismatches':mismatches,
            'auditor':identity(Path(__file__).read_bytes()),'no_inventory_regeneration_or_repository_writes':True,
            'no_engine_or_powershell_execution':True,'limit':'Static changed-input preflight only; mandatory cloud generation/check and stable-contract review remain authoritative.'}
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'report':str(args.output),**identity(args.output.read_bytes()),'status':result['status'],
                      'mismatch_groups':len(mismatches)},indent=2))
    return 0 if not mismatches else 1


if __name__=='__main__':raise SystemExit(main())

#!/usr/bin/env python3
"""Independently inspect the frozen second green source and derived focused workflow.

No workflow generator/census code is imported, and no engine or PowerShell runs.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import itertools
import json
from pathlib import Path
import posixpath
import re
import subprocess

import yaml

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'dwm'
SOURCE = '058f817e587e0fc333ae66b769702d5cf0a68ebc'
BASELINE = 'f08403d5e3a96fe161d4209939016090072f5ac0'
AUX = 'f22f187d77190be74d60c2ad491407f3f6daef84'
PRIOR_SOURCE = '75d129b1c8a79f7cb11dc0d5de75a02ea55f8965'
PRIOR_AUX = 'e91e0b50bd5e8720a3c40d48d02dbd3439dd04ef'
FOLDER = Path(__file__).resolve().parent
CANONICAL = '.github/workflows/windows-tests.yml'
RUNNER = 'tools/testing/Invoke-CloudTests.ps1'
FOCUSED = ('reading_delivery', 'settings', 'persistence', 'localization')
CHECKS: list[str] = []
READS: dict[str, dict] = {}


def require(condition: object, label: str) -> None:
    if not condition:
        raise AssertionError(label)
    CHECKS.append(label)


def identity(raw: bytes) -> dict:
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def git(*args: str) -> bytes:
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def read(path: str, source: str = SOURCE) -> bytes:
    raw = git('show', source + ':' + path)
    if source == SOURCE:
        READS[path] = identity(raw)
    return raw


class Loader(yaml.SafeLoader):
    pass


Loader.yaml_implicit_resolvers = deepcopy(yaml.SafeLoader.yaml_implicit_resolvers)
for key, rules in Loader.yaml_implicit_resolvers.items():
    Loader.yaml_implicit_resolvers[key] = [(tag, pattern) for tag, pattern in rules
                                         if tag != 'tag:yaml.org,2002:bool']
Loader.add_implicit_resolver('tag:yaml.org,2002:bool', re.compile(r'^(?:true|false)$', re.I), list('tTfF'))


def mapping(loader, node, deep=False):
    result = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        if key in result:
            raise AssertionError('Duplicate YAML key: ' + str(key))
        result[key] = loader.construct_object(value_node, deep=deep)
    return result


Loader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, mapping)


def parse(raw: bytes) -> dict:
    result = yaml.load(raw, Loader=Loader)
    require(isinstance(result, dict), 'YAML mapping parsed')
    return result


def declarations(raw: bytes) -> str:
    """Keep line positions and ordinary quoted extends; blank comments/triples."""
    text = raw.decode('utf-8-sig')
    result, index = [], 0
    while index < len(text):
        c = text[index]
        if c == '#':
            end = text.find('\n', index)
            end = len(text) if end < 0 else end
            result.append(' ' * (end - index))
            index = end
        elif c in ('"', "'"):
            start = index
            width = 3 if text.startswith(c * 3, index) else 1
            index += width
            while index < len(text):
                if text[index] == '\\':
                    index += 2
                elif text.startswith(c * width, index):
                    index += width
                    break
                else:
                    index += 1
            require(text[index-width:index] == c * width, 'Terminated GDScript literal')
            value = text[start:index]
            result.append(''.join('\n' if char == '\n' else ' ' for char in value) if width == 3 else value)
        else:
            result.append(c)
            index += 1
    return ''.join(result)


METHODS: dict[str, list[str]] = {}
VISITING: set[str] = set()


def methods(path: str) -> list[str]:
    if path in METHODS:
        return METHODS[path]
    require(path not in VISITING, 'No inherited test cycle: ' + path)
    VISITING.add(path)
    text = declarations(read(path))
    parents = re.findall(r'^extends\s+(.+?)\s*$', text, re.M)
    require(len(parents) == 1, 'One test base: ' + path)
    own = re.findall(r'^func (test_\w+)\(', text, re.M)
    require(len(own) == len(set(own)), 'Distinct own methods: ' + path)
    parent = parents[0]
    if parent == 'Node':
        require(path == 'addons/gut/test.gd' and not own, 'Expected terminal GutTest base')
        base = []
    elif parent == 'GutTest':
        base = methods('addons/gut/test.gd')
    else:
        match = re.fullmatch(r"['\"]([^'\"]+\.gd)['\"]", parent)
        require(match is not None, 'Resolvable inherited script: ' + path)
        relative = match.group(1)
        target = relative.removeprefix('res://') if relative.startswith('res://') else posixpath.normpath(
            posixpath.join(posixpath.dirname(path), relative))
        require(not target.startswith('/') and '..' not in Path(target).parts, 'Contained inherited script')
        base = methods(target)
    result = list(dict.fromkeys([*base, *own]))
    METHODS[path] = result
    VISITING.remove(path)
    return result


def suite_census(names: tuple[str, ...]) -> dict:
    source = read(RUNNER).decode('utf-8-sig')
    suites = {name: re.findall(r"'([^']+\.gd)'", body)
              for name, body in re.findall(r'^    (\w+) = @\((.*?)^    \)', source, re.M | re.S)}
    result = {}
    pairs = []
    for name in names:
        require(name in suites and len(suites[name]) == len(set(suites[name])), 'Distinct registered scripts: ' + name)
        rows = {path: methods(path) for path in suites[name]}
        require(all(rows.values()), 'Every script declares or inherits tests: ' + name)
        pairs.extend((path, method) for path, tests in rows.items() for method in tests)
        result[name] = {'scripts': rows, 'script_count': len(rows), 'case_count': sum(map(len, rows.values()))}
    return {'suites': result, 'case_executions': len(pairs),
            'script_executions': sum(item['script_count'] for item in result.values()),
            'unique_cases': len(set(pairs)), 'unique_scripts': len({path for path, _method in pairs})}


def expanded_jobs(jobs: dict) -> list[str]:
    names = []
    for key, job in jobs.items():
        matrix = job.get('strategy', {}).get('matrix')
        if matrix is None:
            rows = [{}]
        elif set(matrix) == {'include'}:
            rows = matrix['include']
        else:
            require(not set(matrix).intersection({'include', 'exclude'}), 'Plain matrix axes: ' + key)
            rows = [dict(zip(matrix, values)) for values in itertools.product(*matrix.values())]
        for row in rows:
            name = job.get('name', key)
            for axis, value in row.items():
                name = re.sub(r'\$\{\{\s*matrix\.' + re.escape(axis) + r'\s*\}\}', str(value), name)
            require('${{' not in name, 'Expanded job display name: ' + name)
            names.append(name)
    require(len(names) == len(set(names)), 'Distinct expanded job names')
    return names


def main() -> None:
    manifest_path = FOLDER / 'timed-hold-focus2-parallel.yml.manifest.json'
    workflow_path = FOLDER / 'timed-hold-focus2-parallel.yml'
    manifest = json.loads(manifest_path.read_text())
    workflow_raw = workflow_path.read_bytes()
    workflow = parse(workflow_raw)
    require(manifest['source_commit'] == SOURCE and manifest['accepted_baseline'] == BASELINE,
            'Exact source and accepted baseline')
    require(git('rev-parse', SOURCE + '^{tree}').decode().strip() == manifest['source_tree'], 'Exact source tree')
    subprocess.run(['git', '-C', str(REPO), 'merge-base', '--is-ancestor', BASELINE, SOURCE], check=True)
    require(identity(workflow_raw)['sha256'] == manifest['workflow_sha256'], 'Exact generated workflow bytes')
    require(manifest['stage'] == 'focus' and manifest['public_regeneration'] is False, 'Declared focused committed-inventory validation only')
    for path, expected in manifest['source_file_identities'].items():
        raw = read(path)
        require(identity(raw) == expected, 'Frozen source identity: ' + path)
        require((REPO / path).read_bytes() == raw, 'Working bytes equal frozen source: ' + path)
    for record in manifest['helpers']:
        require(identity(Path(record['path']).read_bytes()) == {k:record[k] for k in ('bytes', 'sha256')},
                'Exact derivation helper identity: ' + record['path'])
    changed = set(git('diff', '--name-only', '--diff-filter=ACMRT', '-z', BASELINE, SOURCE).decode().split('\0')) - {''}
    require(changed.issubset(manifest['source_file_identities']), 'All changed source paths inventoried')
    incremental = git('diff', '--name-only', PRIOR_SOURCE, SOURCE).decode().splitlines()
    require(incremental == ['evidence/phase_2r/runtime/game_state_surface.json',
                            'evidence/phase_2r/runtime/save_manager_surface.json',
                            'tests/integration/test_narrative_pause_frontier.gd',
                            'tools/testing/run_timed_hold_journey.py'], 'Exactly four incremental inventory/harness/control paths')
    require(git('diff', '--name-only', PRIOR_SOURCE, SOURCE, '--', 'addons/', 'autoload/', 'scripts/',
                'scenes/', 'project.godot') == b'', 'All runtime/project/scene bytes unchanged from Focus1')
    require(read('tests/integration/test_dialogic_timed_hold_runtime.gd') ==
            read('tests/integration/test_dialogic_timed_hold_runtime.gd', PRIOR_SOURCE), 'Ten native hold tests unchanged')
    adoption = json.loads((FOLDER/'focus1-public-inventory-adoption.json').read_text())
    for item in adoption['adopted']:
        require(identity(read(item['repository_path'])) == item['new'], 'Exact adopted Focus1 inventory: ' + item['repository_path'])
    require(read(CANONICAL) == read(CANONICAL, PRIOR_SOURCE), 'Canonical workflow unchanged from Focus1')
    canonical_raw = read(CANONICAL)
    canonical = parse(canonical_raw)
    require(identity(canonical_raw) == {k:manifest['canonical_workflow'][k] for k in ('bytes', 'sha256')},
            'Exact canonical workflow identity')
    wanted = deepcopy(canonical)
    selected = ('public-surfaces', 'focused-tests', 'rendered-journeys', 'rendered-hospital-reading', 'rendered-timed-hold')
    wanted['jobs'] = {name: wanted['jobs'][name] for name in selected}
    wanted['jobs']['focused-tests']['strategy']['matrix']['suite'] = list(FOCUSED)
    public = wanted['jobs']['public-surfaces']
    replacements = [step for step in public['steps']
                    if step.get('run', '').strip() == './tools/testing/Invoke-PublicSurfaceValidation.ps1 -EmitPayloads']
    require(len(replacements) == 1, 'One read-only committed public inventory command')
    require(not any('-Regenerate' in step.get('run', '') for step in public['steps']), 'No public regeneration in Focus2')
    for name, job in wanted['jobs'].items():
        checkout = [step for step in job['steps'] if step.get('uses') == 'actions/checkout@v7']
        require(len(checkout) == 1 and 'ref' not in checkout[0].get('with', {}), 'Canonical checkout unpinned: ' + name)
        checkout[0].setdefault('with', {}).update({'ref': SOURCE, 'fetch-depth': 0})
    wanted.update({'name': 'Timed hold focus candidate',
                   'on': {'push': {'branches': ['codex/timed-hold-focus2-20261003']}},
                   'concurrency': {'group': 'timed-hold-${{ github.ref }}', 'cancel-in-progress': True}})
    require(workflow == wanted, 'Whole focused workflow equals exact declared mechanical derivation')
    focused_names = expanded_jobs(workflow['jobs'])
    canonical_names = expanded_jobs(canonical['jobs'])
    require(len(focused_names) == 8 and len(canonical_names) == 25, 'Eight focused and twenty-five canonical jobs')
    baseline_raw = read(CANONICAL, BASELINE)
    text = canonical_raw.decode()
    start = text.index('  rendered-timed-hold:\n')
    end = text.index('  rendered-desktop:\n', start)
    require((text[:start] + text[end:]).encode() == baseline_raw, 'Canonical change is solely new hold job bytes')
    canonical_base = parse(baseline_raw)
    require({name:job for name, job in canonical['jobs'].items() if name != 'rendered-timed-hold'} == canonical_base['jobs'],
            'All prior canonical jobs exactly unchanged')
    fragment_path = workflow_path.with_name(workflow_path.name + '.canonical-hold-job.yml')
    fragment = manifest['canonical_hold_job_fragment']
    require(fragment_path.read_bytes() == fragment['text'].encode()
            and identity(fragment_path.read_bytes()) == {k:fragment[k] for k in ('bytes', 'sha256')},
            'Exact emitted canonical fragment bytes')
    require(parse(b'jobs:\n' + fragment_path.read_bytes()) == {'jobs': {'rendered-timed-hold': canonical['jobs']['rendered-timed-hold']}},
            'Emitted canonical fragment equals frozen unpinned job')
    focused = suite_census(('public_surfaces', *FOCUSED))
    for name, item in focused['suites'].items():
        prior = manifest['suite_census']['suites'][name]
        require(item['script_count'] == prior['script_count'] and item['case_count'] == prior['static_case_count'],
                'Independent focused suite totals: ' + name)
        declared = {row['path']: row['static_test_names'] for row in prior['scripts']}
        require({path:set(tests) for path, tests in item['scripts'].items()} ==
                {path:set(tests) for path, tests in declared.items()}, 'Independent exact named census: ' + name)
    require((focused['case_executions'], focused['script_executions'], focused['unique_cases'], focused['unique_scripts'])
            == (1266,110,1266,110), 'Final focused 1266/110 census')
    fixture = 'tests/integration/test_dialogic_timed_hold_runtime.gd'
    require(len(methods(fixture)) == 10 and len(methods('tests/integration/test_dialogic_live_admission.gd')) == 21
            and len(methods('tests/unit/test_witnessed_timed_hold.gd')) == 4, 'Registered 10 native / 21 lifecycle / 4 view tests')
    full = suite_census(('public_surfaces', *canonical['jobs']['focused-tests']['strategy']['matrix']['suite']))
    require((full['case_executions'], full['script_executions'], full['unique_cases'], full['unique_scripts'])
            == (2472,207,2468,206), 'Full canonical 2472/207 census with inherited Shop cases')
    aux_local = subprocess.run(['git', '-C', str(REPO), 'cat-file', '-e', AUX + '^{commit}'], capture_output=True).returncode == 0
    aux = {'reported_workflow_head': AUX, 'locally_materialized': aux_local,
           'remote_metadata_and_actual_checkout_audit': 'Separate parent task; not inferred from this source review.'}
    if aux_local:
        require(git('show', AUX + ':' + manifest['workflow_repository_path']) == workflow_raw, 'Local auxiliary workflow blob exact')
        aux['ordered_parents'] = git('show', '-s', '--format=%P', AUX).decode().strip().split()
        aux['source_diff_paths'] = git('diff', '--name-only', SOURCE, AUX).decode().splitlines()
        require(len(aux['ordered_parents']) == 2 and aux['ordered_parents'][1] == SOURCE,
                'Local auxiliary second parent source')
        require(aux['ordered_parents'][0] == PRIOR_AUX, 'Local auxiliary first parent is prior focused workflow')
        require(aux['source_diff_paths'] == [manifest['workflow_repository_path']], 'Only auxiliary workflow differs from source')
    result = {'status': 'pass_static_frozen_source_and_workflow_only', 'source_commit': SOURCE,
              'source_tree': manifest['source_tree'], 'accepted_baseline': BASELINE,
              'focused_workflow': identity(workflow_raw), 'manifest': identity(manifest_path.read_bytes()),
              'canonical_workflow': identity(canonical_raw), 'source_identity_count': len(manifest['source_file_identities']),
              'prior_source': PRIOR_SOURCE, 'incremental_changed_paths': incremental,
              'runtime_and_native_ten_test_fixture_unchanged': True,
              'adoption_receipt': identity((FOLDER/'focus1-public-inventory-adoption.json').read_bytes()),
              'changed_source_paths': sorted(changed), 'distinct_static_checks_passed': len(set(CHECKS)),
              'literal_parse_observations': CHECKS.count('Terminated GDScript literal'),
              'check_labels': sorted(set(CHECKS)), 'focus_job_names': focused_names, 'canonical_job_names': canonical_names,
              'focused_census': focused, 'canonical_census': full, 'final_native_fixture_test_names': methods(fixture),
              'audited_source_identities': READS, 'auxiliary': aux,
              'auditor': identity(Path(__file__).read_bytes()), 'no_engine_or_powershell_execution': True,
              'no_repository_or_remote_mutations': True,
              'limits': ['Static evidence only; actual cloud jobs, XML and raw semantic/rendered evidence still need independent audit.',
                         'Inventories are exact adopted Focus1 artifact bytes; actual Focus2 read-only validation still requires cloud evidence.',
                         'Prior Run131 remains separate historical checkpoint evidence; no new hold claim is derived from it.',
                         'No production timing, no-Sylvia integration, durable mid-hold Save/Load, or leak-free exporter claim.']}
    output = FOLDER / 'focus2-frozen-source-audit.json'
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'receipt': str(output), **identity(output.read_bytes()), 'distinct_static_checks': len(set(CHECKS)),
                      'focused_cases': focused['case_executions'], 'canonical_cases': full['case_executions'],
                      'auxiliary_locally_materialized': aux_local}, indent=2))


if __name__ == '__main__':
    main()

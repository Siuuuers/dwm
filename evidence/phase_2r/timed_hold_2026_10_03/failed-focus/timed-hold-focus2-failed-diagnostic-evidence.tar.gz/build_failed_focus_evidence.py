#!/usr/bin/env python3
"""Freeze complete failed Focus captures with original ZIPs once and lossless extraction inventories."""
from __future__ import annotations
import argparse
import gzip
import hashlib
import io
import json
import re
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import tarfile
import zipfile

MAX_PART=8*1024*1024
BASELINE='f08403d5e3a96fe161d4209939016090072f5ac0'
CONFIGS={
 'focus1':{
  'run':37092368181,'source':'75d129b1c8a79f7cb11dc0d5de75a02ea55f8965','checkout':'e91e0b50bd5e8720a3c40d48d02dbd3439dd04ef','jobs':8,'artifacts':13,'members':490,'skipped':0,
  'workflow':'timed-hold-focus1.yml','source_stages':['hold-green1-source'],
  'diagnosis':[
   'Failed run: six successful jobs and two failed jobs; no current acceptance.',
   'Across five ordinary suites, 1266 cases execute with one failed outdated reading-delivery refusal control; reading_delivery itself has 515 cases (514 pass, 1 fail). The 35 targeted XML cases pass, but raw native execution has an invalid-Tween resume error during foreign-timeline fixture teardown.',
   'The old refusal control used an eligible hidden non-skippable Wait; source correction selects the visible-Wait boundary while retaining refusal behavior outside the admitted hold.',
   'The rendered process supplied signed nonzero Godot ObjectID values; the positive-only Python checker rejected them. Corrected bounded Python re-audit is diagnostic and does not change the failed cloud job.',
   'Import warnings and all original logs remain preserved; successful component observations cannot accept the failed run.'],
  'support':[
   'hold-contract-review/audit_focus.v1.py','hold-contract-review/audit_focus.v2.py',
   'hold-contract-review/focus1-audit-expectations.json','hold-contract-review/focus1-evidence-review.json',
   'hold-contract-review/focus1-evidence-review-v2.json','hold-contract-review/focus1-diagnostic-summary.json',
   'hold-contract-review/focused-source-review-initial.json','hold-contract-review/focused-source-review.json',
   'hold-contract-review/native-static-review.json','hold-contract-review/runner-invalid-tween-static-review.json',
   'hold-contract-review/visible-wait-refusal-review.json',
   'hold-focus1-runner-correction/audit.json','hold-focus1-render/root-visual-review.json',
   'hold-rendered-semantic-audit/audit_hold.py',
   'hold-rendered-semantic-audit/audit_hold.initial-positive-object-id.py',
   'hold-rendered-semantic-audit/audit_hold.early-diagnostic.py',
   'hold-rendered-semantic-audit/focus1-auditor-corrections.json',
   'hold-rendered-semantic-audit/focus1-complete-envelope.json',
   'hold-rendered-semantic-audit/focus1-diagnostic-semantic-audit.json',
   'hold-rendered-semantic-audit/focus1-full-semantic-audit.json',
   'hold-rendered-semantic-audit/focus1-visual-review.json',
   'hold-cloud-plan/audit_focus1_source.py','hold-cloud-plan/focus1-frozen-source-audit.json',
   'hold-cloud-plan/focus1-inventory-preflight-origin-control.json',
   'hold-cloud-plan/focus1-public-inventory-adoption-review.json',
   'hold-cloud-plan/focus1-public-inventory-adoption.json',
   'hold-cloud-plan/review_public_inventory_adoption.focus1.py',
  ]},
 'focus2':{
  'run':37093072813,'source':'058f817e587e0fc333ae66b769702d5cf0a68ebc','checkout':'f22f187d77190be74d60c2ad491407f3f6daef84','jobs':5,'artifacts':1,'members':8,'skipped':4,
  'workflow':'timed-hold-focus2-parallel.yml','source_stages':['hold-green1-source','hold-green2-source','hold-green3-source'],
  'diagnosis':[
   'Failed run: the public API inventory check failed; four dependent job records were skipped without runner logs. The skipped matrix record did not execute its underlying suites.',
   'Source-backed diagnosis is stale checked-in call-site line inventories after a six-line fixture edit; unchanged public method contracts are not evidence that stale inventory bytes passed.',
   'Only one public-surface artifact exists. No native, ordinary suite, rendered-hold, Hospital or rendered-journey execution is inferred for skipped records.',
   'Independent Focus2 files are source diagnosis and audit expectations, not a completed successful runtime audit. No current acceptance.'],
  'support':[
   'hold-contract-review/audit_focus.v2.py','hold-contract-review/focus2-audit-expectations.json',
   'hold-contract-review/visible-wait-refusal-review.json',
   'hold-cloud-plan/audit_focus2_source.py','hold-cloud-plan/focus2-frozen-source-audit.json',
   'hold-cloud-plan/focus2-inventory-preflight-red.json',
   'hold-cloud-plan/focus2-stale-inventory-source-diagnosis.json',
   'hold-cloud-plan/check_inventory_reference_compatibility.py',
  ]}
}
SHARED_SUPPORT=['hold-cloud-plan/build_timed_hold_workflow.py','hold-cloud-plan/import_auxiliary_tree.py',
 'hospital-tools/build_hospital_broad_workflow.py','hospital-tools/build_layout_workflow.py',
 'hospital-tools/build_paused_settings_f9_workflow.py','hospital-tools/capture_cloud_evidence.js',
 'hospital-tools/cloud_evidence.py']
CONTEXT=['addons/dialogic/Core/DialogicGameHandler.gd','addons/dialogic/Resources/event.gd',
 'addons/dialogic/Modules/Core/subsystem_input.gd','addons/dialogic/Modules/Core/subsystem_animation.gd',
 'autoload/DialogicBridge.gd','tests/integration/test_narrative_pause_frontier.gd',
 'tools/testing/Invoke-IsolatedGodot.ps1']


def require(value,label):
 if not value:raise ValueError(label)
def strict_json(raw):
 def pairs(items):
  d={}
  for k,v in items:
   require(k not in d,'duplicate JSON key: '+k);d[k]=v
  return d
 return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda value: (_ for _ in ()).throw(ValueError('nonfinite JSON '+value)))
def load(path):return strict_json(path.read_text(encoding='utf-8-sig'))
def digest(raw):return hashlib.sha256(raw).hexdigest()
def ident(path):
 with path.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return {'bytes':path.stat().st_size,'sha256':h}
def save(path,value):
 path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args])
def safe(name):
 p=PurePosixPath(name)
 return bool(name) and not p.is_absolute() and '..' not in p.parts and '\\' not in name and '\x00' not in name


def build(base,out,label,cfg):
 repo=base/'dwm';capture=base/('hold-'+label);payload=out/(label+'-payload')
 require(not payload.exists(),'refuse existing payload '+str(payload));payload.mkdir(parents=True)
 records=[]
 def copy(src,dest,kind):
  require(src.is_file() and not src.is_symlink(),'regular input required '+str(src))
  target=payload/dest;require(not target.exists(),'duplicate archive target '+dest)
  target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,target)
  require(ident(src)==ident(target),'copied byte mismatch '+str(src))
  records.append({'archive_path':dest,'source_path':str(src.relative_to(base)),'kind':kind,**ident(src)})
 def raw(dest,data,kind,source):
  target=payload/dest;require(not target.exists(),'duplicate archive target '+dest)
  target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
  records.append({'archive_path':dest,'source_path':source,'kind':kind,**ident(target)})
 run=load(capture/'run.json');jobsdoc=load(capture/'jobs.json');jobs=jobsdoc['jobs'];api_doc=load(capture/'artifacts-api.json');apis=api_doc['artifacts'];downloads=load(capture/'artifact-manifest.json')
 require((run['id'],run['head_sha'],run['run_attempt'],run['status'],run['conclusion'])==(cfg['run'],cfg['checkout'],1,'completed','failure'),'exact failed run')
 require(len(jobs)==jobsdoc['total_count']==cfg['jobs'],'complete expected job census')
 require(len(apis)==api_doc['total_count']==len(downloads)==cfg['artifacts'],'complete artifact API/download census')
 require(load(capture/'omissions.json')=={},'capture omissions must be empty')
 skipped=[j for j in jobs if j['conclusion']=='skipped'];executed=[j for j in jobs if j['conclusion']!='skipped']
 require(len(skipped)==cfg['skipped'],'skipped count')
 expected_logs={f"{j['id']}.log" for j in executed}
 require({p.name for p in (capture/'logs').iterdir() if p.is_file()}==expected_logs,'exact every executed-job log; no synthetic skipped logs')
 actual_checkouts={}
 for job in executed:
  text=(capture/'logs'/f"{job['id']}.log").read_text(encoding='utf-8-sig')
  lines=[re.sub(r'^\d{4}-\S+\s+','',re.sub(r'\x1b\[[0-9;]*m','',line)).strip() for line in text.splitlines()]
  checkouts=[lines[i+1] for i,line in enumerate(lines[:-1]) if 'log -1 --format=%H' in line]
  require(checkouts==[cfg['source']],'exact source-pinned actual checkout for every executed job')
  actual_checkouts[str(job['id'])]=checkouts[0]
 for job in jobs:
  require(job['run_id']==cfg['run'] and job['head_sha']==cfg['checkout'] and job['run_attempt']==1 and job['status']=='completed','job source identity')
 if skipped:
  skipped_doc=load(capture/'skipped-jobs.json');require({j['id'] for j in skipped_doc['jobs']}=={j['id'] for j in skipped},'complete explicit skipped-job receipt')
  require(all(j['log'] is None for j in skipped_doc['jobs']),'no manufactured skipped logs')
 for p in sorted(capture.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(capture)
  if rel.parts[0]=='artifacts':continue
  copy(p,'capture/'+rel.as_posix(),'complete_capture_record')
 api_by_id={a['id']:a for a in apis};require(len(api_by_id)==len(apis),'unique API artifact IDs')
 artifact_records=[];extracted=[];all_extracted=set();all_zip_paths=set()
 require({r['id'] for r in downloads}==set(api_by_id),'all original artifacts represented exactly once')
 for row in sorted(downloads,key=lambda x:x['id']):
  api=api_by_id[row['id']]
  require(all(row[k]==api[k] for k in ['id','name','size_in_bytes','digest','workflow_run']),'captured original API metadata join')
  require(api['workflow_run']['id']==cfg['run'] and api['workflow_run']['head_sha']==cfg['checkout'],'artifact run and head')
  zpath=Path(row['local_zip']);require(zpath not in all_zip_paths,'original ZIP path duplicated');all_zip_paths.add(zpath)
  expected={'bytes':row['size_in_bytes'],'sha256':row['digest'].removeprefix('sha256:')};require(ident(zpath)==expected,'original ZIP API SHA256/size')
  arc=f"original-artifacts/{row['id']}-{row['name']}.zip";copy(zpath,arc,'original_artifact_zip_once')
  folder=capture/'artifacts'/row['name'];members=[];represented=set()
  with zipfile.ZipFile(zpath) as z:
   require(z.testzip() is None,'original ZIP every member CRC')
   require(len(z.namelist())==len(set(z.namelist())),'unique original ZIP names')
   for member in z.infolist():
    require(safe(member.filename),'safe archive member '+member.filename)
    require((member.external_attr>>16)&0o170000!=0o120000,'no original ZIP symlink')
    if member.is_dir():
     members.append({'member':member.filename,'directory':True});continue
    p=folder/member.filename;require(p.is_file() and not p.is_symlink(),'extracted regular member exists')
    data=z.read(member);require(p.read_bytes()==data,'every extracted byte reproduced from original ZIP')
    rel=p.relative_to(capture).as_posix();require(rel not in all_extracted,'extracted path represented once');all_extracted.add(rel);represented.add(member.filename)
    entry={'capture_path':rel,'original_zip_archive_path':arc,'member':member.filename,'bytes':len(data),'sha256':digest(data),'zip_crc32':f'{member.CRC:08x}','stored_separately':False}
    extracted.append(entry);members.append(entry)
  actual={p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file()}
  require(actual==represented,'no unrepresented extracted file')
  artifact_records.append({'id':row['id'],'name':row['name'],'archive_path':arc,**expected,'zip_crc_verified':True,'member_records':members})
 actual_extracted={p.relative_to(capture).as_posix() for p in (capture/'artifacts').rglob('*') if p.is_file()}
 require(actual_extracted==all_extracted and len(all_extracted)==cfg['members'],'complete whole-capture extraction census')
 source=cfg['source'];head=cfg['checkout'];workflow_path='.github/workflows/timed-hold-cloud.yml'
 require(git(repo,'diff','--name-status',source,head).decode().strip()=='A\t'+workflow_path,'workflow-only tree difference')
 publication=load(base/'hold-cloud-plan'/f'{label}-publication.json')
 require(publication['source']==source and publication['workflow']==head,'workflow publication source/head')
 parents=git(repo,'show','-s','--format=%P',head).decode().strip().split()
 require(parents==[publication['previous_aux'],source],'exact ordered auxiliary parents')
 changed=git(repo,'diff','--name-only',BASELINE,source).decode().splitlines()
 context=sorted(set(changed+CONTEXT))
 context_records=[]
 for path in context:
  data=git(repo,'show',source+':'+path);dest='source-context/'+path;raw(dest,data,'frozen_runtime_source',source+':'+path)
  context_records.append({'path':path,'bytes':len(data),'sha256':digest(data),'git_blob':git(repo,'rev-parse',source+':'+path).decode().strip()})
 workflow=git(repo,'show',head+':'+workflow_path)
 require(workflow==(base/'hold-cloud-plan'/cfg['workflow']).read_bytes(),'published workflow equals preserved snapshot')
 raw('workflow/published-timed-hold-cloud.yml',workflow,'published_workflow_snapshot',head+':'+workflow_path)
 for ref,name in [(source,'runtime-source'),(head,'workflow-head')]:
  raw('provenance/'+name+'.commit.txt',git(repo,'cat-file','commit',ref),'exact_git_commit_object',ref)
  raw('provenance/'+name+'.tree.txt',git(repo,'ls-tree','-r',ref),'complete_git_tree_object_inventory',ref)
 provenance={'status':'FAILED_DIAGNOSTIC_CAPTURE_ONLY','accepted_baseline':BASELINE,'runtime_source':source,'actual_checkout':source,'workflow_head':head,'actual_checkout_by_job':actual_checkouts,'workflow_head_parents':parents,'sole_source_tree_difference':workflow_path,'changed_source_paths_from_baseline':changed,'context_files':context_records,'source_context_scope':'Every file changed from accepted baseline plus exact Wait/native handler/input/bridge/refusal/runner context; complete Git tree inventories retain all other source blob identities.'}
 raw('provenance/source-and-workflow.json',(json.dumps(provenance,indent=2)+'\n').encode(),'source_provenance','generated_from_exact_git_objects')
 supports=SHARED_SUPPORT+cfg['support']
 supports += ['hold-cloud-plan/'+cfg['workflow']+'.manifest.json']
 supports += [f'hold-cloud-plan/{label}-{suffix}.json' for suffix in ['api-commit','publication','tree-review']]
 for stage in cfg['source_stages']:
  for name in ['api-commit.json','manifest.json','publication.json','published-blobs.json']:supports.append(stage+'/'+name)
 if label=='focus1':
  require(ident(base/'hold-rendered-semantic-audit/audit_hold.py')==load(base/'hold-rendered-semantic-audit/focus1-full-semantic-audit.json')['auditor_identity'],'exact retained full semantic auditor bytes')
  require(ident(base/'hold-contract-review/audit_focus.v2.py')['sha256']=='ab22f45a67717e8796330f0ec9760dd49448d477c2c2bb1cfb1a1c7d223f911e','frozen Focus1-v2 auditor identity')
 for relative in sorted(set(supports)):copy(base/relative,'support/'+relative,'independent_audit_or_publication_provenance')
 # Source/workflow snapshots above replace duplicate source-stage payload copies.
 copy(Path(__file__).resolve(),'build_failed_focus_evidence.py','archive_builder')
 reconstruction={'schema_version':1,'scope':'Complete original ZIPs are stored once; extracted bytes are not duplicated in this archive.','run_id':cfg['run'],'artifact_count':len(artifact_records),'extracted_file_count':len(extracted),'all_original_zip_crc_verified':True,'all_original_api_digest_size_verified':True,'every_extracted_file_byte_identical_to_original_zip_member':True,'no_unrepresented_extracted_files':True,'artifacts':artifact_records,'extracted_files':extracted,'restoration':'Extract each original-artifacts ZIP into capture/artifacts/<original artifact name>. Verify each member path, size, SHA256 and CRC using this inventory. Original capture artifact-manifest absolute local_zip paths are historical; use the archive_path mapping here.'}
 raw('extraction-inventory.json',(json.dumps(reconstruction,indent=2)+'\n').encode(),'lossless_extraction_reconstruction_inventory','generated_from_every_original_zip_and_capture_file')
 summary={'status':'FAILED_DIAGNOSTIC_ONLY_NOT_ACCEPTANCE','run_id':cfg['run'],'source':source,'actual_checkout':source,'workflow_head':head,'actual_checkout_by_job':actual_checkouts,'job_count':len(jobs),'executed_jobs':len(executed),'skipped_job_records':len(skipped),'original_artifacts':len(artifact_records),'extracted_files_reproducible':len(extracted),'diagnosis':cfg['diagnosis'],'all_capture_records_archived':True,'capture_omissions':{},'intentional_representation':['Extracted member bytes are stored inside their original ZIP once and fully inventoried, not silently omitted.','Partial duplicate captures hold-focus1-public, hold-focus1-reading and hold-focus1-render are not included; their complete original ZIPs and extraction members are already retained. The root visual review is retained separately.','Source-stage changed-file copies are replaced by exact Git source-context snapshots; their original publication/manifests are retained.','Mutable future-run auditors are excluded; frozen Focus1 v1/v2 auditor copies and dated correction receipts are used.'],'no_new_runtime_acceptance':True,'no_local_engine_or_powershell':True}
 raw('diagnostic-summary.json',(json.dumps(summary,indent=2)+'\n').encode(),'diagnostic_summary','generated_from_preserved_failed_capture')
 readme='# Timed-hold '+label+' failed diagnostic evidence\n\n'+ '\n\n'.join(cfg['diagnosis'])+'\n\nEvery executed-job log, source API/capture record, original artifact ZIP, exact source/workflow provenance and selected independent audit/correction record is retained. Each original ZIP appears once; extraction-inventory.json proves all extracted bytes are reproducible and lists their exact hashes. No extracted-member byte copy is added beside its ZIP. No current or whole-game acceptance is implied.\n'
 raw('README.md',readme.encode(),'readme','generated_scope_description')
 inventory={'schema_version':1,'run_id':cfg['run'],'scope':'Every archive payload except this inventory itself, whose identity is recorded by the external package manifest.','files':sorted(records,key=lambda r:r['archive_path'])}
 save(payload/'archive-inventory.json',inventory)
 archive=out/f'timed-hold-{label}-failed-diagnostic-evidence.tar.gz'
 require(not archive.exists(),'refuse existing archive')
 files=sorted(p for p in payload.rglob('*') if p.is_file())
 with archive.open('wb') as output:
  with gzip.GzipFile(filename='',mode='wb',fileobj=output,mtime=0,compresslevel=9) as gz:
   with tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as tar:
    for p in files:
     info=tarfile.TarInfo(p.relative_to(payload).as_posix());info.size=p.stat().st_size;info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname=''
     with p.open('rb') as f:tar.addfile(info,f)
 expected_members={p.relative_to(payload).as_posix():ident(p) for p in files}
 with tarfile.open(archive,'r:gz') as tar:
  members=tar.getmembers();require(len(members)==len(expected_members),'exact tar member count')
  require({m.name for m in members}==set(expected_members),'exact tar member names')
  for m in members:
   require(m.isfile(),'regular tar member');f=tar.extractfile(m);got={'bytes':m.size,'sha256':hashlib.file_digest(f,'sha256').hexdigest()};require(got==expected_members[m.name],'archived roundtrip identity '+m.name)
  require(sum(m.name.startswith('original-artifacts/') for m in members)==cfg['artifacts'],'every original ZIP archived once')
  require(not any(m.name.startswith('capture/artifacts/') for m in members),'no redundant extracted artifact bytes')
 archive_info=ident(archive);parts=[]
 if archive_info['bytes']>MAX_PART:
  with archive.open('rb') as stream:
   offset=0;index=1
   while data:=stream.read(MAX_PART):
    name=archive.name+f'.part{index:03d}';p=out/name;p.write_bytes(data);parts.append({'file':name,'index':index,'offset':offset,'bytes':len(data),'sha256':digest(data)});offset+=len(data);index+=1
  h=hashlib.sha256();total=0
  for item in parts:
   require(item['offset']==total and ident(out/item['file'])=={k:item[k] for k in ['bytes','sha256']},'part order/hash')
   with (out/item['file']).open('rb') as f:
    while data:=f.read(1024*1024):h.update(data);total+=len(data)
  require({'bytes':total,'sha256':h.hexdigest()}==archive_info,'ordered raw-part reassembly matches compressed tar')
 manifest={'schema_version':1,'status':'FAILED_DIAGNOSTIC_EVIDENCE_ONLY','run_id':cfg['run'],'source':source,'actual_checkout':source,'workflow_head':head,'actual_checkout_by_job':actual_checkouts,'archive':{'file':archive.name,**archive_info},'archive_members':len(files),'original_zip_count':cfg['artifacts'],'original_zip_bytes':sum(r['bytes'] for r in artifact_records),'reproducible_extracted_files':len(extracted),'reproducible_extracted_bytes':sum(r['bytes'] for r in extracted),'extraction_inventory':ident(payload/'extraction-inventory.json'),'archive_inventory':ident(payload/'archive-inventory.json'),'every_archive_member_roundtrip_verified':True,'split_required':bool(parts),'part_size_limit':MAX_PART,'parts':parts,'ordered_reassembly_verified':True,'adopt_archive_files':[r['file'] for r in parts] if parts else [archive.name],'do_not_adopt_unsplit_archive_when_parts_are_used':bool(parts),'excluded_raw_extraction_copies_have_lossless_original_zip_representation':True}
 save(out/(label+'-package-manifest.json'),manifest)
 shutil.copyfile(payload/'archive-inventory.json',out/(label+'-archive-inventory.json'))
 shutil.copyfile(payload/'extraction-inventory.json',out/(label+'-extraction-inventory.json'))
 shutil.copyfile(payload/'diagnostic-summary.json',out/(label+'-diagnostic-summary.json'))
 return manifest


def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--base',type=Path,default=Path(__file__).resolve().parents[1]);parser.add_argument('--out',type=Path,default=Path(__file__).resolve().parent);args=parser.parse_args();base=args.base.resolve();out=args.out.resolve();out.mkdir(parents=True,exist_ok=True)
 manifests={label:build(base,out,label,cfg) for label,cfg in CONFIGS.items()}
 adopt=[]
 for label,m in manifests.items():
  names=m['adopt_archive_files']+[label+'-package-manifest.json',label+'-archive-inventory.json',label+'-extraction-inventory.json',label+'-diagnostic-summary.json']
  adopt += [{'file':name,**ident(out/name)} for name in names]
 save(out/'adoption-inventory.json',{'status':'SCRATCH_STAGE_ONLY_REPO_UNCHANGED','files':adopt,'no_current_acceptance':True,'original_zip_count':sum(m['original_zip_count'] for m in manifests.values()),'all_archive_roundtrips_and_raw_part_reassemblies_verified':True})
 print(json.dumps({label:{'bytes':m['archive']['bytes'],'sha256':m['archive']['sha256'],'parts':len(m['parts']),'zip_count':m['original_zip_count'],'extracted_files':m['reproducible_extracted_files']} for label,m in manifests.items()},indent=2))
if __name__=='__main__':main()

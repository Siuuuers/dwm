#requires -Version 7.0
<#
.SYNOPSIS
External, English-only Windows release UI probe. Run ONLY on a disposable cloud runner.
.DESCRIPTION
Consumes the existing export validation ZIP; does not export, patch, inject scripts,
or enable fixture registration. Run each mode in a fresh pwsh process. A owns dispatch.
Capability uses its own empty UserRoot. Create uses a different empty UserRoot; Load
reuses Create's UserRoot and requires its result.json. Every mode needs a fresh OutputPath.
Example (replace all pins with the actual candidate and retained archive receipt):
  ./tools/testing/Invoke-ExportedGameplay.ps1 -Mode Capability -ArchivePath $zip `
    -ExpectedArchiveSha256 $sha256 -ExpectedCommit $commit -UserRoot $probe -OutputPath $out
Then Create with a different UserRoot/OutputPath, then Load with that creator UserRoot,
a third OutputPath and -CreatorReceipt <create-output>/result.json. Pass the successful
capability result.json as -CapabilityReceipt to Create. Renderer defaults to the project's
renderer; an explicit gl_compatibility run is separately scoped and recorded.
Accessibility Always and Audio Dummy are explicit cloud harness settings, not default
accessibility or audio-output qualification. Receipts bind these settings across modes.
Success means bounded machine checks passed. Screenshots require independent visual review;
UIA names alone do not prove full-line pixels. Capability is not Save/Load acceptance.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)][ValidateSet('Capability', 'Create', 'Load')][string]$Mode,
    [Parameter(Mandatory)][string]$ArchivePath,
    [Parameter(Mandatory)][ValidatePattern('^[a-fA-F0-9]{64}$')][string]$ExpectedArchiveSha256,
    [Parameter(Mandatory)][ValidatePattern('^[a-fA-F0-9]{40}$')][string]$ExpectedCommit,
    [Parameter(Mandatory)][string]$UserRoot,
    [Parameter(Mandatory)][string]$OutputPath,
    [string]$CapabilityReceipt,
    [string]$CreatorReceipt,
    [ValidateSet('ProjectDefault', 'gl_compatibility')][string]$Renderer = 'ProjectDefault',
    [ValidateSet('ProjectDefault', 'Always')][string]$Accessibility = 'ProjectDefault',
    [ValidateSet('ProjectDefault', 'Dummy')][string]$Audio = 'ProjectDefault',
    [ValidateRange(10, 60)][int]$StepTimeoutSeconds = 30,
    [ValidateRange(120, 900)][int]$JourneyTimeoutSeconds = 480
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
if (-not $IsWindows) { throw 'WINDOWS_CLOUD_RUNNER_REQUIRED' }
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class DwmExportWindow {
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
    [DllImport("user32.dll")] public static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
    private static System.Threading.Timer watchdog;
    public static volatile bool Expired;
    public static void Arm(System.Diagnostics.Process child, int milliseconds) {
        watchdog = new System.Threading.Timer(_ => {
            Expired = true;
            try { if (!child.HasExited) child.Kill(true); } catch { }
        }, null, milliseconds, System.Threading.Timeout.Infinite);
    }
    public static void Disarm() { if (watchdog != null) watchdog.Dispose(); }
}
'@
[void][DwmExportWindow]::SetThreadDpiAwarenessContext([IntPtr](-4))
$output = [IO.Path]::GetFullPath($OutputPath)
$user = [IO.Path]::GetFullPath($UserRoot)
$archive = [IO.Path]::GetFullPath($ArchivePath)
$utf8 = [Text.UTF8Encoding]::new($false)
$child = $null
$window = $null
$clock = [Diagnostics.Stopwatch]::StartNew()
$events = [Collections.Generic.List[object]]::new()
$result = [ordered]@{
    schema_version = 1; mode = $Mode; ok = $false; visual_review_required = $true
    source_commit = $ExpectedCommit.ToLowerInvariant(); archive_sha256 = $ExpectedArchiveSha256.ToLowerInvariant()
    accessibility_request = $Accessibility; audio_request = $Audio
    renderer_request = $Renderer; user_root = $user; output_path = $output
    scope = 'Ordinary release UI; normal packaged seven-day TEST story; no Challenge registration'
    forced_cleanup = $false; clean_player_exit = $false
}

function Write-Json([string]$Path, $Value) {
    [IO.File]::WriteAllText($Path, (ConvertTo-Json -InputObject $Value -Depth 100), $utf8)
}
function Read-Json([string]$Path) {
    return (Get-Content -LiteralPath $Path -Raw -Encoding utf8 | ConvertFrom-Json -AsHashtable)
}
function Hash([string]$Path) { return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
function Require([bool]$Condition, [string]$Reason) { if (-not $Condition) { throw $Reason } }
function Below([string]$Path, [string]$Parent) {
    return $Path.StartsWith($Parent.TrimEnd('\', '/') + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)
}
function Record([string]$Kind, $Data) {
    $events.Add([ordered]@{ utc = [DateTime]::UtcNow.ToString('o'); kind = $Kind; data = $Data })
    Write-Json (Join-Path $output 'events.json') $events.ToArray()
}
function Check-Live {
    Require ($clock.Elapsed.TotalSeconds -lt $JourneyTimeoutSeconds) 'JOURNEY_TIMEOUT'
    Require ($null -ne $child -and -not $child.HasExited) 'EXPORTED_PROCESS_EXITED_EARLY'
    $child.Refresh()
    Require ([IO.Path]::GetFullPath($child.MainModule.FileName) -ieq $executable) 'PROCESS_EXECUTABLE_CHANGED'
    Require ($child.StartTime.ToUniversalTime().ToString('o') -ceq $result.process.started_utc) 'PROCESS_IDENTITY_CHANGED'
}
function Window {
    Check-Live
    $handle = $child.MainWindowHandle
    if ($handle -eq [IntPtr]::Zero) { return $null }
    $owner = [uint32]0
    [void][DwmExportWindow]::GetWindowThreadProcessId($handle, [ref]$owner)
    Require ($owner -eq $child.Id) 'WINDOW_PID_MISMATCH'
    $element = [Windows.Automation.AutomationElement]::FromHandle($handle)
    Require ($element.Current.ProcessId -eq $child.Id) 'UIA_WINDOW_PID_MISMATCH'
    return $element
}
function Nodes($Root) {
    if ($null -eq $Root) { return @() }
    return @($Root.FindAll([Windows.Automation.TreeScope]::Descendants, [Windows.Automation.Condition]::TrueCondition))
}
function Visible($Element) {
    $c = $Element.Current
    return (-not $c.IsOffscreen -and -not $c.BoundingRectangle.IsEmpty -and
        $c.BoundingRectangle.Width -gt 1 -and $c.BoundingRectangle.Height -gt 1)
}
function Actions($Root, [string]$Name) {
    return @(Nodes $Root | Where-Object {
        $pattern = $null
        (Visible $_) -and $_.Current.IsEnabled -and $_.Current.Name.TrimEnd() -ceq $Name -and
            $_.TryGetCurrentPattern([Windows.Automation.InvokePattern]::Pattern, [ref]$pattern)
    })
}
function Wait-One([string]$Name, [scriptblock]$Find) {
    $watch = [Diagnostics.Stopwatch]::StartNew()
    while ($watch.Elapsed.TotalSeconds -lt $StepTimeoutSeconds) {
        $script:window = Window
        if ($null -ne $window) {
            $items = @(& $Find)
            Require ($items.Count -le 1) "UIA_AMBIGUOUS: $Name ($($items.Count))"
            if ($items.Count -eq 1) { return $items[0] }
        }
        Start-Sleep -Milliseconds 100
    }
    throw "UIA_UNAVAILABLE_OR_TIMEOUT: $Name"
}
function Button([string]$Name) { return Wait-One $Name { Actions $window $Name } }
function Describe($Element) {
    $c = $Element.Current
    return [ordered]@{ name = $c.Name; type = $c.ControlType.ProgrammaticName;
        automation_id = $c.AutomationId; runtime_id = @($Element.GetRuntimeId()); pid = $c.ProcessId;
        enabled = $c.IsEnabled; offscreen = $c.IsOffscreen;
        rectangle = @($c.BoundingRectangle.X, $c.BoundingRectangle.Y, $c.BoundingRectangle.Width, $c.BoundingRectangle.Height);
        patterns = @($Element.GetSupportedPatterns() | ForEach-Object { $_.ProgrammaticName }) }
}
function Capture([string]$Stage) {
    $script:window = Window
    Require ($null -ne $window) 'CAPTURE_WINDOW_MISSING'
    [void][DwmExportWindow]::SetForegroundWindow($child.MainWindowHandle)
    Start-Sleep -Milliseconds 200
    Require ([DwmExportWindow]::GetForegroundWindow() -eq $child.MainWindowHandle) 'CAPTURE_WINDOW_NOT_FOREGROUND'
    $records = @(Nodes $window | ForEach-Object { Describe $_ })
    Write-Json (Join-Path $output "$Stage.uia.json") $records
    $r = $window.Current.BoundingRectangle
    Require (-not $r.IsEmpty -and $r.Width -gt 0 -and $r.Height -gt 0 -and $r.Width -le 4096 -and $r.Height -le 4096) 'CAPTURE_BOUNDS_INVALID'
    $bitmap = [Drawing.Bitmap]::new([int][Math]::Ceiling($r.Width), [int][Math]::Ceiling($r.Height))
    $graphics = [Drawing.Graphics]::FromImage($bitmap)
    $path = Join-Path $output "$Stage.png"
    try {
        $graphics.CopyFromScreen([int]$r.X, [int]$r.Y, 0, 0, $bitmap.Size)
        $bitmap.Save($path, [Drawing.Imaging.ImageFormat]::Png)
    } finally { $graphics.Dispose(); $bitmap.Dispose() }
    Record 'capture' @{ stage = $Stage; file = "$Stage.png"; sha256 = (Hash $path) }
}
function Invoke-UI($Element, [string]$Purpose) {
    Check-Live
    Require ((Visible $Element) -and $Element.Current.IsEnabled) "UIA_ACTION_DISABLED: $Purpose"
    # Runtime IDs and window ancestry bind the current target even if providers omit a child PID.
    $current = $Element
    $belongs = $false
    for ($i = 0; $i -lt 64 -and $null -ne $current; $i++) {
        if ([Windows.Automation.Automation]::Compare($current, $window)) { $belongs = $true; break }
        $current = [Windows.Automation.TreeWalker]::RawViewWalker.GetParent($current)
    }
    Require $belongs 'UIA_ACTION_OUTSIDE_BOUND_WINDOW'
    Require ($window.Current.BoundingRectangle.Contains($Element.Current.BoundingRectangle)) 'UIA_ACTION_OUTSIDE_WINDOW'
    [void][DwmExportWindow]::SetForegroundWindow($child.MainWindowHandle)
    $Element.SetFocus()
    Require ([DwmExportWindow]::GetForegroundWindow() -eq $child.MainWindowHandle) 'UIA_ACTION_NOT_FOREGROUND'
    $pattern = $null
    Require ($Element.TryGetCurrentPattern([Windows.Automation.InvokePattern]::Pattern, [ref]$pattern)) 'UIA_INVOKE_UNSUPPORTED'
    Record 'invoke' @{ purpose = $Purpose; target = (Describe $Element) }
    ([Windows.Automation.InvokePattern]$pattern).Invoke()
    Start-Sleep -Milliseconds 200
}
function Caption([string]$Text) { return Button $Text }
function Observe-Line([string]$Text, [string]$Stage) {
    $null = Caption $Text
    Capture "$Stage-first-observed"
    # Text naming is not visibility proof. Keep a settled screenshot for independent review.
    Start-Sleep -Milliseconds 1600
    $null = Caption $Text
    Capture $Stage
}
function Advance([string]$From, [string]$To, [string]$Stage) {
    Invoke-UI (Caption $From) "advance: $From"
    Observe-Line $To $Stage
}
function Backup-Scope {
    # Find the nearest common accessible ancestor containing all nine uniquely named drawers.
    # If the provider flattens away the surface, refuse instead of falling back to a global match.
    $slots = @(Nodes $window | Where-Object {
        (Visible $_) -and $_.Current.ControlType -eq [Windows.Automation.ControlType]::Button -and
            $_.Current.Name -cmatch '^Slot 1, '
    })
    Require ($slots.Count -eq 1) 'BACKUP_SLOT1_UNAVAILABLE_OR_AMBIGUOUS'
    $ancestor = [Windows.Automation.TreeWalker]::RawViewWalker.GetParent($slots[0])
    for ($i = 0; $i -lt 32 -and $null -ne $ancestor; $i++) {
        Require (-not [Windows.Automation.Automation]::Compare($ancestor, $window)) 'BACKUP_PROVIDER_SURFACE_NOT_EXPOSED'
        $descendants = @(Nodes $ancestor)
        $matched = @($descendants | Where-Object {
            (Visible $_) -and $_.Current.ControlType -eq [Windows.Automation.ControlType]::Button -and
                $_.Current.Name -cmatch '^(Autosave|Quick|Slot [1-7]), '
        })
        if ($matched.Count -eq 9) {
            $identities = @($matched | ForEach-Object { ($_.Current.Name -split ', ', 2)[0] } | Sort-Object -Unique)
            Require ($identities.Count -eq 9) 'BACKUP_DRAWERS_NOT_UNIQUE'
            return $ancestor
        }
        $ancestor = [Windows.Automation.TreeWalker]::RawViewWalker.GetParent($ancestor)
    }
    throw 'BACKUP_PROVIDER_SURFACE_NOT_EXPOSED'
}
function Select-Slot([int]$Number) {
    $scope = Backup-Scope
    $slots = @(Nodes $scope | Where-Object {
        (Visible $_) -and $_.Current.ControlType -eq [Windows.Automation.ControlType]::Button -and
            $_.Current.Name.StartsWith("Slot $Number, ", [StringComparison]::Ordinal)
    })
    Require ($slots.Count -eq 1) 'BACKUP_SLOT_UNAVAILABLE_OR_AMBIGUOUS'
    Invoke-UI $slots[0] "select slot $Number"
}
function Backup-Action([string]$Name) {
    $scope = Backup-Scope
    $drawers = @(Nodes $scope | Where-Object {
        (Visible $_) -and $_.Current.ControlType -eq [Windows.Automation.ControlType]::Button -and
            $_.Current.Name -cmatch '^(Autosave|Quick|Slot [1-7]), '
    })
    # Existing Backup layout has the action dock right of the grid, in its lower half.
    # Mode controls are above the grid. Geometry is observed, never a fixed click coordinate.
    $right = ($drawers | ForEach-Object { $_.Current.BoundingRectangle.Right } | Measure-Object -Maximum).Maximum
    $bottom = ($drawers | ForEach-Object { $_.Current.BoundingRectangle.Bottom } | Measure-Object -Maximum).Maximum
    $top = ($drawers | ForEach-Object { $_.Current.BoundingRectangle.Top } | Measure-Object -Minimum).Minimum
    $actions = @(Actions $scope $Name | Where-Object {
        $_.Current.BoundingRectangle.Left -ge $right -and $_.Current.BoundingRectangle.Top -ge ($top + $bottom) / 2
    })
    Require ($actions.Count -eq 1) "BACKUP_ACTION_UNAVAILABLE_OR_AMBIGUOUS: $Name"
    Record 'backup-action-scope' @{ action = $Name; surface = (Describe $scope); target = (Describe $actions[0]) }
    return $actions[0]
}
function Reading-Save {
    # SceneHost also has a left Save control. Select the unique bottom reading rail action.
    return Wait-One 'reading Save rail' {
        $r = $window.Current.BoundingRectangle
        Actions $window 'Save' | Where-Object {
                $_.Current.BoundingRectangle.Top -gt $r.Top + $r.Height * 0.7
        }
    }
}
function Wait-File([string]$Path) {
    $watch = [Diagnostics.Stopwatch]::StartNew()
    while ($watch.Elapsed.TotalSeconds -lt $StepTimeoutSeconds) {
        Check-Live
        if (Test-Path -LiteralPath $Path -PathType Leaf) {
            try { $value = Read-Json $Path; if ($value.Contains('current_snapshot')) { return $value } } catch { }
        }
        Start-Sleep -Milliseconds 100
    }
    throw "SAVE_FILE_TIMEOUT: $Path"
}
function Save-Slot([int]$Number) {
    Invoke-UI (Reading-Save) "open Save for slot $Number"
    $null = Wait-One 'Backup drawers' {
        Nodes $window | Where-Object { (Visible $_) -and $_.Current.ControlType -eq [Windows.Automation.ControlType]::Button -and $_.Current.Name.TrimEnd() -ceq "Slot $Number, Empty" }
    }
    Select-Slot $Number
    Capture "save-$Number-selected"
    Invoke-UI (Backup-Action 'Save') "commit empty slot $Number"
    $path = Join-Path $dataRoot "saves/slot_$Number.json"
    $document = Wait-File $path
    $null = Wait-One 'Saved status' { Nodes $window | Where-Object { (Visible $_) -and $_.Current.Name.TrimEnd() -ceq 'Saved' } }
    Capture "save-$Number-complete"
    Invoke-UI (Button 'Back') 'close direct Backup host'
    return $document
}
function Snapshot($Document) {
    Require ($Document.Contains('current_snapshot') -and $Document.current_snapshot.Contains('snapshot')) 'SAVE_ENVELOPE_UNEXPECTED'
    return $Document.current_snapshot.snapshot
}
function Canonical($Value) {
    if ($null -eq $Value) { return 'null' }
    if ($Value -is [Collections.IDictionary]) {
        $parts = @($Value.Keys | Sort-Object -CaseSensitive | ForEach-Object {
            (ConvertTo-Json -InputObject ([string]$_) -Compress) + ':' + (Canonical $Value[$_])
        })
        return '{' + ($parts -join ',') + '}'
    }
    if ($Value -is [array]) { return '[' + ((@($Value | ForEach-Object { Canonical $_ })) -join ',') + ']' }
    return ConvertTo-Json -InputObject $Value -Compress -Depth 100
}
function End-Process([bool]$AtTitle) {
    if ($AtTitle) {
        Invoke-UI (Button 'Shut down') 'request normal shutdown'
        $sheet = Wait-One 'Shut down confirmation' {
            Nodes $window | Where-Object { (Visible $_) -and $_.Current.Name.TrimEnd() -ceq 'Shut down?' -and @(Actions $_ 'Shut down').Count -eq 1 }
        }
        Invoke-UI (@(Actions $sheet 'Shut down')[0]) 'confirm normal shutdown'
    } else {
        Capture 'before-window-close'
        $pattern = $null
        Require ($window.TryGetCurrentPattern([Windows.Automation.WindowPattern]::Pattern, [ref]$pattern)) 'NORMAL_WINDOW_CLOSE_UNAVAILABLE'
        Record 'window-close' @{ method = 'UIAutomation.WindowPattern.Close'; pid = $child.Id }
        ([Windows.Automation.WindowPattern]$pattern).Close()
    }
    Require ($child.WaitForExit($StepTimeoutSeconds * 1000)) 'PLAYER_EXIT_TIMEOUT'
    $result.exit_code = $child.ExitCode
    Require ($child.ExitCode -eq 0) 'PLAYER_EXIT_NONZERO'
    $result.clean_player_exit = $true
}
function Receipt([string]$Path, [string]$ExpectedMode) {
    Require (-not [string]::IsNullOrWhiteSpace($Path)) "$ExpectedMode`_RECEIPT_REQUIRED"
    $r = Read-Json ([IO.Path]::GetFullPath($Path))
    Require ($r.ok -and $r.clean_player_exit -and -not $r.forced_cleanup -and $r.mode -ceq $ExpectedMode) 'PREREQUISITE_NOT_SUCCESSFUL'
    Require ($r.archive_sha256 -ceq $result.archive_sha256 -and $r.source_commit -ceq $result.source_commit -and
        $r.renderer_request -ceq $Renderer) 'PREREQUISITE_PACKAGE_OR_RENDERER_MISMATCH'
    Require ($r.accessibility_request -ceq $Accessibility -and $r.audio_request -ceq $Audio) 'PREREQUISITE_ACCESSIBILITY_OR_AUDIO_MISMATCH'
    return $r
}

# No cleanup of caller directories, including on failure. Only the process we launch may be killed.
Require (-not (Test-Path -LiteralPath $output)) 'OUTPUT_MUST_NOT_EXIST'
Require ($output -ine $user -and -not (Below $output $user) -and -not (Below $user $output)) 'USER_OUTPUT_ROOTS_MUST_BE_DISJOINT'
Require (-not (Below $archive $output) -and -not (Below $archive $user)) 'ARCHIVE_MUST_BE_OUTSIDE_WORK_ROOTS'
New-Item -ItemType Directory -Path $output | Out-Null
try {
    Require ((Hash $archive) -ceq $result.archive_sha256) 'ARCHIVE_CHECKSUM_MISMATCH'
    if ($Mode -eq 'Create') { $result.capability = Receipt $CapabilityReceipt 'Capability' }
    if ($Mode -eq 'Load') {
        $creator = Receipt $CreatorReceipt 'Create'
        Require ($creator.user_root -ieq $user) 'CREATOR_USER_ROOT_MISMATCH'
    } else {
        Require (-not (Test-Path -LiteralPath $user)) 'CAPABILITY_CREATE_USER_ROOT_MUST_NOT_EXIST'
        New-Item -ItemType Directory -Path $user | Out-Null
    }
    $package = Join-Path $output 'package'
    New-Item -ItemType Directory -Path $package | Out-Null
    $zip = [IO.Compression.ZipFile]::OpenRead($archive)
    try {
        $seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
        $total = [long]0
        foreach ($entry in $zip.Entries) {
            $destination = [IO.Path]::GetFullPath((Join-Path $package $entry.FullName))
            Require ((Below $destination $package) -and $seen.Add($destination) -and $entry.FullName -notmatch ':') 'UNSAFE_OR_DUPLICATE_ARCHIVE_ENTRY'
            $total += $entry.Length
            Require ($total -le 2GB) 'ARCHIVE_EXPANDED_SIZE_LIMIT'
            if ($entry.FullName.EndsWith('/')) { New-Item -ItemType Directory -Force -Path $destination | Out-Null; continue }
            New-Item -ItemType Directory -Force -Path ([IO.Path]::GetDirectoryName($destination)) | Out-Null
            [IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $destination, $false)
        }
    } finally { $zip.Dispose() }
    $validation = Read-Json (Join-Path $package 'validation.json')
    Require ($validation.ok -and $validation.commit -ceq $result.source_commit -and $validation.engine -ceq '4.6.3.stable') 'EXPORT_RECEIPT_PIN_MISMATCH'
    $listed = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($file in $validation.files) {
        $path = [IO.Path]::GetFullPath((Join-Path $package $file.path))
        Require ((Below $path $package) -and $listed.Add($path)) 'EXPORT_MANIFEST_PATH_INVALID'
        Require ((Get-Item -LiteralPath $path).Length -eq $file.bytes -and (Hash $path) -ceq $file.sha256) 'EXPORTED_FILE_HASH_MISMATCH'
    }
    foreach ($file in Get-ChildItem -LiteralPath $package -Recurse -File) {
        Require ($listed.Contains($file.FullName) -or $file.FullName -ieq (Join-Path $package 'validation.json')) 'UNLISTED_PACKAGE_FILE'
    }
    $executable = Join-Path $package 'DWM.exe'
    Require ($listed.Contains($executable) -and $listed.Contains((Join-Path $package 'DWM.pck'))) 'EXPORTED_EXECUTABLE_OR_PACK_UNLISTED'
    $result.executable_sha256 = Hash $executable
    $result.pck_sha256 = Hash (Join-Path $package 'DWM.pck')
    $dataRoot = Join-Path $user 'appdata/Godot/app_userdata/DWM'
    $profilePath = Join-Path $dataRoot 'profile.json'
    $slotPath = Join-Path $dataRoot 'saves/slot_1.json'
    if ($Mode -eq 'Load') {
        Require ((Hash $slotPath) -ceq $creator.source_slot_sha256) 'CREATOR_SLOT_CHANGED_BEFORE_LOAD'
        Require (-not (Test-Path -LiteralPath (Join-Path $dataRoot 'saves/slot_2.json'))) 'RESTORE_WITNESS_SLOT_NOT_EMPTY'
        $sourceSnapshot = Snapshot (Read-Json $slotPath)
        Require ((Hash $profilePath) -ceq $creator.source_profile_sha256) 'CREATOR_PROFILE_CHANGED_BEFORE_LOAD'
        $sourceProfile = Read-Json $profilePath
        Copy-Item -LiteralPath $profilePath -Destination (Join-Path $output 'profile-before-load.json')
    }
    $log = Join-Path $output 'game.log'
    $start = [Diagnostics.ProcessStartInfo]::new()
    $start.FileName = $executable
    $start.WorkingDirectory = $package
    $start.UseShellExecute = $false
    foreach ($argument in @('--windowed', '--resolution', '1280x720', '--log-file', $log)) { $start.ArgumentList.Add($argument) }
    if ($Renderer -ne 'ProjectDefault') { $start.ArgumentList.Add('--rendering-method'); $start.ArgumentList.Add($Renderer) }
    if ($Accessibility -eq 'Always') { $start.ArgumentList.Add('--accessibility'); $start.ArgumentList.Add('always') }
    if ($Audio -eq 'Dummy') { $start.ArgumentList.Add('--audio-driver'); $start.ArgumentList.Add('Dummy') }
    foreach ($name in @($start.Environment.Keys | Where-Object { $_ -like 'DWM_*' })) { [void]$start.Environment.Remove($name) }
    foreach ($name in @('APPDATA', 'LOCALAPPDATA')) {
        $directory = Join-Path $user $name.ToLowerInvariant()
        New-Item -ItemType Directory -Force -Path $directory | Out-Null
        $start.Environment[$name] = $directory
    }
    $child = [Diagnostics.Process]::new(); $child.StartInfo = $start
    Require ($child.Start()) 'EXPORT_LAUNCH_FAILED'
    # Also bounds a blocking native UIA provider call, not just polling loops.
    [DwmExportWindow]::Arm($child, [int][Math]::Max(1, ($JourneyTimeoutSeconds - $clock.Elapsed.TotalSeconds) * 1000))
    $result.process = @{ pid = $child.Id; started_utc = $child.StartTime.ToUniversalTime().ToString('o'); executable = $executable; arguments = @($start.ArgumentList) }
    $nativeProcess = Get-CimInstance Win32_Process -Filter "ProcessId = $($child.Id)"
    Require ($null -ne $nativeProcess -and [string]$nativeProcess.ExecutablePath -ieq $executable) 'NATIVE_PROCESS_PATH_MISMATCH'
    $result.process.observed_command_line = [string]$nativeProcess.CommandLine
    $null = Button 'New Acc'
    Capture 'title'
    if ($Mode -eq 'Load') {
        Require ($creator.process.pid -ne $child.Id -or $creator.process.started_utc -cne $result.process.started_utc) 'LOAD_NOT_DISTINCT_PROCESS'
        Invoke-UI (Button 'Log in') 'open selected-slot Load from Title'
        $null = Wait-One 'saved slot drawer' { Nodes $window | Where-Object { (Visible $_) -and $_.Current.ControlType -eq [Windows.Automation.ControlType]::Button -and $_.Current.Name -cmatch '^Slot 1, ' } }
        Select-Slot 1
        Capture 'load-slot-selected'
        Invoke-UI (Backup-Action 'Load') 'load source slot 1'
        # Title login may not require a confirmation. Never invoke a duplicate global Load.
        $watch = [Diagnostics.Stopwatch]::StartNew()
        while ($watch.Elapsed.TotalSeconds -lt $StepTimeoutSeconds) {
            $script:window = Window
            if (@(Actions $window 'TEST Day4 closing.').Count -eq 1) { break }
            $sheets = @(Nodes $window | Where-Object { (Visible $_) -and $_.Current.Name.TrimEnd() -ceq 'Load Slot 1?' -and @(Actions $_ 'Load').Count -eq 1 })
            Require ($sheets.Count -le 1) 'LOAD_CONFIRMATION_AMBIGUOUS'
            if ($sheets.Count -eq 1) { Invoke-UI (@(Actions $sheets[0] 'Load')[0]) 'confirm source slot Load'; break }
            Start-Sleep -Milliseconds 100
        }
        Observe-Line 'TEST Day4 closing.' 'restored-day4'
        $restored = Snapshot (Save-Slot 2)
        foreach ($key in @('narrative_checkpoint', 'gameplay', 'scene', 'command_receipts', 'applied_effect_transaction_ids', 'applied_variable_transaction_ids')) {
            Require ($sourceSnapshot.Contains($key) -and $restored.Contains($key)) "RESTORE_WITNESS_FIELD_MISSING: $key"
            Require ((Canonical $sourceSnapshot[$key]) -ceq (Canonical $restored[$key])) "RESTORED_STATE_CHANGED: $key"
        }
        Require ($restored.lifecycle.run_id -ceq $sourceSnapshot.lifecycle.run_id -and $restored.lifecycle.branch_id -cne $sourceSnapshot.lifecycle.branch_id) 'RESTORED_RUN_BRANCH_SEMANTICS'
        $restoredProfile = Read-Json $profilePath
        Require ((Canonical $restoredProfile) -ceq (Canonical $sourceProfile)) 'LOAD_OR_WITNESS_SAVE_CHANGED_PROFILE'
        Copy-Item -LiteralPath $profilePath -Destination (Join-Path $output 'profile-after-load.json')
        Copy-Item -LiteralPath (Join-Path $dataRoot 'saves/slot_2.json') -Destination (Join-Path $output 'restored-slot-2.json')
        Observe-Line 'TEST Day4 closing.' 'restored-after-witness-save'
        $previous = 'TEST Day4 closing.'
        for ($day = 5; $day -le 7; $day++) {
            foreach ($half in @('opening', 'closing')) {
                $next = "TEST Day$day $half."
                Advance $previous $next "day-$day-$half"
                $previous = $next
            }
        }
        Advance $previous 'TEST Seven-day ending.' 'ending'
        Invoke-UI (Caption 'TEST Seven-day ending.') 'finish ending'
        $null = Button 'New Acc'
        Capture 'ending-return-title'
        $completed = Snapshot (Read-Json (Join-Path $dataRoot 'saves/autosave.json'))
        Require ($completed.lifecycle.state -ceq 'COMPLETED' -and $completed.lifecycle.ending_plan.playback_stage -ceq 'GALLERY_RECORDED') 'ENDING_NOT_DURABLY_COMPLETED'
        $completedProfile = Read-Json $profilePath
        $galleryKey = 'ending:' + $sourceSnapshot.lifecycle.run_id + ':gallery:ending.alone'
        Require ($completedProfile.gallery_transaction_receipts.Contains($galleryKey)) 'ENDING_GALLERY_RECEIPT_MISSING'
        Require ((Canonical $completedProfile.gallery_transaction_receipts[$galleryKey]) -ceq (Canonical @{ ending_id = 'ending.alone'; unlocked = $true })) 'ENDING_GALLERY_RECEIPT_WRONG'
        Require ($completedProfile.gallery_transaction_receipts.Count -eq $sourceProfile.gallery_transaction_receipts.Count + 1 -and
            'ending.alone' -cin $completedProfile.gallery_unlocks) 'ENDING_GALLERY_AWARD_COUNT'
        foreach ($key in $sourceProfile.gallery_transaction_receipts.Keys) {
            Require ($completedProfile.gallery_transaction_receipts.Contains($key) -and
                (Canonical $completedProfile.gallery_transaction_receipts[$key]) -ceq (Canonical $sourceProfile.gallery_transaction_receipts[$key])) 'PRIOR_GALLERY_RECEIPT_CHANGED'
        }
        Copy-Item -LiteralPath (Join-Path $dataRoot 'saves/autosave.json') -Destination (Join-Path $output 'completed-autosave.json')
        $result.restored_checkpoint_matches = $true
        End-Process $true
    } else {
        Invoke-UI (Button 'New Acc') 'ordinary New Game'
        Observe-Line 'TEST Day1 opening.' 'new-game'
        Invoke-UI (Button 'Check Computer') 'open Computer'
        $null = Button 'Close Computer'
        Capture 'computer-open'
        Invoke-UI (Button 'Close Computer') 'close Computer'
        Observe-Line 'TEST Day1 opening.' 'computer-closed-same-caption'
        if ($Mode -eq 'Capability') {
            Invoke-UI (Reading-Save) 'discover Backup without saving'
            $null = Wait-One 'empty slot drawer' { Nodes $window | Where-Object { (Visible $_) -and $_.Current.ControlType -eq [Windows.Automation.ControlType]::Button -and $_.Current.Name.TrimEnd() -ceq 'Slot 1, Empty' } }
            Select-Slot 1
            $null = Backup-Action 'Save'
            Capture 'capability-backup-action'
            Require (-not (Test-Path -LiteralPath $slotPath)) 'CAPABILITY_UNEXPECTED_MANUAL_SAVE'
            End-Process $false
        } else {
            $previous = 'TEST Day1 opening.'
            for ($day = 1; $day -le 4; $day++) {
                foreach ($half in @('opening', 'closing')) {
                    if ($day -eq 1 -and $half -ceq 'opening') { continue }
                    $next = "TEST Day$day $half."
                    Advance $previous $next "day-$day-$half"
                    $previous = $next
                }
            }
            $sourceSnapshot = Snapshot (Save-Slot 1)
            Require ($sourceSnapshot.narrative_checkpoint.reading_session.frontier.line_id -ceq 'line.Day4.two') 'WRONG_SAVED_FRONTIER'
            $result.source_slot_sha256 = Hash $slotPath
            Copy-Item -LiteralPath $slotPath -Destination (Join-Path $output 'source-slot-1.json')
            Observe-Line 'TEST Day4 closing.' 'saved-day4'
            End-Process $false
        }
    }
    if ($Mode -eq 'Load') { Require ((Hash $slotPath) -ceq $creator.source_slot_sha256) 'SOURCE_SLOT_MUTATED' }
    if ($Mode -eq 'Create') { Require ((Hash $slotPath) -ceq $result.source_slot_sha256) 'SOURCE_SLOT_MUTATED_ON_EXIT' }
    Require (Test-Path -LiteralPath $log -PathType Leaf) 'GAME_LOG_MISSING'
    $logText = Get-Content -LiteralPath $log -Raw -Encoding utf8
    Require ($logText -notmatch '(?m)SCRIPT ERROR:|^\s*ERROR:|STARTUP_FAILED|Unicode parsing error|Unexpected NUL character') 'GAME_ERROR_LOG'
    $result.renderer_log = @($logText -split '\r?\n' | Where-Object { $_ -match 'Vulkan|OpenGL|D3D12|Direct3D|Rendering' })
    if (Test-Path -LiteralPath $profilePath) { Copy-Item -LiteralPath $profilePath -Destination (Join-Path $output 'profile-after.json') }
    if ($Mode -eq 'Create') { $result.source_profile_sha256 = Hash $profilePath }
    Require (-not [DwmExportWindow]::Expired) 'EXPORTED_PROCESS_WATCHDOG_TIMEOUT'
    $result.ok = $true
} catch {
    $result.failure = $_.Exception.Message
    try { if ($null -ne $child -and -not $child.HasExited) { Capture 'failure' } } catch { $result.capture_failure = $_.Exception.Message }
    throw
} finally {
    [DwmExportWindow]::Disarm()
    if ([DwmExportWindow]::Expired) { $result.forced_cleanup = $true; $result.ok = $false; $result.watchdog_expired = $true }
    if ($null -ne $child) {
        if (-not $child.HasExited) {
            $result.forced_cleanup = $true
            $result.ok = $false
            $child.Kill($true)
            [void]$child.WaitForExit(10000)
        }
        $child.Dispose()
    }
    $result.elapsed_seconds = $clock.Elapsed.TotalSeconds
    Write-Json (Join-Path $output 'result.json') $result
    $evidence = @(Get-ChildItem -LiteralPath $output -File | Sort-Object Name | ForEach-Object {
        @{ file = $_.Name; bytes = $_.Length; sha256 = (Hash $_.FullName) }
    })
    Write-Json (Join-Path $output 'manifest.json') $evidence
}

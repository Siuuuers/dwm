from audit_history_comparisons import *
import sys
name=sys.argv[1];warm=name=='warm-outgoing-proof';prefix='WARM_OUTGOING_PROOF' if warm else 'HISTORY_REGION_SEARCH';count=24 if warm else 16
jid=next(j['id'] for j in read(RUN/'jobs.json')['jobs'] if j['name']==f'Windows / {name} comparison')
success=prefix+'_VERIFIED: '
P,D,L,r,result=base(name,jid,success,count)
assert r['run_id']==str(RUNID) and r['input_sha256']==H and r['retained_checkpoint_count']==66
mapping={'port':'scripts/application/run/SaveManagerCheckpointPort.gd','schema':'scripts/infrastructure/save/SaveDocumentSchema.gd','warm_provenance':'tools/testing/Assert-WarmOutgoingProofBaseline.ps1','journal':'scripts/infrastructure/save/CheckpointJournal.gd','storage':'scripts/infrastructure/storage/JsonFileStorage.gd','file_ops':'tests/support/FakeFileOps.gd','reference':'tests/support/'+('WarmOutgoingProofReference.gd' if warm else 'HistoryRegionSearchReference.gd'),'harness':'tests/manual/'+('benchmark_warm_outgoing_proofs.gd' if warm else 'benchmark_history_region_search.gd'),'driver':'tools/testing/'+('Invoke-WarmOutgoingProofPerformance.ps1' if warm else 'Invoke-HistoryRegionSearchPerformance.ps1')}
if warm:mapping['journal_reference']='tests/support/WarmOutgoingJournalReference.gd'
else:mapping['warm_reference']='tests/support/WarmOutgoingProofReference.gd'
sourcecheck(r,mapping)
provenance=read(RUN/'audit/warm-source-provenance.json');assert provenance['tested_merge']==MERGE and provenance['status']=='verified'
modes=['cold','mixed','warm'] if warm else ['cold','mixed'];metrics=['schema_composition','port_commit_fake_io'] if warm else ['learning_seam','port_commit_fake_io']
assert len(r['pairs'])==count//2
assert {(p['mode'],p['pair']) for p in r['pairs']}=={(m,i) for m in modes for i in range(1,5)}
assert markers(RUN/f'logs/{jid}.log',prefix+'_PAIR: ')==r['pairs']
summary=markers(RUN/f'logs/{jid}.log',prefix+'_COMPARISON: ');assert len(summary)==1
for k,v in summary[0].items():assert r[k]==v
invariant_fields=['input_sha256','output_sha256','bytes','proof_seed','proof_seed_sha256','final_proof_manifest','final_proof_manifest_sha256','prior_journal_sha256','final_journal_sha256','initial_proofs_present','initial_proofs_missing','evidence','reference_commit','reference_port_source_sha256','candidate_port_source_sha256']
if warm:invariant_fields+=['reference_schema_source_sha256','reference_commit_method_sha256','reference_splice_method_sha256','reference_validate_method_sha256','reference_journal_commit','reference_journal_source_sha256','reference_remember_method_sha256','candidate_schema_source_sha256','candidate_journal_source_sha256','journal_reference_source_sha256','control_boundary','scope','timing_boundary']
else:invariant_fields+=['reference_method_sha256']
mode_invariants={}
for row in r['pairs']:
    mode=row['mode'];i=row['pair'];assert row['order']==(['baseline','candidate'] if i%2 else ['candidate','baseline']);present={'cold':0,'mixed':51,'warm':66}[mode]
    for v in row['order']:
        x=row[v];assert raw(L/f'cloud-{name}-{mode}-{i}-{v}.log',prefix+'_BENCHMARK: ')==[x]
        assert x['variant']==v and x['mode']==mode and x['input_sha256']==x['output_sha256']==H and x['bytes']==SIZE
        assert x['journal_bundles']==x['validated_journal_bundles']==66 and x['retained']=={'line':32,'manual_save':32,'semantic':2} and x['schema_version']==x['snapshot_schema_version']==7
        assert x['warmup_count']==2 and x['sample_count']==5 and x['initial_proofs_present']==present and x['initial_proofs_missing']==66-present and len(x['proof_seed'])==present and len(x['final_proof_manifest'])==66
        for k in ['source_unchanged','exact_proof_strings_and_documents','exact_physical_bytes']:assert x[k] is True
        assert x['candidate_port_source_sha256']==r['source_sha256']['port']
        if warm:
            assert x['exact_composed_values_types_and_bytes'] is True and x['reference_commit']==x['reference_journal_commit']==provenance['reference_commit']
            for k in ['port','schema','journal']:assert x[f'reference_{k}_source_sha256']==provenance['reference_source_sha256'][k] and x[f'candidate_{k}_source_sha256']==r['source_sha256'][k]
            for field,method in [('commit','commit'),('splice','_splice_autosave_text'),('validate','_validate_document'),('remember','remember_written_retained_bundle')]:assert x[f'reference_{field}_method_sha256']==provenance['reference_method_sha256'][method]
            assert x['journal_reference_source_sha256']==r['source_sha256']['journal_reference']
        else:
            assert x['reference_commit']==provenance['history_region_reference_commit'] and x['reference_port_source_sha256']==provenance['history_region_port_sha256'] and x['reference_method_sha256']==provenance['history_region_method_sha256']
        for metric in metrics:
            samples=x[metric+'_samples_us'];assert len(samples)==5 and min(samples)>=0 and statistics.median(samples)==x[metric+'_median_us']
            assert x['evidence'][metric]['journal_sha256']==x['final_journal_sha256']
        assert x['evidence'][metrics[0]]['operation_trace']==[] and len(x['evidence']['port_commit_fake_io']['operation_trace'])>0
        if warm:
            e=x['evidence'];assert e['schema_composition']['final_proof_count']==present and e['port_commit_fake_io']['final_proof_count']==66
            assert len(e['schema_composition']['proof_state'])==len(e['port_commit_fake_io']['proof_state'])==66 and len(e['schema_composition']['composed_type_sha256'])==64
        inv={f:x[f] for f in invariant_fields}
        if mode in mode_invariants:assert inv==mode_invariants[mode]
        else:mode_invariants[mode]=inv
    for metric in metrics:assert row['candidate_minus_baseline_us'][metric]==row['candidate'][metric+'_median_us']-row['baseline'][metric+'_median_us']
assert len(r['summaries'])==len(modes)*len(metrics)
for s in r['summaries']:
    selected=[p for p in r['pairs'] if p['mode']==s['mode']];metric=s['metric'];assert len(selected)==s['pairs']==4
    for v in ['baseline','candidate']:assert s[v+'_median_us']==statistics.median(p[v][metric+'_median_us'] for p in selected)
    assert s['median_paired_candidate_minus_baseline_us']==statistics.median(p['candidate_minus_baseline_us'][metric] for p in selected)
result.update({'source_sha256':r['source_sha256'],'source_guard_path':str(RUN/'audit/warm-source-provenance.json'),'source_guard_sha256':sha((RUN/'audit/warm-source-provenance.json').read_bytes()),'exact_current_and_historical_source_boundaries_verified':True,'modes':modes,'pairs_per_mode':4,'samples_per_metric_process':5,'warmups_per_metric_process':2,'raw_measurements_and_summary_medians_verified':True,'exact_proof_manifest_journal_file_hash_ordered_trace_invariants_verified':True,'initial_proof_counts':{m:{'present':{'cold':0,'mixed':51,'warm':66}[m],'missing':66-{'cold':0,'mixed':51,'warm':66}[m]} for m in modes},'summaries':r['summaries'],'sampling':r['sampling'],'scope':r['scope'],'limitations':['FakeFileOps reproduces storage protocol and exact bytes/ordered traces; these measurements do not time physical disk, public preparation, gameplay, rendering, or input-to-paint.','Per-mode alternating pair samples on separate shared Windows runners are observations with no performance threshold; they do not establish a new Pause Save speedup.']})
write_result(name,result)

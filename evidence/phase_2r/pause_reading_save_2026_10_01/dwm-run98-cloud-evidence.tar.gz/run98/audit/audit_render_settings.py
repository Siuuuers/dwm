from pathlib import Path
import json, hashlib, re, struct, zipfile, xml.etree.ElementTree as E
ROOT=Path('/workspace/scratch/e6146007a498/run98')
ART=ROOT/'artifacts'
OUT=ROOT/'audit/render-settings-audit.json'
RUN='36877062304'
MERGE='5792c629b9e0bfe27ce4d5b2b07837dc6a070fbf'
SOURCE='36d2fdca56c53c0d6b8571ded45e92fc6d3a9e91'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
    def pairs(items):
        d={}
        for k,v in items:
            assert k not in d,(str(p),'duplicate JSON key',k)
            d[k]=v
        return d
    return json.loads(p.read_text(encoding='utf-8-sig'),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
def relative(p):return str(p.relative_to(ROOT))
def png(p):
    b=p.read_bytes();assert b[:8]==b'\x89PNG\r\n\x1a\n'
    w,h=struct.unpack('>II',b[16:24]);assert w>0 and h>0
    return {'file':relative(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'width':w,'height':h}

def artifact(prefix):
    name=f'{prefix}-{RUN}-1';p=ART/name
    if not p.exists():return None
    m=next(x for x in read(ROOT/'artifact-manifest.json') if x['name']==name)
    z=Path(m['local_zip']);assert z.stat().st_size==m['size_in_bytes'] and 'sha256:'+sha(z)==m['digest']
    members=0
    with zipfile.ZipFile(z) as f:
        for i in f.infolist():
            q=Path(i.filename);assert not q.is_absolute() and '..' not in q.parts
            if i.is_dir():continue
            target=p/q;assert target.is_file() and target.read_bytes()==f.read(i),str(target)
            members+=1
    assert m['workflow_run']['id']==int(RUN) and m['workflow_run']['head_sha']==SOURCE
    return p,{'name':name,'id':m['id'],'bytes':m['size_in_bytes'],'verified_zip_sha256':sha(z),'verified_file_members':members}

def clean_log(p):
    s=p.read_text(errors='replace')
    found=re.findall(r'^.*(?:SCRIPT ERROR:|(?:^|\s)ERROR:|Unicode parsing error|Unexpected NUL character|Parse Error:).*$' ,s,re.M)
    assert not found,(str(p),found[:3])
    return s

report={'schema_version':1,'run_id':int(RUN),'attempt':1,'candidate_source':SOURCE,'tested_merge':MERGE,
        'audit_complete':False,'runtime_proof_failures':[],'pending_areas':[],
        'rendered_groups':[],'literal_audit':None,'playable_journeys':None,'reading_journey':None,'settings':None,
        'limits':['Artifact assertions and raw evidence are audited; no new Godot or PowerShell execution occurs locally.',
                  'Rendered UI uses Linux software OpenGL; this is not full native Windows all-input acceptance.',
                  'Pixel hashes and dimensions plus produced geometry/contrast assertions are checked; this is not a separate visual review of every screenshot.',
                  'Reading dialogue/catalogue is explicitly noncanonical and production registration remains disabled.']}
for prefix,count,marker in [('desktop-scaling-render',38,'DESKTOP_SCALING_RENDER_VERIFIED'),('delivery-dialogue-render',25,'DELIVERY_DIALOGUE_RENDER_VERIFIED'),('angela-overlay-render',10,'ANGELA_OVERLAY_RENDER_VERIFIED'),('japanese-korean-ui-render',30,'JAPANESE_KOREAN_UI_RENDER_VERIFIED'),('font-choices-render',30,'FONT_CHOICES_RENDER_VERIFIED'),('playable-startup-render',4,'PLAYABLE_STARTUP_RENDER_VERIFIED')]:
    got=artifact(prefix)
    if got is None:report['pending_areas'].append(prefix);continue
    p,receipt=got;x=read(p/'results.json');assert x['ok'] is True and not x.get('failures',[]) and x['captures']==count
    if prefix!='playable-startup-render':assert x['samples']==count and x['renderer']!='headless'
    pics=sorted(p.glob('*.png'));assert len(pics)==count
    log=clean_log(p/'render.log')
    if prefix=='playable-startup-render':
        for m in ['PLAYABLE_STARTUP_PASS','PLAYABLE_DAY_PASS','PLAYABLE_LOGOUT_PASS']:assert m in log
        assert sorted(x['files'])==sorted(q.name for q in pics)
    else:assert marker in log
    item={'group':prefix,'ok':True,'samples':x.get('samples',count),'captures':count,'renderer':x.get('renderer','rendered startup per process log'),'artifact':receipt,'report':relative(p/'results.json'),'report_sha256':sha(p/'results.json'),'captures_verified':[png(q) for q in pics]}
    if prefix=='angela-overlay-render':
        assert len(x['crop_checks'])==2 and all(v['identical'] and v['maximum_channel_difference']==0 for v in x['crop_checks']);item['crop_checks']=x['crop_checks']
    report['rendered_groups'].append(item)
# Literal source hash verification uses the candidate bytes (root separately proves merge equivalence).
got=artifact('ui-literal-audit')
if got is not None:
    p,receipt=got;items=[]
    clean_log(p/'audit.log')
    for name in ['ui_literal_disposition','script_ui_disposition']:
        q=p/(name+'.json');x=read(q);assert not x['failures'] and x['records'] and len(x['source_paths'])==x['source_count']
        for rec in x['records']:
            source=Path('/workspace/scratch/e6146007a498/dwm')/rec['source_path']
            line=source.read_text().splitlines()[rec['line']-1]
            assert hashlib.sha256(line.encode()).hexdigest()==rec['line_sha256'],rec
        items.append({'report':relative(q),'sha256':sha(q),'source_count':x['source_count'],'classified_records':len(x['records']),'failures':[],'source_line_hashes_match_candidate':True})
    history=[z for z in read(p/'script_ui_disposition.json')['records'] if z['source_path']=='scripts/ui/witnessed/WitnessedHistory.gd' and z['key'] in ['witnessed.transport.history','button.close']]
    assert len(history)==2 and all(z['disposition']=='localized_call' for z in history)
    report['literal_audit']={'ok':True,'artifact':receipt,'reports':items,'history_labels_localized':history}

got=artifact('playable-journeys')
if got is not None:
    p,receipt=got;x=read(p/'results.json');assert x['ok'] is True and len(x['cases'])==5
    expected={
        'seven-days-ending-gallery':(4,['PLAYABLE_STARTUP_PASS','PLAYABLE_DAY_PASS','PLAYABLE_SEVEN_DAY_PASS','PLAYABLE_ENDING_PASS','PLAYABLE_GALLERY_PASS']),
        'seven-days-condition-ending':(3,['PLAYABLE_STARTUP_PASS','PLAYABLE_DAY_PASS','PLAYABLE_SEVEN_DAY_PASS','PLAYABLE_DAY7_CONDITION_PASS']),
        'dating-reload':(7,['PLAYABLE_STARTUP_PASS','PLAYABLE_DATING_RELOAD_PASS','PLAYABLE_DATING_QUICK_PASS','PLAYABLE_DATING_PASS']),
        'practice-empty-dtl':(5,['PRACTICE_FIXTURE','PLAYABLE_EMPTY_DTL_PRACTICE_PASS']),
        'practice-legacy-compatibility':(8,['PRACTICE_FIXTURE','PRACTICE_LEGACY_FIXTURE','PLAYABLE_REHEARSAL_LEGACY_PASS'])}
    assert {c['case_id'] for c in x['cases']}==set(expected);cases=[];roots=[]
    for c in x['cases']:
        count,markers=expected[c['case_id']];d=next(p.glob('*/'+c['case_id']));roots.append(c['isolation_root']);assert c['ok'] is True and not c['failures'] and c['user_dir_strictly_contained'] is True
        assert c['user_dir'].startswith(c['isolation_root']+'/') and all(v.startswith(c['isolation_root']+'/') for k,v in c['environment'].items() if k in ['XDG_DATA_HOME','XDG_CONFIG_HOME','XDG_CACHE_HOME','DWM_TEST_ROOT'])
        for phase,record in [('user-dir-proof',c['user_dir_proof']),('journey',c['journey'])]:
            assert record['exit_code']==0 and record['timed_out'] is False
            assert read(d/(phase+'.process.json'))==record
            clean_log(d/(phase+'.stdout.txt'));clean_log(d/(phase+'.stderr.txt'))
        log=clean_log(d/'journey.log')
        assert set(c['markers'])==set(markers) and all(v==1 for v in c['markers'].values())
        for marker in markers:assert sum(line.startswith(marker) for line in log.splitlines())==1
        if c['case_id']=='practice-empty-dtl':assert 'PRACTICE_LEGACY_FIXTURE' not in log and 'PLAYABLE_REHEARSAL_LEGACY_PASS' not in log
        if c['case_id']=='practice-legacy-compatibility':assert 'PLAYABLE_EMPTY_DTL_PRACTICE_PASS' not in log
        assert len(c['captures'])==count and len(list((d/'captures').glob('*.png')))==count
        caps=[]
        for cap in c['captures']:
            v=png(d/'captures'/Path(cap['file']).name)
            assert all(v[k]==cap[k] for k in ['bytes','sha256','width','height']) and (v['width'],v['height'])==(1280,720)
            caps.append(v)
        cases.append({'case_id':c['case_id'],'ok':True,'fixture_scope':c['fixture_scope'],'process_exit':0,'timeout':False,'markers':c['markers'],'isolation_root':c['isolation_root'],'captures_verified':caps})
    assert len(set(roots))==5
    report['playable_journeys']={'ok':True,'artifact':receipt,'report':relative(p/'results.json'),'report_sha256':sha(p/'results.json'),'cases':cases,'capture_count':27,'five_fresh_isolation_roots':True}

got=artifact('reading-rail')
if got is not None:
    p,receipt=got;x=read(p/'result.json');assert x['ok'] is True and not x['failures'] and x['checkout_sha']==MERGE
    assert x['workflow']['GITHUB_RUN_ID']==RUN and x['workflow']['GITHUB_RUN_ATTEMPT']=='1' and x['workflow']['GITHUB_SHA']==MERGE
    d=next(q for q in p.iterdir() if q.is_dir());w=read(d/'write.json');rd=read(d/'read.json');assert x['reports']=={'write':w,'read':rd}
    proof=w['ordinary_pause_save'];stages=['ordinary_pause_entered','ordinary_pause_cancelled','ordinary_pause_continued','ordinary_pause_reentered','ordinary_backup_previewed','ordinary_backup_entered','ordinary_pause_save_committed','ordinary_pause_save_continued'];first=proof[stages[0]];n=first['native'];assert proof['foreign_handle_refused'] is True
    for i,k in enumerate(stages):
        o=proof[k];v=o['native'];assert o['source']==first['source'] and all(v[q]==n[q] for q in ['caption_id','line_id','text','total_characters'])
        assert v['reveal_generation']==n['reveal_generation']+(i>=5)
        if i<5:assert v['revealing'] is True and 0<=v['visible_characters']<v['total_characters'] and 0<=v['visible_ratio']<1
        else:assert o==proof[stages[5]] and v['revealing'] is False and v['visible_ratio']==1 and (v['visible_characters']==-1 or v['visible_characters']>=v['total_characters'])
    assert proof[stages[1]]==first==proof[stages[2]] and proof[stages[3]]==proof[stages[4]]
    checkpoint=proof['saved_checkpoint'];assert checkpoint==first['source']['checkpoint'];assert checkpoint['reading_session']['frontier']['line_id']=='fixture.solo.pre.a'
    seq=checkpoint['reading_session']['ledger']['captions'];assert len(seq)==1 and seq[0]['beat']['line_id']=='fixture.solo.pre.a';assert len(checkpoint['reading_session']['ledger']['entry_contexts'])==1
    slot=d/'saved-pause-slot.json';assert slot.stat().st_size==proof['slot_bytes']==x['retained_pause_slot']['bytes'] and sha(slot)==proof['slot_sha256']==x['retained_pause_slot']['sha256']
    snapshot=read(slot)['current_snapshot']['snapshot'];assert snapshot['narrative_checkpoint']==checkpoint and snapshot['gameplay']['route_context']['active_dating_challenge']==first['source']['physical_record']
    quick=d/'saved-quick.json';assert quick.stat().st_size==w['quick_bytes']==rd['quick_bytes']==x['retained_quick']['bytes'];assert sha(quick)==w['quick_sha256']==rd['quick_sha256']==x['retained_quick']['sha256']
    assert read(quick)['current_snapshot']['snapshot']['narrative_checkpoint']==w['saved_checkpoint'];assert rd['saved_checkpoint']['reading_session']==w['saved_checkpoint']['reading_session']
    assert rd['canonical_transcript']==w['canonical_transcript'] and rd['physical_record']==w['physical_record'];assert [z['line_id'] for z in rd['canonical_transcript']]==['fixture.solo.pre.a','fixture.solo.pre.b','fixture.solo.post.a'];assert len(rd['saved_checkpoint']['reading_session']['ledger']['entry_contexts'])==2
    assert rd['process_id']!=w['process_id'] and w['speech_admissions']>0 and rd['speech_admissions']==0 and w['history_observations']==2 and rd['history_observations']==1
    trace=[json.loads(line) for line in (d/'transactions.jsonl').read_text().splitlines()];write_kinds=['fixture_registered',*stages,'history_inspected','pre_history','automatic_board_handoff','committed_result_then_post_prose','quick_committed','history_inspected','reading_quick_load_cancelled','stale_candidate_refused'];read_kinds=['fresh_restore_prepared','history_inspected','fresh_restore_verified']
    assert [(e['mode'],e['kind']) for e in trace]==[('write',k) for k in write_kinds]+[('read',k) for k in read_kinds]
    for mode,z in [('write',w),('read',rd)]:
        entries=[e for e in trace if e['mode']==mode];assert [e['sequence'] for e in entries]==list(range(1,len(entries)+1)) and all(e['process_id']==z['process_id'] for e in entries)
        for e in entries:
            if e['kind'] in stages:assert e['value']==proof[e['kind']]
        pr=read(d/(mode+'.process.json'));assert pr==x['processes'][mode] and pr['exit_code']==0 and pr['timed_out'] is False
        for suffix in ['stdout.txt','stderr.txt','log']:
            text=clean_log(d/(mode+'.'+suffix));assert 'LIFETIME_DIAGNOSTICS' not in text and 'Resource still in use:' not in text
        assert ('READING_RAIL_WRITE_PASS' if mode=='write' else 'READING_RAIL_READ_PASS') in (d/(mode+'.log')).read_text()
    assert len(x['captures'])==9;caps=[]
    for cap in x['captures']:
        v=png(d/'captures'/Path(cap['file']).name);assert all(v[k]==cap[k] for k in ['bytes','sha256','width','height']);assert (v['width'],v['height'])==(1280,720);caps.append(v)
    report['reading_journey']={'ok':True,'artifact':receipt,'report':relative(p/'result.json'),'report_sha256':sha(p/'result.json'),'tested_merge':x['checkout_sha'],'pause_stages':stages,'all_source_state_unchanged_during_pause_entry_save_and_continue':True,'plain_pause_and_preview_remain_partial':True,'explicit_backup_reveal_generation_delta':1,'foreign_handle_refused_without_mutation':True,'manual_slot':{'locator':'slot:3','bytes':slot.stat().st_size,'sha256':sha(slot),'line_id':'fixture.solo.pre.a','caption_count':1,'immutable_frames':1,'fresh_loaded':False},'quick':{'bytes':quick.stat().st_size,'sha256':sha(quick),'line_id':'fixture.solo.post.a','caption_count':3,'immutable_frames':2,'fresh_loaded':True},'write_pid':w['process_id'],'read_pid':rd['process_id'],'write_speech_admissions':w['speech_admissions'],'read_speech_admissions':0,'write_history_inspections':2,'read_history_inspections':1,'both_process_exit_codes':0,'lifetime_error_markers':[],'trace_entries':len(trace),'trace_sha256':sha(d/'transactions.jsonl'),'captures_verified':caps,'limit':'Fresh READ proves post Quick; manual pre slot is independently retained and admitted but not separately loaded.'}

# Settings refusal/fault receipts are distinct from ordinary GUT and expected refusal XML failures.
got=artifact('windows-settings')
if got is not None:
    p,receipt=got;results=read(p/'ci/storage-refusal/results.json');assert [v['case'] for v in results]==['empty','whitespace'];refusals=[]
    for v in results:
        assert v['exit_code']==1 and v['tests']==83 and v['expected_root_refusals']==80 and v['storage_free_passes']==3
        d=p/'ci/storage-refusal'/v['case'];before=d/'repository-before.json';after=d/'repository-after.json';assert before.read_bytes()==after.read_bytes();inventory=read(before)
        cases=E.parse(d/'tests.xml').getroot().findall('.//testcase');assert len(cases)==83 and sum(c.find('failure') is not None for c in cases)==80 and sum(c.find('error') is not None for c in cases)==0
        assert all('test_root_missing' in ''.join(c.find('failure').itertext()) and 'DWM_TEST_ROOT is required' in ''.join(c.find('failure').itertext()) for c in cases if c.find('failure') is not None)
        refusals.append({'case':v['case'],'expected_refusals':80,'all_refusal_codes':'test_root_missing','storage_free_passes':3,'expected_exit_code':1,'repository_inventory_entries':len(inventory),'before_after_bytes_identical':True,'inventory_sha256':sha(before)})
    faultlog=p/'phase2r_logs/cloud-manual-witness-revision-storage.log';text=clean_log(faultlog);fault=next(json.loads(line) for line in text.splitlines() if line.startswith('{'));assert fault['assertions']==61180 and fault['failures']==[] and 'MANUAL_WITNESS_REVISION_STORAGE_PASS' in text
    invoke=[json.loads(line) for line in (p/'ci/manual-witness-revision-storage.jsonl').read_text(encoding='utf-8-sig').splitlines()];assert len(invoke)==1 and invoke[0]['exit_code']==0
    ordinary=E.parse(p/'ci/settings.xml').getroot().findall('.//testcase');assert len(ordinary)==312 and all(c.find('failure') is None and c.find('error') is None and c.find('skipped') is None for c in ordinary)
    report['settings']={'ok':True,'artifact':receipt,'ordinary_gut_reference':{'tests':312,'passed':312,'scripts':len({c.get('classname') for c in ordinary}),'failure_count':0,'skip_count':0},'negative_storage_roots':refusals,'simulated_fileops_equivalence':fault,'equivalence_log':relative(faultlog),'equivalence_log_sha256':sha(faultlog),'limit':'80 expected refusal assertions in each negative-root case are deliberate, separate from ordinary GUT totals. Restart/fault assertions simulate durable FileOps, not physical OS crash injection.'}

# Completed job logs bind the actual merge and contain the observed success markers.
report['job_log_bindings']=[]
for jid,markers in [('110420749362',['READING_RAIL_CLOUD_RESULT',*[f'PLAYABLE_JOURNEY_PASS: {case}' for case in ['seven-days-ending-gallery','seven-days-condition-ending','dating-reload','practice-empty-dtl','practice-legacy-compatibility']]]),('110420749491',['UI_LITERAL_AUDIT_VERIFIED','PLAYABLE_STARTUP_RENDER_VERIFIED']),('110420751147',['STORAGE_REFUSAL_VERIFIED: empty and whitespace roots refused without repository mutations.','MANUAL_WITNESS_REVISION_STORAGE_PASS'])]:
    p=ROOT/'logs'/(jid+'.log')
    if not p.exists():report['pending_areas'].append('job_log_'+jid);continue
    text=p.read_text(errors='replace');actual=re.findall(r'git(?:\.exe"?)? log -1 --format=%H\r?\n[^\n]*?\b([0-9a-f]{40})\b',text)
    assert actual==[MERGE],(jid,actual)
    for marker in markers:
        assert len(re.findall(r'^\d{4}-\d{2}-\d{2}T\S+Z '+re.escape(marker)+r'(?:$|:| )',text,re.M))==1,(jid,marker)
    report['job_log_bindings'].append({'job_id':jid,'checkout_sha':actual[0],'log':relative(p),'sha256':sha(p),'observed_success_markers':markers})

# Other artifacts are audited once their complete current-run evidence exists.
for key in ['literal_audit','playable_journeys','reading_journey','settings']:
    if report[key] is None:report['pending_areas'].append(key)
report['audit_complete']=not report['pending_areas']
OUT.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'groups_completed':len(report['rendered_groups']),'captures':sum(g['captures'] for g in report['rendered_groups']),'pending':report['pending_areas']}))

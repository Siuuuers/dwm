from pathlib import Path
import hashlib,json
root=Path('/workspace/scratch/e6146007a498/run98')
def load(name):
    p=root/'audit'/name
    return json.loads(p.read_text()),{'file':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
r,rr=load('render-settings-audit.json');p,pr=load('performance-export-audit.json')
for x in [r,p]:
    assert x['audit_complete'] is True
    assert x['runtime_proof_failures']==[] and x['pending_areas']==[]
assert r['run_id']==p['run_id']==36877062304
assert r['candidate_source']==p['source_head']
assert r['tested_merge']==p['tested_merge']
read=r['reading_journey'];perf=p['checkpoint_performance']
summary={
 'schema_version':1,'run_id':r['run_id'],'run_number':98,'run_attempt':1,
 'candidate_source':r['candidate_source'],'tested_merge':r['tested_merge'],
 'audit_scope':'Assigned non-GUT cloud evidence: rendered UI and journeys, literal classification, storage refusal/fault equivalence, checkpoint and retained-history performance, new-account latency, exported release startup.',
 'audit_complete':True,'runtime_proof_failures':[],'pending_areas':[],
 'component_audits':[rr,pr],
 'rendered_ui':{'group_count':len(r['rendered_groups']),'capture_count':sum(g['captures'] for g in r['rendered_groups']),'groups':[{'group':g['group'],'captures':g['captures'],'renderer':g['renderer']} for g in r['rendered_groups']]},
 'literal_audit':{'ok':True,'reports':r['literal_audit']['reports'],'history_title_and_close_labels_localized':True},
 'existing_playable_journeys':{'case_count':len(r['playable_journeys']['cases']),'capture_count':r['playable_journeys']['capture_count'],'five_fresh_isolation_roots':True,'cases':[{'case_id':c['case_id'],'fixture_scope':c['fixture_scope'],'captures':len(c['captures_verified']),'exit_code':c['process_exit']} for c in r['playable_journeys']['cases']]},
 'reading_journey':{k:v for k,v in read.items() if k not in ['captures_verified','artifact','report','report_sha256']},
 'settings_storage':{k:v for k,v in r['settings'].items() if k not in ['artifact','ordinary_gut_reference']},
 'new_account_latency':{k:p['new_account_latency'][k] for k in ['summary','limitations']},
 'paired_checkpoint_performance':{'verified':perf['status']=='verified','ablation':perf['ablation'],'baseline_single_condition_reversal_verified':perf['baseline_single_condition_reversal_verified'],'journey_count':len(perf['journeys']),'fixed_payload_probe_count':len(perf['fixed_payload_probes']),'limitations':perf.get('limitations',[])},
 'retained_history':p['retained_history'],
 'windows_export':{k:p['export'][k] for k in ['conclusion','checkout_merge','receipt','local_export_archive_inspected','cloud_receipt_scope','limitations']},
 'limits':r['limits']+['GUT totals, public contract inventories, all-job checkout provenance and whole-workflow conclusion are recorded by the root audit separately.','Performance and latency results are measured samples; no universal speedup or whole-product acceptance is inferred.']
}
summary['reading_journey']['capture_count']=len(read['captures_verified'])
(root/'audit/non-gut-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'audit_complete':True,'failures':[],'pending':[],'file':'audit/non-gut-summary.json'}))

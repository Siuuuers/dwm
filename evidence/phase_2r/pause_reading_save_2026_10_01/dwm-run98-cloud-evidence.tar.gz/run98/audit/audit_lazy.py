from pathlib import Path
import json,hashlib,zipfile,re,statistics,subprocess
R=Path('/workspace/scratch/e6146007a498/run98');A=R/'artifacts/lazy-normalization-36877062304-1';D=Path('/workspace/scratch/e6146007a498/dwm');M='5792c629b9e0bfe27ce4d5b2b07837dc6a070fbf';S='36d2fdca56c53c0d6b8571ded45e92fc6d3a9e91'
def H(b):return hashlib.sha256(b).hexdigest()
def sha(p):return H(p.read_bytes())
def j(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def git(c,p):return subprocess.check_output(['git','show',c+':'+p],cwd=D)
def func(b,name):
 s=b.decode();m=re.search(r'^static func '+re.escape(name)+r'\(',s,re.M);assert m
 t=s[m.start():];n=re.search(r'\n(?:static )?func ',t)
 if n:t=t[:n.start()]
 return (t.rstrip()+'\n').encode()
meta=next(x for x in j(R/'artifact-manifest.json') if x['name']==A.name);z=Path(meta['local_zip']);assert z.stat().st_size==meta['size_in_bytes'] and 'sha256:'+sha(z)==meta['digest'];assert meta['workflow_run']['id']==36877062304 and meta['workflow_run']['head_sha']==S
with zipfile.ZipFile(z) as f:
 for info in f.infolist():
  if info.is_dir():continue
  q=Path(info.filename);assert not q.is_absolute() and '..' not in q.parts
  assert (A/q).read_bytes()==f.read(info)
x=j(A/'ci/lazy-normalization/results.json');assert x['checkout_ref']==M and x['run_id']=='36877062304' and x['retained_checkpoint_count']==66
consumer=A/'ci/seven-day-history/consumer-input-manifest.json';producer=R/'artifacts/seven-day-inputs-36877062304';assert consumer.read_bytes()==(producer/'consumer-input-manifest.json').read_bytes();manifest=j(consumer);assert manifest['checkout_ref']==M and manifest['producer_run_id']=='36877062304' and manifest['producer_run_attempt']==1
for f,h in manifest['files'].items():assert sha(producer/f)==h
payload=producer/'day7-autosave.json';assert x['input_sha256']==sha(payload);doc=j(payload);assert len(doc['recovery_journal'])==66
paths={'schema':'scripts/infrastructure/save/SaveDocumentSchema.gd','port':'scripts/application/run/SaveManagerCheckpointPort.gd','reference':'tests/support/EagerNormalizationReference.gd','harness':'tests/manual/benchmark_lazy_normalization.gd'}
for k,p in paths.items():assert H(git(M,p))==x['source_sha256'][k]==sha(D/p)
ref=git(M,paths['reference']);constants=dict(re.findall(r'^const (\w+) := "([^"]+)"$',ref.decode(),re.M));assert constants['SOURCE_COMMIT']=='dae70bf9aa05b6b3debb60f95738e5ffc4e97548'
for k,fn in [('SCHEMA','_normalize_engine_text'),('PORT','_normalize_json_string_types')]:
 old=git(constants['SOURCE_COMMIT'],constants[k+'_SOURCE_PATH']);assert H(old)==constants[k+'_SOURCE_SHA256'];assert func(old,fn)==func(ref,fn);assert H(func(ref,fn))==constants[k+'_HELPER_SHA256']
log=R/'logs/110428116825.log';text=log.read_text(errors='replace');checkout=re.findall(r'git(?:\.exe"?)? log -1 --format=%H\r?\n[^\n]*?\b([0-9a-f]{40})\b',text);assert checkout==[M]
assert re.search(r'^\d{4}-\d\d-\d\dT\S+Z LAZY_NORMALIZATION_VERIFIED:',text,re.M)
rawpairs=[json.loads(v) for v in re.findall(r'^\d{4}-\d\d-\d\dT\S+Z LAZY_NORMALIZATION_PAIR: (.+)$',text,re.M)];assert rawpairs==x['pairs'];assert len(x['pairs'])==8
roots=[];invocations=[];measurements=[];last_end=None
for idx,pair in enumerate(x['pairs']):
 mode='full' if idx<4 else 'splice';n=idx%4+1;assert pair['mode']==mode and pair['pair']==n;assert pair['order']==(['baseline','candidate'] if n%2 else ['candidate','baseline'])
 for variant in pair['order']:
  name=f'{mode}-{n}-{variant}';fp=A/'ci/lazy-normalization'/(name+'.jsonl');items=[json.loads(v) for v in fp.read_text(encoding='utf-8-sig').splitlines()];assert len(items)==1;inv=items[0];assert inv['exit_code']==0 and inv['suite_id']=='cloud-lazy-normalization-'+name
  assert '--variant='+variant in inv['argv'] and '--mode='+mode in inv['argv'] and any(v.endswith('day7-autosave.json') for v in inv['argv']);assert inv['user_dir'].startswith(inv['test_root']+'\\');roots.append(inv['test_root'])
  assert inv['started_at_utc']<inv['ended_at_utc']
  if last_end:assert inv['started_at_utc']>=last_end
  last_end=inv['ended_at_utc']
  raw=A/'phase2r_logs'/('cloud-lazy-normalization-'+name+'.log');t=raw.read_text(errors='replace');assert not re.search(r'(?:SCRIPT ERROR:|^ERROR:|LAZY_NORMALIZATION_FAIL|Unicode parsing error|Unexpected NUL)',t,re.M)
  found=[json.loads(v) for v in re.findall(r'^LAZY_NORMALIZATION_BENCHMARK: (.+)$',t,re.M)];assert found==[pair[variant]];v=found[0]
  assert v['variant']==variant and v['mode']==mode and v['input_sha256']==v['output_sha256']==sha(payload) and v['bytes']==payload.stat().st_size
  assert v['journal_bundles']==v['validated_journal_bundles']==66 and v['schema_version']==v['snapshot_schema_version']==7 and v['warmup_count']==2 and v['sample_count']==5
  assert all(v[k] is True for k in ['identity_preserved_unchanged','identity_replaced_changed','source_unchanged'])
  assert v['reference_commit']==constants['SOURCE_COMMIT']
  for k in ['schema','port']:
   assert v['candidate_'+k+'_source_sha256']==x['source_sha256'][k]
   for part in ['SOURCE','HELPER']:assert v['reference_'+k+'_'+part.lower()+'_sha256']==constants[k.upper()+'_'+part+'_SHA256']
  for metric in ['schema_helper','port_helper','port_seam']:
   samples=v[metric+'_samples_us'];assert len(samples)==5 and all(isinstance(a,int) and a>=0 for a in samples) and statistics.median(samples)==v[metric+'_median_us']
  invocations.append({'name':name,'exit_code':0,'isolated_root':inv['test_root'],'invocation_sha256':sha(fp),'measurement_log_sha256':sha(raw)})
  measurements.append(v)
 for k in ['helper_input_sha256','helper_input_bytes','reference_commit','reference_schema_source_sha256','reference_port_source_sha256','reference_schema_helper_sha256','reference_port_helper_sha256']:assert pair['baseline'][k]==pair['candidate'][k]
 for metric in ['schema_helper','port_helper','port_seam']:assert pair['candidate_minus_baseline_us'][metric]==pair['candidate'][metric+'_median_us']-pair['baseline'][metric+'_median_us']
assert len(set(roots))==16
for s in x['summaries']:
 pairs=[p for p in x['pairs'] if p['mode']==s['mode']];metric=s['metric'];assert s['pairs']==4
 for v in ['baseline','candidate']:assert s[v+'_median_us']==statistics.median(p[v][metric+'_median_us'] for p in pairs)
 assert s['median_paired_candidate_minus_baseline_us']==statistics.median(p['candidate_minus_baseline_us'][metric] for p in pairs)
assert len(x['summaries'])==6
# Full helper is exact canonical document without final LF; splice hashes are identical across all paired processes.
full=payload.read_bytes();assert full.endswith(b'\n')
assert all(v['helper_input_sha256']==H(full[:-1]) and v['helper_input_bytes']==len(full)-1 for v in measurements if v['mode']=='full')
assert len({(v['helper_input_sha256'],v['helper_input_bytes']) for v in measurements if v['mode']=='splice'})==1
jobs=j(R/'jobs.json');jobs=jobs['jobs'] if isinstance(jobs,dict) else jobs;job=next(x for x in jobs if x['id']==110428116825);assert job['conclusion']=='success'
out={'schema_version':1,'run_id':36877062304,'run_attempt':1,'candidate_source':S,'tested_merge':M,'audit_complete':True,'runtime_proof_failures':[],'pending_areas':[],'status':'verified','job_id':110428116825,'checkout_merge':M,'job_log_sha256':sha(log),'artifact':{'name':A.name,'id':meta['id'],'verified_zip_sha256':sha(z)},'results_sha256':sha(A/'ci/lazy-normalization/results.json'),'consumer_manifest_sha256':sha(consumer),'input_sha256':sha(payload),'input_bytes':len(full),'retained_checkpoint_count':66,'source_sha256':x['source_sha256'],'frozen_reference':{'commit':constants['SOURCE_COMMIT'],'whole_source_hashes_match':True,'both_helpers_byte_identical_to_history':True,'helper_hashes_match':True},'pair_count':8,'process_count':16,'all_exit_codes_zero':True,'unique_isolation_roots':16,'raw_reports_equal_summary':True,'identity_and_source_unchanged':True,'raw_samples_and_all_medians_recomputed':True,'summaries':x['summaries'],'invocations':invocations,'sampling':x['sampling'],'scope':x['scope'],'limits':['Strict current validator runs in both variants. Timing excludes proof creation, envelope construction, emission and equality checks.','No timing threshold or OS cache flush; no full-save, gameplay, frame-time or universal speedup claim.']}
(R/'audit/lazy-normalization-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'audit_complete':True,'processes':16,'pairs':8,'exact_historical_helpers':True}))

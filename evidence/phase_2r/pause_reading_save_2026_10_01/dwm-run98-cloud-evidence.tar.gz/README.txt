DWM Run98 cloud evidence

manifest.json records every included/excluded extracted file with exact bytes, SHA-256 and original ZIP member. All extracted bytes were compared with the original ZIP, whose hash/size matches GitHub API metadata. Raw run/jobs/API metadata and all23 completed job logs are retained.

Candidate source and tested PR merge differ; see source_boundary and the preserved source-provenance audit. Generated canonical inventory duplicates, most PNG payloads, large native speech diagnostics and the Windows export binary are omitted with explicit provenance/limits. The reading artifact keeps all9 PNGs and exact save bytes.

Verify file SHA-256 and sizes using manifest.json. Archive hash lives in bundle-receipt.json outside the archive to avoid self-reference. Tar/gzip normalization is documented in the manifest. No engines or tests ran during packaging.

DWM focused cloud evidence: Run96 and Run97

Raw files keep their run/artifact-relative paths. manifest.json lists every payload file, exact size, SHA-256, source run/SHA and original ZIP member. Every artifact member was compared byte-for-byte against its original downloaded ZIP; each ZIP hash and size matches GitHub artifact metadata. Raw job logs and API metadata are retained.

Run96 is retained as failed journey evidence plus its focused unit receipts. Run97 is the corrected focused journey and reading-delivery/public-surface evidence. This bundle does not claim Run98 full-gate acceptance.

No signed download metadata is included. Generated public inventory files are excluded because the source-bound canonical copies are committed separately. The four storage-refusal before/after inventories are preserved.

Verify payload SHA-256 and lengths from manifest.json. Deterministic tar/gzip normalization is documented there; the archive SHA-256 is recorded externally to avoid a self-reference. No engine or test execution occurred while packaging.

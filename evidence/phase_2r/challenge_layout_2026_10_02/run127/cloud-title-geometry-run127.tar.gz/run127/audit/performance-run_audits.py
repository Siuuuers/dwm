#!/usr/bin/env python3
"""Run the accepted performance auditors against completed Run127 data.

Only retained evidence and Git objects are read. Outputs are component audit JSON
and reproducibility records; this launcher does not join final broad acceptance.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys


ROOT = Path('/workspace/scratch/e169b180163f')
HERE = ROOT / 'run127-performance-tools'
RUN = ROOT / 'run127'
REPO = ROOT / 'dwm'
SOURCE = '79b36d90e3ea41d36a81a4c5ba0f87b0ae4a7bfa'
CHECKOUT = 'd1c3205392205ab85306f1e2afed15d58b517bd1'
MASTER = '6a5ddf1564870b43aa9140cad7e0e5b12e43f399'
RUN_ID = 36960182145
HISTORICAL = ('226d3da868784baacc6fc33f58823f95b5815a51',
              '5c3368dbba14475a3749bd71df971bfed353699f',
              'dae70bf9aa05b6b3debb60f95738e5ffc4e97548')


def read(path: Path):
    def pairs(items):
        value = {}
        for key, item in items:
            if key in value:
                raise ValueError(f'Duplicate JSON key: {key}')
            value[key] = item
        return value
    return json.loads(path.read_text(encoding='utf-8-sig'), object_pairs_hook=pairs)


def identity(path: Path) -> dict:
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def main() -> None:
    if not __debug__:
        raise RuntimeError('Assertion-based auditors must run without Python optimization')
    metadata = read(RUN / 'run.json')
    assert metadata['id'] == RUN_ID and metadata['run_number'] == 127
    assert metadata['head_sha'] == SOURCE and metadata['run_attempt'] == 1
    assert metadata['status'] == 'completed' and metadata['conclusion'] == 'success'
    generic = read(RUN / 'audit/generic-evidence-audit.json')
    assert generic['generic_audit_pass'] is True and generic['run']['id'] == RUN_ID
    boundary = read(RUN / 'audit/source-provenance.json')
    assert generic['source_boundary'] == boundary
    assert boundary['source'] == SOURCE and boundary['tested_checkout'] == CHECKOUT
    assert boundary['master'] == MASTER and boundary['all_unlisted_paths_byte_identical'] is True
    for revision in (SOURCE, CHECKOUT, MASTER, *HISTORICAL):
        subprocess.run(['git', '-C', str(REPO), 'cat-file', '-e', revision + '^{commit}'], check=True)
    provenance = read(HERE / 'helper-provenance.json')
    assert provenance['run_id'] == RUN_ID
    assert provenance['modified_helpers'] == ['performance-auditors/join_non_gut.py']
    for helper in provenance['helpers']:
        original = HERE / helper['path']
        assert identity(original) == {key: helper[key] for key in ('bytes', 'sha256')}
        target = RUN / 'audit' / helper['path']
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            assert target.read_bytes() == original.read_bytes(), f'Changed copied auditor: {target}'
        else:
            shutil.copyfile(original, target)
    output = RUN / 'audit/performance-export-audit.json'
    assert not output.exists(), 'Retain any earlier partial diagnostic deliberately before a rerun'
    environment = os.environ.copy()
    environment.update({
        'DWM_AUDIT_RUN_ROOT': str(RUN), 'DWM_AUDIT_REPO': str(REPO),
        'DWM_AUDIT_SOURCE': SOURCE, 'DWM_AUDIT_CHECKOUT': CHECKOUT,
        'DWM_AUDIT_ATTEMPT': '1', 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONOPTIMIZE': '0',
    })
    working = RUN / 'audit/performance-auditors'
    steps = [
        ['audit_next_checkpoint_export.py', '--run-root', str(RUN), '--repo', str(REPO),
         '--source', SOURCE, '--checkout', CHECKOUT, '--master', MASTER],
        ['audit_warm_source_guard.py'],
        ['audit_retained_performance.py'],
        ['audit_history_comparisons.py'],
        ['audit_region_warm_measurements.py', 'history-region-search'],
        ['audit_region_warm_measurements.py', 'warm-outgoing-proof'],
        ['../lazy-auditors/audit_lazy.py'],
        ['finish_retained_history.py'],
    ]
    executions = []
    logs = HERE / 'execution-logs'
    logs.mkdir(exist_ok=True)
    for ordinal, arguments in enumerate(steps, 1):
        command = [sys.executable, *arguments]
        result = subprocess.run(command, cwd=working, env=environment, text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        log = logs / f'{ordinal:02d}-{Path(arguments[0]).stem}.log'
        log.write_text(result.stdout, encoding='utf-8')
        executions.append({'ordinal': ordinal, 'arguments': arguments,
                           'exit_code': result.returncode, 'log': str(log), **identity(log)})
        print(json.dumps({'step': ordinal, 'audit': arguments[0], 'exit_code': result.returncode,
                          'output': result.stdout[-4000:]}), flush=True)
        if result.returncode != 0:
            (HERE / 'partial-execution.json').write_text(json.dumps(executions, indent=2) + '\n')
            raise RuntimeError(f'Component audit failed at step {ordinal}; diagnostics retained')
    performance = read(output)
    lazy = read(RUN / 'audit/lazy-normalization-audit.json')
    warm = read(RUN / 'audit/warm-source-provenance.json')
    assert performance['source_head'] == SOURCE and performance['tested_merge'] == CHECKOUT
    assert performance['run_id'] == RUN_ID and performance['audit_complete'] is True
    assert performance['status'] == 'verified' and performance['runtime_proof_failures'] == []
    assert performance['pending_areas'] == []
    assert lazy['candidate_source'] == SOURCE and lazy['tested_merge'] == CHECKOUT
    assert lazy['run_id'] == RUN_ID and lazy['audit_complete'] is True
    assert lazy['runtime_proof_failures'] == [] and lazy['pending_areas'] == []
    assert warm['tested_merge'] == CHECKOUT and warm['status'] == 'verified'
    retained = dict(provenance)
    retained['execution'] = executions
    retained['launcher'] = identity(Path(__file__))
    retained['outputs'] = {name: identity(RUN / 'audit' / name) for name in
                           ('performance-export-audit.json', 'lazy-normalization-audit.json',
                            'warm-source-provenance.json')}
    retained['scope'] = 'Independent performance/export/history/lazy components only; final non-GUT and broad joins remain separate.'
    (RUN / 'audit/performance-helper-identities.json').write_text(json.dumps(retained, indent=2) + '\n')
    shutil.copyfile(__file__, RUN / 'audit/performance-runner.py')
    print(json.dumps({'performance_components_verified': True, 'run_id': RUN_ID,
                      'source': SOURCE, 'checkout': CHECKOUT, 'steps': len(steps)}), flush=True)


if __name__ == '__main__':
    main()

# Read-only Run 120 performance evidence audit

These Python tools inspect retained GitHub Actions receipts and exact source bytes. They do not run Godot or PowerShell. Run without Python optimization (`-O`), which disables assertion gates.

Prerequisites: completed `run.json`, all-attempt `jobs.json`, API artifact metadata, downloaded artifact ZIPs and byte-identical extractions, cloud logs, `audit/source-provenance.json`, and a Git repository containing the tested source, merge and historical control objects. `artifact-manifest.json` must still resolve its downloaded ZIP paths. The oversized Windows export archive is an explicit transport omission; the export audit verifies the cloud source-bound startup/export receipt and API metadata, and makes no local binary-inspection claim.

Set the explicit identities below (paths are examples):

```sh
export DWM_AUDIT_RUN_ROOT=/absolute/path/run120
export DWM_AUDIT_REPO=/absolute/path/dwm
export DWM_AUDIT_SOURCE=1459af29ad467ca1375ed12fe9e2f31671ce8171
export DWM_AUDIT_CHECKOUT=e84131335d7e49a4d7ae151f99df6f8f2ce93eec
export DWM_AUDIT_ATTEMPT=1
```

From the retained `audit/performance-auditors` directory (with the sibling `audit/lazy-auditors` directory), run in order:

```sh
python audit_next_checkpoint_export.py --run-root "$DWM_AUDIT_RUN_ROOT" --repo "$DWM_AUDIT_REPO" --source "$DWM_AUDIT_SOURCE" --checkout "$DWM_AUDIT_CHECKOUT" --master 6a5ddf1564870b43aa9140cad7e0e5b12e43f399
python audit_warm_source_guard.py
python audit_retained_performance.py
python audit_history_comparisons.py
python audit_region_warm_measurements.py history-region-search
python audit_region_warm_measurements.py warm-outgoing-proof
python ../lazy-auditors/audit_lazy.py
python finish_retained_history.py
```

The first command refuses to overwrite a previous `performance-export-audit.json`; archive any prior diagnostic report deliberately before a rerun. Subsequent commands fill independently checked sections. The final join requires all four consumer comparisons and the no-checkout aggregate gate. Final outputs are `audit/performance-export-audit.json`, `audit/warm-source-provenance.json` and `audit/lazy-normalization-audit.json`.

The producer represents 35 isolated invocations. Consumers represent 6 outgoing-normalization invocations, 16 lazy-normalization invocations (8 pairs), 16 history-region-search invocations (8 pairs), and 24 warm-outgoing-proof invocations (12 pairs): 62 consumer invocations. Each paired comparison distinguishes process-pair counts from its five inner timing samples. The wrapper records distinct roots, arguments and UTC intervals; it does not retain independent process IDs. Timings on shared Windows runners establish no universal speedup, frame-time threshold, or performance claim about the new reading-selector increment.

`origin-manifest.json` records copied helper provenance and the few additional receipt/summary completeness checks. The sibling lazy helper has its own `auditor-origin.json`. No runtime source, workflow gates or test expectations were changed by these auditors.

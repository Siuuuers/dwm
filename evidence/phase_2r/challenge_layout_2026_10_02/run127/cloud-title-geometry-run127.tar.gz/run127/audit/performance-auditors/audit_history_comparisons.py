import json,pathlib,hashlib,subprocess,statistics,collections
from audit_context import *
A=RUN/'audit/performance-export-audit.json';audit=read(A);hist=audit['retained_history'];manifest=hist['producer']['consumer_input_manifest'];H=manifest['files']['day7-autosave.json'];SIZE=hist['producer']['payload_bytes']
def base(name,job_id,success,count):
    P=RUN/f'artifacts/{name}-{RUNID}-{ATTEMPT}';D=P/f'ci/{name}';L=P/'phase2r_logs';r=read(D/'results.json');assert r['checkout_ref']==MERGE
    assert read(P/'ci/seven-day-history/consumer-input-manifest.json')==manifest
    receipt=job(job_id,f'Windows / {name} comparison',success)
    assert markers(RUN/f'logs/{job_id}.log','DAY7_CONSUMER_INPUTS_VERIFIED: ')==[manifest]
    inv=[]
    for p in D.glob('*.jsonl'):
        x=[json.loads(s) for s in p.read_text(encoding='utf-8-sig').splitlines() if s];assert len(x)==1 and x[0]['exit_code']==0;inv+=x
        assert x[0]['suite_id']=='cloud-'+name+'-'+p.stem and x[0]['started_at_utc']<x[0]['ended_at_utc']
        assert '--headless' in x[0]['argv'] and '\\.godot\\phase2r_tests\\' in x[0]['test_root'] and x[0]['user_dir'].startswith(x[0]['test_root']+'\\')
    assert len(inv)==count and len(set(x['test_root'] for x in inv))==count
    assert len(list(L.glob('*.log')))==count
    for p in L.glob('*.log'):
        t=p.read_text(encoding='utf-8-sig');assert all(e not in t for e in ['SCRIPT ERROR:','ERROR: Failed to load','Unicode parsing error','Unexpected NUL character'])
    return P,D,L,r,{'status':'verified',**receipt,'artifact_archive':artifact(f'{name}-{RUNID}-{ATTEMPT}'),'same_producer_input_manifest_verified':True,'producer_run_id':RUNID,'producer_run_attempt':ATTEMPT,'producer_input_hashes':manifest['files'],'isolated_processes':count,'process_ids_recorded':False,'process_identity_scope':'Source-bound wrapper execution with distinct isolated roots and UTC intervals; no independent process IDs are retained.','raw_log_count':count,'all_invocations_exit_zero':True,'evidence_sha256':{str(p.relative_to(RUN)):sha(p.read_bytes()) for p in list(D.glob('*'))+list(L.glob('*.log'))+[P/'ci/seven-day-history/consumer-input-manifest.json'] if p.is_file()}}
def sourcecheck(r,mapping):
    assert set(mapping)==set(r['source_sha256'])
    for key,path in mapping.items():assert r['source_sha256'][key]==sha(blob(path))
def write_result(name,result):
    audit=read(A);audit['retained_history']['comparisons'][name]=result;A.write_text(json.dumps(audit,indent=2)+'\n');print(name,'verified')

def outgoing():
    name='outgoing-normalization';jid=execution_job('Windows / outgoing-normalization comparison')['id'];P,D,L,r,result=base(name,jid,'OUTGOING_NORMALIZATION_PERFORMANCE_VERIFIED: six exact-payload probes with unchanged validation and retention.',6)
    sourcecheck(r,{'checkpoint_port':'scripts/application/run/SaveManagerCheckpointPort.gd','document_schema':'scripts/infrastructure/save/SaveDocumentSchema.gd','run_schema':'scripts/domain/run/RunSnapshotSchema.gd'})
    localized=read(RUN/f'artifacts/checkpoint-payloads-{RUNID}/payload-manifest.json');assert read(P/'ci/performance/payload-manifest.json')==localized==r['localized_payload_manifest']
    assert markers(RUN/f'logs/{jid}.log','OUTGOING_NORMALIZATION_MEASUREMENT: ')==r['measurements']
    assert len(r['measurements'])==6
    assert {(x['variant'],x['label']) for x in r['measurements']}=={(v,l) for v in ['baseline','candidate'] for l in ['zh-CN','zh-HK','day7']}
    rows=[]
    for row in r['measurements']:
        x=row['measurement'];v=row['variant'];label=row['label'];f=(RUN/f'artifacts/seven-day-inputs-{RUNID}/day7-autosave.json') if label=='day7' else (RUN/f'artifacts/checkpoint-payloads-{RUNID}/fixed-{label}-autosave.json');h=sha(f.read_bytes());n=66 if label=='day7' else 2
        assert raw(L/f'cloud-{name}-{v}-{label}.log','OUTGOING_NORMALIZATION_BENCHMARK: ')==[x]
        assert x['variant']==v and x['input_sha256']==x['output_sha256']==h and x['bytes']==f.stat().st_size and x['journal_bundles']==x['validated_journal_bundles']==n and x['schema_version']==x['snapshot_schema_version']==7
        assert len(x['samples_us'])==5 and min(x['samples_us'])>=0 and statistics.median(x['samples_us'])==x['median_us']
        rows.append({'variant':v,'label':label,'input_output_sha256':h,'retained_checkpoints':n,'samples':5,'median_us':x['median_us']})
    result.update({'source_sha256':r['source_sha256'],'localized_producer_manifest_verified':True,'measurements':rows,'ablation':r['ablation'],'limitations':['Seam normalization proof on identical current producer payloads; does not prove a complete gameplay splice proof set, physical save performance, or current reading increment speedup.']});write_result(name,result)

if __name__=='__main__':outgoing()

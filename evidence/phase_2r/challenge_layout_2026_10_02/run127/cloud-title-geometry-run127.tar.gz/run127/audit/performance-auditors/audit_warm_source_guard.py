import pathlib,subprocess,re,hashlib,json
from audit_context import RUN, REPO, MERGE
sha=lambda s:hashlib.sha256(s.encode()).hexdigest()
def git(path,commit=MERGE):return subprocess.check_output(['git','show',commit+':'+path],cwd=REPO).decode().replace('\r\n','\n')
def method(t,n):
    found=re.findall(r'^(?:static )?func '+re.escape(n)+r'\(.*?(?=^(?:func |static func |## )|\Z)',t,re.M|re.S);assert len(found)==1
    return found[0].rstrip('\r\n')+'\n'
P='scripts/application/run/SaveManagerCheckpointPort.gd';S='scripts/infrastructure/save/SaveDocumentSchema.gd';J='scripts/infrastructure/save/CheckpointJournal.gd';REF='226d3da868784baacc6fc33f58823f95b5815a51'
hashes={'port':'bac00cb4df7573a6c670bbab1593e77f6ca8d0dd31b3cd7dade6d50616fd04bc','schema':'1676d41225675acf4e3c154c60e38c2bd831417047266d5a9f00e4466bd448b2','journal':'617aa35fe71b426c8c0b643b9fdda2e65322f5e37e652fb98bf7f78f64e7c344'}
mh={'commit':'c8a1d78923cee29d2af4b6520e34d3d131d83ead92b170e8f907f8454132ed58','_splice_autosave_text':'2d35e02daecdb6fc77cb7058132a76b7301825115f6db29750e3de81145b6d9c','_validate_document':'f5836a5a142eab40679a4b4f76dbff9bd2dc0c1ee92dc18874db350c6526ef61','remember_written_retained_bundle':'70a0dcfb3e8668366339d986a2b96949a0b6a36b31fad67957f33a3698c994d4'}
hp,hs,hj=[git(p,REF) for p in [P,S,J]];cp,cs,cj=[git(p) for p in [P,S,J]];fp=git('tests/support/WarmOutgoingProofReference.gd');fj=git('tests/support/WarmOutgoingJournalReference.gd')
for key,text in zip(['port','schema','journal'],[hp,hs,hj]):assert sha(text)==hashes[key]
n='remember_written_retained_bundle';orig=method(hj,n);assert sha(orig)==mh[n] and method(fj,n)==orig;assert sha(cj.replace(method(cj,n),orig))==hashes['journal']
bp=cp
for n in ['commit','_splice_autosave_text']:
    orig=method(hp,n);control=method(fp,n)
    if n=='_splice_autosave_text':control=control.replace('proven_journal: Array = [], _proven_documents: Array = []) -> String:','proven_journal: Array = []) -> String:')
    assert sha(orig)==mh[n] and control==orig;bp=bp.replace(method(cp,n),orig)
comment='## `proven_documents` collects the normalized document proofs under those same ids/text lifetimes;\n## an empty entry preserves the raw-proof fallback. Neither output is trusted on a failed splice.\n'
assert comment in bp;bp=bp.replace(comment,'');assert sha(bp)==hashes['port']
orig=method(hs,'_validate_document');assert sha(orig)==mh['_validate_document'];cur=method(cs,'_validate_document')
normalized='\t\tif normalized_proofs:\n\t\t\tcomposed = _proven_entries(proven_journal)\n\t\telse:\n\t\t\tfor bundle: Variant in proven_journal:\n\t\t\t\tcomposed.append(_normalize_engine_text(bundle))\n'
original='\t\tfor bundle: Variant in proven_journal:\n\t\t\tcomposed.append(_normalize_engine_text(bundle))\n'
assert normalized in cur;raw=cur.replace('profile: Dictionary = {}, normalized_proofs: bool = false)','profile: Dictionary = {})').replace(normalized,original);assert raw==orig
adapter=method(cs,'_validate_outgoing_document_proofs');comment="## Internal splice adapter: the port collected each normalized document proof from the journal\n## under the SAME checkpoint id as its raw bundle and exact spliced text. These journal-owned\n## proofs were normalized before their bytes were proven, never mutated in place, and share the\n## text's retention/reset/restore lifetime. A complete set needs only detached composition; an\n## absent, partial or text-only set retains validate_outgoing()'s raw normalization unchanged.\n"
assert comment+adapter+'\n' in cs;assert sha(cs.replace(comment+adapter+'\n','').replace(cur,orig))==hashes['schema']
regionref='5c3368dbba14475a3749bd71df971bfed353699f';rp=git(P,regionref);n='_remember_written_history';rm=method(rp,n);assert sha(rp)=='72d400998c3bc6d9a3b4a7645bfd24a749e34a78eaa140ba73d1b23d6fc20310';assert sha(rm)=='470919ccd5ff929337c6a0c00185e9082772c97de7f5ce72a3b9e0209dff4617';assert method(git('tests/support/HistoryRegionSearchReference.gd'),n)==rm
assert method(hp,n)==method(cp,n);assert hp.replace(method(cp,n),rm)==rp
out={'status':'verified','tested_merge':MERGE,'reference_commit':REF,'reference_source_sha256':hashes,'reference_method_sha256':mh,'whole_port_schema_journal_narrow_reconstruction_verified':True,'frozen_methods_byte_equal_after_reviewed_signature_adapter':True,'public_raw_proof_validator_historical_body_preserved':True,'history_region_reference_commit':regionref,'history_region_port_sha256':sha(rp),'history_region_method_sha256':sha(rm),'history_region_whole_port_reconstruction_verified':True,'scope':'Read-only Python audit of source bytes from exact Git commits; no Godot or PowerShell execution.'}
(RUN/'audit/warm-source-provenance.json').write_text(json.dumps(out,indent=2)+'\n');print('warm and region exact historical source guard verified')

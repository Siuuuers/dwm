import json,pathlib,hashlib,subprocess,statistics,collections
from audit_context import *
P=RUN/f'artifacts/seven-day-history-{RUNID}-{ATTEMPT}'; D=P/'ci/seven-day-history'; L=P/'phase2r_logs'; I=RUN/f'artifacts/seven-day-inputs-{RUNID}'
r=read(D/'results.json');m=read(I/'consumer-input-manifest.json');assert m==read(D/'consumer-input-manifest.json')
assert m['schema_version']==1 and m['checkout_ref']==MERGE and m['producer_run_id']==str(RUNID) and m['producer_run_attempt']==ATTEMPT
assert set(m['files'])=={'results.json','day7-autosave.json'}
for f,h in m['files'].items():assert sha((I/f).read_bytes())==h and (I/f).read_bytes()==(D/f).read_bytes()
payload=read(I/'day7-autosave.json');assert payload['schema_version']==7
h=m['files']['day7-autosave.json'];assert r['checkout_ref']==MERGE and r['payload_sha256']==h and r['write']['autosave_sha256']==h and r['cold_read']['autosave_sha256']==h
assert len(payload['recovery_journal'])==66
counts=collections.Counter(x['checkpoint_kind'] for x in payload['recovery_journal']);assert counts['line']==32 and counts['manual_save']==32 and sum(counts.values())==66
assert r['write']=={'autosave_sha256':h,'days':7,'retained':{'line':32,'manual_save':32,'semantic':2},'synthetic_checkpoints':98}
assert [d['day'] for d in r['days']]==list(range(1,8))
assert all(len(d['synthetic_checkpoint_us'][k])==7 for d in r['days'] for k in ['line','manual_save'])
assert r['days'][-1]['autosave_sha256']==h and r['days'][-1]['files']['saves/autosave.json']==(I/'day7-autosave.json').stat().st_size
write=L/'cloud-seven-day-history-write.log'
assert raw(write,'SEVEN_DAY_HISTORY_DAY: ')==r['days']; assert raw(write,'SEVEN_DAY_HISTORY_WRITE_PASS: ')==[r['write']]
for field,prefix in [('checkpoint_profiles','DWM_CHECKPOINT_PROFILE '),('consequence_profiles','DWM_CONSEQUENCE_PROFILE ')]:
    assert raw(write,prefix)==r[field]
    assert all(x.get('ok',True) for x in r[field])
assert [x for x in raw(write,'DWM_SAVE_LOAD_PROFILE ') if x.get('context','')!='']==r['save_load_write_profiles']
source=r['save_admission_comparison']['source_code_sha256'];manual=r['manual_prepare_comparison']['source_code_sha256'];code=blob('autoload/SaveManager.gd');assert sha(code)==source['candidate']==manual['candidate']
for path,hsh in source['shared'].items():assert sha(blob(path))==hsh
for filename,key in [('derive_save_admission_baseline.py','baseline'),('derive_save_prepare_baseline.py','manual')]:
    space={'__name__':'audit_helper'};exec(compile(blob('tools/testing/'+filename),filename,'exec'),space)
    expected=space['derive_baseline'](code);fname='baseline-SaveManager.gd' if key=='baseline' else 'baseline-prepare-SaveManager.gd';assert (D/fname).read_bytes()==expected
    assert sha(expected)==(source['baseline'] if key=='baseline' else manual['baseline'])
for key,path in [('storage','scripts/infrastructure/storage/JsonFileStorage.gd'),('harness','tests/manual/benchmark_manual_save_write.gd'),('witness_port','tests/support/ManualSaveWitnessPort.gd')]:assert sha(blob(path))==manual[key]
identity=['restored_gameplay_sha256','restored_board_sha256','restored_recovery_journal_sha256']
for variant in ['enabled','disabled']:
    result=r['parse_cache_comparison'][variant];path=L/f'cloud-seven-day-history-read-cache-{variant}.log';assert raw(path,'SEVEN_DAY_HISTORY_READ_PASS: ')==[result]
    assert result['autosave_sha256']==h and result['save_manager_sha256']==source['candidate'] and result['day']==7 and result['retained_checkpoint_count']==66
    assert result['parse_cache_enabled']==(variant=='enabled')
    for f in identity:assert result[f]==r['cold_read'][f]
    field='save_load_read_profiles' if variant=='enabled' else 'save_load_read_control_profiles';assert [x for x in raw(path,'DWM_SAVE_LOAD_PROFILE ') if x.get('context','')!='']==r[field]
assert r['cold_read']==r['parse_cache_comparison']['enabled']
manual_invariants=['candidate_sha256','capture_input_sha256','prepared_record_sha256','source_revision','source_files_sha256','output_files_sha256','prior_journal_sha256','journal_sha256','output_sha256','output_bytes','retained_checkpoint_count','parse_cache_before']
for field,stem,metric,prefix,hashes in [('save_admission_comparison','read-admission','login_us','SEVEN_DAY_HISTORY_READ_PASS: ',source),('manual_prepare_comparison','prepare','prepare_us','MANUAL_SAVE_WRITE_PASS: ',manual)]:
    comp=r[field];assert len(comp['pairs'])==8
    retained=read(D/('admission-pairs.json' if stem=='read-admission' else 'manual-prepare-pairs.json'));assert comp==retained
    for i,pair in enumerate(comp['pairs'],1):
        assert pair['pair']==i and pair['order']==(['baseline','candidate'] if i%2 else ['candidate','baseline'])
        for variant in pair['order']:
            x=pair[variant];path=L/f'cloud-seven-day-history-{stem}-pair-{i}-{variant}.log';assert raw(path,prefix)==[x]
            assert x['save_manager_sha256']==hashes[variant] and x['retained_checkpoint_count']==66 and x['parse_cache_enabled'] and x[metric]>=0
            if stem=='read-admission':
                assert x['autosave_sha256']==h and x['day']==7
                for f in identity:assert x[f]==r['cold_read'][f]
                prof=[y for y in raw(path,'DWM_SAVE_LOAD_PROFILE ') if y.get('context','')!='']
            else:
                assert x['write_variant']=='production' and x['timing_mode']=='legacy-phase-context' and x['strict_validation_calls']==1
                assert x['prepare_validation_calls']==0 and x['source_files_sha256']['autosave.json']==h and x['output_files_sha256']['autosave.json']==h
                for f in manual_invariants:assert x[f]==comp['pairs'][0]['baseline'][f]
                prof=[y for y in raw(path,'DWM_SAVE_LOAD_PROFILE ') if y.get('context')=='manual-write-prepare']
            assert prof==pair['profiles'][variant]
            negative=[y for y in prof if not y.get('ok',True)]
            if stem=='read-admission':assert negative==[]
            else:assert len(negative)==1 and negative[0]['scope']=='restore_prepare' and negative[0]['code']=='TRANSACTION_PARTICIPANTS_NOT_CONFIGURED'
        assert pair['candidate_minus_baseline_us']==pair['candidate'][metric]-pair['baseline'][metric]
    assert comp['summary']['pair_count']==8
    for variant in ['baseline','candidate']:assert comp['summary'][f'{variant}_median_{metric}']==statistics.median(x[variant][metric] for x in comp['pairs'])
    assert comp['summary']['median_paired_candidate_minus_baseline_us']==statistics.median(x['candidate_minus_baseline_us'] for x in comp['pairs'])
invocations=[]
for p in D.glob('*.jsonl'):
    rows=[json.loads(s) for s in p.read_text(encoding='utf-8-sig').splitlines() if s];assert len(rows)==1 and rows[0]['exit_code']==0
    invocations.append(rows[0]);assert '--headless' in rows[0]['argv']
    assert rows[0]['suite_id']=='cloud-seven-day-history-'+p.stem and rows[0]['started_at_utc']<rows[0]['ended_at_utc']
    assert '\\.godot\\phase2r_tests\\' in rows[0]['test_root'] and rows[0]['user_dir'].startswith(rows[0]['test_root']+'\\')
assert len(invocations)==35 and len(set(x['test_root'] for x in invocations))==35
assert len(list(L.glob('*.log')))==35
for p in L.glob('*.log'):
    t=p.read_text(encoding='utf-8-sig');assert all(error not in t for error in ['SCRIPT ERROR:','ERROR: Failed to load','Unicode parsing error','Unexpected NUL character'])
producer_id=execution_job('Windows / seven-day retained history producer')['id']
producer_job=job(producer_id,'Windows / seven-day retained history producer','SEVEN_DAY_HISTORY_PERFORMANCE_VERIFIED: seven real days, saturated checkpoint budgets, exact cold Login.')
assert markers(RUN/f'logs/{producer_id}.log','SEVEN_DAY_HISTORY_PROOF: ')[0]['payload_sha256']==h
out={'status':'producer_verified_waiting_for_comparisons','producer':{'status':'verified',**producer_job,'artifact_archives':[artifact(f'seven-day-inputs-{RUNID}'),artifact(f'seven-day-history-{RUNID}-{ATTEMPT}')],'consumer_input_manifest':m,'payload_bytes':(I/'day7-autosave.json').stat().st_size,'retained_checkpoint_kinds':dict(counts),'write_receipt':r['write'],'cold_read_receipt':r['cold_read'],'days':7,'checkpoint_profiles':len(r['checkpoint_profiles']),'consequence_profiles':len(r['consequence_profiles']),'checkpoint_diagnostics':r['checkpoint_diagnostics'],'isolated_processes_verified':len(invocations),'process_ids_recorded':False,'raw_log_count':35,'save_admission_comparison':{'source_sha256':source,'summary':r['save_admission_comparison']['summary'],'matched_pairs':8,'derived_current_source_baseline_byte_verified':True},'manual_prepare_comparison':{'source_sha256':manual,'summary':r['manual_prepare_comparison']['summary'],'matched_pairs':8,'derived_current_source_baseline_byte_verified':True,'strict_validation_calls_per_process':1,'expected_negative_profile_per_process':{'scope':'restore_prepare','code':'TRANSACTION_PARTICIPANTS_NOT_CONFIGURED','explanation':'The isolated manual SaveManager has no restore participants. Occupied-slot inspection records load unavailable while preserving save availability, as SaveManager explicitly admits this code; public Save prepare/commit and exact output checks succeed.'}},'parse_cache_control':r['parse_cache_comparison'],'raw_report_markers_matched':True,'all_source_fields_verified_against_tested_merge':True,'all_invocations_exit_zero':True,'day7_gameplay_board_journal_identity_matched':True,'evidence_sha256':{str(p.relative_to(RUN)):sha(p.read_bytes()) for p in list(D.glob('*'))+list(L.glob('*.log')) if p.is_file()},'limitations':['Fresh process execution is source-bound to Invoke-IsolatedGodot.ps1 and receipts establish distinct roots/UTC intervals; wrapper receipts do not record independent process IDs.','Seven synthetic line and seven synthetic manual checkpoint records per day, plus real Slot 1 save/App loss/Schedule Done progression; this is not authored-dialogue content acceptance.','Eight alternating matched process pairs per ablation on one shared Windows runner; timing observations establish no frame-time or universal speedup guarantee.','These retained-history controls exercise existing save optimizations, not a performance comparison of the current reading increment.']},'comparisons':{},'aggregate':{'status':'awaiting_local_evidence'}}
audit=read(RUN/'audit/performance-export-audit.json');assert audit['source_head']==HEAD and audit['tested_merge']==MERGE and audit['run_id']==RUNID;audit['retained_history']=out;audit['status']='partial_pending_comparisons';(RUN/'audit/performance-export-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps({'producer':'verified','processes':35,'retained':66,'payload_sha256':h,'summary_path':str(RUN/'audit/performance-export-audit.json')}))

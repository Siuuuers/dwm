"""Join independently verified current cloud components without new engine acceptance."""
import ast
from pathlib import Path
import hashlib
import json
from audit_context import RUN, RUNID, RUN_METADATA, HEAD, MERGE, SOURCE_BOUNDARY, blob, sha

root, source, merge = RUN, HEAD, MERGE
records = []


def record(path):
    records.append({"file": str(path.relative_to(root)), "sha256": sha(path.read_bytes())})


def read(name, source_key, merge_key):
    path = root / "audit" / name
    value = json.loads(path.read_text())
    assert value["audit_complete"] is True, name
    assert value.get("runtime_proof_failures", []) == [], name
    assert value.get("pending_areas", []) == [], name
    assert value[source_key] == source and value[merge_key] == merge, name
    if "run_id" in value:
        assert value["run_id"] == RUNID, name
    record(path)
    return value


render = read("rendered-functional-audit.json", "candidate_source", "tested_merge")
storage = read("settings-storage-audit.json", "source_sha", "tested_checkout_sha")
trace = read("next-reading-trace-audit.json", "source", "checkout")
performance = read("performance-export-audit.json", "source_head", "tested_merge")
reading = trace["original_proof_and_process_audit"]
assert len(reading) == 1
journey = reading[0]
driver_path = "tools/testing/run_reading_rail_journey.py"
driver = blob(driver_path)
assert trace["frozen_driver"] == {"path": driver_path, "sha256": sha(driver)}
constants = {}
for node in ast.parse(driver).body:
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
        if node.targets[0].id in {"MODES", "NEXT_MODES", "CAPTURES", "NEXT_CAPTURES"}:
            constants[node.targets[0].id] = ast.literal_eval(node.value)
assert constants["MODES"] == ("write", "read", "repeat", "variant", "witness-read")
assert constants["NEXT_MODES"] == ("next-unseen", "next", "next-read")
all_modes = list(constants["MODES"] + constants["NEXT_MODES"])
assert journey["modes"] == all_modes
assert len(set(journey["process_ids"].values())) == len(all_modes) == 8
assert len(journey["captures"]) == len(constants["CAPTURES"]) == 9
assert journey["write_read_seal"]["file_count"] == 14
assert journey["exact_witnesses"]["durable_witness_count"] == 5
assert len(render["rendered_groups"]) == 6
assert render["playable_journeys"]["capture_count"] == 27
assert len(render["playable_journeys"]["cases"]) == 5
assert performance["retained_history"]["aggregate"]["status"] == "verified"

next_path = root / "audit/next-component-audit.json"
next_component = json.loads(next_path.read_text())
assert next_component["next_component_audit_pass"] is True
assert next_component["checkout"] == merge
assert next_component["report"] == journey["report_identity"]
assert next_component["process_ids"] == {mode: journey["process_ids"][mode] for mode in constants["NEXT_MODES"]}
assert all(next_component[key] is True for key in ["source_and_destination_exact", "silent_traversal",
    "auto_off_refusal_then_exact_retry", "fresh_challenge_and_history_restore"])
assert len(next_component["captures"]) == len(constants["NEXT_CAPTURES"]) == 3
record(next_path)

generic_path = root / "audit/generic-evidence-audit.json"
generic = json.loads(generic_path.read_text())
assert generic["generic_audit_pass"] is True
assert generic["source_boundary"] == SOURCE_BOUNDARY
assert generic["run"]["id"] == RUNID and generic["run"]["head_sha"] == source
assert generic["reading"] == reading
for filename, expected in generic["raw_metadata_identities"].items():
    raw_bytes = (root / filename).read_bytes()
    assert {"bytes": len(raw_bytes), "sha256": sha(raw_bytes)} == expected

run = RUN_METADATA
assert run["id"] == RUNID and run["head_sha"] == source
result = {
    "schema_version": 2, "run_id": run["id"], "run_number": run["run_number"],
    "run_attempt": run["run_attempt"], "candidate_source": source, "tested_merge": merge,
    "audit_complete": True, "runtime_proof_failures": [], "pending_areas": [],
    "component_audits": records,
    "generic_audit_binding": {"file": str(generic_path.relative_to(root)), "sha256": sha(generic_path.read_bytes())},
    "audit_scope": "Rendered UI and literal classification, five existing journeys, eight-process witness/Next journey, Settings/storage fault equivalence, checkpoint/retained-history controls, New Account latency and cloud export startup receipt.",
    "rendered_ui": {"groups": render["rendered_groups"]},
    "literal_audit": render["literal_audit"],
    "existing_playable_journeys": render["playable_journeys"],
    "reading_journey": journey,
    "next_component": next_component,
    "reading_capture_counts": {"original_files": 9, "sealed_copies": 9,
        "distinct_original_png_hashes": len({x["sha256"] for x in journey["captures"]}),
        "next_files": len(next_component["captures"])},
    "settings_storage": storage,
    "new_account_latency": performance["new_account_latency"],
    "paired_checkpoint_performance": performance["checkpoint_performance"],
    "retained_history": performance["retained_history"],
    "windows_export": performance["export"],
    "limits": [
        "Full GUT totals, all-job checkout identities and final workflow conclusion are joined by the separate broad acceptance audit.",
        "Reading and Next proof uses fixed noncanonical English Solo fixtures; production authored catalogue registration remains separate.",
        "Nine original capture files include identical restored-image pairs; nine sealed copies add no scenarios.",
        "This original eight-process journey covers catalogue v1; the separately bound physical-selector journey supplies catalogue-v2 physical writer/reader coverage.",
        "The historical cold board-null Load title-clipping interpretation was erroneous; the separate source-bound title/layout audit records the correction without a production fix or a whole-UI visual-polish claim.",
        "The manual pre-line slot is physically retained and admitted, but only the post-line Quick is independently fresh-loaded in the original proof.",
        "Next fresh Load recovers challenge entry and exact History; no generated board playthrough is claimed.",
        "Fault/restart probes simulate FileOps failures; they do not inject physical OS crashes.",
        "Performance observations establish no universal speedup or input-to-paint guarantee.",
        "The large Windows export archive is not locally inspected; export scope comes from source-bound cloud validator and receipt.",
        "Capture hashes and machine predicates do not imply manual inspection of every image or native all-input/accessibility acceptance."
    ]
}
(root / "audit/non-gut-summary.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"audit_complete": True, "component_count": len(records),
                  "reading_processes": 8, "runtime_proof_failures": []}))

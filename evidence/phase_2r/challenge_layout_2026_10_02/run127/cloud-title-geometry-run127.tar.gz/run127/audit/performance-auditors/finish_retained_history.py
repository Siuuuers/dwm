"""Join completed retained-history comparisons and the aggregate cloud gate."""
from audit_history_comparisons import RUN, RUNID, MERGE, ATTEMPT, read, sha, job, execution_job
import json

path = RUN / "audit/performance-export-audit.json"
audit = read(path)
history = audit["retained_history"]
lazy_path = RUN / "audit/lazy-normalization-audit.json"
lazy = read(lazy_path)
assert lazy["audit_complete"] and lazy["runtime_proof_failures"] == []
assert lazy["tested_merge"] == MERGE and lazy["run_id"] == RUNID
assert lazy["input_sha256"] == history["producer"]["consumer_input_manifest"]["files"]["day7-autosave.json"]
history["comparisons"]["lazy-normalization"] = {
    "status": "verified", "audit": str(lazy_path.relative_to(RUN)),
    "audit_sha256": sha(lazy_path.read_bytes()), **lazy}
expected = {"outgoing-normalization", "lazy-normalization", "history-region-search", "warm-outgoing-proof"}
assert set(history["comparisons"]) == expected
assert all(value["status"] == "verified" for value in history["comparisons"].values())
aggregate = execution_job("Windows / seven-day retained history")
log_path = RUN / "logs" / f"{aggregate['id']}.log"
text = log_path.read_text(encoding="utf-8-sig")
assert "DWM_PRODUCER_RESULT: success" in text
assert "DWM_COMPARISONS_RESULT: success" in text
assert any(s["name"] == "Require the Day7 producer and all four comparison jobs" and s["conclusion"] == "success" for s in aggregate["steps"])
assert "log -1 --format=%H" not in text
assert aggregate["run_attempt"] == ATTEMPT and aggregate["status"] == "completed"
history["aggregate"] = {"status": "verified", "job_id": aggregate["id"],
    "run_attempt": ATTEMPT, "name": aggregate["name"], "conclusion": aggregate["conclusion"],
    "checkout": None, "log": str(log_path.relative_to(RUN)),
    "log_sha256": sha(log_path.read_bytes()),
    "scope": "Requires the successful producer and all four isolated comparisons; no checkout or engine execution in the aggregate."}
history["status"] = "verified"
audit.update(status="verified", audit_complete=True, runtime_proof_failures=[], pending_areas=[])
path.write_text(json.dumps(audit, indent=2) + "\n")
print(json.dumps({"audit_complete": True, "producer_processes": 35,
    "comparison_processes": 6 + 16 + 16 + 24, "comparisons": sorted(expected),
    "aggregate_job_id": aggregate["id"]}))

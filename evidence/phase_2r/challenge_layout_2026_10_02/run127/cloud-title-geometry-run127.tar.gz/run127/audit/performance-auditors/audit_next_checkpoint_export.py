#!/usr/bin/env python3
"""Read-only verification of retained cloud checkpoint/export/latency evidence.

Does not execute Godot, PowerShell, downloaded source, or downloaded binaries.
Writes only its JSON audit; retained-history comparison audit is a separate owner.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import statistics
import subprocess


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def no_duplicates(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def decode(text):
    return json.loads(text, object_pairs_hook=no_duplicates)


def read(path):
    return decode(path.read_text(encoding="utf-8-sig"))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def markers(text, prefix):
    # Actions logs may prefix each line with a UTC timestamp.
    result = []
    for raw in text.splitlines():
        line = re.sub(r"^\d{4}-\d\d-\d\dT[^ ]+ ", "", raw)
        if line.startswith(prefix):
            result.append(decode(line[len(prefix):]))
    return result


def one_marker(text, prefix):
    found = markers(text, prefix)
    require(len(found) == 1, f"Exactly one marker required: {prefix}")
    return found[0]


def engine_log(path):
    text = path.read_text(encoding="utf-8-sig")
    require(not re.search(r"SCRIPT ERROR:|ERROR: Failed to load|Unicode parsing error|Unexpected NUL character", text),
            f"Engine error in raw probe log: {path}")
    require("Godot Engine v4.6.3.stable" in text, f"Unexpected engine in raw log: {path}")
    return text


def full_sha(value):
    if not re.fullmatch(r"[0-9a-f]{40}", value):
        raise argparse.ArgumentTypeError("expected a full lowercase 40-hex Git SHA")
    return value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-root", type=Path, required=True,
                        help="retained run directory containing run.json, jobs.json, logs and artifacts")
    parser.add_argument("--repo", type=Path, required=True,
                        help="local Git repository containing the exact tested checkout")
    parser.add_argument("--source", type=full_sha, required=True, help="source head SHA from the run metadata")
    parser.add_argument("--checkout", type=full_sha, required=True, help="exact checkout SHA recorded in job logs")
    parser.add_argument("--master", type=full_sha, required=True, help="master SHA recorded in the audit report")
    args = parser.parse_args()
    root = args.run_root.resolve()
    args.repo = args.repo.resolve()
    if not root.is_dir():
        parser.error("--run-root must identify an existing directory")
    if not args.repo.is_dir():
        parser.error("--repo must identify an existing directory")
    run = read(root / "run.json")
    jobs = read(root / "jobs.json")["jobs"]
    api = read(root / "artifacts-api.json")["artifacts"]
    downloaded = read(root / "artifact-manifest.json")
    run_id, attempt = run["id"], run["run_attempt"]
    require(type(run_id) is int and run_id > 0 and type(attempt) is int and attempt > 0,
            "Positive integer run ID and attempt required")
    provenance = read(root / "audit/source-provenance.json")
    require(provenance["source"] == args.source, "Provenance source mismatch")
    require(provenance["tested_checkout"] == args.checkout, "Provenance checkout mismatch")
    require(provenance["master"] == args.master, "Provenance master mismatch")
    require(run["head_sha"] == args.source, "Run source mismatch")
    evidence = []

    def record(path):
        item = {"file": str(path.relative_to(root)), "sha256": sha(path.read_bytes())}
        if item not in evidence:
            evidence.append(item)
        return item

    def source(path):
        return subprocess.check_output(["git", "show", f"{args.checkout}:{path}"], cwd=args.repo)

    def artifact(name, inspect=True):
        matches = [a for a in api if a["name"] == name]
        require(len(matches) == 1, f"Missing/duplicate API artifact: {name}")
        item = matches[0]
        require(item["workflow_run"]["id"] == run_id and item["workflow_run"]["head_sha"] == args.source,
                f"Artifact source mismatch: {name}")
        summary = {"name": name, "artifact_id": item["id"], "api_digest": item["digest"],
                   "api_size_in_bytes": item["size_in_bytes"]}
        if inspect:
            rows = [a for a in downloaded if a["name"] == name]
            require(len(rows) == 1, f"Missing downloaded artifact: {name}")
            zip_path = Path(rows[0]["local_zip"])
            blob = zip_path.read_bytes()
            require(len(blob) == item["size_in_bytes"] and "sha256:" + sha(blob) == item["digest"],
                    f"Archive API size/digest mismatch: {name}")
            summary.update(archive_sha256=sha(blob), api_digest_verified=True)
        return root / "artifacts" / name, summary, item

    def job(name):
        rows = [j for j in jobs if j["name"] == name]
        require(len(rows) == 1, f"Missing/duplicate job: {name}")
        j = rows[0]
        require(j["head_sha"] == args.source and j["run_id"] == run_id and j["run_attempt"] == attempt,
                f"Job source mismatch: {name}")
        require(j["status"] == "completed" and j["conclusion"] == "success", f"Job not successful: {name}")
        log = root / "logs" / f"{j['id']}.log"
        text = log.read_text(encoding="utf-8-sig")
        require(re.search(r"(?m)^\S+Z " + re.escape(args.checkout) + r"\s*$", text) is not None,
                f"Exact merge checkout absent from job log: {name}")
        log_item = record(log)
        return {"job_id": j["id"], "job_name": name, "conclusion": j["conclusion"],
                "run_attempt": attempt, "checkout_merge": args.checkout, "log": log_item["file"],
                "log_sha256": log_item["sha256"]}, text

    roots = set()

    def invocation(path, suite):
        rows = [decode(line) for line in path.read_text(encoding="utf-8-sig").splitlines() if line.strip()]
        require(len(rows) == 1, f"Expected one invocation: {path}")
        row = rows[0]
        require(row["suite_id"] == suite and row["exit_code"] == 0, f"Invocation failure: {suite}")
        require(row["test_root"] not in roots, f"Reused isolated root: {suite}")
        require("\\.godot\\phase2r_tests\\" in row["test_root"] and row["user_dir"].startswith(row["test_root"] + "\\"),
                f"Unisolated invocation: {suite}")
        require(row["started_at_utc"] < row["ended_at_utc"], f"Invocation timestamps reversed: {suite}")
        roots.add(row["test_root"])
        record(path)
        return row

    output = {"schema_version": 1, "run_id": run_id, "run_number": run["run_number"], "run_attempt": attempt,
              "source_head": args.source, "tested_merge": args.checkout, "master": args.master,
              "status": "assigned_sections_verified", "audit_complete": False,
              "runtime_proof_failures": [], "pending_areas": ["retained_history"]}

    exported, export_log = job("Windows / exported release startup")
    receipt = one_marker(export_log, "WINDOWS_EXPORT_RECEIPT ")
    require(receipt["ok"] is True and receipt["commit"] == args.checkout and receipt["engine"] == "4.6.3.stable",
            "Export receipt engine/source failure")
    for digest in [receipt["templates_sha256"], receipt["executable_sha256"], receipt["pck_sha256"], receipt["archive"]["sha256"]]:
        require(re.fullmatch(r"[0-9a-f]{64}", digest), "Malformed export digest")
    require(receipt["runtime_data_files_verified"] > 0 and receipt["archive"]["bytes"] > 0, "Empty export")
    require("WINDOWS_EXPORT_VALIDATED:" in export_log, "Export validation terminal marker absent")
    _, _, export_api = artifact(f"windows-export-{run_id}-{attempt}", inspect=False)
    validator_path = "tools/testing/Invoke-WindowsExportValidation.ps1"
    validator = source(validator_path)
    for required in [b"'--quit-after', '240'", b"$executable @('--headless'", b"ConvertFrom-Json", b"$validationFailures.Count -ne 0", b"WINDOWS_EXPORT_RECEIPT"]:
        require(required in validator, "Export validator scope changed")
    exported.update(receipt=receipt, api_artifact={k: v for k, v in export_api.items() if k not in ["url", "archive_download_url", "node_id"]},
                    local_export_archive_inspected=False, local_export_archive_downloaded=False,
                    validation_contract_source={"path": validator_path, "sha256": sha(validator), "commit": args.checkout},
                    cloud_receipt_scope=["Unsigned x86_64 release export using standard Godot 4.6.3",
                        f"{receipt['runtime_data_files_verified']} packaged runtime data files matched source hashes and forbidden development directories were excluded",
                        "Isolated exported DWM.exe headless startup with adjacent PCK, 240 iterations, and newly created JSON-parseable isolated Profile"],
                    limitations=["Large export archive and nested validation/startup logs were not downloaded or locally inspected; scope derives from source-bound validator, job success and cloud receipt.",
                        "No graphical, UIA, screen-reader, audible-quality or release-readiness acceptance.",
                        "API artifact digest covers the Actions wrapper; receipt archive digest covers its nested Windows package."])
    output["export"] = exported

    start_files = len(evidence)
    latency, latency_log = job("Windows / new_account")
    latency_dir, latency_artifact, _ = artifact(f"windows-new_account-{run_id}-{attempt}")
    summary_path = latency_dir / "ci/new-account-latency.json"
    summary = read(summary_path)
    record(summary_path)
    latency_raw = latency_dir / "phase2r_logs/cloud-new-account-latency.log"
    raw_text = engine_log(latency_raw)
    record(latency_raw)
    require(summary == one_marker(raw_text, "NEW_ACC_LATENCY_VERIFIED "), "Latency report differs from raw marker")
    require(summary["ok"] is True and [s["case"] for s in summary["samples"]] == ["fresh", "replacement"], "Latency pair missing")
    for sample in summary["samples"]:
        require(sample["button_to_desktop_us"] > 0 and sample["max_frame_gap_us"] >= 0, "Invalid latency value")
    invoke = invocation(latency_dir / "ci/new-account-latency.jsonl", "cloud-new-account-latency")
    require("res://tests/integration/verify_new_acc_latency.gd" in invoke["argv"], "Wrong latency probe")
    latency.update(latency_artifact, summary=summary, invocation=invoke, evidence_files=evidence[start_files:],
                   limitations=["Two actual Windows cloud samples; no causal speedup or universal responsiveness claim.",
                                "Wrapper records isolated root and UTC interval, not process PID; no independent PID claim."])
    output["new_account_latency"] = latency

    start_files = len(evidence)
    perf, perf_log = job("Windows / paired checkpoint performance")
    perf_dir, perf_artifact, _ = artifact(f"checkpoint-performance-{run_id}-{attempt}")
    payload_dir, payload_artifact, _ = artifact(f"checkpoint-payloads-{run_id}")
    perf_root = perf_dir / "ci/performance"
    results_path = perf_root / "results.json"
    results = read(results_path)
    record(results_path)
    require(results["checkout_ref"] == args.checkout, "Checkpoint report checkout mismatch")
    manifest_path = payload_dir / "payload-manifest.json"
    manifest = read(manifest_path)
    record(manifest_path)
    require(manifest == read(perf_root / "payload-manifest.json") == one_marker(perf_log, "CHECKPOINT_PERFORMANCE_PAYLOADS: "), "Producer manifest copies differ")
    record(perf_root / "payload-manifest.json")
    require(manifest["checkout_ref"] == args.checkout and str(manifest["producer_run_id"]) == str(run_id)
            and manifest["producer_run_attempt"] == attempt, "Payload source/run mismatch")
    schema_path = "scripts/infrastructure/save/SaveDocumentSchema.gd"
    candidate = source(schema_path)
    baseline_path = perf_root / "baseline-SaveDocumentSchema.gd"
    baseline = baseline_path.read_bytes()
    record(baseline_path)
    needle = b'if key == "current_snapshot" or (use_proven_journal and key == "recovery_journal"):'
    require(candidate.count(needle) == 1 and baseline == candidate.replace(needle, b'if key == "current_snapshot":'), "Baseline is not the single-condition ablation")
    require(results["schema_sha256"] == {"baseline": sha(baseline), "candidate": sha(candidate)}, "Schema hashes differ")
    payloads = {p["locale"]: p for p in manifest["payloads"]}
    require(set(payloads) == {"zh-CN", "zh-HK"}, "Wrong payload locale set")
    for locale, p in payloads.items():
        payload = payload_dir / p["file"]
        blob = payload.read_bytes()
        require(blob == (perf_root / p["file"]).read_bytes() and sha(blob) == p["sha256"], "Fixed payload bytes differ")
        document = decode(blob.decode("utf-8-sig"))
        require(document["schema_version"] == document["current_snapshot"]["snapshot"]["schema_version"] == 7
                and len(document["recovery_journal"]) == 2, "Physical payload format differs from manifest")
        require(p["producer_variant"] == "baseline" and p["producer_schema_sha256"] == sha(baseline), "Wrong fixed payload producer")
        require(p["schema_version"] == p["snapshot_schema_version"] == 7 and p["journal_bundles"] == 2, "Wrong payload format")
        record(payload)
        record(perf_root / p["file"])
    expected = {(variant, locale) for variant in ["baseline", "candidate"] for locale in ["zh-CN", "zh-HK"]}
    require(len(results["journeys"]) == len(results["fixed_payloads"]) == 4, "Wrong checkpoint probe count")
    require({(j["variant"], j["locale"]) for j in results["journeys"]} == expected, "Wrong journey matrix")
    require({(j["variant"], j["locale"]) for j in results["fixed_payloads"]} == expected, "Wrong fixed matrix")
    journeys, probes, invocations = [], [], []
    for row in results["journeys"]:
        name = row["variant"] + "-" + row["locale"]
        raw_path = perf_dir / "phase2r_logs" / f"cloud-performance-{name}.log"
        text = engine_log(raw_path)
        record(raw_path)
        require(text.count("CLICK_LATENCY_PASS:") == 1, "Journey terminal marker missing")
        reply = one_marker(text, "CLICK_LATENCY_REPLY: ")
        require(reply["locale"] == row["locale"] and reply["contains_non_ascii"] is True, "Localized receipt missing")
        require(one_marker(text, "CLICK_LATENCY_MODE: ")["mode"] == "fresh-account", "Not a fresh journey")
        for key, prefix in [("summary", "CLICK_LATENCY_SUMMARY: "), ("settlement", "CLICK_LATENCY_SETTLED: "),
                            ("checkpoint_profiles", "DWM_CHECKPOINT_PROFILE "), ("consequence_profiles", "DWM_CONSEQUENCE_PROFILE ")]:
            require(row[key] == markers(text, prefix) and row[key], f"Report/raw log mismatch: {name}/{key}")
        require(row["dating_ending"] == ("win" if row["locale"] == "zh-CN" else "loss"), "Wrong journey terminal outcome")
        settlements = row["settlement"]
        require(len(settlements) == 3 and {(s["surface"], s["ending"]) for s in settlements}
                == {("app", "win"), ("app", "loss"), ("dating", row["dating_ending"])}, "Missing terminal settlement coverage")
        for settled in settlements:
            require(settled["end_to_end_us"] >= 0 and settled["settled_after_us"] >= 0, "Invalid settlement timing")
            require(settled.get("settled") is True if settled["surface"] == "app" else settled["phase"] == "post_challenge",
                    "Unsettled performance terminal")
        invoke = invocation(perf_root / f"{name}.jsonl", f"cloud-performance-{name}")
        require("--headless" in invoke["argv"] and "res://tests/manual/benchmark_minesweeper_click_latency.gd" in invoke["argv"]
                and f"--reply-locale={row['locale']}" in invoke["argv"] and f"--dating-ending={row['dating_ending']}" in invoke["argv"],
                "Wrong localized journey invocation")
        invocations.append(invoke)
        journeys.append({"variant": row["variant"], "locale": row["locale"], "dating_ending": row["dating_ending"],
                         "settlement": row["settlement"], "checkpoint_profiles": len(row["checkpoint_profiles"]),
                         "consequence_profiles": len(row["consequence_profiles"]), "summary_keys": [s["key"] for s in row["summary"]],
                         "invocation_exit_code": invoke["exit_code"]})
    for row in results["fixed_payloads"]:
        name = row["variant"] + "-" + row["locale"] + "-fixed"
        raw_path = perf_dir / "phase2r_logs" / f"cloud-performance-{name}.log"
        record(raw_path)
        measurement = row["measurement"]
        require(measurement == one_marker(engine_log(raw_path), "CHECKPOINT_JSON_BENCHMARK: "), "Fixed result/raw marker mismatch")
        payload = payload_dir / payloads[row["locale"]]["file"]
        require(measurement["input_sha256"] == measurement["output_sha256"] == sha(payload.read_bytes()), "Fixed input/output hashes differ")
        require(measurement["bytes"] == payload.stat().st_size and measurement["journal_bundles"] == measurement["validated_journal_bundles"] == 2, "Fixed payload dimensions differ")
        require(set(measurement["samples"]) == {"parse_us", "schema_us", "stringify_us", "value_validation_us", "outgoing_validation_us"}, "Wrong benchmark phase set")
        for phase, samples in measurement["samples"].items():
            require(len(samples) == 5 and all(isinstance(v, int) and v >= 0 for v in samples), "Invalid five-sample phase")
            require(statistics.median(samples) == measurement[phase + "_median"], "Fixed phase median mismatch")
        invoke = invocation(perf_root / f"{name}.jsonl", f"cloud-performance-{name}")
        require("--headless" in invoke["argv"] and "res://tests/manual/benchmark_checkpoint_json.gd" in invoke["argv"], "Wrong fixed benchmark invocation")
        invocations.append(invoke)
        probes.append({"variant": row["variant"], "locale": row["locale"], "bytes": measurement["bytes"],
                       "sha256": measurement["input_sha256"], "journal_bundles": 2, "five_samples_per_phase": True,
                       "median_us": {k: v for k, v in measurement.items() if k.endswith("_median")}})
    require(len(invocations) == 8 and len({i["test_root"] for i in invocations}) == 8, "Checkpoint isolated invocation count mismatch")
    require("CHECKPOINT_PERFORMANCE_VERIFIED: four localized journeys and four matched-payload probes." in perf_log, "Checkpoint terminal receipt missing")
    perf.update(status="verified", artifacts=[perf_artifact, payload_artifact], ablation=results["ablation"],
                baseline_single_condition_reversal_verified=True, schema_sha256=results["schema_sha256"],
                producer_manifest=manifest, journeys=journeys, fixed_payload_probes=probes,
                invocations=invocations, distinct_isolated_invocations=8, process_ids_recorded=False,
                evidence_files=evidence[start_files:], limitations=[results["timing_policy"], results["journey_comparison"],
                    "These probes do not measure the new exact-caption witness path or establish its speedup.",
                    "Invocation receipts establish distinct isolated roots and UTC intervals; these wrappers do not retain process IDs."])
    output["checkpoint_performance"] = perf
    output["assigned_scope"] = {"checkpoint_export_new_account_verified": True, "local_engines_executed": False,
                                "retained_history_owned_by_root": True}
    target = root / "audit/performance-export-audit.json"
    require(not target.exists(), "Refusing to overwrite another audit owner's completed sections")
    target.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({"ok": True, "audit": str(target), "checkpoint_invocations": 8,
                      "latency_samples": len(summary["samples"]), "export_archive_inspected": False}))


if __name__ == "__main__":
    main()

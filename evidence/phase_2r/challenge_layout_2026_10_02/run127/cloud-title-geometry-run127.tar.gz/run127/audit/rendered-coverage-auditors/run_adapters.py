#!/usr/bin/env python3
"""Execute six read-only evidence auditors only after the completed generic audit exists."""
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/scratch/e169b180163f')
RUN = ROOT / 'run127'
HERE = Path(__file__).resolve().parent
SOURCE = '79b36d90e3ea41d36a81a4c5ba0f87b0ae4a7bfa'
CHECKOUT = 'd1c3205392205ab85306f1e2afed15d58b517bd1'


def read(path):
    return json.loads(path.read_text())


def main():
    run = read(RUN / 'run.json')
    generic = read(RUN / 'audit/generic-evidence-audit.json')
    assert run['id'] == 36960182145 and run['status'] == 'completed' and run['conclusion'] == 'success'
    assert generic['generic_audit_pass'] is True
    assert generic['source_boundary']['source'] == SOURCE and generic['source_boundary']['tested_checkout'] == CHECKOUT
    assert generic['run']['id'] == run['id']
    jobs = read(RUN / 'jobs.json')['jobs']
    settings = [row for row in jobs if row['name'] == 'Windows / settings and profile persistence' and row['run_attempt'] == run['run_attempt']]
    if not settings:
        settings = [row for row in jobs if 'settings' in row['name'].lower() and row['run_attempt'] == run['run_attempt']]
    assert len(settings) == 1 and settings[0]['conclusion'] == 'success'
    archives = read(RUN / 'artifact-manifest.json')
    archive = next(row for row in archives if row['name'] == f"windows-settings-{run['id']}-{run['run_attempt']}")
    common = ['--run-root', str(RUN), '--repo', str(ROOT / 'dwm'), '--source', SOURCE, '--checkout', CHECKOUT]
    commands = [
        ('rendered-functional-audit.json', 'audit_rendered_functional.py', common),
        ('next-reading-trace-audit.json', 'audit_rendered_reading_trace.py', common),
        ('next-component-audit.json', 'audit_rendered_next_component.py', [str(RUN)]),
        ('settings-storage-audit.json', 'audit_coverage_settings_storage.py', common + ['--job-id', str(settings[0]['id']), '--artifact-zip', archive['local_zip']]),
        ('physical-selector-public-surfaces-audit.json', 'audit_coverage_public_surfaces.py', common),
        ('physical-selector-test-discovery.json', 'audit_coverage_test_discovery.py', common),
    ]
    def execute(item):
        name, script, arguments = item
        command = [sys.executable, '-B', str(HERE / script), *arguments]
        process = subprocess.run(command, text=True, capture_output=True)
        (HERE / (script + '.stdout.txt')).write_text(process.stdout)
        (HERE / (script + '.stderr.txt')).write_text(process.stderr)
        report_path = RUN / 'audit' / name
        report = read(report_path) if report_path.exists() else {}
        complete = report.get('audit_complete', report.get('next_component_audit_pass', False))
        passed = process.returncode == 0 and complete is True and not report.get('runtime_proof_failures') and not report.get('pending_areas')
        return {'auditor': script, 'report': str(report_path), 'exit_code': process.returncode, 'audit_pass': passed,
                'reported_failures': report.get('runtime_proof_failures', report.get('failure'))}
    with ThreadPoolExecutor(max_workers=6) as executor:
        results = list(executor.map(execute, commands))
    if any(row['audit_pass'] and row['auditor'] == 'audit_coverage_settings_storage.py' for row in results):
        raw = (RUN / 'audit/settings-storage-audit.json').read_bytes()
        (RUN / 'audit/physical-selector-settings-storage-audit.json').write_bytes(raw)
    summary = {'run_id': run['id'], 'source': SOURCE, 'checkout': CHECKOUT,
               'audit_pass': all(row['audit_pass'] for row in results), 'components': results}
    (HERE / 'component-execution-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))
    return 0 if summary['audit_pass'] else 1


if __name__ == '__main__':
    raise SystemExit(main())

#!/usr/bin/env python3
"""Independently audit retained rendered/functionality artifacts. No engines are executed.
Copied bounded validators from Run98 and narrowed to six render groups, literal ownership,
and five playable journeys; reading, GUT, storage, export and timings have separate owners.
Run with mandatory --run-root, --repo, --source and --checkout identities.
"""
from pathlib import Path
import argparse, json, hashlib, re, struct, subprocess, zipfile, xml.etree.ElementTree as E
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--run-root',type=Path,required=True)
parser.add_argument('--repo',type=Path,required=True)
parser.add_argument('--source',required=True,help='Exact 40-character source commit SHA')
parser.add_argument('--checkout',required=True,help='Exact 40-character tested checkout commit SHA')
args=parser.parse_args()
assert all(re.fullmatch(r'[0-9a-f]{40}',v) for v in [args.source,args.checkout]),'EXACT_SOURCE_AND_CHECKOUT_SHAS_REQUIRED'
ROOT=args.run_root.resolve()
REPO=args.repo.resolve()
assert ROOT.is_dir() and REPO.is_dir(),'RUN_ROOT_AND_REPO_REQUIRED'
ART=ROOT/'artifacts'
OUT=ROOT/'audit/rendered-functional-audit.json'
MERGE=args.checkout
SOURCE=args.source
source_lines={}

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
    def pairs(items):
        d={}
        for k,v in items:
            assert k not in d,(str(p),'duplicate JSON key',k)
            d[k]=v
        return d
    return json.loads(p.read_text(encoding='utf-8-sig'),object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))
def relative(p):return str(p.relative_to(ROOT))
def png(p):
    b=p.read_bytes();assert b[:8]==b'\x89PNG\r\n\x1a\n'
    w,h=struct.unpack('>II',b[16:24]);assert w>0 and h>0
    return {'file':relative(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'width':w,'height':h}

def artifact(prefix, required_report='results.json', pinned_attempt=None):
    rows=[m for m in read(ROOT/'artifact-manifest.json') if re.fullmatch(re.escape(prefix+'-'+RUN)+r'-\d+',m['name'])] if (ROOT/'artifact-manifest.json').exists() else []
    rows.sort(key=lambda m:int(m['name'].rsplit('-',1)[1]),reverse=True)
    if pinned_attempt is not None:rows=[m for m in rows if int(m['name'].rsplit('-',1)[1])==pinned_attempt]
    rows=[m for m in rows if (ART/m['name']).is_dir() and (required_report is None or (ART/m['name']/required_report).is_file())]
    if not rows:return None
    m=rows[0];name=m['name'];p=ART/name
    z=Path(m['local_zip']);assert z.stat().st_size==m['size_in_bytes'] and 'sha256:'+sha(z)==m['digest']
    members=0
    with zipfile.ZipFile(z) as f:
        for i in f.infolist():
            q=Path(i.filename);assert not q.is_absolute() and '..' not in q.parts
            if i.is_dir():continue
            target=p/q;assert target.is_file() and target.read_bytes()==f.read(i),str(target)
            members+=1
    api=next(x for x in read(ROOT/'artifacts-api.json')['artifacts'] if x['id']==m['id'])
    assert all(api[k]==m[k] for k in ['id','name','size_in_bytes','digest'])
    assert api['workflow_run']['id']==int(RUN) and api['workflow_run']['head_sha']==SOURCE
    return p,{'name':name,'attempt':int(name.rsplit('-',1)[1]),'id':m['id'],'bytes':m['size_in_bytes'],'verified_zip_sha256':sha(z),'verified_file_members':members}

def clean_log(p):
    s=p.read_text(errors='replace')
    found=re.findall(r'^.*(?:SCRIPT ERROR:|(?:^|\s)ERROR:|Unicode parsing error|Unexpected NUL character|Parse Error:).*$' ,s,re.M)
    assert not found,(str(p),found[:3])
    return s


run=read(ROOT/'run.json')
assert type(run['id']) is int and run['id']>0 and type(run['run_attempt']) is int and run['run_attempt']>0,'VALID_RUN_ATTEMPT_REQUIRED'
RUN=str(run['id'])
provenance=read(ROOT/'audit/source-provenance.json')
assert run['head_sha']==provenance['source']==SOURCE,'SOURCE_SHA_MISMATCH'
assert provenance['tested_checkout']==MERGE,'TESTED_CHECKOUT_SHA_MISMATCH'

report={'schema_version':1,'run_id':int(RUN),'attempt_policy':'Every accepted artifact binds to its own successful execution attempt; older failure diagnostics are retained separately when present.','candidate_source':SOURCE,'tested_merge':MERGE,
        'audit_complete':False,'runtime_proof_failures':[],'pending_areas':[],
        'rendered_groups':[],'literal_audit':None,'playable_journeys':None,
        'limits':['Artifact assertions and raw evidence are audited; no Godot or PowerShell execution occurs locally.',
                  'Rendered UI uses Linux software OpenGL; this is not full native Windows all-input acceptance.',
                  'Pixel hashes/dimensions and produced geometry/contrast assertions are checked; no separate visual review of every capture is claimed.',
                  'Challenge title geometry is audited separately; these existing render assertions establish no title defect, repair or complete visual polish.',
                  'Five playable journeys exercise their explicit fixture scopes, not every narrative route. Day 7 condition-ending explicitly seeds condition values before the actual wine purchase; Practice explicitly seeds prior-ending and, separately, historical-signature fixtures.',
                  'Reading, storage, ordinary GUT, exported startup and performance evidence are excluded and have separate audit owners.']}
try:
    for prefix,count,marker in [('desktop-scaling-render',38,'DESKTOP_SCALING_RENDER_VERIFIED'),('delivery-dialogue-render',25,'DELIVERY_DIALOGUE_RENDER_VERIFIED'),('angela-overlay-render',10,'ANGELA_OVERLAY_RENDER_VERIFIED'),('japanese-korean-ui-render',30,'JAPANESE_KOREAN_UI_RENDER_VERIFIED'),('font-choices-render',30,'FONT_CHOICES_RENDER_VERIFIED'),('playable-startup-render',4,'PLAYABLE_STARTUP_RENDER_VERIFIED')]:
        got=artifact(prefix)
        if got is None:report['pending_areas'].append(prefix);continue
        p,receipt=got;x=read(p/'results.json');assert x['ok'] is True and not x.get('failures',[]) and x['captures']==count
        if prefix!='playable-startup-render':assert x['samples']==count and x['renderer']!='headless'
        pics=sorted(p.glob('*.png'));assert len(pics)==count
        log=clean_log(p/'render.log')
        if prefix=='playable-startup-render':
            for m in ['PLAYABLE_STARTUP_PASS','PLAYABLE_DAY_PASS','PLAYABLE_LOGOUT_PASS']:assert m in log
            assert sorted(x['files'])==sorted(q.name for q in pics)
        else:
            raw=[json.loads(line[len(marker):].strip()) for line in log.splitlines() if line.startswith(marker+" ")]
            assert raw==[x],(prefix,"raw rendered receipt differs from results")
        item={'group':prefix,'ok':True,'samples':x.get('samples',count),'captures':count,'renderer':x.get('renderer','rendered startup per process log'),'artifact':receipt,'report':relative(p/'results.json'),'report_sha256':sha(p/'results.json'),'captures_verified':[png(q) for q in pics]}
        if 'states' in x:
            assert len(x['states'])==count and {v['file'] for v in x['states']}=={q.name for q in pics}
            assert all(v['visible_text_nodes']>0 for v in x['states'])
        if prefix=='delivery-dialogue-render':
            assert len(x['evidence'])==count and {v['file'] for v in x['evidence']}=={q.name for q in pics}
        if prefix=='desktop-scaling-render':
            assert len(x['launcher_pixels'])==6 and all(v['distinct_icons']==7 and v['unread'] is True for v in x['launcher_pixels'])
            assert len(x['shop_pixels'])==7 and all(v['card_pixels']>0 and v['inspector_pixels']>0 for v in x['shop_pixels'])
        if prefix=='angela-overlay-render':
            assert len(x['crop_checks'])==2 and all(v['identical'] and v['maximum_channel_difference']==0 for v in x['crop_checks']);item['crop_checks']=x['crop_checks']
        report['rendered_groups'].append(item)
    # Literal source hash verification uses the candidate bytes (root separately proves merge equivalence).
    got=artifact('ui-literal-audit','audit.log')
    if got is not None:
        p,receipt=got;items=[]
        clean_log(p/'audit.log')
        for name in ['ui_literal_disposition','script_ui_disposition']:
            q=p/(name+'.json');x=read(q);assert not x['failures'] and x['records'] and len(x['source_paths'])==x['source_count']
            for rec in x['records']:
                source_path=rec['source_path']
                if source_path not in source_lines:
                    source_lines[source_path]=subprocess.check_output(['git','show',f'{SOURCE}:{source_path}'],cwd=REPO).decode('utf-8').splitlines()
                line=source_lines[source_path][rec['line']-1]
                assert hashlib.sha256(line.encode()).hexdigest()==rec['line_sha256'],rec
            items.append({'report':relative(q),'sha256':sha(q),'source_count':x['source_count'],'classified_records':len(x['records']),'failures':[],'source_line_hashes_match_candidate':True})
        history=[z for z in read(p/'script_ui_disposition.json')['records'] if z['source_path']=='scripts/ui/witnessed/WitnessedHistory.gd' and z['key'] in ['witnessed.transport.history','button.close']]
        assert len(history)==2 and all(z['disposition']=='localized_call' for z in history)
        report['literal_audit']={'ok':True,'artifact':receipt,'reports':items,'history_labels_localized':history}
    
    got=artifact('playable-journeys')
    if got is not None:
        p,receipt=got;x=read(p/'results.json');assert x['ok'] is True and len(x['cases'])==5
        expected={
            'seven-days-ending-gallery':(4,['PLAYABLE_STARTUP_PASS','PLAYABLE_DAY_PASS','PLAYABLE_SEVEN_DAY_PASS','PLAYABLE_ENDING_PASS','PLAYABLE_GALLERY_PASS']),
            'seven-days-condition-ending':(3,['PLAYABLE_STARTUP_PASS','PLAYABLE_DAY_PASS','PLAYABLE_SEVEN_DAY_PASS','PLAYABLE_DAY7_CONDITION_PASS']),
            'dating-reload':(7,['PLAYABLE_STARTUP_PASS','PLAYABLE_DATING_RELOAD_PASS','PLAYABLE_DATING_QUICK_PASS','PLAYABLE_DATING_PASS']),
            'practice-empty-dtl':(5,['PRACTICE_FIXTURE','PLAYABLE_EMPTY_DTL_PRACTICE_PASS']),
            'practice-legacy-compatibility':(8,['PRACTICE_FIXTURE','PRACTICE_LEGACY_FIXTURE','PLAYABLE_REHEARSAL_LEGACY_PASS'])}
        assert {c['case_id'] for c in x['cases']}==set(expected);cases=[];roots=[]
        for c in x['cases']:
            count,markers=expected[c['case_id']];d=next(p.glob('*/'+c['case_id']));roots.append(c['isolation_root']);assert c['ok'] is True and not c['failures'] and c['user_dir_strictly_contained'] is True
            assert c['user_dir'].startswith(c['isolation_root']+'/') and all(v.startswith(c['isolation_root']+'/') for k,v in c['environment'].items() if k in ['XDG_DATA_HOME','XDG_CONFIG_HOME','XDG_CACHE_HOME','DWM_TEST_ROOT'])
            for phase,record in [('user-dir-proof',c['user_dir_proof']),('journey',c['journey'])]:
                assert record['exit_code']==0 and record['timed_out'] is False
                assert read(d/(phase+'.process.json'))==record
                clean_log(d/(phase+'.stdout.txt'));clean_log(d/(phase+'.stderr.txt'))
            proof_log=clean_log(d/'user-dir-proof.log')
            actual_dirs=[line.split('=',1)[1].rstrip('/') for line in proof_log.splitlines() if line.startswith('PHASE2R_USER_DIR=')]
            assert actual_dirs==[c['user_dir'].rstrip('/')],(c['case_id'],'native user_dir proof mismatch')
            log=clean_log(d/'journey.log')
            assert set(c['markers'])==set(markers) and all(v==1 for v in c['markers'].values())
            for marker in markers:assert sum(line.startswith(marker) for line in log.splitlines())==1
            if c['case_id']=='practice-empty-dtl':assert 'PRACTICE_LEGACY_FIXTURE' not in log and 'PLAYABLE_REHEARSAL_LEGACY_PASS' not in log
            if c['case_id']=='practice-legacy-compatibility':assert 'PLAYABLE_EMPTY_DTL_PRACTICE_PASS' not in log
            assert len(c['captures'])==count and len(list((d/'captures').glob('*.png')))==count
            caps=[]
            for cap in c['captures']:
                v=png(d/'captures'/Path(cap['file']).name)
                assert all(v[k]==cap[k] for k in ['bytes','sha256','width','height']) and (v['width'],v['height'])==(1280,720)
                caps.append(v)
            cases.append({'case_id':c['case_id'],'ok':True,'fixture_scope':c['fixture_scope'],'process_exit':0,'timeout':False,'markers':c['markers'],'isolation_root':c['isolation_root'],'captures_verified':caps,
            'native_user_dir_verified':actual_dirs[0],
            'observed_pass_receipts':{marker:next(line for line in log.splitlines() if line.startswith(marker)) for marker in markers},
            'explicit_fixture_markers':[line for line in log.splitlines() if '_FIXTURE:' in line],
            'raw_evidence_sha256':{relative(q):sha(q) for q in sorted(d.iterdir()) if q.is_file() and q.suffix in ['.json','.txt','.log']}})
        assert len(set(roots))==5
        report['playable_journeys']={'ok':True,'artifact':receipt,'report':relative(p/'results.json'),'report_sha256':sha(p/'results.json'),'cases':cases,'capture_count':27,'five_fresh_isolation_roots':True}
    

except Exception as exc:
    import traceback
    report['runtime_proof_failures'].append({'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()})

report['job_log_bindings']=[]
report['infrastructure_attempts']=[]
for prior in [ROOT/'audit/rendered-first-attempt-job.json',ROOT/'audit/rendered-second-attempt-job.json']:
    if not prior.exists():continue
    failed=read(prior);p=ROOT/'logs'/(str(failed['id'])+'.log')
    try:
        text=p.read_text(errors='replace')
        failed_steps={v['name']:v['conclusion'] for v in failed['steps']}
        assert failed['conclusion']=='failure' and failed['run_attempt'] in [1,2]
        assert failed_steps['Install Godot and software display']=='failure' and failed_steps['Import project']=='skipped'
        assert all(failed_steps[n]=='skipped' for n in ['Render and verify desktop scaling','Render and verify delivery and dialogue','Render and verify Angela stat overlay','Render and verify Japanese and Korean UI','Render and verify font choices','Verify rendered startup and Logout consent'])
        assert "The action 'Install Godot and software display' has timed out after 5 minutes." in text
        assert 'line 4: : command not found' in text and 'Process completed with exit code 127.' in text
        diagnostic=artifact('ui-literal-audit',None,failed['run_attempt'])
        assert diagnostic is not None and not (diagnostic[0]/'audit.log').exists()
        report['infrastructure_attempts'].append({'job_id':failed['id'],'attempt':failed['run_attempt'],'conclusion':'failure',
            'log':relative(p),'log_sha256':sha(p),'api_job_record':relative(prior),'api_job_record_sha256':sha(prior),
            'install_timeout_minutes':5,'import_and_all_render_steps_skipped':True,
            'literal_audit_exit':127,'literal_audit_reason':'Always-run audit reached empty engine path after installer timeout. Its two JSON files are committed inventories copied by the always-run shell step, with no audit.log or fresh audit execution.',
            'diagnostic_artifact':diagnostic[1],
            'scope':'No project import/render execution occurred in this attempt. Diagnostic literal artifact is excluded from acceptance.'})
    except Exception as exc:
        report['runtime_proof_failures'].append({'section':'renderer-failure-provenance:'+str(failed['run_attempt']),'type':type(exc).__name__,'message':str(exc)})
expected_jobs={
    'Rendered seven-day, ending, Gallery and Dating journeys':[f'PLAYABLE_JOURNEY_PASS: {case}' for case in ['seven-days-ending-gallery','seven-days-condition-ending','dating-reload','practice-empty-dtl','practice-legacy-compatibility']],
    'Rendered desktop and dialogue / Linux software OpenGL':['DESKTOP_SCALING_RENDER_VERIFIED','DELIVERY_DIALOGUE_RENDER_VERIFIED','ANGELA_OVERLAY_RENDER_VERIFIED','JAPANESE_KOREAN_UI_RENDER_VERIFIED','FONT_CHOICES_RENDER_VERIFIED','PLAYABLE_STARTUP_RENDER_VERIFIED','UI_LITERAL_AUDIT_VERIFIED']}
job_records={}
metadata_snapshot=ROOT/'audit/rendered-audit-job-snapshot.json'
metadata_snapshot.write_bytes((ROOT/'jobs.json').read_bytes())
for metadata in [ROOT/'audit/attempt1-final-jobs.json',metadata_snapshot]:
    if metadata.exists():
        for job in read(metadata)['jobs']:
            job_records.setdefault(job['id'],{'job':job,'metadata':metadata})
for name,markers in expected_jobs.items():
    try:
        expected_attempt=(report['playable_journeys']['artifact']['attempt'] if report['playable_journeys'] else None) if 'journeys' in name else (report['literal_audit']['artifact']['attempt'] if report['literal_audit'] else None)
        matches=[v['job'] for v in job_records.values() if v['job']['name']==name and v['job']['run_attempt']==expected_attempt and v['job']['conclusion']=='success']
        matches=[j for j in matches if (ROOT/'logs'/(str(j['id'])+'.log')).is_file()]
        if not matches:
            report['pending_areas'].append('successful_job_and_log:'+name);continue
        assert len(matches)==1
        job=matches[0];p=ROOT/'logs'/(str(job['id'])+'.log')
        assert job['run_id']==int(RUN) and job['head_sha']==SOURCE
        metadata=job_records[job['id']]['metadata']
        text=p.read_text(errors='replace')
        actual=re.findall(r'git(?:\.exe"?)? log -1 --format=%H\r?\n[^\n]*?\b([0-9a-f]{40})\b',text)
        assert actual==[MERGE],(name,actual)
        rendered_markers={'DESKTOP_SCALING_RENDER_VERIFIED':'desktop-scaling-render',
            'DELIVERY_DIALOGUE_RENDER_VERIFIED':'delivery-dialogue-render','ANGELA_OVERLAY_RENDER_VERIFIED':'angela-overlay-render',
            'JAPANESE_KOREAN_UI_RENDER_VERIFIED':'japanese-korean-ui-render','FONT_CHOICES_RENDER_VERIFIED':'font-choices-render'}
        for marker in markers:
            observed=re.findall(r'^\d{4}-\d{2}-\d{2}T\S+Z '+re.escape(marker)+r'(?=$|:| )(.*)$',text,re.M)
            if marker in rendered_markers:
                # Workflow prints the native receipt and the validated log receipt.
                assert len(observed)==2,(name,marker,len(observed))
                matching=next(v for v in report['rendered_groups'] if v['group']==rendered_markers[marker])
                assert matching['artifact']['attempt']==expected_attempt
                expected=read(ROOT/matching['report'])
                assert all(json.loads(v.strip())==expected for v in observed),(name,marker,'receipt mismatch')
            else:assert len(observed)==1,(name,marker,len(observed))
        report['job_log_bindings'].append({'job_id':job['id'],'attempt':job['run_attempt'],'name':name,'checkout_sha':actual[0],
            'log':relative(p),'sha256':sha(p),'observed_success_markers':markers,
            'execution_api_metadata':relative(metadata),'execution_api_metadata_sha256':sha(metadata),
            'current_api_metadata':relative(metadata_snapshot),'current_api_metadata_sha256':sha(metadata_snapshot),
            'current_api_metadata_origin':'Exact jobs.json bytes copied at audit time; other run jobs may still be in progress.',
            'current_api_alias_candidates':[{'id':v['id'],'run_attempt':v['run_attempt']} for v in read(metadata_snapshot)['jobs']
                if v['name']==name and v['id']!=job['id'] and all(v.get(k)==job.get(k) for k in ['status','conclusion','started_at','completed_at','head_sha','runner_id'])]})
    except Exception as exc:
        report['runtime_proof_failures'].append({'section':'job_log:'+name,'type':type(exc).__name__,'message':str(exc)})
for key in ['literal_audit','playable_journeys']:
    if report[key] is None:report['pending_areas'].append(key)
report['audit_complete']=not report['pending_areas'] and not report['runtime_proof_failures']
report['verified_capture_count']=sum(g['captures'] for g in report['rendered_groups'])+(report['playable_journeys']['capture_count'] if report['playable_journeys'] else 0)
report['full_render_acceptance']=report['audit_complete']
report['infrastructure_failure_count']=len(report['infrastructure_attempts'])
report['auditor_sha256']=sha(Path(__file__))
OUT.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'complete':report['audit_complete'],'rendered_groups':len(report['rendered_groups']),
    'captures':report['verified_capture_count'],'pending':report['pending_areas'],'failures':report['runtime_proof_failures']},indent=2))

#!/usr/bin/env python3
"""Independently join Next process receipts to exact durable checkpoint bytes."""
import hashlib
import json
from pathlib import Path
import struct
import sys

NEXT_CAPTURE_NAMES = {"01-next-unseen.png", "02-next-board.png", "03-next-restored-board.png"}


def read(path):
    def pairs(items):
        value = {}
        for key, item in items:
            assert key not in value, (path, key)
            value[key] = item
        return value
    return json.loads(path.read_text(encoding="utf-8-sig"), object_pairs_hook=pairs)


def identity(path):
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


root = Path(sys.argv[1]).resolve()
run = read(root / "run.json")
assert type(run["id"]) is int and run["id"] > 0
assert type(run["run_attempt"]) is int and run["run_attempt"] > 0
paths = list((root / "artifacts").glob("reading-rail-*/result.json"))
assert len(paths) == 1
result = read(paths[0])
assert result["ok"] is True and result["failures"] == []
execution_attempt = int(result["workflow"]["GITHUB_RUN_ATTEMPT"])
assert result["workflow"]["GITHUB_RUN_ID"] == str(run["id"])
provenance = read(root / "audit/source-provenance.json")
assert result["checkout_sha"] == provenance["tested_checkout"]
if run["event"] == "pull_request":
    assert run["head_sha"] == provenance["source"]
    assert result["workflow"]["GITHUB_SHA"] == provenance["tested_checkout"]
else:
    assert result["workflow"]["GITHUB_SHA"] == run["head_sha"]
assert 0 < execution_attempt <= run["run_attempt"]
assert paths[0].parent.name == f"reading-rail-{run['id']}-{execution_attempt}"
folder = paths[0].parent / Path(result["artifact_root"]).name
assert read(folder / "result.json") == result
reports = result["reports"]
unseen, written, restored = (reports[name] for name in ("next-unseen", "next", "next-read"))
assert len({row["process_id"] for row in reports.values()}) == 8
for name, row in reports.items():
    assert read(folder / (name + ".json")) == row
    assert result["processes"][name]["exit_code"] == 0
    assert result["processes"][name]["timed_out"] is False

source = written["source_checkpoint"]["reading_session"]
destination = written["checkpoint"]["reading_session"]
operation = destination["next_operation"]
plan = operation["plan"]
assert [row["phase"] for row in written["checkpoint_results"]] == ["source", "destination"]
for row in written["checkpoint_results"]:
    assert row["result"]["ok"] is True
    assert row["result"]["receipt"]["phase"] == row["phase"]
    assert row["result"]["receipt"]["operation_id"] == operation["operation_id"]
assert destination["schema_version"] == 2 and operation["schema_version"] == 1
assert operation["phase"] == "destination"
assert plan["source_ledger"] == source["ledger"]
assert plan["source_frontier"] == source["frontier"]
assert source["frontier"]["line_id"] == "fixture.solo.pre.a"
assert plan["destination"] == {"kind": "completion", "caption": None}
assert [row["beat"]["line_id"] for row in plan["traversed_captions"]] == ["fixture.solo.pre.b"]
assert hashlib.sha256(json.dumps(plan, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest() == operation["operation_id"]
assert destination["ledger"]["captions"] == source["ledger"]["captions"] + plan["traversed_captions"]
assert len({row["publication_id"] for row in destination["ledger"]["captions"]}) == 2
assert {key: value for key, value in destination["ledger"].items() if key != "captions"} == {
    key: value for key, value in source["ledger"].items() if key != "captions"}
assert destination["boundary"] == "between_entries" and destination["frontier"] == {}
assert all(row["beat"] in written["witnesses_before"].values() for row in destination["ledger"]["captions"])
assert written["acknowledgement_receipt"]["was_visited_before_presentation"] is True
assert written["physical_record"]["phase"] == "challenge"
for key in ("checkpoint", "history", "physical_record", "autosave_sha256", "autosave_bytes"):
    assert restored[key] == written[key], key
assert restored["speech_admissions"] == 0 and restored["next_active"] is False
assert restored["profile_unchanged"] is True
autosave = folder / "next-autosave.json"
assert identity(autosave) == {"bytes": written["autosave_bytes"], "sha256": written["autosave_sha256"]}
snapshot = read(autosave)["current_snapshot"]["snapshot"]
assert snapshot["narrative_checkpoint"] == written["checkpoint"]
assert snapshot["gameplay"]["route_context"]["active_dating_challenge"] == written["physical_record"]

assert unseen["acknowledgement_receipt"]["was_visited_before_presentation"] is False
assert unseen["beat"]["presentation_signature"]["content_revision"] == "fixture-next-unseen-v1"
assert unseen["auto_off_refusals"] == 1 and unseen["auto_off_matching_writes"] == 2
assert unseen["auto_enabled_after"] is False and unseen["current_line_complete"] is True
for key in ("ledger", "frontier"):
    assert unseen["checkpoint"]["reading_session"][key] == unseen["source_checkpoint"]["reading_session"][key]
for row in (unseen, written):
    assert row["replacement_confirmations"] == 1
    assert row["witnesses_before"] == row["witnesses_after"]
    observations = [row["observations"]]
    if row is unseen:
        observations.append(row["refusal_observations"])
    for observation in observations:
        assert all(observation[key] == 0 for key in (
            "text_started", "about_to_show_text", "caption_publications", "intermediate_checkpoint_admissions"))
        assert observation["speech_before"] == observation["speech_after"]
assert written["observations"]["exclusive_activations"] == 1
assert unseen["refusal_observations"]["exclusive_activations"] == 0

captures = []
assert len(result["next_captures"]) == len(NEXT_CAPTURE_NAMES)
assert {Path(row["file"]).name for row in result["next_captures"]} == NEXT_CAPTURE_NAMES
assert {path.name for path in (folder / "next" / "captures").glob("*.png")} == NEXT_CAPTURE_NAMES
for row in result["next_captures"]:
    assert Path(row["source"]).name == Path(row["file"]).name
    path = folder / "next" / "captures" / Path(row["file"]).name
    raw = path.read_bytes()
    assert raw[:8] == b"\x89PNG\r\n\x1a\n" and raw[12:16] == b"IHDR"
    assert identity(path) == {key: row[key] for key in ("bytes", "sha256")}
    assert struct.unpack(">II", raw[16:24]) == (row["width"], row["height"])
    captures.append({"path": path.relative_to(root).as_posix(), **identity(path)})
assert len({row["path"] for row in captures}) == len(NEXT_CAPTURE_NAMES)
report = {"schema_version": 1, "next_component_audit_pass": True,
    "run_id": run["id"], "run_attempt": run["run_attempt"], "source": provenance["source"], "execution_attempt": execution_attempt, "workflow_head": run["head_sha"],
    "run_metadata_identity": identity(root / "run.json"),
    "checkout": result["checkout_sha"], "report": identity(paths[0]),
    "process_ids": {name: reports[name]["process_id"] for name in ("next-unseen", "next", "next-read")},
    "operation_id": operation["operation_id"], "autosave": identity(autosave),
    "source_and_destination_exact": True, "silent_traversal": True,
    "auto_off_refusal_then_exact_retry": True, "fresh_challenge_and_history_restore": True,
    "captures": captures, "limits": [
        "Fixed v1 noncanonical Solo catalogue; production dialogue remains outside this proof.",
        "This original physical v1 journey does not establish v2 physical Save/Load; the separate v2 artifact is audited independently.",
        "Historical title clipping was an incorrect image interpretation; bounded geometry is audited separately, and PNG integrity alone does not establish visual polish.",
        "Challenge entry is recovered; this does not claim a generated board was played or restored.",
        "FileOps fault tests do not establish physical OS-crash recovery.",
        "Rendered Linux evidence does not establish exhaustive native Windows input or accessibility acceptance."]}
target = root / "audit/next-component-audit.json"
target.parent.mkdir(parents=True, exist_ok=True)
target.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
print(json.dumps(report))

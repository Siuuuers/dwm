#!/usr/bin/env python3
"""Read-only audit of cloud Settings/Profile, real-root refusal and FileOps proof.

Runs neither Godot nor PowerShell. The report is published only after every
required assertion succeeds; original cloud artifacts are never modified.
"""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath, PureWindowsPath
import re
import stat
import subprocess
import xml.etree.ElementTree as ET
import zipfile


def require(value, label):
    if not value:
        raise ValueError(label)


def strict_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, 'DUPLICATE_JSON_KEY: ' + key)
            result[key] = value
        return result
    def nonfinite(value):
        raise ValueError('NONFINITE_JSON: ' + value)
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=nonfinite)


def read(path):
    return strict_json(path.read_text(encoding='utf-8-sig'))


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': digest(raw)}


def clean(line):
    line = re.sub(r'\x1b\[[0-9;]*m', '', line)
    return re.sub(r'^\ufeff?\d{4}-\d\d-\d\dT\S+\s', '', line).strip()


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--run-root', type=Path, required=True)
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--source', required=True, help='Exact 40-character source commit SHA')
parser.add_argument('--checkout', required=True, help='Exact 40-character tested checkout commit SHA')
parser.add_argument('--job-id', type=int, required=True)
parser.add_argument('--artifact-zip', type=Path, required=True)
args = parser.parse_args()
root = args.run_root.resolve()
run, jobs, api = (read(root / name) for name in ('run.json', 'jobs.json', 'artifacts-api.json'))
source = read(root / 'audit/source-provenance.json')
require(re.fullmatch(r'[0-9a-f]{40}', args.source) and re.fullmatch(r'[0-9a-f]{40}', args.checkout),
        'EXACT_SOURCE_AND_CHECKOUT_SHAS_REQUIRED')
require(type(run['id']) is int and run['id'] > 0
        and type(run['run_attempt']) is int and run['run_attempt'] > 0, 'VALID_RUN_ATTEMPT_REQUIRED')
require(run['head_sha'] == source['source'] == args.source, 'SOURCE_SHA_MISMATCH')
require(source['tested_checkout'] == args.checkout, 'TESTED_CHECKOUT_SHA_MISMATCH')
job_rows = [j for j in jobs['jobs'] if j['id'] == args.job_id]
require(len(job_rows) == 1, 'EXACT_SETTINGS_JOB_REQUIRED')
job = job_rows[0]
require(job['run_id'] == run['id'] and job['run_attempt'] == run['run_attempt']
        and job['status'] == 'completed' and job['conclusion'] == 'success'
        and 'settings' in job['name'].lower(), 'PASSING_CURRENT_SETTINGS_JOB_REQUIRED')
log = root / 'logs' / f'{args.job_id}.log'
lines = [clean(line) for line in log.read_text(encoding='utf-8-sig').splitlines()]
checkouts = [lines[i + 1] for i, line in enumerate(lines[:-1]) if 'log -1 --format=%H' in line
             and re.fullmatch(r'[0-9a-f]{40}', lines[i + 1])]
require(checkouts and all(value == source['tested_checkout'] for value in checkouts), 'SETTINGS_CHECKOUT_MISMATCH')
artifact_rows = [a for a in api['artifacts'] if a['name'] == f"windows-settings-{run['id']}-{run['run_attempt']}"]
require(len(artifact_rows) == 1, 'ONE_CURRENT_SETTINGS_ARTIFACT_REQUIRED')
artifact = artifact_rows[0]
require(artifact['workflow_run']['id'] == run['id'] and artifact['workflow_run']['head_sha'] == run['head_sha'],
        'ARTIFACT_RUN_SOURCE_MISMATCH')
zip_id = identity(args.artifact_zip)
require(artifact['digest'] == 'sha256:' + zip_id['sha256'] and artifact['size_in_bytes'] == zip_id['bytes'],
        'ORIGINAL_ARTIFACT_ZIP_HASH_SIZE_MISMATCH')
folder = root / 'artifacts' / artifact['name']
with zipfile.ZipFile(args.artifact_zip) as archive:
    members = [m for m in archive.infolist() if not m.is_dir()]
    require(len({m.filename for m in members}) == len(members), 'DUPLICATE_ZIP_MEMBERS')
    for member in members:
        path = PurePosixPath(member.filename)
        require(not path.is_absolute() and '..' not in path.parts and '\\' not in member.filename
                and not stat.S_ISLNK(member.external_attr >> 16), 'UNSAFE_ZIP_MEMBER')
    require(not any(p.is_symlink() for p in folder.rglob('*')), 'EXTRACTED_SYMLINK')
    local = {p.relative_to(folder).as_posix(): p for p in folder.rglob('*') if p.is_file()}
    require(set(local) == {m.filename for m in members}, 'EXTRACTED_MEMBER_SET_MISMATCH')
    for member in members:
        raw = archive.read(member)
        require(identity(local[member.filename]) == {'bytes': member.file_size, 'sha256': digest(raw)},
                'EXTRACTED_MEMBER_BYTES_MISMATCH: ' + member.filename)

results = [strict_json(line[len('CLOUD_GUT_RESULT '):]) for line in lines if line.startswith('CLOUD_GUT_RESULT ')]
require(len(results) == 1 and results[0]['suite'] == 'settings', 'ONE_SETTINGS_GUT_RECEIPT_REQUIRED')
gut = results[0]
xml = folder / 'ci/settings.xml'
tree = ET.parse(xml)
require(len(tree.findall('.//testcase')) == gut['test_cases'] == gut['passed'] and gut['skipped'] == 0
        and not tree.findall('.//failure') and not tree.findall('.//error') and not tree.findall('.//skipped'),
        'SETTINGS_GUT_RECEIPT_XML_MISMATCH')
for node in tree.iter():
    for key in ('failures', 'errors', 'skipped', 'disabled'):
        require(int(node.get(key, '0')) == 0, 'NONZERO_DECLARED_GUT_' + key)
xml_scripts = {s.get('name'): len(s.findall('./testcase')) for s in tree.findall('.//testsuite')}
require(len(xml_scripts) == gut['requested_scripts'] == gut['reported_scripts'] == len(gut['scripts']),
        'GUT_SCRIPT_COUNT_MISMATCH')
for row in gut['scripts']:
    require(xml_scripts[row['script']] == row['test_cases'] == row['passed'] and row['skipped'] == 0,
            'PER_SCRIPT_GUT_RECEIPT_XML_MISMATCH')
profile_scripts = {name: count for name, count in xml_scripts.items()
                   if name in ('tests/unit/test_profile_caption_witnesses.gd',
                               'tests/unit/test_profile_manager.gd',
                               'tests/integration/test_restore_preserves_current_profile.gd')}
require(len(profile_scripts) == 3 and profile_scripts['tests/unit/test_profile_caption_witnesses.gd'] == 10
        and profile_scripts['tests/integration/test_restore_preserves_current_profile.gd'] == 4,
        'EXACT_WITNESS_AND_RESTORE_SUITES_REQUIRED')

invocations = []
for relative, suite, script in (
        ('ci/settings.jsonl', 'cloud-settings', 'res://addons/gut/gut_cmdln.gd'),
        ('ci/manual-witness-revision-storage.jsonl', 'cloud-manual-witness-revision-storage',
         'res://tests/backup_storage/test_manual_witness_revision_storage.gd')):
    path = folder / relative
    records = [strict_json(line) for line in path.read_text(encoding='utf-8-sig').splitlines() if line.strip()]
    require(len(records) == 1, 'ONE_ISOLATED_INVOCATION_REQUIRED: ' + suite)
    receipt = records[0]
    require(receipt['suite_id'] == suite and receipt['exit_code'] == 0 and script in receipt['argv'],
            'ISOLATED_INVOCATION_MISMATCH')
    testroot, userdir = PureWindowsPath(receipt['test_root']), PureWindowsPath(receipt['user_dir'])
    require(testroot.is_absolute() and testroot in userdir.parents and '.godot' in testroot.parts
            and 'phase2r_tests' in testroot.parts, 'ISOLATED_USER_DIRECTORY_REQUIRED')
    invocations.append({'path': relative, 'identity': identity(path), **receipt})
require(invocations[0]['test_root'] != invocations[1]['test_root'], 'DISTINCT_PROCESS_ROOTS_REQUIRED')

require('STORAGE_REFUSAL_VERIFIED: empty and whitespace roots refused without repository mutations.' in lines,
        'STORAGE_REFUSAL_MARKER_REQUIRED')
refusals = []
for row in read(folder / 'ci/storage-refusal/results.json'):
    case = row['case']
    require(case in ('empty', 'whitespace') and row['exit_code'] == 1, 'EXPECTED_NEGATIVE_STORAGE_CASE_REQUIRED')
    directory = folder / 'ci/storage-refusal' / case
    before, after = (directory / name for name in ('repository-before.json', 'repository-after.json'))
    require(before.read_bytes() == after.read_bytes(), 'STORAGE_REFUSAL_CHANGED_REPOSITORY_BYTES')
    inventory = read(before)
    require(inventory and all(k.startswith(('file:', 'dir:')) for k in inventory), 'INVENTORY_SHAPE')
    require(all(k.split(':', 1)[1].split('/')[0] not in ('.git', '.godot') for k in inventory), 'INVENTORY_EXCLUSIONS')
    negative = ET.parse(directory / 'tests.xml')
    failures = negative.findall('.//failure')
    cases = negative.findall('.//testcase')
    passes = [c for c in cases if not any(c.find(k) is not None for k in ('failure', 'error', 'skipped'))]
    require(len(failures) == row['expected_root_refusals'] == 80
            and all('test_root_missing' in ''.join(f.itertext()) for f in failures)
            and len(cases) == row['tests'] == 83 and len(passes) == row['storage_free_passes'] == 3
            and not negative.findall('.//error') and not negative.findall('.//skipped'), 'EXPECTED_ROOT_REFUSAL_XML_MISMATCH')
    pass_names = sorted(c.get('name') for c in passes)
    require(pass_names == sorted(['test_clear_transient_consequence_checkpoints_does_not_depend_on_storage_readiness',
                                 'test_prepare_consequence_checkpoint_requires_configuration',
                                 'test_prepare_composes_the_autosave_journal_from_the_journals_own_proofs']),
            'EXACT_STORAGE_FREE_CASES_REQUIRED')
    console_paths = [directory / p for p in ('console.log', 'user-dir-console.log', 'godot.log', 'user-dir.log')]
    console = '\n'.join(p.read_text(encoding='utf-8-sig') for p in console_paths)
    require(not re.search(r'SCRIPT ERROR:|ERROR: Failed to load|Unicode parsing error|Unexpected NUL character', console),
            'NEGATIVE_ROOT_UNEXPECTED_EXECUTION_ERROR')
    markers = [line.removeprefix('PHASE2R_USER_DIR=') for line in (directory / 'user-dir-console.log').read_text(
        encoding='utf-8-sig').splitlines() if line.startswith('PHASE2R_USER_DIR=')]
    require(len(markers) == 1 and PureWindowsPath(markers[0]) == PureWindowsPath(row['user_dir']), 'NEGATIVE_USER_DIR_RECEIPT')
    userpath = PureWindowsPath(row['user_dir'])
    require(userpath.is_absolute() and ('.godot', 'ci', 'storage-refusal', case, 'appdata',
                                       'Godot', 'app_userdata', 'DWM') == userpath.parts[-8:],
            'NEGATIVE_USER_DIR_ISOLATION')
    refusals.append({'case': case, 'expected_refusals': len(failures), 'storage_free_passes': len(passes),
                    'storage_free_case_names': pass_names,
                    'inventory_entries': len(inventory), 'inventory_files': sum(k.startswith('file:') for k in inventory),
                    'inventory_directories': sum(k.startswith('dir:') for k in inventory),
                    'before_after_bytes_identical': True, 'inventory_identity': identity(before),
                    'negative_xml_identity': identity(directory / 'tests.xml'), 'user_dir': row['user_dir'],
                    'console_identities': {p.name: identity(p) for p in console_paths}})
require(len(refusals) == 2 and {r['case'] for r in refusals} == {'empty', 'whitespace'}, 'BOTH_STORAGE_REFUSAL_CASES_REQUIRED')

faultlog = folder / 'phase2r_logs/cloud-manual-witness-revision-storage.log'
faultlines = faultlog.read_text(encoding='utf-8-sig').splitlines()
faults = [strict_json(line) for line in faultlines if line.startswith('{"assertions":')]
expected_faults = {'assertions': 61180, 'write_pairs': 14, 'write_fault_pairs': 154, 'restart_pairs': 2218,
                   'restart_fault_pairs': 1604, 'distinct_snapshots': 94, 'refusal_pairs': 30, 'failures': []}
require(faults == [expected_faults], 'EXACT_PASSING_FILEOPS_RECEIPT_REQUIRED')
require(sum(line == 'MANUAL_WITNESS_REVISION_STORAGE_PASS' for line in faultlines) == 1
        and sum(line == 'MANUAL_WITNESS_REVISION_STORAGE_PASS' for line in lines) == 1, 'ONE_FILEOPS_PASS_MARKER_REQUIRED')
require([strict_json(line) for line in lines if line.startswith('{"assertions":')] == faults,
        'JOB_AND_RAW_FILEOPS_RECEIPT_MISMATCH')

source_paths = ('tools/testing/Invoke-CloudTests.ps1', 'tools/testing/Invoke-StorageRefusalChecks.ps1',
                'tests/support/TemporaryStorage.gd', 'tests/backup_storage/test_manual_witness_revision_storage.gd',
                'tests/backup_storage/CrashFileOps.gd', 'tests/support/FakeFileOps.gd',
                'tests/support/ManualSaveWitnessPort.gd',
                'scripts/infrastructure/storage/JsonFileStorage.gd', 'autoload/SaveManager.gd',
                'tests/unit/test_minesweeper_shop_purchase_participant.gd',
                'tests/unit/test_save_manager_checkpoint_port.gd',
                'tests/unit/test_profile_caption_witnesses.gd', 'tests/integration/test_restore_preserves_current_profile.gd')
source_identities = {}
source_texts = {}
for path in source_paths:
    def blob(revision):
        return subprocess.check_output(['git', '-C', str(args.repo), 'show', revision + ':' + path])
    candidate, tested = blob(source['source']), blob(source['tested_checkout'])
    require(candidate == tested, 'RELEVANT_SOURCE_TESTED_CHECKOUT_DIFFERENCE: ' + path)
    source_identities[path] = {'bytes': len(tested), 'sha256': digest(tested), 'candidate_and_merge_identical': True}
    source_texts[path] = tested.decode('utf-8')
    for case in ('empty', 'whitespace'):
        inventory = read(folder / 'ci/storage-refusal' / case / 'repository-before.json')
        require(inventory.get('file:' + path) == digest(tested),
                'ROOT_REFUSAL_INVENTORY_SOURCE_HASH_MISMATCH: ' + case + ': ' + path)
driver = source_texts['tools/testing/Invoke-StorageRefusalChecks.ps1']
require("$testRoot = if ($case -eq 'empty') { '' } else { '   ' }" in driver
        and "$start.Environment['DWM_TEST_ROOT'] = $TestRoot" in driver
        and "if name.split('/')[0] in ('.git','.godot'): continue" in driver
        and "--cached','--others','--exclude-standard'" in driver, 'REAL_ROOT_DRIVER_SCOPE_CHANGED')
temporary = source_texts['tests/support/TemporaryStorage.gd']
require(temporary.index('wrapper_root.strip_edges().is_empty()') < temporary.index('DirAccess.make_dir_recursive_absolute')
        and 'test_root_missing' in temporary, 'ROOT_GUARD_PRECEDES_DIRECTORY_CREATION')
harness = source_texts['tests/backup_storage/test_manual_witness_revision_storage.gd']
require('for disabled: bool in [false, true]' in harness and 'baseline.snapshots == candidate.snapshots' in harness
        and 'baseline.trace == candidate.trace' in harness and 'baseline.persisted == candidate.persisted' in harness
        and 'result.persisted == seed and result.snapshots.is_empty()' in harness
        and 'original_wins or outgoing_wins' in harness, 'FAULT_HARNESS_SCOPE_CHANGED')

report = {'schema_version': 2, 'run_id': run['id'], 'run_attempt': run['run_attempt'], 'job_id': args.job_id,
          'audit_complete': True, 'runtime_proof_failures': [], 'pending_areas': [],
          'source_sha': source['source'], 'tested_checkout_sha': source['tested_checkout'],
          'artifact': {k: artifact[k] for k in ('id', 'name', 'digest', 'size_in_bytes')},
          'original_zip_identity': zip_id, 'extracted_files_verified_byte_for_byte': len(members),
          'ordinary_gut': gut, 'profile_boundary_scripts': profile_scripts,
          'xml_identity': identity(xml), 'job_log_identity': identity(log), 'isolated_invocations': invocations,
          'storage_refusal': refusals, 'refusal_results_identity': identity(folder / 'ci/storage-refusal/results.json'),
          'simulated_fileops_equivalence': faults[0], 'fault_log_identity': identity(faultlog),
          'source_file_identities': source_identities,
          'limits': ['Expected negative root-refusal failures are excluded from ordinary GUT totals.',
                     'Repository inventories include tracked/nonignored files and directory names outside .git/.godot; byte-identical inventories do not assert no writes anywhere.',
                     'Refusal child APPDATA and LOCALAPPDATA are isolated beneath each case; Godot boot may write there.',
                     'The three storage-free passing cases are not a zero-root-snapshot counter. No such counter or claim is inferred.',
                     'Fault/restart receipts compare ordered operations, durable simulated FileOps snapshots and exact old/new reconciliation with cache enabled and disabled; they do not inject physical OS crashes.',
                     'Audit checks recorded cloud results and source/bytes; it executes neither Godot nor PowerShell locally.']}
out = root / 'audit/settings-storage-audit.json'
out.write_text(json.dumps(report, sort_keys=True, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'path': str(out), 'gut_passed': gut['passed'], 'fileops_assertions': faults[0]['assertions'],
                  'artifact_zip_sha256': zip_id['sha256']}))

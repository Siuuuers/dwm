"""Shared explicit identities for read-only retained cloud evidence auditors."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import zipfile

if not __debug__:
    raise RuntimeError("These assertion-based auditors must not run with Python -O.")

parser = argparse.ArgumentParser(description=__doc__)
for flag, env in [("run-root", "RUN_ROOT"), ("repo", "REPO"),
                  ("source", "SOURCE"), ("checkout", "CHECKOUT")]:
    default = os.environ.get("DWM_AUDIT_" + env)
    parser.add_argument("--" + flag, default=default, required=default is None)
parser.add_argument("--attempt", type=int, default=int(os.environ.get("DWM_AUDIT_ATTEMPT", "1")),
                    help="One admitted successful retained-history attempt; default preserves prior attempt-1 proof.")
ARGS, EXTRA_ARGS = parser.parse_known_args()
RUN = Path(ARGS.run_root).resolve()
ROOT = RUN.parent
REPO = Path(ARGS.repo).resolve()
HEAD, MERGE, ATTEMPT = ARGS.source, ARGS.checkout, ARGS.attempt
assert all(re.fullmatch(r"[0-9a-f]{40}", value) for value in (HEAD, MERGE))
assert ATTEMPT > 0


def _pairs(items):
    result = {}
    for key, value in items:
        assert key not in result, f"Duplicate JSON key: {key}"
        result[key] = value
    return result


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"), object_pairs_hook=_pairs)


def sha(value):
    return hashlib.sha256(value).hexdigest()


RUN_METADATA = read(RUN / "run.json")
RUNID = RUN_METADATA["id"]
assert isinstance(RUNID, int) and RUNID > 0
assert RUN_METADATA["head_sha"] == HEAD
assert RUN_METADATA["run_attempt"] >= ATTEMPT
for revision in (HEAD, MERGE):
    assert subprocess.check_output(["git", "rev-parse", revision + "^{commit}"], cwd=REPO).decode().strip() == revision
(RUN / "audit").mkdir(parents=True, exist_ok=True)
SOURCE_BOUNDARY = read(RUN / "audit/source-provenance.json")
assert SOURCE_BOUNDARY["source"] == HEAD and SOURCE_BOUNDARY["tested_checkout"] == MERGE
assert SOURCE_BOUNDARY["all_unlisted_paths_byte_identical"] is True


def blob(path):
    return subprocess.check_output(["git", "show", MERGE + ":" + path], cwd=REPO)


def markers(path, prefix):
    return [json.loads(line.split(prefix, 1)[1], object_pairs_hook=_pairs)
            for line in Path(path).read_text(encoding="utf-8-sig").splitlines()
            if prefix in line and line.split(prefix, 1)[1].startswith("{")]


def raw(path, prefix):
    return [json.loads(line[len(prefix):], object_pairs_hook=_pairs)
            for line in Path(path).read_text(encoding="utf-8-sig").splitlines()
            if line.startswith(prefix)]


def artifact(name):
    rows = [item for item in read(RUN / "artifact-manifest.json") if item["name"] == name]
    assert len(rows) == 1, name
    item = rows[0]
    assert item["workflow_run"]["id"] == RUNID and item["workflow_run"]["head_sha"] == HEAD
    metadata = [row for row in read(RUN / "artifacts-api.json")["artifacts"] if row["id"] == item["id"]]
    assert len(metadata) == 1
    metadata = metadata[0]
    assert metadata["expired"] is False
    assert all(item[key] == metadata[key] for key in ["id", "name", "size_in_bytes", "digest", "workflow_run"])
    archive_path = Path(item["local_zip"])
    assert archive_path.stat().st_size == metadata["size_in_bytes"]
    assert "sha256:" + sha(archive_path.read_bytes()) == item["digest"]
    extracted = RUN / "artifacts" / name
    members = {}
    with zipfile.ZipFile(archive_path) as archive:
        for info in archive.infolist():
            if info.is_dir():
                continue
            path = PurePosixPath(info.filename)
            assert not path.is_absolute() and ".." not in path.parts and "\\" not in info.filename
            assert not stat.S_ISLNK(info.external_attr >> 16)
            assert str(path) not in members
            raw_bytes = archive.read(info)
            local = extracted.joinpath(*path.parts)
            assert local.is_file() and not local.is_symlink()
            assert local.read_bytes() == raw_bytes, (name, str(path))
            members[str(path)] = {"bytes": len(raw_bytes), "sha256": sha(raw_bytes)}
    assert members
    actual = {path.relative_to(extracted).as_posix() for path in extracted.rglob("*") if path.is_file()}
    assert actual == set(members), (name, "archive/extraction file-set mismatch")
    return {**{key: item[key] for key in ["id", "name", "size_in_bytes", "digest"]},
            "all_extracted_members_byte_verified": True, "member_count": len(members),
            "extracted_member_identities": members}


def execution_job(name):
    candidates = [item for item in read(RUN / "jobs.json")["jobs"]
                  if item["name"] == name and item["conclusion"] == "success"
                  and item.get("run_attempt", 1) == ATTEMPT]
    assert len(candidates) == 1, (name, ATTEMPT, "one admitted successful job required")
    return candidates[0]


def job(identifier, name, marker=None):
    item = next(row for row in read(RUN / "jobs.json")["jobs"] if row["id"] == identifier)
    assert item["name"] == name and item["conclusion"] == "success" and item["run_attempt"] == ATTEMPT
    path = RUN / f"logs/{identifier}.log"
    text = path.read_text(encoding="utf-8-sig")
    checkout = re.findall(r"git(?:\.exe\"?)? log -1 --format=%H\r?\n[^\n]*?\b([0-9a-f]{40})\b", text)
    assert checkout == [MERGE], (name, checkout, MERGE)
    if marker:
        assert marker in text
    return {"job_id": identifier, "name": name, "conclusion": "success", "run_attempt": ATTEMPT,
            "log_sha256": sha(path.read_bytes())}

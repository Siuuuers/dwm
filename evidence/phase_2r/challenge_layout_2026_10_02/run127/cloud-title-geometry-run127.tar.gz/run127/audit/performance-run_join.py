#!/usr/bin/env python3
"""Join completed Run127 independent components using the retained strict helper."""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys

from run_audits import CHECKOUT, HERE, REPO, RUN, RUN_ID, SOURCE, identity, read


def main() -> None:
    if not __debug__:
        raise RuntimeError('Assertion-based auditors must run without Python optimization')
    metadata = read(RUN / 'run.json')
    assert metadata['id'] == RUN_ID and metadata['run_number'] == 127
    assert metadata['head_sha'] == SOURCE and metadata['run_attempt'] == 1
    assert metadata['status'] == 'completed' and metadata['conclusion'] == 'success'
    provenance = read(HERE / 'helper-provenance.json')
    join_record = next(item for item in provenance['helpers']
                       if item['path'] == 'performance-auditors/join_non_gut.py')
    helper = RUN / 'audit' / join_record['path']
    assert identity(helper) == {key: join_record[key] for key in ('bytes', 'sha256')}
    required = ('rendered-functional-audit.json', 'settings-storage-audit.json',
                'next-reading-trace-audit.json', 'performance-export-audit.json',
                'next-component-audit.json', 'generic-evidence-audit.json')
    before = {name: identity(RUN / 'audit' / name) for name in required}
    output = RUN / 'audit/non-gut-summary.json'
    assert not output.exists(), 'Do not overwrite a previous component join silently'
    environment = os.environ.copy()
    environment.update({
        'DWM_AUDIT_RUN_ROOT': str(RUN), 'DWM_AUDIT_REPO': str(REPO),
        'DWM_AUDIT_SOURCE': SOURCE, 'DWM_AUDIT_CHECKOUT': CHECKOUT,
        'DWM_AUDIT_ATTEMPT': '1', 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONOPTIMIZE': '0',
    })
    command = [sys.executable, str(helper)]
    result = subprocess.run(command, cwd=helper.parent, env=environment, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log = HERE / 'execution-logs/09-join_non_gut.log'
    log.parent.mkdir(exist_ok=True)
    log.write_text(result.stdout, encoding='utf-8')
    print(result.stdout, end='', flush=True)
    assert result.returncode == 0, 'Non-GUT join failed; log retained'
    assert before == {name: identity(RUN / 'audit' / name) for name in required}
    summary = read(output)
    assert summary['run_id'] == RUN_ID and summary['run_number'] == 127
    assert summary['run_attempt'] == 1 and summary['candidate_source'] == SOURCE
    assert summary['tested_merge'] == CHECKOUT and summary['audit_complete'] is True
    assert summary['runtime_proof_failures'] == [] and summary['pending_areas'] == []
    execution = {'run_id': RUN_ID, 'source': SOURCE, 'checkout': CHECKOUT,
                 'command': command, 'exit_code': result.returncode, 'log': identity(log),
                 'helper': identity(helper), 'inputs_unchanged': before,
                 'output': identity(output),
                 'scope': 'Independent non-GUT component join only; root owns final broad acceptance.'}
    (HERE / 'join-execution.json').write_text(json.dumps(execution, indent=2) + '\n')
    print(json.dumps({'independent_non_gut_audit_complete': True, 'run_id': RUN_ID,
                      'source': SOURCE, 'checkout': CHECKOUT}), flush=True)


if __name__ == '__main__':
    main()
